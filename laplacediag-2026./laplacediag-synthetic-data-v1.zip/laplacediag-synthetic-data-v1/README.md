# LaplaceDiag synthetic pump data v1

This archive contains all 438 stored synthetic pump recordings used by the paper's
three model arms and its subsequent projection and LSTM controls. No recording
was generated, altered, subsampled, or omitted during export. The NPZ bytes match
the frozen input SHA256 values. This is synthetic data, not a real plant dataset.

## Contents and experimental separation

| Purpose | Recordings |
| --- | ---: |
| Healthy training | 15 |
| Separate healthy validation | 6 |
| Healthy effect reference | 24 |
| Healthy prediction check | 24 |
| Healthy alarm calibration | 129 |
| Tests | 240 |

recordings.json fixes the assignment to seeds 993101, 993102 and 993103.
There are 5 training, 2 validation, 8 reference, 8 prediction-check, 43 calibration
and 80 test recordings per seed. All allowed training windows are used.
The 30 test basis groups each contain healthy operation and seven fault variants.
The 120 pump-fault recordings are the primary actuator-localization population.
The remaining tests contain 30 healthy recordings, 60 sensor faults and 30 leaks.
Paired variants of one basis group are not independent statistical samples.

## Array schema and timing

Use numpy.load(path, allow_pickle=False). Each NPZ contains float64 arrays:

* command: shape [T, 2], dimensionless pump commands in [0, 1]. Column order is pump 0, pump 1.
* y: shape [T+1, 3], primary tank-level sensor values in metres, tanks 0, 1, 2.
* confirmation: shape [T+1, 3], separately stored confirmation sensor stream.
* time: shape [T+1], timestamps in seconds, sampled every five seconds.

command[t] is applied between time[t] and time[t+1]. A forecast at origin t
uses commands through t-1 and measured levels through t. The twelve prediction
targets are y[t+1:t+13]. The twelve commanded inputs are command[t:t+12].
Only command and y are read by the diagnostic comparison. Do not add confirmation
or fault annotations to the model inputs. Fault labels are evaluation references,
not supervised training targets. Training, scaling, reference estimation and
calibration use only their explicitly assigned healthy recordings.

The evaluation_annotations.json file contains condition, zero-based affected
actuator, onset index and basis_group for each test. A null actuator means that
the fault is outside the two pump-fault categories or that the recording is healthy.
Fault onset is sample 120. End-of-record classification at sample 360 has seen
20 minutes after onset. Not every internal time sample is an independent test.

## Reproduction

Unzip this archive beside laplacediag-code-v1. Run the data verification and
replay commands in that archive's README. No external data download is needed
for the pump projection control. The external TEP recordings are not included.

## Attribution and license

See NOTICE, LICENSE.md, LICENSES and RELEASE_STATUS.json. Copyright attribution:
Oliver Niggemann, Helmut Schmidt University, Hamburg, Germany, for original data
and database contributions where rights exist. The data are released under CC-BY-SA-4.0.
The user confirmed authority to release the original data. Use is at your own risk, without
warranties, and legally mandatory liabilities remain unaffected.
