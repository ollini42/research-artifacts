# License scope

The user has confirmed authority to release the original software contributions
and artificial pump data and identified no additional known rightsholders.
Original release tooling and original added software contributions are licensed
under AGPL-3.0-or-later. Original data, database contributions where rights exist,
documentation and the supplied original model-array artifacts are licensed under
CC-BY-SA-4.0. This explicit model-artifact grant is not an assertion that a
training-data license automatically licenses learned weights.

Historical source files retain their existing MIT or GPL-3.0-or-later notices.
The legacy MIT attribution is "Copyright (c) 2026 ETFA Paper authors". Rights in
those portions remain governed by their retained licenses. File manifests and
companion notices identify the terms. The package contains full unmodified
license texts. No externally published dataset or third-party model is included.

NOTICE states attribution and warranty and liability information. Use is at your
own risk. Legally mandatory liabilities remain unaffected. The institution's
name identifies affiliation and does not imply endorsement. No material has
been uploaded or publicly deposited by preparing this export.
