# LaplaceDiag paper artifacts v1

LaplaceDiag diagnoses changes in actuator effects using a healthy learned plant
model. It estimates current effects from completed input/output windows and
compares them with a separately estimated healthy reference. No controller is
learned. The supplied experiment has one physical operating configuration.

This prepared export accompanies Oliver Niggemann's paper, **LaplaceDiag: Fault
Diagnosis through Changes in Learned Actuator Effects**. It contains scientific
source, tests, fixed configurations, three saved pump models in inert JSON form,
expected results and a portable CPU replay. The original-contribution and data rights were confirmed by the user.
See RELEASE_STATUS.json. Nothing has been uploaded.

## Quick reproduction without training

Use Python 3.12. Extract both archives beside each other. From this directory:

```bash
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-replay.txt
python scripts/main.py verify --data ../laplacediag-synthetic-data-v1
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python scripts/main.py replay-pump-control --data ../laplacediag-synthetic-data-v1 --output ../pump-control-reproduction
```

The output directory must not exist. Verification checks every payload checksum
and all 438 original NPZ files. Replay recomputes all 129 calibration recordings
and all 240 tests for the three saved parent models, then repeats the computation
with an independent formula for the joint projection score. The original data,
weights and archive files remain read-only. This command creates no model fits,
new observations or simulations. The output includes all decisions, not only
correct ones, and an integrity report. The expected primary end-of-record counts
are 113/120 for LaplaceDiag, 89/120 for joint LaplaceNet projection and 71/120 for
separate LaplaceNet projection. See expected/pump_control.json for the full panel.
This is the original-model control, not the history-refitted comparison.

The three saved models are ordinary JSON arrays, not Python pickle files. Their
original model hashes are retained. Replay needs only NumPy and uses a previously
verified independent implementation of the neural forward pass.

## Source layout and versions

| Directory | Purpose |
| --- | --- |
| src/high_level_control | Current fixed-healthy-reference implementation, adopted 2 November 2026 |
| experiments/pump_frozen/high_level_control | Historical window-centered pump implementation used for reported pump results |
| experiments/pump_control | Portable derivative of the verified joint-projection control |
| experiments/pump_lstm | Original independent encoder-decoder LSTM, training and own-signature projection |
| experiments/pump_series_archive | Original scientific series driver and timing calculations for inspection |
| experiments/tep_lstm | Independent TEP LSTM, inference, projection and data-reader source |
| experiments/tep_fixed_reference | Reported fixed-reference TEP estimation and comparison source |
| configs | Exported scientific configurations and exact seeds/splits |
| assets | Three original pump models and their healthy reference/calibration |
| expected | Full recorded pump summaries and TEP endpoint table |
| tests | Current and frozen estimator regression tests |
| provenance/generator | Synthetic plant and acquisition definitions, not invoked by replay |

MANIFEST.json maps every distributed payload to its checksum and license notice.
SOURCE_PROVENANCE.json distinguishes unchanged source copies from portable or
redacted copies and records original and exported checksums. Historical scientific
inputs were not edited. The current estimator is **not** substituted into the
historical pump replay. That would be a new scientific comparison.

The archived cluster drivers retain their original execution checks and are
provided for source inspection, not as portable launch scripts. Use scripts/main.py
for the commands above. No private host setup, SSH key, Slurm submission, build
cache, optimizer journal or external raw dataset is packaged.

## Model training

Install requirements-training.txt in a suitable PyTorch environment. These commands
perform new reproduction fits only when explicitly invoked by the recipient:

```bash
python -m pip install -r requirements-training.txt
python scripts/main.py train-pump-parent --seed 993101 --device cpu --output ../parent-993101
python scripts/main.py train-pump-lstm --seed 993101 --device cuda:0 --output ../lstm-993101
python scripts/main.py train-pump-history --seed 993101 --device cuda:0 --output ../history-993101
```

Repeat for seeds 993102 and 993103. All 1277 training and 530 separate validation
windows per seed are retained. The parent fit uses 2560 epochs, hidden width 64,
four Laplace points and no linear readout refinement. The LSTM uses its own
32-unit encoder and decoder. Its two fixed learning rates are selected only by
validation error after complete training. History fits change only the history
network while keeping the specified actuator operator and normalization fixed.
Neither test labels nor test performance select a model or hyperparameter.

These training entry points are thin adapters to the exported original functions.
They were syntax-checked, not retrained during export. They must not be interpreted
as a new empirical validation of training on a different device. The original
GPU history fits used the pinned container in docs/ENVIRONMENT.md. CPU and GPU
arithmetic can differ. Exact weights, rather than retraining on a new backend,
are needed for bitwise replay of a particular trained model.

## Reproduction coverage and remaining files

The pump data and original-model projection control are self-contained. The six
history-refitted ASUS checkpoints and the six independent pump-LSTM candidate
checkpoints are not included. Only the original three pump models were locally
available, and the existing Workstation checkpoint store could not be reached
while preparing this release. Their scientific source, full training recipes,
configuration, expected results and version identities are supplied. Do not claim
that the history-refitted or LSTM table was freshly replayed from this ZIP alone.
The original reports distinguish 113/120 versus 70/120 in the history-refitted
comparison from 113/120 versus 57/120 in the independent LSTM control.

TEP is an external dataset. Its raw files and trained candidate checkpoints are
not redistributed here. The exact split IDs and estimator source are included
for inspection and reconstruction. See docs/EXTERNAL_DATA.md. The complete
end-to-end TEP experiment is not a self-contained command in this export.

## Tests and limitations

```bash
PYTHONPATH=src python -m pytest tests/current -q
PYTHONPATH=experiments/pump_frozen python -m pytest tests/pump_frozen -q
```

The frozen and current suites must run in separate processes. Tests that require
PyTorch cannot run in a NumPy-only environment. Export checks and their actual
results are in EXPORT_VALIDATION.json. They do not replace the original scientific
audits and do not establish a universal diagnostic, safety or real-time guarantee.
The TEP endpoint uses 19.2 hours of completed observations. Endpoint accuracy is
not early localization accuracy. Healthy calibration supports the stated empirical
rank comparison under the acquisition assumptions, not a universal error bound.
VARX in the pump study is an anomaly baseline, not an actuator-localization method.
The TEP VARX comparison additionally implements joint actuator-signature attribution.

## Citation, attribution and license

Please cite the paper title above, the archive version and its checksum. No DOI
or publication venue is invented. A permanent repository URL or DOI should be
added only after the files are deposited. Contact: oliver.niggemann@hsu-hh.de.
Affiliation: Helmut Schmidt University, Hamburg, Germany, Professorship of
Computer Science in Mechanical Engineering.

See LICENSE.md, NOTICE and LICENSES. Original release tooling is licensed under
AGPL-3.0-or-later, data/documentation under CC-BY-SA-4.0. Existing MIT and GPL notices
are preserved. Use is at your own risk, without warranties. Legally mandatory
liabilities remain unaffected. No institutional endorsement is implied.
