"""Small deterministic regression tests, no experimental observations generated."""
import tempfile
from pathlib import Path
import unittest
import numpy as np
import torch
from model import PlantLSTM,configure,numpy_predict
from projection import predict_with_signatures,joint,decisions,calibration
from train import fit
from common import ROOT,read,inputs,windows,dataset


class ScienceTests(unittest.TestCase):
    def setUp(self):
        configure()
        torch.manual_seed(74)

    def test_capacity(self):
        self.assertEqual(sum(p.numel() for p in PlantLSTM().parameters()),9699)

    def test_full_real_training_population(self):
        for seed in (993101,993102,993103):
            self.assertEqual(len(dataset(seed,'train')['history']),1277)
            self.assertEqual(len(dataset(seed,'validation')['history']),530)

    def test_observation_alignment(self):
        row=next(r for r in read(ROOT/'records.json') if r['split']=='train')
        scaler=read(ROOT/'scalers.json')[str(row['seed'])]
        w=windows(row,scaler,1)
        with np.load(inputs()/row['input_path']) as raw:
            u=(raw['command']-scaler['u_mean'])/scaler['u_scale']
            y=(raw['y']-scaler['y_mean'])/scaler['y_scale']
        np.testing.assert_allclose(w['history'][0,:,:2],u[:12],rtol=1e-6,atol=1e-7)
        np.testing.assert_allclose(w['history'][0,:,2:],y[1:13],rtol=1e-6,atol=1e-7)
        np.testing.assert_allclose(w['command'][0],u[12:24],rtol=1e-6,atol=1e-7)
        np.testing.assert_allclose(w['target'][0],y[13:25],rtol=1e-6,atol=1e-7)

    def test_causal_decoder(self):
        net=PlantLSTM().double()
        h=torch.randn(2,12,5,dtype=torch.float64)
        u=torch.randn(2,12,2,dtype=torch.float64)
        other=u.clone(); other[:,8:]+=20
        with torch.no_grad():
            np.testing.assert_array_equal(net(h,u)[:,:8].numpy(),net(h,other)[:,:8].numpy())

    def test_independent_recurrence(self):
        net=PlantLSTM().double()
        h=torch.randn(3,12,5,dtype=torch.float64)
        u=torch.randn(3,12,2,dtype=torch.float64)
        state={k:v.tolist() for k,v in net.state_dict().items()}
        with torch.no_grad():expected=net(h,u).numpy()
        np.testing.assert_allclose(numpy_predict(state,h.numpy(),u.numpy()),expected,atol=1e-13,rtol=1e-12)

    def test_signature_against_autograd(self):
        net=PlantLSTM().double()
        h=torch.randn(2,12,5,dtype=torch.float64)
        u=torch.randn(2,12,2,dtype=torch.float64)
        state={k:v.tolist() for k,v in net.state_dict().items()}
        _,s=predict_with_signatures(lambda a,b:numpy_predict(state,a,b),h.numpy(),u.numpy())
        for j in range(2):
            direction=torch.zeros_like(u); direction[:,:,j]=u[:,:,j]
            _,expected=torch.autograd.functional.jvp(lambda x:net(h,x),u,direction)
            np.testing.assert_allclose(s[:,:,:,j],expected.numpy(),atol=2e-7,rtol=1e-4)

    def test_joint_independent_formula(self):
        rng=np.random.default_rng(18)
        s=rng.normal(size=(16,12,3,2)); r=s@np.array([.5,-.3])+rng.normal(size=(16,12,3))*.02
        a=joint(r,s,np.ones(3));b=joint(r,s,np.ones(3),True)
        np.testing.assert_allclose(a['scores'],b['scores'],rtol=1e-12)
        np.testing.assert_allclose(a['gains'],[.5,-.3],atol=.005)

    def test_unidentified(self):
        s=np.ones((16,12,3,2))
        self.assertIsNone(joint(np.ones((16,12,3)),s,np.ones(3))['scores'])

    def test_current_separate_from_alarm(self):
        r=dict(id='a',seed=1,checks=[dict(observed_until=204,scores=[4,0]),dict(observed_until=216,scores=[0,0])])
        d=decisions(r,[1]*43)['checks'][-1]
        self.assertTrue(d['ever_alarm']);self.assertEqual(d['candidates'],[])

    def test_calibration_no_test(self):
        with self.assertRaises(ValueError):calibration([dict(split='test')]*43)

    def test_ties_conservative(self):
        r=dict(id='a',seed=1,checks=[dict(observed_until=204,scores=[1,1])])
        self.assertEqual(decisions(r,[1]*43)['checks'][0]['p_values'],[1,1])

    def resume_check(self,device):
        rng=np.random.default_rng(91)
        w=dict(history=rng.normal(size=(8,12,5)).astype('f'),command=rng.normal(size=(8,12,2)).astype('f'),
               target=rng.normal(size=(8,12,3)).astype('f'))
        with tempfile.TemporaryDirectory() as tmp:
            a=fit(w,w,70,.001,3,Path(tmp)/'a.pt',device)
            self.assertIsNone(fit(w,w,70,.001,3,Path(tmp)/'b.pt',device,budget_seconds=0))
            b=fit(w,w,70,.001,3,Path(tmp)/'b.pt',device)
            self.assertEqual(a,b)
            with self.assertRaises(ValueError):fit(w,w,71,.001,3,Path(tmp)/'b.pt',device)

    def test_resume_cpu(self):self.resume_check('cpu')

    def test_resume_cuda(self):
        self.assertTrue(torch.cuda.is_available(),'CUDA required before scientific release')
        self.resume_check('cuda')


if __name__=='__main__':unittest.main()
