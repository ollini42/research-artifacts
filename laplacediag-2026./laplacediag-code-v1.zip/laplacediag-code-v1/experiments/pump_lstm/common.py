"""Bound inputs and complete causal windows for the LSTM comparison."""
import hashlib
import json
import os
from pathlib import Path
from collections import Counter
import numpy as np

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path = Path(path)
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2, allow_nan=False)
        stream.write('\n')


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix('.tmp')
    with temporary.open('w') as stream:
        json.dump(value, stream, sort_keys=True, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def inputs():
    return Path(os.environ['ON_ML_INPUT_ROOT'])


def verify():
    for name, digest in read(ROOT/'manifest.json')['files'].items():
        if sha(ROOT/name) != digest:
            raise ValueError('changed source: '+name)
    for name, digest in read(ROOT/'input_binding.json')['files'].items():
        if sha(inputs()/name) != digest:
            raise ValueError('changed input: '+name)
    plan = read(ROOT/'plan.json')
    rows = read(ROOT/'records.json')
    counts = Counter((r['seed'], r['split']) for r in rows)
    expected = Counter({(s,k):n for s in plan['seeds'] for k,n in
                        [('train',5),('validation',2),('reference',8),('model_check',8),('calibration',43),('test',80)]})
    if counts != expected or len({r['id'] for r in rows}) != 438:
        raise ValueError('incorrect complete population')
    return plan, rows


def windows(row, scaler, stride):
    path = inputs()/row['input_path']
    if sha(path) != row['sha256']:
        raise ValueError('changed recording')
    with np.load(path, allow_pickle=False) as stored:
        u = (stored['command']-scaler['u_mean'])/scaler['u_scale']
        y = (stored['y']-scaler['y_mean'])/scaler['y_scale']
    origins = np.arange(12, len(u)-11, stride)
    history = np.asarray([np.concatenate([u[t-12:t],y[t-11:t+1]],axis=1) for t in origins], dtype=np.float32)
    command = np.asarray([u[t:t+12] for t in origins], dtype=np.float32)
    target = np.asarray([y[t+1:t+13] for t in origins], dtype=np.float32)
    if history.shape[1:] != (12,5) or command.shape[1:] != (12,2) or target.shape[1:] != (12,3):
        raise ValueError('window shape differs')
    if not all(np.isfinite(a).all() for a in (history,command,target)):
        raise ValueError('nonfinite window')
    return dict(history=history,command=command,target=target,origins=origins)


def dataset(seed, split, stride=1):
    if split not in ('train','validation','reference','model_check','calibration','test'):
        raise ValueError('unknown split')
    scaler = read(ROOT/'scalers.json')[str(seed)]
    records = [r for r in read(ROOT/'records.json') if r['seed']==seed and r['split']==split]
    values = [windows(r,scaler,stride) for r in records]
    return {k:np.concatenate([v[k] for v in values]) for k in values[0]}


def experiment_binding():
    return dict(manifest_sha256=sha(ROOT/'manifest.json'), plan_sha256=sha(ROOT/'plan.json'),
                inputs_sha256=sha(ROOT/'input_binding.json'))
