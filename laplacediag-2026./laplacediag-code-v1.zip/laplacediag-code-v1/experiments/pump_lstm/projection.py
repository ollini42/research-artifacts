"""Joint projection using only the independently trained LSTM predictor."""
import numpy as np


def predict_with_signatures(predict,history,command,epsilon=1e-3):
    prediction=predict(history,command)
    signatures=[]
    for actor in range(2):
        plus=command.astype(float).copy()
        minus=plus.copy()
        plus[:,:,actor]*=1+epsilon
        minus[:,:,actor]*=1-epsilon
        signatures.append((predict(history,plus)-predict(history,minus))/(2*epsilon))
    return prediction,np.stack(signatures,axis=-1)


def joint(residual,signature,error_scale,audit=False):
    residual=np.asarray(residual,dtype=float)
    signature=np.asarray(signature,dtype=float)
    error_scale=np.asarray(error_scale,dtype=float)
    if signature.shape!=residual.shape+(2,) or error_scale.shape!=(3,) or np.any(error_scale<=0):
        raise ValueError('incompatible signature')
    if any(not np.isfinite(a).all() for a in (residual,signature,error_scale)):
        raise ValueError('nonfinite signature')
    r=((residual-residual.mean(0))/error_scale).ravel()
    design=((signature-signature.mean(0))/error_scale[None,None,:,None]).reshape(-1,2)
    norm=np.linalg.norm(design,axis=0)
    if np.any(norm<=1e-6):return dict(status='unidentified_signature',scores=None,gains=None,condition=None)
    x=design/norm
    singular=np.linalg.svd(x,compute_uv=False)
    cond=float(singular[0]/singular[-1]) if singular[-1]>0 else None
    if cond is None or cond>1e6:return dict(status='unidentified_signature',scores=None,gains=None,condition=cond)
    coef=np.linalg.lstsq(x,r,rcond=None)[0]
    if audit:
        scores=[]
        for j in range(2):
            other=x[:,[1-j]]
            unique=x[:,j]-other@np.linalg.lstsq(other,x[:,j],rcond=None)[0]
            scores.append(float((unique@r)**2/(unique@unique)/len(r)))
    else:
        scores=(coef**2/np.diag(np.linalg.inv(x.T@x))/len(r)).tolist()
    return dict(status='estimated',scores=scores,gains=(coef/norm).tolist(),condition=cond)


def calibration(records):
    if len(records)!=43 or any(r['split']!='calibration' for r in records):raise ValueError('calibration population')
    return [max(max(c['scores'] or [0.]) for c in r['checks']) for r in records]


def decisions(record,maxima):
    if len(maxima)!=43:raise ValueError('calibration count')
    first=None
    reports=[]
    for c in record['checks']:
        scores=c['scores']
        p=None if scores is None else [(1+sum(x>=s for x in maxima))/44 for s in scores]
        candidates=[] if p is None else [j for j,v in enumerate(p) if v<=.05]
        if candidates and first is None:first=c['observed_until']
        reports.append(dict(observed_until=c['observed_until'],scores=scores,p_values=p,
            candidates=candidates,identifiable=scores is not None,ever_alarm=first is not None,first_alarm_at=first))
    return dict(id=record['id'],seed=record['seed'],checks=reports)
