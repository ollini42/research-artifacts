"""Independent recurrence replays and healthy-only calibrated diagnosis."""
from collections import Counter
from contextlib import contextmanager
import os
from pathlib import Path
import sys
import time
import numpy as np
import torch
from common import ROOT,read,save,sha,verify,inputs,windows,dataset,experiment_binding
from model import PlantLSTM,numpy_predict,configure
from projection import predict_with_signatures,joint,calibration,decisions

METHODS=('laplacediag','laplace_projection','lstm_projection')


@contextmanager
def audit_guard(destination):
    active=[True]
    def hook(event,args):
        if not active[0]:return
        if event in ('subprocess.Popen','os.system','socket.connect'):
            raise RuntimeError('external action forbidden during audit')
        targets=[]
        if event=='open':
            path,mode,flags=args
            if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND) and not isinstance(path,int):targets=[path]
        elif event in ('os.mkdir','os.remove','os.rmdir','os.truncate','os.chmod','os.utime'):targets=[args[0]]
        elif event in ('os.rename','os.link','os.symlink'):targets=args[:2]
        if any(not Path(p).resolve().is_relative_to(destination.resolve()) for p in targets):
            raise RuntimeError('write outside audit folder')
    sys.addaudithook(hook)
    original=torch.optim.Optimizer.__init__
    def forbidden(*args,**kwargs):raise RuntimeError('optimizer forbidden in audit')
    torch.optim.Optimizer.__init__=forbidden
    try:yield
    finally:
        active[0]=False
        torch.optim.Optimizer.__init__=original


def compare(a,b):
    if isinstance(a,dict):
        if a.keys()!=b.keys():raise AssertionError('different keys')
        for k in a:compare(a[k],b[k])
    elif isinstance(a,list):
        if len(a)!=len(b):raise AssertionError('different lengths')
        for x,y in zip(a,b):compare(x,y)
    elif isinstance(a,float):np.testing.assert_allclose(a,b,rtol=2e-7,atol=2e-10)
    elif a!=b:raise AssertionError((a,b))


def chosen(seed,audit):
    folder=ROOT/'training'/str(seed)
    selected=read(folder/'selected.json')
    if any(selected[k]!=v for k,v in experiment_binding().items()):raise ValueError('selection binding changed')
    candidates=[read(folder/f'candidate_{i}.json') for i in (0,1)]
    best=min(range(2),key=lambda i:(candidates[i]['validation_mse'],i))
    if selected['candidate']!=best or selected['candidate_sha256']!=sha(folder/f'candidate_{best}.json'):
        raise ValueError('validation selection not minimal')
    for c in candidates:
        trace=c['trace']
        if c['identity']['binding']!=experiment_binding() or [t['epoch'] for t in trace]!=list(range(2561)):
            raise ValueError('incomplete or foreign training')
        minimum=min(trace,key=lambda x:x['validation_mse'])
        if minimum['epoch']!=c['best_epoch'] or minimum['validation_mse']!=c['validation_mse']:
            raise ValueError('checkpoint selection differs')
        if audit:
            val=dataset(seed,'validation')
            net=PlantLSTM()
            net.load_state_dict({k:torch.tensor(v) for k,v in c['state_dict'].items()})
            with torch.no_grad():
                mse=float(torch.mean((net(torch.tensor(val['history']),torch.tensor(val['command']))-torch.tensor(val['target']))**2))
            np.testing.assert_allclose(mse,c['validation_mse'],rtol=5e-5,atol=2e-7)
    return candidates[best]


def error_metrics(prediction,target,scaler):
    rmse=np.sqrt(np.mean((prediction-target)**2,axis=(0,1)))
    physical=rmse*np.asarray(scaler['y_scale'])
    return dict(rmse_m=physical.tolist(),rmse_training_range=(physical/scaler['y_range']).tolist(),windows=len(target))


def aggregate(records,annotations):
    result={}
    for method in METHODS:
        conditions={}
        for condition in sorted({annotations[r['id']]['condition'] for r in records}):
            subset=[r for r in records if annotations[r['id']]['condition']==condition]
            counts={}
            alarms=0
            delays=[]
            for r in subset:
                ann=annotations[r['id']]
                checks=r['methods'][method]
                alarms+=checks[-1]['ever_alarm']
                if ann['onset'] is not None and checks[-1]['first_alarm_at'] is not None:
                    delays.append((checks[-1]['first_alarm_at']-ann['onset'])*5/60)
                for c in checks:
                    candidates=c['candidates']
                    if not c['identifiable']:category='not_identifiable'
                    elif not candidates:category='none'
                    elif len(candidates)>1:category='multiple'
                    elif ann['actuator'] is None:category='false_actor'
                    elif candidates==[ann['actuator']]:category='correct'
                    else:category='wrong'
                    counts.setdefault(str(c['observed_until']),Counter())[category]+=1
            conditions[condition]=dict(recordings=len(subset),alarms=alarms,
                median_alarm_delay_minutes=None if not delays else float(np.median(delays)),current_by_step=counts)
        result[method]=conditions
    groups={}
    for r in records:
        ann=annotations[r['id']]
        if ann['actuator'] is None:continue
        flags=[int(r['methods'][m][-1]['candidates']==[ann['actuator']]) for m in METHODS]
        groups.setdefault(tuple(ann['basis_group']),[]).append(flags)
    if len(records)!=240 or len(groups)!=30 or any(len(v)!=4 for v in groups.values()):
        raise ValueError('incorrect paired population')
    strata=[np.array([np.sum(groups[k],axis=0) for k in sorted(groups) if k[0]==s]) for s in (993101,993102,993103)]
    total=sum(x.sum(0) for x in strata)
    rng=np.random.default_rng(771509)
    draw=np.array([sum(s[rng.integers(0,10,10)].sum(0) for s in strata) for _ in range(10000)])
    result['primary']=dict(recordings=120,correct=dict(zip(METHODS,map(int,total))),
        laplace_minus_lstm=float((total[0]-total[2])/120),
        paired_group_bootstrap_95_ci=np.quantile((draw[:,0]-draw[:,2])/120,[.025,.975]).tolist())
    return result


def run(audit=False):
    configure()
    _,rows=verify()
    target=ROOT/('audit' if audit else 'results')
    target.mkdir(mode=0o700)
    begin=time.monotonic()
    all_decisions=[]
    quality={}
    fit_hashes={str(p.relative_to(ROOT)):sha(p) for p in sorted((ROOT/'training').glob('*/*.json')) if 'progress' not in p.name}
    # Import and initialize all numerical code before activating write protection.
    with torch.no_grad():PlantLSTM()(torch.zeros(1,12,5),torch.zeros(1,12,2))
    with audit_guard(target):
        for seed in (993101,993102,993103):
            fitted=chosen(seed,audit)
            state=fitted['state_dict']
            predict=lambda h,u:numpy_predict(state,h,u)
            scaler=read(ROOT/'scalers.json')[str(seed)]
            quality[str(seed)]={}
            for split in ('train','validation','reference','model_check'):
                w=dataset(seed,split,1 if split in ('train','validation') else 12)
                prediction=predict(w['history'],w['command'])
                quality[str(seed)][split]=error_metrics(prediction,w['target'],scaler)
                if split=='reference':error_scale=np.maximum(np.sqrt(np.mean((prediction-w['target'])**2,axis=(0,1))),1e-6)
                if audit:
                    native=PlantLSTM().double().eval()
                    native.load_state_dict({k:torch.tensor(v,dtype=torch.float64) for k,v in state.items()})
                    with torch.no_grad():native_prediction=native(torch.tensor(w['history'],dtype=torch.float64),torch.tensor(w['command'],dtype=torch.float64)).numpy()
                    np.testing.assert_allclose(prediction,native_prediction,rtol=1e-10,atol=1e-11)
            records=[]
            for split in ('calibration','test'):
                for row in [r for r in rows if r['seed']==seed and r['split']==split]:
                    w=windows(row,scaler,12)
                    prediction,signature=predict_with_signatures(predict,w['history'],w['command'])
                    if audit:
                        # Check derivative stability without changing the frozen evaluation step.
                        _,half=predict_with_signatures(predict,w['history'],w['command'],5e-4)
                        np.testing.assert_allclose(signature,half,rtol=2e-3,atol=2e-5)
                    checks=[]
                    for i in range(14):
                        q=joint(w['target'][i:i+16]-prediction[i:i+16],signature[i:i+16],error_scale,audit=audit)
                        checks.append(dict(observed_until=int(w['origins'][i+15]+12),first_origin=int(w['origins'][i]),**q))
                    if [c['observed_until'] for c in checks]!=list(range(204,361,12)):raise ValueError('time mismatch')
                    records.append(dict(id=row['id'],seed=seed,split=split,checks=checks,
                        prediction_error=error_metrics(prediction,w['target'],scaler)))
                if split=='calibration':
                    maxima=calibration(records)
                    save(target/f'calibration_{seed}.json',dict(maxima=maxima,error_scale=error_scale.tolist()))
            save(target/f'scores_{seed}.json',records)
            tests=[decisions(r,maxima) for r in records if r['split']=='test']
            controls=read(inputs()/f'joint_projection_v1/results/decisions_current_{seed}.json')
            controls={r['id']:r for r in controls}
            for d in tests:
                methods={'lstm_projection':d['checks']}
                for new,old in (('laplacediag','laplacediag'),('laplace_projection','joint_projection')):
                    methods[new]=[]
                    for c in controls[d['id']]['checks']:
                        v=c['methods'][old]
                        methods[new].append(dict(observed_until=c['observed_until'],
                            candidates=v['current_assignment']['candidate_actuators'],
                            identifiable=v['current_assignment']['status']=='tested',
                            ever_alarm=v['alarm_history']['ever_alarm'],first_alarm_at=v['alarm_history']['first_alarm_at']))
                all_decisions.append(dict(id=d['id'],seed=seed,methods=methods))
            save(target/f'decisions_{seed}.json',tests)
        # Annotations are used only after all models, references, thresholds and decisions are fixed.
        annotations=read(inputs()/'series_v1/r6/evaluation_annotations.json')
        summary=aggregate(all_decisions,annotations)
        save(target/'quality.json',quality)
        save(target/'comparison.json',all_decisions)
        save(target/'summary.json',summary)
        if audit:
            for p in (ROOT/'results').glob('*.json'):compare(read(p),read(target/p.name))
            if fit_hashes!={p:sha(ROOT/p) for p in fit_hashes}:raise ValueError('models changed during audit')
            verify()
            save(target/'final_integrity_review.json',dict(integrity_status='passed',new_fits=0,
                new_transition_fits=0,new_observations=0,originals_unchanged=True,
                independent_recurrence_check=True,independent_partial_projection_check=True,
                replayed_test_recordings=240,replayed_calibration_recordings=129,
                trained_candidates=6,selected_models=3,replayed_diagnosis_times=3360,
                model_bindings=fit_hashes,**experiment_binding(),
                results={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'results').glob('*.json')}))
    print({'audit':audit,'seconds':time.monotonic()-begin,'primary':summary['primary']},flush=True)
