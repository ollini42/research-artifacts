"""A separate encoder-decoder LSTM without an explicit forcing matrix."""
import numpy as np
import torch
from torch import nn


class PlantLSTM(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder = nn.LSTM(5,32,batch_first=True)
        self.decoder = nn.LSTM(2,32,batch_first=True)
        self.output = nn.Linear(32,3)

    def forward(self, history, command):
        _, state = self.encoder(history)
        values, _ = self.decoder(command,state)
        return self.output(values)


def configure(threads=2):
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False


def numpy_predict(state, history, command):
    """Independent NumPy implementation of the documented LSTM recurrence."""
    state = {k:np.asarray(v,dtype=float) for k,v in state.items()}
    n = len(history)
    h = np.zeros((n,32))
    c = np.zeros_like(h)
    def step(x,h,c,prefix):
        a = x@state[prefix+'.weight_ih_l0'].T + h@state[prefix+'.weight_hh_l0'].T
        a += state[prefix+'.bias_ih_l0']+state[prefix+'.bias_hh_l0']
        i,f,g,o = np.split(a,4,axis=1)
        sigmoid = lambda z: 1/(1+np.exp(-np.clip(z,-700,700)))
        c = sigmoid(f)*c+sigmoid(i)*np.tanh(g)
        return sigmoid(o)*np.tanh(c),c
    for t in range(history.shape[1]):
        h,c = step(history[:,t],h,c,'encoder')
    result=[]
    for t in range(command.shape[1]):
        h,c = step(command[:,t],h,c,'decoder')
        result.append(h@state['output.weight'].T+state['output.bias'])
    return np.stack(result,axis=1)
