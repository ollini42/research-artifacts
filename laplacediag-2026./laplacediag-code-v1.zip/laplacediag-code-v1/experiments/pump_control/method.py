"""Joint nominal-signature projection, with conditional actuator contributions.

The fixed signatures come exclusively from the healthy plant-effect reference.
The score is the reduction in residual squared error attributable to one
actuator after allowing all other actuators to explain the observations.
Thresholds are calibrated on separate healthy recordings, never on faults.
"""
import numpy as np


def signatures(residual, inputs, operator, error_scale):
    residual = np.asarray(residual, dtype=float)
    inputs = np.asarray(inputs, dtype=float)
    operator = np.asarray(operator, dtype=float)
    error_scale = np.asarray(error_scale, dtype=float)
    if inputs.ndim != 3 or residual.ndim != 3 or inputs.shape[:2] != residual.shape[:2]:
        raise ValueError("incompatible observation windows")
    n, h, m = inputs.shape
    if operator.shape != (h * residual.shape[2], h * m) or error_scale.shape != (residual.shape[2],):
        raise ValueError("incompatible reference")
    if any(not np.isfinite(x).all() for x in (residual, inputs, operator, error_scale)) or np.any(error_scale <= 0):
        raise ValueError("nonfinite values or nonpositive scale")
    r = ((residual - residual.mean(0, keepdims=True)) / error_scale).ravel()
    columns = []
    for j in range(m):
        selected = np.zeros_like(inputs)
        selected[:, :, j] = inputs[:, :, j]
        effect = (selected.reshape(n, -1) @ operator.T).reshape(residual.shape)
        columns.append(((effect - effect.mean(0, keepdims=True)) / error_scale).ravel())
    return r, np.column_stack(columns)


def joint_scores(residual, inputs, operator, error_scale, *, audit=False):
    r, design = signatures(residual, inputs, operator, error_scale)
    norm = np.linalg.norm(design, axis=0)
    if np.any(norm <= 1e-6):
        return dict(status="unidentified_signature", scores=None, gains=None, condition=None)
    scaled = design / norm
    singular = np.linalg.svd(scaled, compute_uv=False)
    condition = float(singular[0] / singular[-1]) if singular[-1] > 0 else None
    if condition is None or condition > 1e6:
        return dict(status="unidentified_signature", scores=None, gains=None, condition=condition)
    weights = np.linalg.lstsq(scaled, r, rcond=None)[0]
    gains = weights / norm
    if not audit:
        covariance_geometry = np.linalg.inv(scaled.T @ scaled)
        scores = weights ** 2 / np.diag(covariance_geometry) / len(r)
    else:
        # Independent Frisch-Waugh calculation avoids the inverse-Gram formula.
        scores = []
        for j in range(design.shape[1]):
            others = np.delete(scaled, j, axis=1)
            unique = scaled[:, j] - others @ np.linalg.lstsq(others, scaled[:, j], rcond=None)[0]
            scores.append((unique @ r) ** 2 / (unique @ unique) / len(r))
        scores = np.asarray(scores)
    return dict(status="estimated", scores=scores.tolist(), gains=gains.tolist(), condition=condition)
