"""Frozen-model comparison on the complete registered pump population.

This module imports no optimizer, simulator or neural training code. The only
model evaluation is the previously checked NumPy forward pass of saved weights.
The separate audit uses a different formula for the joint projection score.
"""
from __future__ import annotations
import argparse
from collections import Counter
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time
import types
import numpy as np
from method import joint_scores
from frozen_forward import numpy_free

PACKAGE = Path(__file__).resolve().parents[2]
ROOT = PACKAGE / 'unused-output'
BASE = PACKAGE.parent / 'laplacediag-synthetic-data-v1'
SOURCE = PACKAGE / 'experiments/pump_frozen'
sys.path.insert(0,str(SOURCE))
from high_level_control.laplace_diag import EffectBasis, estimate_effect, change_scores, EpisodeCalibration, EpisodeMonitor
from high_level_control.laplace_diag_experiment import make_windows, load_record, projection_scores, estimate_from_dict, window_consistency, current_category

METHODS = ('laplacediag', 'projection', 'joint_projection')


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


@contextmanager
def guard(destination):
    active = [True]
    def hook(event, args):
        if not active[0]:
            return
        if event in {'subprocess.Popen', 'os.system', 'socket.connect'}:
            raise RuntimeError('external work forbidden during evaluation and audit')
        targets = []
        if event == 'open':
            path, mode, flags = args
            if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND) and not isinstance(path, int):
                targets = [path]
        elif event in {'os.mkdir', 'os.remove', 'os.rmdir', 'os.truncate', 'os.chmod', 'os.utime'}:
            targets = [args[0]]
        elif event in {'os.rename', 'os.link', 'os.symlink'}:
            targets = args[:2]
        for path in targets:
            if not Path(path).resolve().is_relative_to(destination.resolve()):
                raise RuntimeError('write outside new output forbidden: ' + str(path))
    sys.addaudithook(hook)
    try:
        yield
    finally:
        active[0] = False


def verify():
    from release_io import verify_data
    rows=verify_data(BASE)
    return read(PACKAGE/'configs/pump_control.json'),rows


def score(row, model, reference, audit):
    raw = load_record(BASE / row['path'])
    scaler = {k: np.asarray(v) for k,v in model['scaler'].items()}
    w = make_windows(raw, scaler, 12, 12, 12)
    free, original = numpy_free(model, w['history'])
    np.testing.assert_allclose(original, reference['neural_operator'], rtol=3e-6, atol=2e-7)
    basis = EffectBasis(reference['temporal_basis'], 2, 3)
    healthy = estimate_from_dict(reference['estimate'])
    operator = basis.operator(healthy.coefficients)
    prediction = free + (w['u'].reshape(len(free), -1) @ operator.T).reshape(free.shape)
    checks = []
    for i in range(14):
        selected = slice(i, i+16)
        u, y, b = w['u'][selected], w['y'][selected], free[selected]
        estimate = estimate_effect(basis, u, y, b)
        lap = change_scores(basis, healthy, estimate)
        residual = y - prediction[selected]
        separate = projection_scores(residual, u, operator, np.asarray(reference['neural_error_scale']))
        joint = joint_scores(residual, u, operator, reference['neural_error_scale'], audit=audit)
        consistency = window_consistency(basis, u, y, b)
        checks.append(dict(observed_until=int(w['origins'][i+15]+12), first_origin=int(w['origins'][i]),
                           scores=dict(laplacediag=None if lap is None else lap.tolist(),
                                       projection=separate.tolist(), joint_projection=joint['scores']),
                           joint=joint, consistency=dict(score=consistency['score'],status=consistency['status']),
                           estimate_status=estimate.status))
    if [x['observed_until'] for x in checks] != list(range(204,361,12)):
        raise ValueError('observation schedule differs')
    return dict(id=row['id'], seed=row['seed'], split=row['split'], input_sha256=row['sha256'], checks=checks)


def calibrate(records):
    result = {m: [] for m in METHODS}
    result['consistency'] = []
    if len(records) != 43 or any(r['split'] != 'calibration' for r in records):
        raise ValueError('only the complete healthy calibration set is allowed')
    for r in records:
        for m in METHODS:
            result[m].append(max(max(c['scores'][m] or [0.]) for c in r['checks']))
        result['consistency'].append(max(c['consistency']['score'] or 0. for c in r['checks']))
    return result


def decide(record, calibration, use_gate):
    monitors = {m: EpisodeMonitor(EpisodeCalibration(np.asarray(calibration[m]),14,.05),2) for m in METHODS}
    gate = EpisodeCalibration(np.asarray(calibration['consistency']),14,.05)
    decisions = []
    for c in record['checks']:
        reason = None
        gate_score = c['consistency']['score']
        if use_gate:
            if gate_score is None:
                reason = 'stationarity_not_determined'
            elif gate.p_values(np.array([gate_score]))[0] <= .05:
                reason = 'window_not_stationary'
        decisions.append(dict(observed_until=c['observed_until'], methods={m: monitor.update(
            None if c['scores'][m] is None else np.asarray(c['scores'][m]),
            observed_until=c['observed_until'],assignment_reason=reason) for m,monitor in monitors.items()}))
    return dict(id=record['id'],seed=record['seed'],checks=decisions)


def aggregate(reports, annotations):
    result = {}
    for m in METHODS:
        result[m] = {}
        for condition in sorted({annotations[r['id']]['condition'] for r in reports}):
            rows = [r for r in reports if annotations[r['id']]['condition'] == condition]
            counts, delays = {}, []
            alarms = 0
            for r in rows:
                ann = annotations[r['id']]
                last = r['checks'][-1]['methods'][m]['alarm_history']
                alarms += last['ever_alarm']
                if ann['onset'] is not None and last['first_alarm_at'] is not None:
                    delays.append((last['first_alarm_at']-ann['onset'])*5/60)
                for c in r['checks']:
                    key = str(c['observed_until'])
                    category = current_category(c['methods'][m]['current_assignment'],ann['actuator'],'projection')
                    counts.setdefault(key, Counter())[category] += 1
            result[m][condition] = dict(recordings=len(rows), alarms=alarms,
                median_alarm_delay_minutes=None if not delays else float(np.median(delays)),
                current_by_step=counts)
    pump = [r for r in reports if annotations[r['id']]['actuator'] is not None]
    groups = {}
    cross = Counter()
    for r in pump:
        ann = annotations[r['id']]
        flags = [int(r['checks'][-1]['methods'][m]['current_assignment']['candidate_actuators']==[ann['actuator']]) for m in METHODS]
        groups.setdefault(tuple(ann['basis_group']), []).append(flags)
        cross[tuple(flags)] += 1
    if len(pump)!=120 or len(groups)!=30 or any(len(v)!=4 for v in groups.values()):
        raise ValueError('wrong paired population')
    strata = [np.array([np.sum(groups[k],axis=0) for k in sorted(groups) if k[0]==s]) for s in (993101,993102,993103)]
    rng = np.random.default_rng(771509)
    draws = np.array([sum(s[rng.integers(0,10,10)].sum(0) for s in strata) for _ in range(10000)])
    totals = sum(s.sum(0) for s in strata)
    result['primary'] = dict(recordings=120, correct=dict(zip(METHODS,map(int,totals))),
        laplace_minus_joint=float((totals[0]-totals[2])/120),
        paired_group_bootstrap_95_ci=np.quantile((draws[:,0]-draws[:,2])/120,[.025,.975]).tolist(),
        cross_counts={','.join(map(str,k)):v for k,v in sorted(cross.items())})
    return result


def close(a,b):
    if isinstance(a,dict):
        if a.keys()!=b.keys(): raise AssertionError('keys differ')
        for k in a: close(a[k],b[k])
    elif isinstance(a,list):
        if len(a)!=len(b): raise AssertionError('length differs')
        for x,y in zip(a,b):close(x,y)
    elif isinstance(a,float):
        np.testing.assert_allclose(a,b,rtol=2e-10,atol=2e-12)
    elif a!=b:
        raise AssertionError((a,b))


def run(audit):
    plan, rows = verify()
    destination = ROOT / ('audit' if audit else 'results')
    destination.mkdir(mode=0o700)
    begin = time.perf_counter()
    with guard(destination):
        models = read(PACKAGE / 'assets/pump_parent_models.json')
        all_reports = {'current':[], 'current_consistency':[]}
        snapshot = PACKAGE / 'assets'
        for seed in plan['seeds']:
            reference = read(snapshot / str(seed) / 'reference.json')
            records = [score(r,models[str(seed)],reference,audit) for r in rows
                       if r['seed']==seed and r['split']=='calibration']
            calibration = calibrate(records)
            # Save and freeze healthy calibration before evaluating any test of this seed.
            save(destination / f'calibration_{seed}.json',calibration)
            prior = read(snapshot / str(seed) / 'calibration.json')
            for method in ('laplacediag','projection'):
                np.testing.assert_allclose(calibration[method],prior[method],rtol=3e-4,atol=2e-6)
            tests = [score(r,models[str(seed)],reference,audit) for r in rows
                     if r['seed']==seed and r['split']=='test']
            records += tests
            save(destination / f'scores_{seed}.json',records)
            for variant in all_reports:
                ds = [decide(r,calibration,variant=='current_consistency') for r in tests]
                save(destination / f'decisions_{variant}_{seed}.json',ds)
                all_reports[variant] += ds
            print(json.dumps(dict(seed=seed,stage='audit' if audit else 'evaluate',recordings=len(records),seconds=time.perf_counter()-begin)),flush=True)
        # Annotations are opened only after all scores and decisions are fixed.
        annotations = read(BASE / 'evaluation_annotations.json')
        summary = {v:aggregate(rs,annotations) for v,rs in all_reports.items()}
        if summary['current_consistency']['primary']['correct']['laplacediag']!=113 or summary['current_consistency']['primary']['correct']['projection']!=71:
            raise AssertionError('replay does not reproduce frozen-model historical endpoint')
        save(destination/'summary.json',summary)
        if audit:
            for path in (ROOT/'results').glob('*.json'):
                if path.name=='runtime.json':continue
                close(read(path),read(destination/path.name))
            verify()
            save(destination/'final_integrity_review.json',dict(
                campaign_id=plan['campaign_id'],integrity_status='passed',
                source_manifest_sha256=sha(PACKAGE/'MANIFEST.json'),input_binding_sha256=sha(BASE/'recordings.json'),
                new_fits=0,new_transition_fits=0,new_observations=0,originals_unchanged=True,
                reused_neural_models=3,calibration_recordings=129,test_recordings=240,
                replayed_decisions=240*14*3*2,independent_joint_score_formula='partial residualized signature',
                files={str(p.relative_to(ROOT)):sha(p) for folder in ('results','audit') for p in sorted((ROOT/folder).glob('*.json'))},
                limitations=plan['limitations']))
        save(destination/'runtime.json',dict(seconds=time.perf_counter()-begin,python=sys.version,
             executable=sys.executable,numpy=np.__version__,platform=sys.platform,machine=platform.machine(),
             threads={k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS')}))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--audit',action='store_true')
    args=parser.parse_args()
    run(args.audit)
