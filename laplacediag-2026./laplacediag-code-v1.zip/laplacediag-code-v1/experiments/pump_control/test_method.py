import unittest
import numpy as np
from method import joint_scores, signatures


class JointProjectionTests(unittest.TestCase):
    def setUp(self):
        rng = np.random.default_rng(42)
        self.u = rng.normal(size=(32, 3, 2))
        self.op = rng.normal(size=(9, 6))
        self.scale = np.array([1., 2., 3.])

    def residual(self, gains):
        return ((self.u * gains).reshape(32, 6) @ self.op.T).reshape(32, 3, 3)

    def test_exact_two_gain_recovery(self):
        got = joint_scores(self.residual([-.4, .7]), self.u, self.op, self.scale)
        np.testing.assert_allclose(got['gains'], [-.4, .7], atol=1e-12)

    def test_absent_actor_does_not_inherit_correlated_signature(self):
        self.u[:, :, 1] = self.u[:, :, 0] + .15 * self.u[:, :, 1]
        self.op = np.tile(np.eye(3), (3, 2))[:, [0, 3, 1, 4, 2, 5]]
        got = joint_scores(self.residual([-.6, 0]), self.u, self.op, self.scale)
        self.assertGreater(got['scores'][0], 1e-4)
        self.assertLess(got['scores'][1], 1e-25)

    def test_conditional_score_is_reduced_model_rss_difference(self):
        r = self.residual([-.4, .7])
        y, x = signatures(r, self.u, self.op, self.scale)
        full = y - x @ np.linalg.lstsq(x, y, rcond=None)[0]
        expected = []
        for j in range(2):
            z = np.delete(x, j, axis=1)
            reduced = y - z @ np.linalg.lstsq(z, y, rcond=None)[0]
            expected.append((reduced @ reduced - full @ full) / len(y))
        np.testing.assert_allclose(joint_scores(r, self.u, self.op, self.scale)['scores'], expected, atol=1e-12)

    def test_independent_audit_formula(self):
        a = joint_scores(self.residual([-.4, .7]), self.u, self.op, self.scale)
        b = joint_scores(self.residual([-.4, .7]), self.u, self.op, self.scale, audit=True)
        np.testing.assert_allclose(a['scores'], b['scores'], rtol=1e-12)

    def test_collinear_signatures_are_not_attributed(self):
        self.u[:, :, 1] = self.u[:, :, 0]
        self.op[:, 1::2] = self.op[:, ::2]
        self.assertIsNone(joint_scores(self.residual([1, 0]), self.u, self.op, self.scale)['scores'])

    def test_offset_and_sign_invariance(self):
        r = self.residual([-.4, .7])
        a = joint_scores(r, self.u, self.op, self.scale)
        b = joint_scores(-r + np.arange(9).reshape(1, 3, 3), self.u, self.op, self.scale)
        np.testing.assert_allclose(a['scores'], b['scores'], rtol=1e-12)

    def test_output_units_invariance(self):
        units = np.array([3, .4, 2])
        a = joint_scores(self.residual([-.4, .7]), self.u, self.op, self.scale)
        b = joint_scores(self.residual([-.4, .7]) * units, self.u,
                         self.op * np.tile(units, 3)[:, None], self.scale * units)
        np.testing.assert_allclose(a['scores'], b['scores'], rtol=1e-12)

    def test_invalid_values_rejected(self):
        with self.assertRaises(ValueError):
            joint_scores(self.residual([-.4, .7]), self.u, self.op, np.zeros(3))


if __name__ == '__main__':
    unittest.main()
