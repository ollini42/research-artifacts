"""Previously audited, unchanged NumPy evaluation of frozen LaplaceNet arrays."""
import numpy as np

def numpy_free(model, history):
    """Independent forward evaluation of the saved v3 fixed-transfer network."""
    assert model["architecture_version"] == "causal_laplace_convolution_v3"
    assert model["config"]["transfer_mode"] == "fixed"
    state = {k: np.asarray(v, dtype=np.float32) for k, v in model["state_dict"].items()}
    h = np.asarray(history, dtype=np.float32)
    for prefix in ("encoder.0", "encoder.3"):
        h = np.tanh(h @ state[prefix + ".weight"].T + state[prefix + ".bias"])
    values = h @ state["free_head.weight"].T + state["free_head.bias"]
    cfg, dims = model["config"], model["dimensions"]
    k, horizon, outputs = cfg["laplace_points"], dims["horizon"], dims["output_dim"]
    values = values.reshape(-1, k, outputs, 2)
    z = values[..., 0] + np.complex64(1j) * values[..., 1]
    dt = cfg["sampling_time_seconds"]
    frequencies = np.arange(k, dtype=np.float32) * np.float32(np.pi / (horizon * dt))
    times = np.arange(1, horizon + 1, dtype=np.float32) * np.float32(dt)
    s = np.float32(cfg["laplace_sigma"]) + np.complex64(1j) * frequencies
    inverse = np.exp(s[:, None] * times[None, :]).astype(np.complex64)
    inverse[0] *= np.float32(0.5)
    free = np.float32(2 / (horizon * dt)) * np.einsum("bko,kh->bho", z, inverse).real
    transfer = state["fixed_transfer"][..., 0] + 1j * state["fixed_transfer"][..., 1]
    impulse = np.float32(2 / horizon) * np.einsum("koi,kh->hoi", transfer, inverse).real
    operator = np.zeros((horizon, outputs, horizon, dims["input_dim"]))
    for i in range(horizon):
        for j in range(i + 1):
            operator[i, :, j] = impulse[i - j]
    return free.astype(float), operator.reshape(horizon * outputs, -1)
