"""Shared validated I/O and audit primitives for the evaluation-only repeat."""

import json, hashlib, os, sys, subprocess, time
from pathlib import Path
from contextlib import contextmanager
from unittest.mock import patch
ROOT = Path(__file__).resolve().parent

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)

def verify_allocation(plan):
    from launch import duration_seconds, fields, memory_mib, tres

    registered = read(ROOT / "job.json")
    if os.environ.get("SLURM_JOB_ID") != registered["job_id"]:
        raise ValueError("unregistered job cannot execute this campaign")
    raw = subprocess.check_output(
        ["scontrol", "show", "job", "-o", registered["job_id"]], text=True, timeout=20
    )
    values = fields(raw)
    if (
        values.get("JobState") != "RUNNING"
        or values.get("Command") != str(ROOT / "run.slurm")
        or values.get("WorkDir") != str(ROOT)
        or values.get("Comment") != registered["comment"]
        or values.get("NodeList") != "<ORIGINAL_NODE>"
        or values.get("NumNodes") not in ("1", "1-1")
        or duration_seconds(values.get("TimeLimit", ""))
        != registered["time_limit_minutes"] * 60
    ):
        raise ValueError("actual execution identity differs")
    for name in ("ReqTRES", "AllocTRES"):
        resources = tres(values[name])
        if (
            resources.get("cpu") != str(plan["cpu_count"])
            or memory_mib(resources["mem"]) != plan["memory_mib"]
            or any("gpu" in k and v != "1" for k, v in resources.items())
        ):
            raise ValueError("actual resources differ: " + name)
    from execution import verify_live_gpu
    gpu_proof = verify_live_gpu(values)
    atomic(
        ROOT / "runtime_proof.json",
        {
            "scontrol_raw": raw,
            "time": time.time(),
            "python": sys.version,
            "executable": sys.executable,
            "requested_and_allocated_verified": True,
            "gpu": gpu_proof,
        },
    )

def load_model(case):
    import torch

    from high_level_control.models import LaplaceNetOperator

    checkpoint = torch.load(case / "model.pt", map_location="cpu", weights_only=False)
    c, d = checkpoint["config"], checkpoint["dimensions"]
    model = LaplaceNetOperator(
        **d,
        hidden_dim=c["hidden_dim"],
        laplace_points=c["laplace_points"],
        sigma=c["laplace_sigma"],
        sampling_time_seconds=c["sampling_time_seconds"],
        transfer_mode="fixed",
        architecture_version=checkpoint["architecture_version"],
    )
    model.load_state_dict(checkpoint["state_dict"])
    if "forcing" in checkpoint:
        from high_level_control.laplace_diag_history import FrozenForcingHistory
        model = FrozenForcingHistory(model, checkpoint["forcing"])
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    return model

def arrays(path):
    import numpy as np

    with np.load(path, allow_pickle=False) as content:
        return {k: content[k].copy() for k in content.files}

@contextmanager
def audit_guard(output):
    """Forbid training and writes outside a new audit directory in this process."""
    import torch

    import high_level_control.laplace_diag_experiment as experiment
    import high_level_control.two_phase_learning as learning
    import high_level_control.laplace_diag_history as history_learning

    state = {"active": True}

    def forbidden(*args, **kwargs):
        raise RuntimeError("audit attempted optimization or neural fitting")

    def hook(event, args):
        if not state["active"]:
            return
        targets = []
        if event == "open":
            path, mode, flags = args
            writing = bool(
                flags
                & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)
            )
            if writing and not isinstance(path, int):
                targets = [path]
        elif event in {
            "os.mkdir",
            "os.remove",
            "os.rmdir",
            "os.truncate",
            "os.chmod",
            "os.utime",
        }:
            targets = [args[0]]
        elif event in {"os.rename", "os.link", "os.symlink"}:
            targets = list(args[:2])
        for target in targets:
            if not Path(target).resolve().is_relative_to(output.resolve()):
                raise RuntimeError(
                    "audit write outside its private output: " + str(target)
                )

    sys.addaudithook(hook)
    with (
        patch.object(learning, "fit_laplace", forbidden),
        patch.object(history_learning, "fit_history", forbidden),
        patch.object(experiment, "fit_varx", forbidden),
        patch.object(torch.optim.Optimizer, "__init__", forbidden),
    ):
        try:
            yield
        finally:
            state["active"] = False

def compare_numeric(old, new):
    """Compare deterministic science while excluding newly measured runtimes."""
    import numpy as np

    excluded = {
        "seconds_wall_cpu",
        "shared_neural_prediction_seconds",
        "varx_prediction_seconds",
        "consistency_wall_cpu",
    }
    if isinstance(old, dict):
        if set(old) != set(new):
            raise AssertionError("replay schema differs")
        for key in old:
            if key not in excluded:
                compare_numeric(old[key], new[key])
    elif isinstance(old, list):
        if len(old) != len(new):
            raise AssertionError("replay population differs")
        for x, y in zip(old, new, strict=True):
            compare_numeric(x, y)
    elif isinstance(old, (float, int)) and not isinstance(old, bool):
        np.testing.assert_allclose(new, old, atol=1e-8, rtol=1e-6)
    elif old != new:
        raise AssertionError("replay value differs")

def assess_quality(xml, returncode, critical):
    suites = list(xml.iter("testsuite"))
    failed = sum(int(s.get("failures", 0)) + int(s.get("errors", 0)) for s in suites)
    tested = sum(int(s.get("tests", 0)) for s in suites)
    skipped = sum(int(s.get("skipped", 0)) for s in suites)
    passed = {
        (test.get("classname", "").split(".")[-1], test.get("name"))
        for test in xml.iter("testcase")
        if not any(
            test.find(tag) is not None for tag in ("skipped", "failure", "error")
        )
    }
    if returncode or failed or tested <= skipped or not critical.issubset(passed):
        raise ValueError(
            "software quality failed, missing critical tests or skipped critical tests"
        )
    return {"tests": tested, "skipped": skipped, "critical_tests_passed": len(critical)}
