"""Isolated online updates on fixed healthy recordings, including preprocessing."""
import copy, os, resource, time
import numpy as np
import torch
from workflow import ROOT,ARMS,rows_for,case_model,effect_operator,identity
from support import read,atomic,arrays,sha
from high_level_control.laplace_diag import EffectBasis,estimate_effect,change_scores,EpisodeMonitor,EpisodeCalibration
from high_level_control.laplace_diag_experiment import load_record,make_windows,neural_components,estimate_from_dict,projection_scores,varx_prediction,window_consistency,check_time


def benchmark(device):
    torch.set_num_threads(1);plan=read(ROOT/'plan.json');all_results=[]
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    for arm in ARMS:
        for seed in plan['seeds']:
            row=sorted(rows_for(seed,'model_check'),key=lambda r:r['id'])[0]
            record=load_record(ROOT/row['path']); parent=__import__('pathlib').Path(os.environ['ON_ML_PARENT_ROOT'])/'results'/str(seed)
            scaler,linear=arrays(parent/'scaler.npz'),arrays(parent/'varx.npz');model=case_model(seed,arm).to(device)
            reference=read(ROOT/'results'/arm/str(seed)/'reference.json');calibration=read(ROOT/'results'/arm/str(seed)/'calibration.json')
            basis=EffectBasis(np.asarray(reference['temporal_basis']),2,3);healthy=estimate_from_dict(reference['estimate']);operator=effect_operator(reference)
            full=make_windows(record,scaler,12,12,12)
            ends=full['origins'][15:]+12
            if not len(ends):raise ValueError('latency recording too short')
            for method in ('laplacediag','projection','varx'):
                measurements=[]
                uses_cuda=device.startswith('cuda') and method!='varx'
                if uses_cuda:torch.cuda.reset_peak_memory_stats()
                for repeat in range(120):
                    check_time(plan['scientific_cutoff_unix'])
                    until=int(ends[repeat%len(ends)])
                    if uses_cuda:torch.cuda.synchronize()
                    begin=time.perf_counter();phase=begin
                    w=make_windows({'u':record['u'][:until],'y':record['y'][:until+1]},scaler,12,12,12)
                    w={k:v[-16:] for k,v in w.items()};pre=time.perf_counter()-phase
                    phase=time.perf_counter()
                    if method!='varx':
                        free,_,_=neural_components(model,w)
                        if uses_cuda:torch.cuda.synchronize()
                        prediction=free+(w['u'].reshape(16,-1)@operator.T).reshape(free.shape)
                    else:prediction=varx_prediction(linear,w)
                    prediction_time=time.perf_counter()-phase;phase=time.perf_counter()
                    if method=='laplacediag':score=change_scores(basis,healthy,estimate_effect(basis,w['u'],w['y'],free))
                    elif method=='projection':score=projection_scores(w['y']-prediction,w['u'],operator,np.asarray(reference['neural_error_scale']))
                    else:score=np.asarray([float(np.mean(((w['y']-prediction)/np.asarray(reference['linear_error_scale']))**2))])
                    method_time=time.perf_counter()-phase;phase=time.perf_counter();reason=None
                    if method!='varx':
                        consistency=window_consistency(basis,w['u'],w['y'],free)
                        c=EpisodeCalibration(np.asarray(calibration['window_consistency']),14,.05)
                        if consistency['score'] is None:reason='stationarity_not_determined'
                        elif c.p_values(np.array([consistency['score']]))[0]<=.05:reason='window_not_stationary'
                    gate_time=time.perf_counter()-phase;phase=time.perf_counter()
                    monitor=EpisodeMonitor(EpisodeCalibration(np.asarray(calibration[method]),14,.05),1 if method=='varx' else 2)
                    monitor.update(score,observed_until=until,assignment_reason=reason)
                    decision_time=time.perf_counter()-phase
                    if uses_cuda:torch.cuda.synchronize()
                    if repeat>=20:measurements.append([time.perf_counter()-begin,pre,prediction_time,method_time,gate_time,decision_time])
                values=np.asarray(measurements)
                all_results.append(dict(identity=identity(seed,arm),method=method,model_device=device if method!='varx' else 'cpu',input_id=row['id'],input_sha256=row['sha256'],warmup_updates=20,measured_updates=100,
                    phases=['end_to_end','preprocessing','prediction_including_host_device_transfers','method','consistency_gate','decision'],seconds_p50=np.quantile(values,.5,axis=0).tolist(),seconds_p95=np.quantile(values,.95,axis=0).tolist(),raw_seconds=measurements,
                    peak_process_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,peak_cuda_allocated_bytes=torch.cuda.max_memory_allocated() if uses_cuda else None,
                    scope='fully recomputed current 16-window update, one numerical CPU thread, no concurrent throughput work, RSS is process high-water mark'))
    atomic(ROOT/'latency'/('cuda.json' if device.startswith('cuda') else 'cpu.json'),all_results)


def verify_latency():
    plan=read(ROOT/'plan.json');proof={}
    for file in ('cpu.json','cuda.json'):
        path=ROOT/'latency'/file;rows=read(path)
        expected={(s,a,m) for s in plan['seeds'] for a in ARMS for m in ('laplacediag','projection','varx')}
        actual={(x['identity']['seed'],x['identity']['arm'],x['method']) for x in rows}
        if len(rows)!=27 or actual!=expected:raise ValueError('incomplete isolated latency panel')
        for row in rows:
            seed,arm=row['identity']['seed'],row['identity']['arm']
            selected=sorted(rows_for(seed,'model_check'),key=lambda x:x['id'])[0]
            if row['identity']!=identity(seed,arm) or row['input_id']!=selected['id'] or row['input_sha256']!=selected['sha256'] or row['warmup_updates']!=20 or row['measured_updates']!=100:raise ValueError('latency binding differs')
            raw=np.asarray(row['raw_seconds'])
            if raw.shape!=(100,6) or not np.isfinite(raw).all() or (raw<0).any():raise ValueError('invalid latency measurements')
            np.testing.assert_allclose(np.quantile(raw,.5,axis=0),row['seconds_p50'])
            np.testing.assert_allclose(np.quantile(raw,.95,axis=0),row['seconds_p95'])
        proof[file]=sha(path)
    return proof
