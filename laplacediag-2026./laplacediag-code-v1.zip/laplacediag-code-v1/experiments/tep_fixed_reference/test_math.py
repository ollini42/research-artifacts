import unittest
import numpy as np
import anchored_math as m

class MathTests(unittest.TestCase):
    def setUp(self):
        self.rng=np.random.default_rng(8104)
        self.x=self.rng.normal(size=(384,2))
        self.b=np.array([[2.,-1.],[.3,.8]])
        self.z=self.x@self.b+self.rng.normal(0,.02,size=(384,2))

    def test_regression_independent_replay(self):
        a=m.regression(self.x,self.z)
        b=m.regression(self.x,self.z,True)
        np.testing.assert_allclose(a[0],b[0],atol=1e-12)
        np.testing.assert_allclose(a[1],b[1],atol=1e-12)

    def test_fixed_reference_preserves_constant_offset(self):
        x=self.x+np.array([8,0])
        b0=m.regression(x,self.z)[0]
        b1=m.regression(x,self.z+np.array([1.,2.]))[0]
        self.assertGreater(np.linalg.norm(b1-b0),.1)
        c0=m.regression(x-x.mean(0),self.z-self.z.mean(0))[0]
        c1=m.regression(x-x.mean(0),(self.z+1)-(self.z+1).mean(0))[0]
        np.testing.assert_allclose(c0,c1,atol=1e-12)

    def test_reference_shift_invariance(self):
        ref=m.reference(self.x,self.z,np.ones(2),np.eye(2))
        a=m.effect(self.x+2,self.z+1,ref)
        shifted=m.reference(self.x+7,self.z+9,np.ones(2),np.eye(2))
        b=m.effect(self.x+9,self.z+10,shifted)
        np.testing.assert_allclose(a[0],b[0],rtol=1e-10)

    def test_projection_independent_replay(self):
        sig=self.rng.normal(size=(384,5,2))
        residual=np.einsum('noi,i->no',sig,[.2,-.3])+.03*self.rng.normal(size=(384,5))
        args=(residual,sig,np.zeros(5),np.zeros((5,2)),np.ones(5))
        a=m.projection(*args)
        b=m.projection(*args,True)
        np.testing.assert_allclose(a[0],b[0],rtol=1e-10)
        np.testing.assert_allclose(a[1].ravel(),[.2,-.3],atol=.01)

    def test_sign_reversal_not_confirmed(self):
        a=(np.array([10,20]),np.array([[1,2],[2,1]]))
        b=(np.array([15,10]),np.array([[-1,-2],[4,2]]))
        np.testing.assert_array_equal(m.confirmed_score(a,b),[0,10])

    def test_missing_half_unavailable(self):
        self.assertIsNone(m.confirmed_score((None,None),(np.ones(2),np.ones((2,2)))))

    def test_rank_deficiency_unavailable(self):
        self.assertIsNone(m.regression(np.ones((384,2)),self.z))

    def test_nonfinite_rejected(self):
        with self.assertRaises(ValueError):
            m.regression(self.x,np.full_like(self.z,np.nan))

    def test_confirmation_cannot_add_candidate(self):
        cal=np.arange(150)
        raw=m.decide([200,0],cal)
        confirmed=m.decide([210,220],cal,full=raw)
        self.assertEqual(confirmed['candidates'],[0])

    def test_rank_pvalue_ties_conservative(self):
        result=m.decide([1,2],np.ones(150))
        np.testing.assert_allclose(result['p'],[1,1/151])

    def test_confirmation_causal_window(self):
        stream=self.rng.normal(size=(900,2))
        def score(a,end):
            l=m.regression(a[end-384:end-192],self.z[:192])
            r=m.regression(a[end-192:end],self.z[192:])
            return m.confirmed_score((np.sum(l[0]**2,1),l[0]),(np.sum(r[0]**2,1),r[0]))
        before=score(stream,500)
        stream[500:]+=10000
        np.testing.assert_array_equal(before,score(stream,500))

if __name__=='__main__': unittest.main()
