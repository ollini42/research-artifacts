"""Immutable configuration, lineage and exclusive result writes."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def plain(x):
    if isinstance(x, dict):
        return {k: plain(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [plain(v) for v in x]
    if hasattr(x, 'tolist'):
        return plain(x.tolist())
    return x


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open('x') as f:
        json.dump(plain(value), f, sort_keys=True, allow_nan=False)
        f.write('\n')


def binding():
    return {k: sha(ROOT/n) for k, n in (
        ('source_sha256', 'manifest.json'), ('plan_sha256', 'plan.json'),
        ('parent_inventory_sha256', 'parent_inventory.json'))}


def verify(parent=True):
    m = read(ROOT/'manifest.json')
    for n, h in m['files'].items():
        if sha(ROOT/n) != h:
            raise ValueError('source changed: '+n)
    p = read(ROOT/'plan.json')
    old = set(p['retrospective_test_runs'])
    new = set(p['test_runs'])
    excluded = set(p['calibration_runs']+p['qualification_runs']+p['excluded_previous_test_or_screen_runs'])
    if len(old) != 80 or len(new) != 83 or new != set(range(1,501))-excluded-old:
        raise ValueError('new test population changed')
    if old & (excluded | new) or p['window_predictions'] != 384 or p['new_neural_fits'] != 0:
        raise ValueError('invalid immutable protocol')
    if parent:
        base = Path(p['parent_root'])
        for n, h in read(ROOT/'parent_inventory.json').items():
            if sha(base/n) != h:
                raise ValueError('parent changed: '+n)
    return p


def import_parent():
    base = read(ROOT/'plan.json')['parent_root']
    if base not in sys.path:
        sys.path.append(base)

