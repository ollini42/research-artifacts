"""Fixed-reference effect and projection scores, without window centering."""
import numpy as np


def regression(x, z, audit=False):
    x, z = np.asarray(x, float), np.asarray(z, float)
    scale = np.sqrt(np.mean(x*x, axis=0))
    if not np.isfinite(x).all() or not np.isfinite(z).all():
        raise ValueError('nonfinite regression input')
    if np.any(scale < 1e-8) or len(x) <= x.shape[1]:
        return None
    xn = x/scale
    if np.linalg.cond(xn) > 1e6:
        return None
    if audit:
        q, r = np.linalg.qr(xn, mode='reduced')
        b = np.linalg.solve(r, q.T@z)/scale[:, None]
    else:
        b = np.linalg.lstsq(x, z, rcond=None)[0]
    residual = z-x@b
    bread = np.linalg.inv(x.T@x)
    influence = np.einsum('ij,nj,nk->nik', bread, x, residual).reshape(len(x), -1)
    cov = influence.T@influence*(len(x)/(len(x)-x.shape[1]))
    if audit:
        q = np.linalg.qr(x, mode='reduced')[0]
        np.testing.assert_allclose(x@b, q@(q.T@z), rtol=1e-8, atol=1e-10)
    return b, cov


def reference(u, residual, error, nominal, audit=False):
    um, rm = np.mean(u, axis=0), np.mean(residual, axis=0)
    x, z = u-um, residual-rm
    fit = regression(x, z, audit)
    if fit is None:
        raise ValueError('unidentified healthy reference')
    raw = nominal+fit[0]
    weighted = (raw/error).T
    if np.linalg.matrix_rank(weighted) != 2:
        raise ValueError('rank deficient healthy effect space')
    q = np.linalg.qr(weighted, mode='reduced')[0]
    b, cov = regression(x, z/error@q, audit)
    return dict(input_mean=um, residual_mean=rm, error=error, basis=q,
                raw=raw, coefficient=b, covariance=cov)


def effect(u, residual, ref, audit=False):
    x = u-ref['input_mean']
    z = (residual-ref['residual_mean'])/ref['error']@ref['basis']
    result = regression(x, z, audit)
    if result is None:
        return None, None
    b, cov = result
    delta = b-ref['coefficient']
    var = np.diag(cov)+np.diag(ref['covariance'])
    score = (delta.ravel()**2/np.maximum(var, 1e-12)).reshape(2,2).mean(1)
    return score, delta


def projection(residual, signature, residual_mean, signature_mean, error, audit=False):
    r = ((residual-residual_mean)/error).ravel()
    design = ((signature-signature_mean)/error[None,:,None]).reshape(-1,2)
    scale = np.linalg.norm(design, axis=0)
    if np.any(scale < 1e-6):
        return None, None
    x = design/scale
    if np.linalg.cond(x) > 1e6:
        return None, None
    b = np.linalg.lstsq(x, r, rcond=None)[0]
    if audit:
        scores = []
        for j in range(2):
            other = x[:,1-j]
            unique = x[:,j]-other*(other@x[:,j])/(other@other)
            scores.append((unique@r)**2/(unique@unique)/len(r))
        score = np.asarray(scores)
    else:
        score = b*b/np.diag(np.linalg.inv(x.T@x))/len(r)
    return score, (b/scale)[:,None]


def confirmed_score(left, right):
    """Evidence in disjoint halves, with consistent signed change direction."""
    a, da = left
    b, db = right
    if a is None or b is None:
        return None
    aligned = np.sum(da*db, axis=1) > 0
    return np.where(aligned, np.minimum(a,b), 0.)


def decide(scores, calibration, alpha=.05, full=None):
    if scores is None or (full is not None and full['status'] == 'unavailable'):
        return dict(status='unavailable', candidates=[], p=None)
    p = (1+(np.asarray(calibration)[:,None] >= scores).sum(0))/(len(calibration)+1)
    candidates = np.flatnonzero(p <= alpha).tolist()
    if full is not None:
        candidates = [c for c in candidates if c in full['candidates']]
    status = 'assigned' if len(candidates)==1 else 'ambiguous' if candidates else 'no_assignment'
    return dict(status=status, candidates=candidates, p=p)
