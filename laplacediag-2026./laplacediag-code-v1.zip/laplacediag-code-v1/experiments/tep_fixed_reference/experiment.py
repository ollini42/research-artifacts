"""Frozen-model TEP comparison with fixed healthy anchoring and causal confirmation."""
import argparse
import time
from pathlib import Path
import numpy as np
from v2_common import ROOT, read, save, sha, plain, binding, verify, import_parent
import_parent()
import evaluate as old
from common import windows, load_record as parent_record
from data_reader import load_frame, signals
from inference import predict, signatures
from audit_guard import report_only
import anchored_math as am

METHODS = old.METHODS
ARMS = ('centered', 'healthy_anchor', 'healthy_anchor_confirmed')
KEYS = tuple(a+'|'+m for a in ARMS for m in METHODS)


def cache_path(kind, run, fault):
    return ROOT/'cache'/f'{kind}_{run}_{fault}.npz'


def load_record(kind, run, fault=0):
    with np.load(cache_path(kind, run, fault), allow_pickle=False) as f:
        return f['u'], f['y']


def store_or_check(path, value, audit=False):
    if audit or path.exists():
        old.compare(read(path), plain(value))
    else:
        save(path, value)


def prepare(faults=False, audit=False):
    p=read(ROOT/'plan.json')
    tests=sorted(p['test_runs']+p['retrospective_test_runs'])
    groups=[('TEP_Faulty_Testing.RData','faulty_testing','fault',tests,[7,14],960)] if faults else [
        ('TEP_FaultFree_Training.RData','fault_free_training','train',list(range(1,301)),[0],500),
        ('TEP_FaultFree_Testing.RData','fault_free_testing','healthy',sorted(p['calibration_runs']+p['qualification_runs']+tests),[0],960)]
    bound={}
    for name,obj,kind,runs,faults_,length in groups:
        path=Path(p['raw_root'])/name
        info=p['raw_files'][name]
        if path.stat().st_size!=info['bytes'] or sha(path)!=info['sha256']:
            raise ValueError('original source differs: '+name)
        frame=load_frame(path,obj,faults_,runs) if kind=='fault' else load_frame(path,obj)
        for run in runs:
            for f in faults_:
                u,y=signals(frame,run,f,length)
                dest=cache_path(kind,run,f)
                if audit or dest.exists():
                    uu,yy=load_record(kind,run,f)
                    if not np.array_equal(u,uu) or not np.array_equal(y,yy):
                        raise ValueError('own cache differs from original')
                else:
                    dest.parent.mkdir(mode=0o700,exist_ok=True)
                    with dest.open('xb') as out:
                        np.savez_compressed(out,u=u,y=y)
                previous=Path(p['parent_root'])/'cache'/dest.name
                if previous.exists():
                    with np.load(previous,allow_pickle=False) as z:
                        if not np.array_equal(u,z['u']) or not np.array_equal(y,z['y']):
                            raise ValueError('parent cache differs from original')
                bound[dest.name]=sha(dest)
        del frame
    value=dict(records=bound,count=len(bound),binding=binding())
    store_or_check(ROOT/('fault_inputs.json' if faults else 'healthy_inputs.json'),value,audit)
    return value


class Evaluation(old.Evaluation):
    def __init__(self,seed,audit=False):
        # Parent checks all six candidates' validation minima and model identities.
        super().__init__(seed,audit)
        self.new_plan=read(ROOT/'plan.json')
        refs=[self.prepare_record('train',r) for r in range(201,301)]
        cat=lambda k:np.concatenate([r[k] for r in refs]).astype(float)
        self.anchor=am.reference(cat('u'),cat('lap_residual'),self.errors['lap'],self.lap.g[:,[3,9]].T,audit)
        self.means={k:dict(residual=cat(k+'_residual').mean(0),signature=cat(k+'_signature').mean(0))
                    for k in ('lap','lstm','varx')}
        self.binding=dict(**binding(),seed=seed,selected_model_sha256=self.selection['candidate_sha256'])

    def prepare_record(self,kind,run,fault=0,full=True):
        w=windows(*load_record(kind,run,fault),self.s)
        target=w['target'][:,0]
        lap=old.parent_prediction(self.lap,w)
        varx=np.c_[np.ones(len(target)),w['old_history'],w['command'][:,0]]@self.varx
        if full:
            lstm,sig=signatures(self.state,w['history'],w['command'])
        else:
            lstm=predict(self.state,w['history'],w['command'])[:,0]
            sig=None
        u=w['command'][:,0,[3,9]]
        return dict(u=u,target=w['target_sample'],lap_residual=target-lap,lstm_residual=target-lstm,
                    varx_residual=target-varx,lstm_signature=sig,
                    lap_signature=np.einsum('ni,oi->noi',u,self.lap.g[:,[3,9]]),
                    varx_signature=np.einsum('ni,io->noi',u,self.varx[-11:][[3,9]]))

    def anchored(self,p,part):
        results={'LaplaceDiag':am.effect(p['u'][part],p['lap_residual'][part],self.anchor,self.audit)}
        for m,k in zip(METHODS[1:],('lstm','varx','lap')):
            results[m]=am.projection(p[k+'_residual'][part],p[k+'_signature'][part],
                                    self.means[k]['residual'],self.means[k]['signature'],self.errors[k],self.audit)
        return results

    def record(self,kind,run,fault=0):
        p=self.prepare_record(kind,run,fault)
        count=len(p['target'])
        ends=list(range(384,count+1,16))
        if ends[-1]!=count:
            ends.append(count)
        rows=[]
        for end in ends:
            a=slice(end-384,end)
            centered={'LaplaceDiag':old.effect_score(p['u'][a],p['lap_residual'][a],self.reference,self.audit)['scores']}
            for m,k in zip(METHODS[1:],('lstm','varx','lap')):
                centered[m]=old.projection(p[k+'_residual'][a],p[k+'_signature'][a],self.errors[k],self.audit)
            whole=self.anchored(p,a)
            left=self.anchored(p,slice(end-384,end-192))
            right=self.anchored(p,slice(end-192,end))
            vals={}
            for m in METHODS:
                vals['centered|'+m]=centered[m]
                vals['healthy_anchor|'+m]=whole[m][0]
                vals['healthy_anchor_confirmed|'+m]=am.confirmed_score(left[m],right[m])
            rows.append(dict(sample=int(p['target'][end-1]),first_target_sample=int(p['target'][a.start]),scores=vals))
        result=plain(dict(seed=self.seed,kind=kind,run=run,fault=fault,checks=rows,binding=self.binding))
        # Reproduce the previous trial on every available historical record.
        if run in self.new_plan['retrospective_test_runs'] and kind!='train':
            previous=Path(self.new_plan['parent_root'])/f'results/{self.seed}/test/{run}_{fault}.json'
            prior=read(previous)['raw']
            old.compare(plain([dict(sample=r['sample'],scores={m:r['scores']['centered|'+m] for m in METHODS}) for r in rows]),
                        [dict(sample=r['sample'],scores=r['scores']) for r in prior['checks']])
        return result


def summarize(record,cal):
    reports=[]
    for row in record['checks']:
        values={}
        for key in KEYS:
            arm,m=key.split('|')
            full=values['healthy_anchor|'+m] if arm=='healthy_anchor_confirmed' else None
            values[key]=am.decide(row['scores'][key],cal[key],full=full)
        reports.append(dict(sample=row['sample'],first_target_sample=row['first_target_sample'],methods=values))
    truth={7:0,14:1}.get(record['fault'])
    summary={}
    for key in KEYS:
        all_=[r['methods'][key] for r in reports]
        end=all_[-1]
        correct=[r for r in reports if truth is not None and r['methods'][key]['candidates']==[truth]]
        wrong=[r for r in reports if truth is not None and len(r['methods'][key]['candidates'])==1 and r['methods'][key]['candidates']!=[truth]]
        alarms=[r for r in reports if r['methods'][key]['candidates']]
        summary[key]=dict(end_status=end['status'],end_candidates=end['candidates'],
            correct=truth is not None and end['candidates']==[truth],
            wrong=truth is not None and len(end['candidates'])==1 and end['candidates']!=[truth],
            ever_alarm=bool(alarms),ever_correct=bool(correct),ever_wrong=bool(wrong),
            false_actuator_assignment=truth is None and len(end['candidates'])>0,
            ever_false_actuator_assignment=truth is None and bool(alarms),
            first_correct_delay_seconds=(correct[0]['sample']-161)*180 if correct else None,
            first_alarm_delay_seconds=(alarms[0]['sample']-161)*180 if alarms and truth is not None else None,
            available_checks=sum(x['status']!='unavailable' for x in all_),total_checks=len(all_))
    return plain(dict(seed=record['seed'],run=record['run'],fault=record['fault'],methods=summary,
                      decisions=reports,binding=record['binding']))


def healthy(seed,audit=False):
    ev=Evaluation(seed,audit)
    out=ROOT/f'results/{seed}'
    cal={k:[] for k in KEYS}
    coverage={k:[] for k in KEYS}
    for run in ev.new_plan['calibration_runs']:
        r=ev.record('healthy',run)
        store_or_check(out/f'calibration/{run}.json',r,audit)
        for k in KEYS:
            available=[x['scores'][k] for x in r['checks'] if x['scores'][k] is not None]
            cal[k].append(max(max(s) for s in available) if available else 0.)
            coverage[k].append(len(available)/len(r['checks']))
    store_or_check(out/'calibration.json',dict(maxima=cal,binding=ev.binding),audit)
    development=[]
    for run in ev.new_plan['qualification_runs']:
        r=ev.record('healthy',run)
        d=summarize(r,cal)
        store_or_check(out/f'development/{run}.json',dict(raw=r,summary=d),audit)
        development.append(d)
    for folder, ids, prefix in [('calibration',ev.new_plan['calibration_runs'],''),('development',ev.new_plan['qualification_runs'],'')]:
        if {f.name for f in (out/folder).glob('*.json')}!={f'{r}.json' for r in ids}:
            raise ValueError('unexpected healthy result population')
    fpr={k:np.mean([r['methods'][k]['ever_alarm'] for r in development]) for k in KEYS}
    cover={k:min(coverage[k]+[r['methods'][k]['available_checks']/r['methods'][k]['total_checks'] for r in development]) for k in KEYS}
    checks=dict(complete_calibration=all(len(v)==150 for v in cal.values()),coverage=all(v>=.9 for v in cover.values()),
        lstm_predictive_quality=ev.validation_mse['lstm']<=2*ev.validation_mse['lap'],sensitivity_stable=ev.sensitivity_stable)
    value=plain(dict(checks=checks,comparison_released=all(checks.values()),validation_mse=ev.validation_mse,
        false_assignment_fraction=fpr,false_assignment_passed={k:v<=.1 for k,v in fpr.items()},minimum_coverage=cover,
        anchor=ev.anchor,means=ev.means,binding=ev.binding))
    store_or_check(out/'healthy.json',value,audit)
    return value


def tests(seed,audit=False):
    ev=Evaluation(seed,audit)
    out=ROOT/f'results/{seed}'
    cal=read(out/'calibration.json')['maxima']
    counts={}
    for cohort,field in [('newly_reserved','test_runs'),('retrospective','retrospective_test_runs')]:
        rows=[]
        for run in ev.new_plan[field]:
            for fault in (0,7,14):
                r=ev.record('fault' if fault else 'healthy',run,fault)
                d=summarize(r,cal)
                store_or_check(out/f'{cohort}/{run}_{fault}.json',dict(raw=r,summary=d),audit)
                rows.append(d)
        counts[cohort]=len(rows)
    return counts


def aggregate(audit=False):
    p=read(ROOT/'plan.json')
    result={}
    for cohort,field in [('newly_reserved','test_runs'),('retrospective','retrospective_test_runs')]:
        files=[ROOT/f'results/{s}/{cohort}/{r}_{f}.json' for s in p['seeds'] for r in p[field] for f in (0,7,14)]
        rows=[read(f)['summary'] for f in files]
        expected_paths=set(files)
        actual_paths={f for seed in p['seeds'] for f in (ROOT/f'results/{seed}/{cohort}').glob('*.json')}
        if expected_paths!=actual_paths:
            raise ValueError('unexpected or missing result file')
        expected={(s,r,f) for s in p['seeds'] for r in p[field] for f in (0,7,14)}
        if len(rows)!=len(expected) or {(r['seed'],r['run'],r['fault']) for r in rows}!=expected:
            raise ValueError('incorrect evaluation population')
        by_fault={}
        for fault in (0,7,14):
            by_fault[str(fault)]={}
            for k in KEYS:
                vals=[r['methods'][k] for r in rows if r['fault']==fault]
                delays=[v['first_correct_delay_seconds'] for v in vals if v['first_correct_delay_seconds'] is not None]
                by_fault[str(fault)][k]=dict(n=len(vals),**{n:sum(v[n] for v in vals) for n in ('correct','wrong','ever_alarm','ever_correct','ever_wrong','false_actuator_assignment','ever_false_actuator_assignment')},
                    **{n:sum(v['end_status']==n for v in vals) for n in ('assigned','ambiguous','no_assignment','unavailable')},
                    correct_delay_median_seconds=float(np.median(delays)) if delays else None)
        contrasts={}
        pairs=[('healthy_anchor_confirmed|LaplaceDiag','healthy_anchor_confirmed|'+m) for m in METHODS[1:]]
        pairs += [(a+'|LaplaceDiag',b+'|LaplaceDiag') for a,b in [('healthy_anchor','centered'),('healthy_anchor_confirmed','healthy_anchor')]]
        for a,b in pairs:
            groups=[np.mean([int(r['methods'][a]['correct'])-int(r['methods'][b]['correct']) for r in rows if r['run']==run and r['fault']!=0]) for run in p[field]]
            rng=np.random.default_rng(771510)
            draws=np.mean(np.asarray(groups)[rng.integers(0,len(groups),size=(10000,len(groups)))],axis=1)
            contrasts[a+' minus '+b]=dict(difference=float(np.mean(groups)),ci95=np.quantile(draws,[.025,.975]))
        result[cohort]=dict(base_runs=len(p[field]),test_evaluations=len(rows),counts=by_fault,paired_contrasts=contrasts)
    value=dict(cohorts=result,binding=binding(),new_fits=0,new_observations=0,exploratory=True)
    store_or_check(ROOT/'results/summary.json',value,audit)
    return value


def worker(stage,seed,audit=False):
    verify()
    if audit:
        allowed=ROOT/f'audit/seed_{seed}_{stage}'
        allowed.mkdir(mode=0o700,parents=True,exist_ok=False)
        with report_only(allowed):
            value=healthy(seed,True) if stage=='healthy' else tests(seed,True)
            save(allowed/'replay.json',dict(passed=True,stage=stage,seed=seed,counts=value if stage=='tests' else None,binding=binding()))
    else:
        value=healthy(seed) if stage=='healthy' else tests(seed)
    return value


def finish():
    verify()
    audit=ROOT/'audit'
    audit.mkdir(mode=0o700,exist_ok=True)
    original_read=read(ROOT/'healthy_inputs.json')
    with report_only(audit):
        prepare(False,True)
        released=all(read(ROOT/f'results/{s}/healthy.json')['comparison_released'] for s in read(ROOT/'plan.json')['seeds'])
        if released:
            prepare(True,True)
            aggregate(True)
        for s in read(ROOT/'plan.json')['seeds']:
            stages=('healthy','tests') if released else ('healthy',)
            for stage in stages:
                r=read(audit/f'seed_{s}_{stage}/replay.json')
                if r.get('binding')!=binding() or not r.get('passed'):
                    raise ValueError('unbound replay')
        verify()
        report=dict(integrity_status='passed',new_fits=0,new_transition_fits=0,new_observations=0,
            originals_unchanged=True,neural_candidates_replayed=6,selected_lstm_models=3,laplace_models=3,varx_models=3,
            healthy_originals_reconstructed=original_read['count'],fault_originals_reconstructed=326 if released else 0,
            calibration_evaluations=450,development_evaluations=150,test_evaluations=1467 if released else 0,
            model_arm_decision_trajectories=17604 if released else 0,comparison_released=released,
            healthy_inputs_sha256=sha(ROOT/'healthy_inputs.json'),fault_inputs_sha256=sha(ROOT/'fault_inputs.json') if released else None,
            summary_sha256=sha(ROOT/'results/summary.json'),binding=binding())
        save(audit/'final_integrity_review.json',report)


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('stage',choices=['prepare','prepare-faults','healthy','tests','aggregate','finish'])
    ap.add_argument('--seed',type=int)
    ap.add_argument('--audit',action='store_true')
    a=ap.parse_args()
    if a.stage=='prepare': prepare()
    elif a.stage=='prepare-faults': prepare(True)
    elif a.stage in ('healthy','tests'): worker(a.stage,a.seed,a.audit)
    elif a.stage=='aggregate': aggregate()
    else: finish()
