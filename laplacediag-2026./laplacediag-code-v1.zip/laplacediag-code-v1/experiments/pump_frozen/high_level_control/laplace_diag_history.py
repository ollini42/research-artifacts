"""Healthy history fine-tuning with an immutable, explicitly selected forcing.

Copyright (c) 2026 Oliver Niggemann. Licensed under GPL-3.0-or-later.
Only the encoder and free-response head are optimized. This is a plant model.
"""
from __future__ import annotations

import copy
import hashlib
import os
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn


def tensor_digest(value):
    return hashlib.sha256(value.detach().cpu().contiguous().numpy().tobytes()).hexdigest()


class FrozenForcingHistory(nn.Module):
    """Use the parent history network and a constant causal forcing matrix."""

    def __init__(self, parent, forcing):
        super().__init__()
        self.base = copy.deepcopy(parent)
        for parameter in self.base.parameters():
            parameter.requires_grad_(False)
        for module in (self.base.encoder, self.base.free_head):
            for parameter in module.parameters():
                parameter.requires_grad_(True)
        self.register_buffer("forcing", torch.as_tensor(forcing, dtype=torch.float32).clone())
        if self.forcing.ndim != 2 or not torch.isfinite(self.forcing).all():
            raise ValueError("invalid frozen forcing")

    def components(self, history):
        free, _ = self.base.components(history)
        return free, self.forcing.unsqueeze(0).expand(len(history), -1, -1)

    def forward(self, history, inputs):
        free, _ = self.components(history)
        return free + inputs.reshape(len(inputs), -1) @ self.forcing.T


def atomic_torch(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("wb") as stream:
        torch.save(value, stream)
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def fit_history(model, training, validation, config, *, seed, device, deadline,
                progress_path, identity):
    """Full-data Adam with separate validation and resumable epoch checkpoints."""
    if not len(training["u"]) or not len(validation["u"]):
        raise ValueError("both training and separate validation are mandatory")
    if device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("requested CUDA is unavailable")
    torch.manual_seed(seed)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model = model.to(device)
    frozen = {n: tensor_digest(p) for n, p in model.named_parameters() if not p.requires_grad}
    forcing_digest = tensor_digest(model.forcing)
    tensors = [{k: torch.as_tensor(w[k], device=device, dtype=torch.float32)
                for k in ("history", "u", "y")} for w in (training, validation)]
    train, val = tensors
    optimizer = torch.optim.Adam([p for p in model.parameters() if p.requires_grad],
                                 lr=config["learning_rate"], weight_decay=config["weight_decay"])
    rng = np.random.default_rng(seed)
    trace, best, best_epoch, next_epoch = [], float("inf"), -1, 1
    best_state = None
    progress_path = Path(progress_path)
    started = time.perf_counter()

    def validation_loss():
        model.eval()
        with torch.no_grad():
            loss = ((model(val["history"], val["u"]) - val["y"].flatten(1)) ** 2).mean()
        value = float(loss.item())
        if not np.isfinite(value):
            raise ValueError("non-finite validation loss")
        return value

    if progress_path.exists():
        saved = torch.load(progress_path, map_location=device, weights_only=False)
        if saved["identity"] != identity or saved["forcing_digest"] != forcing_digest:
            raise ValueError("incompatible training checkpoint")
        model.load_state_dict(saved["state"])
        optimizer.load_state_dict(saved["optimizer"])
        rng.bit_generator.state = saved["rng"]
        trace, best, best_epoch, best_state = (saved[x] for x in ("trace", "best", "best_epoch", "best_state"))
        next_epoch = saved["epoch"] + 1
    else:
        best = validation_loss()
        best_epoch = 0
        best_state = copy.deepcopy(model.state_dict())
        trace.append({"epoch": 0, "validation_mse": best})

    def checkpoint(epoch):
        atomic_torch(progress_path, dict(identity=identity, forcing_digest=forcing_digest,
            state=model.state_dict(), optimizer=optimizer.state_dict(), rng=rng.bit_generator.state,
            trace=trace, best=best, best_epoch=best_epoch, best_state=best_state, epoch=epoch))

    for epoch in range(next_epoch, config["epochs_per_new_fit"] + 1):
        if time.time() >= deadline:
            checkpoint(epoch - 1)
            raise TimeoutError("scientific cutoff reached, last completed epoch saved")
        model.train()
        order = rng.permutation(len(train["u"]))
        for start in range(0, len(order), config["batch_size"]):
            index = torch.as_tensor(order[start:start + config["batch_size"]], device=device)
            optimizer.zero_grad(set_to_none=True)
            error = model(train["history"][index], train["u"][index]) - train["y"][index].flatten(1)
            loss = (error ** 2).mean()
            if not torch.isfinite(loss):
                raise ValueError("non-finite training loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], config["gradient_clip"])
            optimizer.step()
        value = validation_loss()
        trace.append({"epoch": epoch, "validation_mse": value,
                      "examples": len(order), "order_sha256": hashlib.sha256(order.tobytes()).hexdigest()})
        if value < best:
            best, best_epoch = value, epoch
            best_state = copy.deepcopy(model.state_dict())
        if epoch % 32 == 0 or epoch == config["epochs_per_new_fit"]:
            checkpoint(epoch)
    model.load_state_dict(best_state)
    if frozen != {n: tensor_digest(p) for n, p in model.named_parameters() if not p.requires_grad}:
        raise AssertionError("frozen parent parameters changed")
    if tensor_digest(model.forcing) != forcing_digest:
        raise AssertionError("forcing changed")
    return model.cpu().eval(), dict(trace=trace, selected_epoch=best_epoch,
        minimum_validation_mse=best, training_windows=len(training["u"]),
        validation_windows=len(validation["u"]), completed_epochs=config["epochs_per_new_fit"],
        forcing_sha256=forcing_digest, seconds_this_invocation=time.perf_counter()-started,
        device=device, dtype="float32", amp=False, tf32=False, identity=identity)
