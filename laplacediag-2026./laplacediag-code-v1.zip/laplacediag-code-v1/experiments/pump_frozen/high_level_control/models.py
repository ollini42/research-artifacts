"""PyTorch models for causal representations, local operators and detection."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

import numpy as np
import torch
from torch import nn


@lru_cache(maxsize=64)
def _laplace_geometry(
    horizon: int, points: int, sigma: float, dt: float, device: torch.device, dtype: torch.dtype
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Cache only constant quadrature geometry, never weights or observations.

    Normal tensors are required even if the first call is inference-only.
    The constants can subsequently participate in an autograd computation.
    Callers must not modify the returned tensors in place.
    """
    with torch.inference_mode(False), torch.no_grad():
        frequencies = torch.arange(points, device=device, dtype=dtype) * (torch.pi / (horizon * dt))
        times = torch.arange(1, horizon + 1, device=device, dtype=dtype) * dt
        s = torch.complex(torch.full_like(frequencies, sigma), frequencies)
        inverse = torch.exp(s[:, None] * times[None, :])
        weights = torch.ones_like(frequencies)
        weights[0] = 0.5
        inverse = inverse * weights[:, None]
        indices = torch.arange(horizon, device=device)
        lag = indices[:, None] - indices[None, :]
        return inverse, lag.clamp_min(0), lag >= 0


def set_deterministic_seed(seed: int) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)


class CausalVQAutoencoder(nn.Module):
    """Compact causal history encoder with vector-quantized prototypes."""

    def __init__(self, input_dim: int, hidden_dim: int, latent_dim: int, num_modes: int) -> None:
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, latent_dim),
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, input_dim),
        )
        self.codebook = nn.Parameter(torch.empty(num_modes, latent_dim))
        nn.init.normal_(self.codebook, std=0.2)

    def encode(self, history: torch.Tensor) -> torch.Tensor:
        return self.encoder(history)

    def distances(self, embedding: torch.Tensor) -> torch.Tensor:
        return torch.sum((embedding[:, None, :] - self.codebook[None, :, :]) ** 2, dim=-1)

    def quantize(self, embedding: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        distances = self.distances(embedding)
        labels = torch.argmin(distances, dim=1)
        return self.codebook[labels], labels

    def forward(self, history: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        embedding = self.encode(history)
        quantized, labels = self.quantize(embedding)
        straight_through = embedding + (quantized - embedding).detach()
        return self.decoder(straight_through), embedding, labels


@dataclass(frozen=True)
class RepresentationOutput:
    embedding: np.ndarray
    distances: np.ndarray
    labels: np.ndarray


def fit_representation(
    model: CausalVQAutoencoder,
    train_history: np.ndarray,
    epochs: int,
    vq_epochs: int,
    batch_size: int,
    learning_rate: float,
    commitment_weight: float,
    seed: int,
) -> list[dict[str, float]]:
    """Warm up a continuous autoencoder, initialize K-means and fine-tune VQ."""

    from sklearn.cluster import KMeans

    set_deterministic_seed(seed)
    history = torch.as_tensor(train_history, dtype=torch.float32)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    generator = np.random.default_rng(seed)
    log: list[dict[str, float]] = []
    for epoch in range(epochs):
        losses: list[float] = []
        for indices in _batches(len(history), batch_size, generator):
            optimizer.zero_grad(set_to_none=True)
            embedding = model.encode(history[indices])
            reconstruction = model.decoder(embedding)
            loss = torch.mean((reconstruction - history[indices]) ** 2)
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach()))
        log.append({"phase": 0.0, "epoch": float(epoch), "loss": float(np.mean(losses))})

    with torch.no_grad():
        embedding = model.encode(history).cpu().numpy()
    kmeans = KMeans(n_clusters=model.codebook.shape[0], random_state=seed, n_init=10)
    kmeans.fit(embedding)
    with torch.no_grad():
        model.codebook.copy_(torch.as_tensor(kmeans.cluster_centers_, dtype=torch.float32))

    for epoch in range(vq_epochs):
        losses = []
        for indices in _batches(len(history), batch_size, generator):
            optimizer.zero_grad(set_to_none=True)
            batch = history[indices]
            embedding = model.encode(batch)
            quantized, _ = model.quantize(embedding)
            straight_through = embedding + (quantized - embedding).detach()
            reconstruction = model.decoder(straight_through)
            reconstruction_loss = torch.mean((reconstruction - batch) ** 2)
            codebook_loss = torch.mean((quantized - embedding.detach()) ** 2)
            commitment_loss = torch.mean((embedding - quantized.detach()) ** 2)
            loss = reconstruction_loss + codebook_loss + commitment_weight * commitment_loss
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach()))
        log.append({"phase": 1.0, "epoch": float(epoch), "loss": float(np.mean(losses))})
    model.eval()
    return log


def representation_output(model: CausalVQAutoencoder, history: np.ndarray) -> RepresentationOutput:
    model.eval()
    with torch.no_grad():
        embedding = model.encode(torch.as_tensor(history, dtype=torch.float32))
        distances = model.distances(embedding)
        labels = torch.argmin(distances, dim=1)
    return RepresentationOutput(
        embedding=embedding.cpu().numpy(),
        distances=distances.cpu().numpy(),
        labels=labels.cpu().numpy().astype(np.int64),
    )


class HistoryConditionedAffineOperator(nn.Module):
    """Causal finite-horizon affine comparison conditioned on observed history."""

    def __init__(self, history_dim: int, input_dim: int, output_dim: int, horizon: int, hidden_dim: int) -> None:
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.horizon = horizon
        future_input_dim = horizon * input_dim
        future_output_dim = horizon * output_dim
        self.backbone = nn.Sequential(
            nn.Linear(history_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
        )
        self.bias_head = nn.Linear(hidden_dim, future_output_dim)
        self.operator_head = nn.Linear(hidden_dim, future_output_dim * future_input_dim)

    def components(self, history: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        features = self.backbone(history)
        bias = self.bias_head(features)
        operator = self.operator_head(features).reshape(
            -1, self.horizon * self.output_dim, self.horizon * self.input_dim
        )
        output_steps = torch.arange(self.horizon, device=history.device).repeat_interleave(self.output_dim)
        input_steps = torch.arange(self.horizon, device=history.device).repeat_interleave(self.input_dim)
        return bias, operator * (input_steps[None, :] <= output_steps[:, None])

    def forward(self, history: torch.Tensor, future_u: torch.Tensor) -> torch.Tensor:
        bias, operator = self.components(history)
        flat_input = future_u.reshape(-1, self.horizon * self.input_dim, 1)
        prediction = bias + torch.bmm(operator, flat_input).squeeze(-1)
        return prediction.reshape(-1, self.horizon, self.output_dim)

    def operator_signature(self, history: torch.Tensor) -> torch.Tensor:
        """Return the finite-horizon input-output operator for mode scoring."""

        _, operator = self.components(history)
        return operator.reshape(len(history), -1)


class LaplaceNetOperator(nn.Module):
    """Causal forced-system model with a learned fixed-grid Laplace response.

    The architecture follows the decoupling used by Laplace-Net. A history
    encoder predicts a free response and optionally a complex transfer function.
    A differentiable Bromwich approximation yields positive-lag impulse
    coefficients. Their lower-triangular convolution excludes every influence
    of later inputs on earlier outputs by construction. Transfer coefficients
    are unbounded. A fixed transfer is shared across histories within a mode.
    The history-conditioned alternative is a named comparison, not a claim of
    reproducing the original authors' implementation. Version 3 leaves encoder
    features unnormalized. Version 2 exists only for explicit reconstruction of
    historical checkpoints with their original LayerNorm parameters.
    """

    def __init__(
        self,
        history_dim: int,
        input_dim: int,
        output_dim: int,
        horizon: int,
        hidden_dim: int,
        laplace_points: int,
        sigma: float,
        sampling_time_seconds: float,
        transfer_mode: str = "history_conditioned",
        architecture_version: str = "causal_laplace_convolution_v3",
    ) -> None:
        super().__init__()
        if transfer_mode not in {"fixed", "history_conditioned"}:
            raise ValueError("transfer_mode must be fixed or history_conditioned")
        if architecture_version not in {"causal_laplace_convolution_v2", "causal_laplace_convolution_v3"}:
            raise ValueError("unsupported Laplace-Net architecture version")
        self.architecture_version = architecture_version
        self.transfer_mode = transfer_mode
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.horizon = horizon
        self.laplace_points = laplace_points
        self.sigma = float(sigma)
        self.sampling_time_seconds = float(sampling_time_seconds)
        self.encoder = nn.Sequential(
            nn.Linear(history_dim, hidden_dim),
            # Keep the slot and explicit legacy branch for exact old-checkpoint
            # loading. New fits preserve the unnormalized history features.
            nn.LayerNorm(hidden_dim) if architecture_version == "causal_laplace_convolution_v2" else nn.Identity(),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
        )
        complex_transfer_values = 2 * laplace_points * output_dim * input_dim
        complex_free_values = 2 * laplace_points * output_dim
        self.transfer_head = (
            nn.Linear(hidden_dim, complex_transfer_values) if transfer_mode == "history_conditioned" else None
        )
        self.fixed_transfer = (
            nn.Parameter(torch.empty(laplace_points, output_dim, input_dim, 2)) if transfer_mode == "fixed" else None
        )
        self.free_head = nn.Linear(hidden_dim, complex_free_values)
        if self.transfer_head is not None:
            nn.init.normal_(self.transfer_head.weight, std=0.02)
            nn.init.zeros_(self.transfer_head.bias)
        if self.fixed_transfer is not None:
            nn.init.normal_(self.fixed_transfer, std=0.02)
        nn.init.normal_(self.free_head.weight, std=0.02)
        nn.init.zeros_(self.free_head.bias)

    def _laplace_components(self, history: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        features = self.encoder(history)
        batch = len(history)
        if self.fixed_transfer is not None:
            transfer_values = self.fixed_transfer.unsqueeze(0).expand(batch, -1, -1, -1, -1)
        else:
            assert self.transfer_head is not None
            transfer_values = self.transfer_head(features).reshape(
                batch, self.laplace_points, self.output_dim, self.input_dim, 2
            )
        free_values = self.free_head(features).reshape(batch, self.laplace_points, self.output_dim, 2)
        transfer = torch.complex(transfer_values[..., 0], transfer_values[..., 1])
        free = torch.complex(free_values[..., 0], free_values[..., 1])
        return transfer, free

    def _grid(self, device: torch.device, dtype: torch.dtype) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        duration = self.horizon * self.sampling_time_seconds
        frequencies = torch.arange(self.laplace_points, device=device, dtype=dtype) * (torch.pi / duration)
        future_time = torch.arange(1, self.horizon + 1, device=device, dtype=dtype) * self.sampling_time_seconds
        excitation_time = torch.arange(self.horizon, device=device, dtype=dtype) * self.sampling_time_seconds
        return frequencies, future_time, excitation_time

    _native_grid = _grid

    def forward(self, history: torch.Tensor, future_u: torch.Tensor) -> torch.Tensor:
        if future_u.shape[1:] != (self.horizon, self.input_dim):
            raise ValueError(
                f"future_u must have shape [batch, {self.horizon}, {self.input_dim}], found {tuple(future_u.shape)}"
            )
        bias, operator = self.components(history)
        prediction = bias + torch.bmm(operator, future_u.reshape(len(history), -1, 1)).squeeze(-1)
        return prediction.reshape(-1, self.horizon, self.output_dim)

    def operator_signature(self, history: torch.Tensor) -> torch.Tensor:
        """Return real and imaginary transfer values on the fixed grid."""

        transfer, _ = self._laplace_components(history)
        return torch.view_as_real(transfer).reshape(len(history), -1)

    def components(self, history: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Return free response and a block-lower-triangular causal operator.

        Input u[t+j] affects y[t+i+1] only when j <= i. The extra dt in
        the forced response is the quadrature weight of the convolution.
        This finite-horizon construction does not certify long-term stability.
        """
        transfer, free = self._laplace_components(history)
        if type(self) is LaplaceNetOperator and getattr(self._grid, "__func__", None) is getattr(
            self._native_grid, "__func__", None
        ):
            inverse, lag, causal = _laplace_geometry(
                self.horizon, self.laplace_points, self.sigma, self.sampling_time_seconds, history.device, history.dtype
            )
        else:
            frequencies, future_time, _ = self._grid(history.device, history.dtype)
            s = torch.complex(torch.full_like(frequencies, self.sigma), frequencies)
            inverse = torch.exp(s[:, None] * future_time[None, :])
            weights = torch.ones_like(frequencies)
            weights[0] = 0.5
            inverse = inverse * weights[:, None]
            indices = torch.arange(self.horizon, device=history.device)
            offsets = indices[:, None] - indices[None, :]
            lag, causal = offsets.clamp_min(0), offsets >= 0
        bias = (2.0 / (self.horizon * self.sampling_time_seconds)) * torch.einsum("bko,kh->bho", free, inverse).real
        impulse = (2.0 / self.horizon) * torch.einsum("bkoi,kh->bhoi", transfer, inverse).real
        blocks = impulse[:, lag] * causal[None, :, :, None, None]
        operator = blocks.permute(0, 1, 3, 2, 4).reshape(
            len(history), self.horizon * self.output_dim, self.horizon * self.input_dim
        )
        return bias.reshape(len(history), -1), operator


OperatorModel = HistoryConditionedAffineOperator | LaplaceNetOperator


def build_operator(
    backend: str,
    history_dim: int,
    input_dim: int,
    output_dim: int,
    horizon: int,
    hidden_dim: int,
    laplace_points: int,
    laplace_sigma: float,
    sampling_time_seconds: float,
) -> OperatorModel:
    """Build the explicitly selected local dynamics backend."""

    if backend == "affine":
        return HistoryConditionedAffineOperator(history_dim, input_dim, output_dim, horizon, hidden_dim)
    if backend == "laplace_net":
        return LaplaceNetOperator(
            history_dim,
            input_dim,
            output_dim,
            horizon,
            hidden_dim,
            laplace_points,
            laplace_sigma,
            sampling_time_seconds,
        )
    raise ValueError(f"unknown operator backend: {backend}")


def fit_operator(
    model: OperatorModel,
    history: np.ndarray,
    future_u: np.ndarray,
    future_y: np.ndarray,
    epochs: int,
    batch_size: int,
    learning_rate: float,
    l2_weight: float,
    seed: int,
) -> list[float]:
    set_deterministic_seed(seed)
    history_tensor = torch.as_tensor(history, dtype=torch.float32)
    input_tensor = torch.as_tensor(future_u, dtype=torch.float32)
    output_tensor = torch.as_tensor(future_y, dtype=torch.float32)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=l2_weight)
    model.train()
    generator = np.random.default_rng(seed)
    log: list[float] = []
    for _ in range(epochs):
        losses: list[float] = []
        for indices in _batches(len(history), batch_size, generator):
            optimizer.zero_grad(set_to_none=True)
            prediction = model(history_tensor[indices], input_tensor[indices])
            loss = torch.mean((prediction - output_tensor[indices]) ** 2)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            losses.append(float(loss.detach()))
        log.append(float(np.mean(losses)))
    model.eval()
    return log


def operator_predictions(
    model: OperatorModel,
    history: np.ndarray,
    future_u: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    model.eval()
    with torch.no_grad():
        history_tensor = torch.as_tensor(history, dtype=torch.float32)
        prediction = model(history_tensor, torch.as_tensor(future_u, dtype=torch.float32))
        operator = model.operator_signature(history_tensor)
    return prediction.cpu().numpy(), operator.cpu().numpy()


class CausalModeDetector(nn.Module):
    """Deployment detector that uses causal history only."""

    def __init__(self, history_dim: int, hidden_dim: int, num_classes: int) -> None:
        super().__init__()
        self.normalization = nn.LayerNorm(history_dim)
        self.network = nn.Sequential(
            nn.Linear(history_dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(0.05),
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, num_classes),
        )

    def forward(self, history: torch.Tensor) -> torch.Tensor:
        return self.network(self.normalization(history))


def fit_detector(
    model: CausalModeDetector,
    history: np.ndarray,
    labels: np.ndarray,
    epochs: int,
    batch_size: int,
    learning_rate: float,
    seed: int,
) -> list[float]:
    set_deterministic_seed(seed)
    history_tensor = torch.as_tensor(history, dtype=torch.float32)
    label_tensor = torch.as_tensor(labels, dtype=torch.long)
    counts = np.bincount(labels, minlength=model.network[-1].out_features).astype(np.float64)
    weights = np.zeros_like(counts)
    observed = counts > 0
    weights[observed] = np.sqrt(np.sum(counts) / counts[observed])
    weights[observed] /= np.mean(weights[observed])
    class_weights = torch.as_tensor(weights, dtype=torch.float32)
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=1e-4)
    model.train()
    generator = np.random.default_rng(seed)
    log: list[float] = []
    for _ in range(epochs):
        losses: list[float] = []
        for indices in _batches(len(history), batch_size, generator):
            optimizer.zero_grad(set_to_none=True)
            logits = model(history_tensor[indices])
            loss = nn.functional.cross_entropy(
                logits,
                label_tensor[indices],
                weight=class_weights,
                label_smoothing=0.02,
            )
            loss.backward()
            optimizer.step()
            losses.append(float(loss.detach()))
        log.append(float(np.mean(losses)))
    model.eval()
    return log


def detector_probabilities(model: CausalModeDetector, history: np.ndarray) -> np.ndarray:
    """Return frozen causal class probabilities without thresholding."""

    model.eval()
    with torch.no_grad():
        logits = model(torch.as_tensor(history, dtype=torch.float32))
        return torch.softmax(logits, dim=1).cpu().numpy().astype(np.float32)


def detector_predictions(
    model: CausalModeDetector,
    history: np.ndarray,
    unknown_label: int,
    confidence_threshold: float,
    supported_modes: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    probabilities = deployment_detector_probabilities(
        detector_probabilities(model, history),
        unknown_label,
        supported_modes,
    )
    labels_array = np.argmax(probabilities, axis=1).astype(np.int64)
    confidence_array = np.max(probabilities, axis=1)
    labels_array[confidence_array < confidence_threshold] = unknown_label
    return labels_array, confidence_array


def calibrate_detector_threshold(
    model: CausalModeDetector,
    history: np.ndarray,
    labels: np.ndarray,
    unknown_label: int,
    configured_threshold: float,
    supported_modes: np.ndarray | None = None,
) -> tuple[float, float]:
    """Select a bounded unknown threshold by macro F1 on validation trajectories."""

    from sklearn.metrics import f1_score

    probabilities = deployment_detector_probabilities(
        detector_probabilities(model, history),
        unknown_label,
        supported_modes,
    )
    confidence_array = np.max(probabilities, axis=1)
    predictions_array = np.argmax(probabilities, axis=1).astype(np.int64)
    candidates = np.unique(
        np.concatenate(
            [
                np.array([0.0, configured_threshold], dtype=np.float64),
                np.quantile(confidence_array, np.linspace(0.0, 0.95, 40)),
            ]
        )
    )
    best_threshold = configured_threshold
    best_score = -np.inf
    for threshold in candidates:
        if threshold > configured_threshold:
            continue
        candidate_labels = predictions_array.copy()
        candidate_labels[confidence_array < threshold] = unknown_label
        score = float(f1_score(labels, candidate_labels, average="macro", zero_division=0))
        if score > best_score or (np.isclose(score, best_score) and threshold < best_threshold):
            best_threshold = float(threshold)
            best_score = score
    return best_threshold, best_score


def deployment_detector_probabilities(
    probabilities: np.ndarray,
    unknown_label: int,
    supported_modes: np.ndarray | None,
) -> np.ndarray:
    """Remove unsupported regular classes without renormalizing their evidence."""

    deployment = np.asarray(probabilities, dtype=np.float32).copy()
    if deployment.ndim not in {1, 2} or deployment.shape[-1] != unknown_label + 1:
        raise ValueError(f"expected a final detector dimension of {unknown_label + 1}")
    if supported_modes is None:
        return deployment
    supported = np.asarray(supported_modes, dtype=bool)
    if supported.shape != (unknown_label,):
        raise ValueError(f"expected {unknown_label} supported-mode flags")
    deployment[..., :unknown_label] *= supported.astype(np.float32)
    return deployment


def freeze_model(model: nn.Module) -> None:
    """Freeze learned parameters while retaining gradients with respect to inputs."""

    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)


def _batches(size: int, batch_size: int, generator: np.random.Generator) -> list[np.ndarray]:
    permutation = generator.permutation(size)
    return [permutation[start : start + batch_size] for start in range(0, size, batch_size)]
