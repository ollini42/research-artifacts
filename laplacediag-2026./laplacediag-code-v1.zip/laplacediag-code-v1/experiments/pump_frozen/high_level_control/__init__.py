"""LaplaceDiag scientific modules. See the release manifest for versions."""
