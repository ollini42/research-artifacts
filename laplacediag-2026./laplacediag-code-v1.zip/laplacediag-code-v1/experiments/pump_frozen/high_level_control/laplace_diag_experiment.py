"""Small, fixed-operating-condition LaplaceDiag comparison on saved recordings.

The only neural fit is a healthy forward plant model with explicit validation.
Fault annotations are read only by aggregate_reports, after predictions are
saved. No simulator, controller training or state-selection code is invoked.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path
from typing import Any

import numpy as np

from .laplace_diag import (
    EffectBasis,
    EffectEstimate,
    EpisodeCalibration,
    EpisodeMonitor,
    change_scores,
    estimate_effect,
)

METHODS = ("laplacediag", "projection", "varx")


def sha256(path: Path) -> str:
    """Hash one explicitly selected artifact, never a whole historical cache."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save_json(path: Path, value: Any) -> None:
    """Atomically write a private, finite JSON result."""
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(path)


def check_time(deadline: float) -> None:
    """Cooperatively stop before the reserved audit period, not after it."""
    if time.time() >= deadline:
        raise TimeoutError("scientific work cutoff reached")


def load_record(path: Path) -> dict[str, np.ndarray]:
    """Read only recorded commands and primary sensors, excluding hidden truth."""
    with np.load(path, allow_pickle=False) as data:
        u, y = (
            np.array(data["command"], dtype=np.float64),
            np.array(data["y"], dtype=np.float64),
        )
    if (
        u.ndim != 2
        or y.ndim != 2
        or len(y) != len(u) + 1
        or not np.isfinite(u).all()
        or not np.isfinite(y).all()
    ):
        raise ValueError("invalid recorded command/sensor arrays")
    return {"u": u, "y": y}


def training_scaler(records: list[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    """Estimate fixed normalization exclusively from healthy training records."""
    result = {}
    for key in ("u", "y"):
        values = np.concatenate([x[key] for x in records])
        result[key + "_mean"] = values.mean(axis=0)
        result[key + "_scale"] = np.maximum(values.std(axis=0), 1e-8)
        result[key + "_range"] = np.maximum(np.ptp(values, axis=0), 1e-8)
    return result


def make_windows(
    record: dict[str, np.ndarray],
    scaler: dict[str, np.ndarray],
    history: int,
    horizon: int,
    stride: int = 1,
) -> dict[str, np.ndarray]:
    """At origin t, history ends at y[t], targets start at y[t+1]."""
    if any(type(x) is not int or x < 1 for x in (history, horizon, stride)):
        raise ValueError("window dimensions and stride must be positive integers")
    u = (record["u"] - scaler["u_mean"]) / scaler["u_scale"]
    y = (record["y"] - scaler["y_mean"]) / scaler["y_scale"]
    origins = np.arange(history, len(u) - horizon + 1, stride, dtype=np.int64)
    if not len(origins):
        raise ValueError("recording has no complete windows")
    return {
        "history": np.asarray(
            [
                np.r_[u[t - history : t].ravel(), y[t - history + 1 : t + 1].ravel()]
                for t in origins
            ],
            dtype=np.float32,
        ),
        "u": np.asarray([u[t : t + horizon] for t in origins], dtype=np.float32),
        "y": np.asarray(
            [y[t + 1 : t + horizon + 1] for t in origins], dtype=np.float32
        ),
        "origins": origins,
    }


def concatenate_windows(windows: list[dict[str, np.ndarray]]) -> dict[str, np.ndarray]:
    """Concatenate complete windows while retaining recording identity."""
    value = {
        key: np.concatenate([x[key] for x in windows])
        for key in ("history", "u", "y", "origins")
    }
    value["sequence"] = np.concatenate(
        [np.full(len(x["u"]), i, dtype=np.int64) for i, x in enumerate(windows)]
    )
    return value


def fit_varx(
    windows: dict[str, np.ndarray], ridge: float = 1e-6
) -> dict[str, np.ndarray]:
    """Fit causal direct-horizon linear predictions to all healthy train windows.

    A separate linear equation for each horizon sees the same history as the
    neural model and only commands up to that horizon. Ridge is prespecified.
    This is a dynamic linear prediction/anomaly baseline, not a root-cause oracle.
    """
    if not np.isfinite(ridge) or ridge <= 0:
        raise ValueError("ridge must be positive")
    h, u, y = (np.asarray(windows[k], dtype=np.float64) for k in ("history", "u", "y"))
    count, horizon, inputs = u.shape
    free = np.empty((horizon, h.shape[1] + 1, y.shape[2]))
    operator = np.zeros((horizon * y.shape[2], horizon * inputs))
    for lead in range(horizon):
        x = np.c_[np.ones(count), h, u[:, : lead + 1].reshape(count, -1)]
        penalty = np.eye(x.shape[1]) * ridge * count
        penalty[0, 0] = 0
        coefficients = np.linalg.solve(x.T @ x + penalty, x.T @ y[:, lead])
        free[lead] = coefficients[: h.shape[1] + 1]
        operator[lead * y.shape[2] : (lead + 1) * y.shape[2], : (lead + 1) * inputs] = (
            coefficients[h.shape[1] + 1 :].T
        )
    return {"free": free, "operator": operator}


def varx_prediction(
    model: dict[str, np.ndarray], windows: dict[str, np.ndarray]
) -> np.ndarray:
    """Evaluate the saved causal linear baseline without fitting."""
    h, u = windows["history"], windows["u"]
    free = np.einsum("bd,hdo->bho", np.c_[np.ones(len(h)), h], model["free"])
    return free + (u.reshape(len(u), -1) @ model["operator"].T).reshape(free.shape)


def verify_varx_normal_equations(
    model: dict[str, np.ndarray], windows: dict[str, np.ndarray], ridge: float
) -> None:
    """Audit the fitted baseline against all training equations without a solve."""
    h, u, y = (np.asarray(windows[k], dtype=np.float64) for k in ("history", "u", "y"))
    count, horizon, inputs = u.shape
    for lead in range(horizon):
        x = np.c_[np.ones(count), h, u[:, : lead + 1].reshape(count, -1)]
        coefficients = np.r_[
            model["free"][lead],
            model["operator"][
                lead * y.shape[2] : (lead + 1) * y.shape[2], : (lead + 1) * inputs
            ].T,
        ]
        penalty = np.eye(x.shape[1]) * ridge * count
        penalty[0, 0] = 0
        left, right = (x.T @ x + penalty) @ coefficients, x.T @ y[:, lead]
        np.testing.assert_allclose(
            left, right, rtol=1e-8, atol=1e-8 * max(1.0, float(np.max(np.abs(right))))
        )
        if np.any(
            model["operator"][
                lead * y.shape[2] : (lead + 1) * y.shape[2], (lead + 1) * inputs :
            ]
            != 0
        ):
            raise ValueError("noncausal VARX coefficient")


def projection_scores(
    residual: np.ndarray,
    inputs: np.ndarray,
    operator: np.ndarray,
    error_scale: np.ndarray,
) -> np.ndarray:
    """Rank full-horizon single-actuator signatures of the SAME frozen plant model.

    The least-squares projection uses every sensor and forecast lead. Per-lead
    centering matches the nuisance-offset treatment in LaplaceDiag. Both signs
    are allowed. No fault magnitude or type is supplied to the comparison.
    """
    count, horizon, channels = inputs.shape
    centered_residual = residual - residual.mean(axis=0, keepdims=True)
    r = (centered_residual / error_scale).reshape(-1)
    scores = np.zeros(channels)
    for channel in range(channels):
        selected = np.zeros_like(inputs)
        selected[:, :, channel] = inputs[:, :, channel]
        effect = (selected.reshape(count, -1) @ operator.T).reshape(residual.shape)
        effect -= effect.mean(axis=0, keepdims=True)
        signature = (effect / error_scale).reshape(-1)
        denominator = float(signature @ signature)
        if denominator > 1e-12:
            scores[channel] = float(signature @ r) ** 2 / denominator / r.size
    return scores


def estimate_dict(estimate: EffectEstimate) -> dict[str, Any]:
    """Persist the current estimate and approximate uncertainty for complete replay."""
    return {
        key: value.tolist() if isinstance(value, np.ndarray) else value
        for key, value in vars(estimate).items()
    }


def estimate_from_dict(value: dict[str, Any]) -> EffectEstimate:
    return EffectEstimate(**value)


def window_consistency(
    basis: EffectBasis, inputs: np.ndarray, observed: np.ndarray, free: np.ndarray
) -> dict[str, Any]:
    """Compare two fixed time halves without estimating a favorable change point.

    The score has no theoretical chi-square interpretation. Its maximum over a
    complete episode must be calibrated using separate healthy recordings.
    Non-rejection is not proof of constant effects or an accurate free response.
    """
    if len(inputs) % 2:
        raise ValueError("consistency check needs two equally sized time halves")
    middle = len(inputs) // 2
    if middle < 8:
        return {"status": "insufficient_windows", "score": None, "halves": None}
    first = estimate_effect(basis, inputs[:middle], observed[:middle], free[:middle])
    second = estimate_effect(basis, inputs[middle:], observed[middle:], free[middle:])
    scores = change_scores(basis, first, second)
    return {
        "status": "estimated" if scores is not None else "not_determined",
        "score": None if scores is None else float(np.max(scores)),
        "halves": [estimate_dict(first), estimate_dict(second)],
    }


def neural_components(
    model: Any, windows: dict[str, np.ndarray]
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Evaluate independent windows, returning only frozen forward-model quantities."""
    import torch

    device = next(model.parameters()).device
    free, operators = [], []
    model.eval()
    with torch.no_grad():
        for start in range(0, len(windows["u"]), 512):
            history = torch.as_tensor(
                windows["history"][start : start + 512], device=device
            )
            b, g = model.components(history)
            free.append(b.cpu().numpy())
            operators.append(g[0].cpu().numpy())
            if not torch.allclose(g, g[0:1].expand_as(g), atol=1e-6, rtol=1e-6):
                raise ValueError(
                    "LaplaceDiag requires fixed transfer within this operating condition"
                )
    operator = operators[0].astype(np.float64)
    if any(not np.allclose(x, operator, atol=1e-6) for x in operators):
        raise ValueError(
            "history-dependent operator cannot serve as a constant reference"
        )
    b = np.concatenate(free).reshape(windows["y"].shape).astype(np.float64)
    prediction = b + (windows["u"].reshape(len(b), -1) @ operator.T).reshape(b.shape)
    return b, operator, prediction


def score_record(
    record: dict[str, np.ndarray],
    scaler: dict[str, np.ndarray],
    model: Any,
    linear: dict[str, np.ndarray],
    reference: dict[str, Any],
    settings: dict[str, Any],
    *,
    retain_estimates: bool = True,
) -> dict[str, Any]:
    """Produce causal scores. Neither the recording ID nor hidden truth is accepted."""
    windows = make_windows(
        record, scaler, settings["history"], settings["horizon"], settings["horizon"]
    )
    begin = time.perf_counter()
    free, operator, prediction = neural_components(model, windows)
    shared_seconds = time.perf_counter() - begin
    begin = time.perf_counter()
    linear_prediction = varx_prediction(linear, windows)
    linear_seconds = time.perf_counter() - begin
    basis = EffectBasis(
        np.asarray(reference["temporal_basis"]),
        record["u"].shape[1],
        record["y"].shape[1],
    )
    healthy = estimate_from_dict(reference["estimate"])
    neural_prediction = prediction
    if healthy.coefficients is not None:
        # Both methods receive exactly the same healthy effect reference.
        # The network's original G is retained separately for model-quality reporting.
        operator = basis.operator(healthy.coefficients)
        prediction = free + (windows["u"].reshape(len(free), -1) @ operator.T).reshape(
            free.shape
        )
    size = settings["block_windows"]
    results = []
    for stop in range(size, len(windows["u"]) + 1):
        selected = slice(stop - size, stop)
        u, observed, b = windows["u"][selected], windows["y"][selected], free[selected]
        begin, cpu_begin = time.perf_counter(), time.process_time()
        current = estimate_effect(basis, u, observed, b)
        scores = change_scores(basis, healthy, current)
        elapsed = {
            "laplacediag": [
                time.perf_counter() - begin,
                time.process_time() - cpu_begin,
            ]
        }
        begin, cpu_begin = time.perf_counter(), time.process_time()
        projected = projection_scores(
            observed - prediction[selected],
            u,
            operator,
            np.asarray(reference["neural_error_scale"]),
        )
        elapsed["projection"] = [
            time.perf_counter() - begin,
            time.process_time() - cpu_begin,
        ]
        begin, cpu_begin = time.perf_counter(), time.process_time()
        linear_residual = (observed - linear_prediction[selected]) / np.asarray(
            reference["linear_error_scale"]
        )
        # Residual energy across the same complete observation block. This
        # baseline detects anomalies and makes no physical localization claim.
        linear_score = float(np.mean(linear_residual**2))
        elapsed["varx"] = [time.perf_counter() - begin, time.process_time() - cpu_begin]
        result = {
            "observed_until": int(windows["origins"][stop - 1] + settings["horizon"]),
            "first_origin": int(windows["origins"][stop - size]),
            "scores": {
                "laplacediag": None if scores is None else scores.tolist(),
                "projection": projected.tolist(),
                "varx": [linear_score],
            },
            "estimate_status": current.status,
            "seconds_wall_cpu": elapsed,
        }
        if settings.get("consistency_check", False):
            begin, cpu_begin = time.perf_counter(), time.process_time()
            result["window_consistency"] = window_consistency(basis, u, observed, b)
            result["consistency_wall_cpu"] = [
                time.perf_counter() - begin, time.process_time() - cpu_begin
            ]
        if retain_estimates:
            result["estimate"] = estimate_dict(current)
        results.append(result)
    return {
        "checks": results,
        "completed_windows": len(windows["u"]),
        "shared_neural_prediction_seconds": shared_seconds,
        "varx_prediction_seconds": linear_seconds,
        "timing_scope": "batched replay and score components, not full online latency",
        "neural_rmse_original": (
            np.sqrt(np.mean((neural_prediction - windows["y"]) ** 2, axis=(0, 1)))
            * scaler["y_scale"]
        ).tolist(),
        "neural_rmse_training_range": (
            np.sqrt(np.mean((neural_prediction - windows["y"]) ** 2, axis=(0, 1)))
            * scaler["y_scale"]
            / scaler["y_range"]
        ).tolist(),
    }


def attach_decisions(
    scores: dict[str, Any], calibration: dict[str, Any], *, consistency_gate: bool = False
) -> dict[str, Any]:
    """Apply frozen episode tests, recording every check including abstentions."""
    monitors = {
        name: EpisodeMonitor(
            EpisodeCalibration(
                np.asarray(calibration[name]),
                calibration["maximum_checks"],
                calibration["alpha"],
            ),
            1 if name == "varx" else 2,
        )
        for name in METHODS
    }
    consistency_calibration = None
    if consistency_gate:
        consistency_calibration = EpisodeCalibration(
            np.asarray(calibration["window_consistency"]),
            calibration["maximum_checks"], calibration["alpha"]
        )
    for check in scores["checks"]:
        reason = None
        if consistency_calibration is not None:
            consistency = check["window_consistency"]
            if consistency["score"] is None or not consistency_calibration.resolution_sufficient:
                reason = "stationarity_not_determined"
                check["consistency_p_value"] = None
            else:
                p = float(consistency_calibration.p_values(np.array([consistency["score"]]))[0])
                check["consistency_p_value"] = p
                if p <= consistency_calibration.alpha:
                    reason = "window_not_stationary"
        check["decisions"] = {
            name: monitor.update(
                None
                if check["scores"][name] is None
                else np.asarray(check["scores"][name]),
                observed_until=check["observed_until"],
                assignment_reason=reason if name != "varx" else None,
            )
            for name, monitor in monitors.items()
        }
    return scores


def aggregate_reports(
    reports: list[tuple[dict[str, Any], dict[str, Any]]],
) -> dict[str, Any]:
    """Evaluate alarm histories and current assignments as distinct outcomes.

    Every scheduled observation end is retained. A previous candidate never
    supplies a current assignment, including when the current estimate is
    unavailable. VARX remains an anomaly detector without actuator labels.
    """
    output = {}
    for name in METHODS:
        categories: dict[str, list[dict[str, Any]]] = {}
        for annotation, report in reports:
            condition = annotation["condition"]
            onset = annotation["onset"]
            decisions = [
                (x["observed_until"], x["decisions"][name]) for x in report["checks"]
            ]
            if not decisions or any(x.get("decision_schema") != 2 for _, x in decisions):
                raise ValueError("current evaluation requires decision schema 2")
            alarming = [(t, x) for t, x in decisions if x["alarm_history"]["ever_alarm"]]
            first = alarming[:1]
            post = [(t, x) for t, x in first if onset is not None and t > onset]
            chosen = None
            if post and name != "varx":
                candidate = post[0][1]["current_assignment"]["candidate_actuators"]
                chosen = candidate[0] if len(candidate) == 1 else None
            categories.setdefault(condition, []).append(
                {
                    "any_alarm": bool(alarming),
                    "pre_onset_alarm": bool(
                        onset is not None and any(t <= onset for t, _ in first)
                    ),
                    "pre_onset_evaluable": bool(
                        onset is not None and any(t <= onset for t, _ in decisions)
                    ),
                    "detected_after_onset": bool(post),
                    "delay_steps": None if not post else post[0][0] - onset,
                    "candidate": chosen,
                    "matches_injected_actuator": None
                    if annotation["actuator"] is None or name == "varx"
                    else chosen == annotation["actuator"],
                    "unavailable_checks": sum(
                        x["current_assignment"]["status"] != "tested" for _, x in decisions
                    ),
                    "current_by_step": {
                        str(t): current_category(x["current_assignment"], annotation["actuator"], name)
                        for t, x in decisions
                    },
                    "wall_seconds": [
                        x["seconds_wall_cpu"][name][0] for x in report["checks"]
                    ],
                }
            )
        output[name] = {}
        for condition, values in categories.items():
            times = np.asarray([t for x in values for t in x["wall_seconds"]])
            delays = [x["delay_steps"] for x in values if x["delay_steps"] is not None]
            schedule = set(values[0]["current_by_step"])
            if any(set(x["current_by_step"]) != schedule for x in values):
                raise ValueError("different observation schedules cannot be pooled")
            matched = {}
            for step in sorted(schedule, key=int):
                counts = {key: 0 for key in (
                    "unique_correct", "unique_wrong", "multiple_candidates",
                    "no_significant_candidate", "not_determined", "anomaly_without_localization",
                    "candidate_without_actuator_ground_truth"
                )}
                for value in values:
                    counts[value["current_by_step"][step]] += 1
                matched[step] = {"recordings": len(values), **counts}
            output[name][condition] = {
                "recordings": len(values),
                "alarms": sum(x["any_alarm"] for x in values),
                "pre_onset_alarms": sum(x["pre_onset_alarm"] for x in values),
                "pre_onset_evaluable_recordings": sum(
                    x["pre_onset_evaluable"] for x in values
                ),
                "detected_after_onset": sum(x["detected_after_onset"] for x in values),
                "median_delay_steps": None if not delays else float(np.median(delays)),
                "matching_actuator_candidates_at_first_alarm": None
                if name == "varx" or not condition.startswith("pump")
                else sum(x["matches_injected_actuator"] for x in values),
                "unavailable_checks": sum(x["unavailable_checks"] for x in values),
                "current_assignment_by_step": matched,
                "score_component_wall_seconds_p50_p95": None
                if not len(times)
                else np.quantile(times, [0.5, 0.95]).tolist(),
            }
    return output


def current_category(assignment: dict[str, Any], actual: int | None, method: str) -> str:
    """Classify one current decision, never the accumulated alarm history."""
    if assignment["status"] != "tested":
        return "not_determined"
    candidates = assignment["candidate_actuators"]
    if not candidates:
        return "no_significant_candidate"
    if method == "varx":
        return "anomaly_without_localization"
    if actual is None:
        return "candidate_without_actuator_ground_truth"
    if len(candidates) != 1:
        return "multiple_candidates"
    return "unique_correct" if candidates[0] == actual else "unique_wrong"
