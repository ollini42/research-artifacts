"""Label-free Laplace-Net fitting, noise heuristics and purged evidence splits.

This module contains no segmentation or state-merging decisions. The caller
must complete segmentation before requesting merges and must keep final test
trajectories outside all fitting and evidence-selection calls.
"""

from __future__ import annotations

import copy
import hashlib
import logging
import math
import os
import platform
from collections.abc import Callable, Iterator, Sequence
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from typing import Any

import numpy as np
import torch

from .models import LaplaceNetOperator

LOGGER = logging.getLogger(__name__)


def _finite_array(value: np.ndarray, name: str, ndim: int) -> np.ndarray:
    array = np.asarray(value, dtype=np.float32)
    if array.ndim != ndim or any(size < 1 for size in array.shape):
        raise ValueError(f"{name} must be a nonempty {ndim}-dimensional array")
    if not np.isfinite(array).all():
        raise ValueError(f"{name} contains NaN, infinity or values outside float32 range")
    return array.copy()


def _integer_vector(value: np.ndarray, name: str, count: int) -> np.ndarray:
    array = np.asarray(value)
    if array.shape != (count,) or array.dtype.kind not in "iu":
        raise ValueError(f"{name} must be an integer array with shape ({count},)")
    if np.any(array < 0) or np.any(array > np.iinfo(np.int64).max):
        raise ValueError(f"{name} must contain nonnegative int64-compatible values")
    return array.astype(np.int64, copy=True)


@dataclass(frozen=True)
class ModelData:
    """Copied, finite windows without mode labels or simulator parameters.

    ``time`` is the integer prediction origin. A window conservatively uses
    raw samples in the inclusive interval [time - history, time + horizon].
    ``history`` stores flattened causal features, not the history length.
    """

    history: np.ndarray
    future_u: np.ndarray
    future_y: np.ndarray
    sequence: np.ndarray | None = None
    time: np.ndarray | None = None

    def __post_init__(self) -> None:
        for name, ndim in (("history", 2), ("future_u", 3), ("future_y", 3)):
            object.__setattr__(self, name, _finite_array(getattr(self, name), name, ndim))
        count = len(self.history)
        if len(self.future_u) != count or len(self.future_y) != count:
            raise ValueError("history, future_u and future_y must have the same window count")
        if self.future_u.shape[1] != self.future_y.shape[1]:
            raise ValueError("future_u and future_y must have the same horizon")
        for name in ("sequence", "time"):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(self, name, _integer_vector(value, name, count))

    def __len__(self) -> int:
        return len(self.history)

    def subset(self, indices: np.ndarray | Sequence[int]) -> ModelData:
        """Return independent copies of selected windows, retaining their origins."""

        chosen = _indices(indices, len(self))
        return ModelData(
            self.history[chosen],
            self.future_u[chosen],
            self.future_y[chosen],
            None if self.sequence is None else self.sequence[chosen],
            None if self.time is None else self.time[chosen],
        )


@dataclass(frozen=True)
class LaplaceFitConfig:
    """Scientific fit settings shared by CPU and CUDA runs without fallback."""

    hidden_dim: int = 32
    laplace_points: int = 8
    laplace_sigma: float = 0.2
    sampling_time_seconds: float = 0.1
    epochs: int = 30
    batch_size: int = 128
    learning_rate: float = 0.003
    weight_decay: float = 1e-5
    gradient_clip: float = 5.0
    seed: int = 0
    device: str = "cpu"
    backend: str = "laplace_net"
    min_epochs: int = 1
    convergence_patience: int | None = None
    convergence_relative_tolerance: float = 1e-3
    transfer_mode: str = "fixed"
    training_strategy: str = "cold_start"
    validation_fraction: float = 0.0
    shrink_factor: float = 0.5
    perturb_std: float = 0.001
    linear_readout_refinement: bool = False
    # Historical serialized configurations remain readable. fit_laplace rejects
    # every retired timing before constructing a model or optimizer.
    linear_readout_refinement_timing: str = "each_checkpoint"

    def __post_init__(self) -> None:
        if self.linear_readout_refinement_timing not in {"each_checkpoint", "selected_checkpoint"}:
            raise ValueError("unknown readout refinement timing")
        if self.linear_readout_refinement_timing == "selected_checkpoint" and not self.linear_readout_refinement:
            raise ValueError("selected-checkpoint readout requires enabled refinement")
        if type(self.linear_readout_refinement) is not bool or (
            self.linear_readout_refinement and self.transfer_mode != "fixed"
        ):
            raise ValueError("linear_readout_refinement requires a boolean flag and fixed transfer")
        if self.backend != "laplace_net":
            raise ValueError("two-phase learning requires backend='laplace_net', with no affine fallback")
        if self.transfer_mode not in {"fixed", "history_conditioned"}:
            raise ValueError("transfer_mode must be fixed or history_conditioned")
        if self.training_strategy not in {"cold_start", "warm_start", "shrink_perturb"}:
            raise ValueError("unsupported training_strategy")
        if not math.isfinite(self.validation_fraction) or not 0 <= self.validation_fraction < 0.5:
            raise ValueError("validation_fraction must lie in [0, 0.5)")
        if not math.isfinite(self.shrink_factor) or not 0 < self.shrink_factor <= 1:
            raise ValueError("shrink_factor must lie in (0, 1]")
        if not math.isfinite(self.perturb_std) or self.perturb_std < 0:
            raise ValueError("perturb_std must be finite and nonnegative")
        for name in ("hidden_dim", "laplace_points", "epochs", "batch_size", "min_epochs"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"{name} must be a positive integer")
        if self.min_epochs > self.epochs:
            raise ValueError("min_epochs must not exceed the epochs budget")
        if self.convergence_patience is not None and (
            isinstance(self.convergence_patience, bool)
            or not isinstance(self.convergence_patience, int)
            or self.convergence_patience < 1
        ):
            raise ValueError("convergence_patience must be a positive integer or None")
        if (
            isinstance(self.convergence_relative_tolerance, bool)
            or not math.isfinite(self.convergence_relative_tolerance)
            or not 0 <= self.convergence_relative_tolerance < 1
        ):
            raise ValueError("convergence_relative_tolerance must be finite and in [0, 1)")
        if isinstance(self.seed, bool) or not isinstance(self.seed, int) or not 0 <= self.seed < 2**32:
            raise ValueError("seed must be an integer in [0, 2**32)")
        for name in ("sampling_time_seconds", "learning_rate", "gradient_clip"):
            value = getattr(self, name)
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if not math.isfinite(self.laplace_sigma) or self.laplace_sigma < 0:
            raise ValueError("laplace_sigma must be finite and nonnegative")
        if not math.isfinite(self.weight_decay) or self.weight_decay < 0:
            raise ValueError("weight_decay must be finite and nonnegative")
        try:
            device = torch.device(self.device)
        except (RuntimeError, ValueError, TypeError) as error:
            raise ValueError(f"invalid device {self.device!r}") from error
        if device.type not in {"cpu", "cuda"}:
            raise ValueError("only cpu and cuda devices are supported")


def _cpu_copy(value: Any) -> Any:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {key: _cpu_copy(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_cpu_copy(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_cpu_copy(item) for item in value)
    return copy.deepcopy(value)


def _optimizer_checkpoint(optimizer: torch.optim.Optimizer, *, refined: bool) -> dict[str, Any]:
    state = optimizer.state_dict()
    if refined:
        # Completed readouts deliberately reset Adam. Do not copy its moments
        # to CPU only to discard them immediately afterwards.
        state = {**state, "state": {}}
    return _cpu_copy(state)


@dataclass
class LaplaceFitResult:
    """Frozen selected model with compatible optimizer state and an audit log."""

    model: LaplaceNetOperator
    config: LaplaceFitConfig
    log: list[dict[str, float]]
    best_epoch: int
    best_train_mse: float
    optimizer_state: dict[str, Any]
    dimensions: dict[str, int]
    training_status: dict[str, Any]

    def checkpoint(self) -> dict[str, Any]:
        """Return CPU tensors for caller-owned atomic checkpoint serialization."""

        return {
            "state_dict": _cpu_copy(self.model.state_dict()),
            "optimizer_state_dict": _cpu_copy(self.optimizer_state),
            "config": asdict(self.config),
            "dimensions": dict(self.dimensions),
            "epoch": self.best_epoch,
            "seed": self.config.seed,
            "best_train_mse": self.best_train_mse,
            "log": copy.deepcopy(self.log),
            "training_status": copy.deepcopy(self.training_status),
            "checkpoint_selection": self.training_status["checkpoint_selection"],
            "architecture_version": self.model.architecture_version,
            "software": {"python": platform.python_version(), "torch": str(torch.__version__), "numpy": np.__version__},
        }


@contextmanager
def _deterministic_training(seed: int, device: torch.device) -> Iterator[None]:
    if device.type == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA was explicitly requested but is unavailable, refusing CPU fallback")
        if os.environ.get("CUBLAS_WORKSPACE_CONFIG") not in {":4096:8", ":16:8"}:
            raise RuntimeError("set CUBLAS_WORKSPACE_CONFIG=:4096:8 before Python starts for deterministic CUDA fits")
        devices = [torch.cuda.current_device() if device.index is None else device.index]
        if devices[0] >= torch.cuda.device_count():
            raise RuntimeError(f"requested CUDA device {devices[0]} does not exist")
    else:
        devices = []
    enabled = torch.are_deterministic_algorithms_enabled()
    warn_only = torch.is_deterministic_algorithms_warn_only_enabled()
    with torch.random.fork_rng(devices=devices):
        try:
            torch.use_deterministic_algorithms(True, warn_only=False)
            # torch.manual_seed also seeds every CUDA device. Snapshotting one
            # device would then leave unrelated generators changed on exit.
            torch.random.default_generator.manual_seed(seed)
            if devices:
                with torch.cuda.device(devices[0]):
                    torch.cuda.manual_seed(seed)
            yield
        finally:
            torch.use_deterministic_algorithms(enabled, warn_only=warn_only)


def _finite_parameters(model: LaplaceNetOperator) -> None:
    finite = torch.stack([torch.isfinite(parameter).all() for parameter in model.parameters()])
    if not finite.all():
        raise FloatingPointError("Laplace-Net produced non-finite parameters")


def _tensor_batch(data: ModelData, indices: np.ndarray | slice, device: torch.device) -> tuple[torch.Tensor, ...]:
    return tuple(
        torch.as_tensor(values[indices], dtype=torch.float32, device=device)
        for values in (data.history, data.future_u, data.future_y)
    )


def _training_mse(
    model: LaplaceNetOperator, data: ModelData, batch_size: int, weights: np.ndarray | None = None
) -> float:
    prediction = predict_laplace(model, data, batch_size)
    if weights is None:
        return float(np.mean((prediction.astype(np.float64) - data.future_y) ** 2))
    errors = np.mean((prediction.astype(np.float64) - data.future_y) ** 2, axis=(1, 2))
    return float(np.average(errors, weights=weights))


_NATIVE_TRAINING_MSE = _training_mse


def _completed_candidate(
    model: LaplaceNetOperator,
    data: ModelData,
    validation: ModelData | None,
    config: LaplaceFitConfig,
    sample_weights: np.ndarray | None,
    *,
    workspace: LaplaceNetOperator | None = None,
) -> tuple[LaplaceNetOperator, float, float, dict[str, Any]]:
    """Complete one candidate without changing the live Adam trajectory.

    The copied model receives a fitting-only linear solve. The held-out role
    is used afterwards only to score the completed candidate. Keeping Adam's
    parameters untouched avoids pairing its moments with polished weights.
    """
    if not config.linear_readout_refinement:
        mse = _training_mse(model, data, config.batch_size, sample_weights)
        score = _training_mse(model, validation, config.batch_size) if validation is not None else mse
        return model, mse, score, {"enabled": False}

    from . import two_phase_readout

    # The readout solver uses CPU float64 on every host. Score its float32
    # result on CPU too, so an artifact replay uses the same evaluation path.
    if (
        workspace is None
        or not two_phase_readout._native_refiners_unchanged()
        or _training_mse is not _NATIVE_TRAINING_MSE
    ):
        candidate = copy.deepcopy(model).cpu().eval()
    else:
        # One private CPU model per fit is sufficient. Selected checkpoints
        # still own independent copies, and Adam's live model is untouched.
        candidate = workspace
        candidate.load_state_dict(model.state_dict())
    before_mse = _training_mse(candidate, data, config.batch_size, sample_weights)
    before_score = _training_mse(candidate, validation, config.batch_size) if validation is not None else before_mse
    status = two_phase_readout.refine_linear_readout(
        candidate, data, config.weight_decay, sample_weights=sample_weights
    )
    _finite_parameters(candidate)
    mse = _training_mse(candidate, data, config.batch_size, sample_weights)
    score = _training_mse(candidate, validation, config.batch_size) if validation is not None else mse
    status.update(
        accepted=True,
        before_train_mse=before_mse,
        after_train_mse=mse,
        before_selection_mse=before_score,
        after_selection_mse=score,
        selection_data="internal_validation" if validation is not None else "training_only",
    )
    return candidate, mse, score, status


def _resume_data_digest(data, validation, sample_weights):
    digest = hashlib.sha256()
    for label, block in (("training", data), ("validation", validation)):
        digest.update(label.encode())
        if block is None:
            digest.update(b"none")
            continue
        for name in ("history", "future_u", "future_y", "sequence", "time"):
            value = getattr(block, name)
            digest.update(name.encode())
            if value is None:
                digest.update(b"none")
            else:
                array = np.ascontiguousarray(value)
                digest.update(str((array.shape, array.dtype.str)).encode())
                digest.update(memoryview(array).cast("B"))
    if sample_weights is not None:
        digest.update(memoryview(np.ascontiguousarray(sample_weights)).cast("B"))
    return digest.hexdigest()


def fit_laplace(
    data: ModelData,
    config: LaplaceFitConfig,
    *,
    validation: ModelData | None = None,
    initial_fit: LaplaceFitResult | None = None,
    sample_weights: np.ndarray | None = None,
    resume_state: dict[str, Any] | None = None,
    epoch_callback: Callable[[dict[str, Any]], None] | None = None,
) -> LaplaceFitResult:
    """Freeze a checkpoint chosen on separate internal validation when supplied.

    Parameters are initialized after seeding. Epoch zero is the initialized
    model and is a valid candidate. When refinement is enabled, every candidate
    is refined on training windows before scoring and checkpoint selection.
    Adam's weight_decay is L2 weight regularization, not a penalty on the number
    of active mode models.
    The caller must purge raw support between fitting and validation windows.
    Neither split may contain the external segment-admission evidence. Warm
    starts copy weights, reset Adam and never mutate the parent checkpoint.
    A plateau is a heuristic, not a certificate of model adequacy.
    Exactly uniform positive weights use the same arithmetic as no weights.
    """

    if os.environ.get("HLC_READ_ONLY") == "1":
        raise RuntimeError("read-only audit attempted a new Laplace fit")
    if config.linear_readout_refinement_timing != "each_checkpoint":
        raise ValueError("retired readout timing is metadata-only and cannot train new models")
    if sample_weights is not None:
        sample_weights = np.asarray(sample_weights, dtype=np.float64)
        if sample_weights.shape != (len(data),) or not np.isfinite(sample_weights).all() or np.any(sample_weights <= 0):
            raise ValueError("sample_weights must contain one finite positive weight per complete window")
        # A full stratified sample has equal inclusion weights. Preserve the
        # unweighted fit exactly instead of introducing a different reduction
        # and readout path for an equivalent training objective.
        if np.all(sample_weights == sample_weights[0]):
            sample_weights = None
        else:
            sample_weights = sample_weights / sample_weights.mean()
    device = torch.device(config.device)
    dimensions = {
        "history_dim": data.history.shape[1],
        "input_dim": data.future_u.shape[2],
        "output_dim": data.future_y.shape[2],
        "horizon": data.future_u.shape[1],
    }
    if config.validation_fraction and validation is None:
        raise ValueError("validation_fraction requires an explicit purged internal validation split")
    if initial_fit is not None:
        if config.training_strategy == "cold_start":
            raise ValueError("cold_start must not receive an initial_fit")
        if initial_fit.dimensions != dimensions or initial_fit.config.transfer_mode != config.transfer_mode:
            raise ValueError("initial_fit architecture does not match")
        if initial_fit.model.architecture_version != "causal_laplace_convolution_v3":
            raise ValueError("legacy normalized checkpoints cannot initialize the unnormalized architecture")
    if validation is not None and any(
        getattr(validation, name).shape[1:] != getattr(data, name).shape[1:]
        for name in ("history", "future_u", "future_y")
    ):
        raise ValueError("internal validation dimensions do not match training")
    resume_binding = None
    if resume_state is not None or epoch_callback is not None:
        if config.device != "cpu" or initial_fit is not None or config.training_strategy != "cold_start":
            raise ValueError("epoch continuation currently requires a CPU cold start")
        resume_binding = {
            "format": "laplace_epoch_resume_v1", "config": asdict(config),
            "dimensions": dimensions, "data_sha256": _resume_data_digest(data, validation, sample_weights),
            "torch": str(torch.__version__), "numpy": np.__version__,
            "threads": torch.get_num_threads(),
        }
        if resume_state is not None:
            if resume_state.get("binding") != resume_binding:
                raise ValueError("epoch continuation data/configuration/runtime differs")
            completed = resume_state.get("epoch")
            if type(completed) is not int or not 0 <= completed <= config.epochs:
                raise ValueError("invalid completed epoch in continuation")
            if len(resume_state["log"]) != completed + 1 or any(
                row["epoch"] != index for index, row in enumerate(resume_state["log"])
            ):
                raise ValueError("incomplete epoch history in continuation")
            key = "validation_mse" if validation is not None else "train_mse"
            scores = [row[key] for row in resume_state["log"]]
            if any(not math.isfinite(v) or v < 0 for row in resume_state["log"] for v in (row[key], row["train_mse"])):
                raise ValueError("non-finite continuation score")
            best = min(range(len(scores)), key=scores.__getitem__)
            if (resume_state["best_epoch"] != best or resume_state["best_score"] != scores[best]
                    or resume_state["best_mse"] != resume_state["log"][best]["train_mse"]):
                raise ValueError("inconsistent selected continuation checkpoint")
            last = resume_state["last_significant_epoch"]
            if (type(last) is not int or not 0 <= last <= completed
                    or not math.isfinite(resume_state["significant_mse"])
                    or resume_state["significant_mse"] < resume_state["best_score"]):
                raise ValueError("invalid continuation convergence counters")
            expected_plateau = (config.convergence_patience is not None and completed >= config.min_epochs
                                and completed - last >= config.convergence_patience)
            if type(resume_state["plateau_reached"]) is not bool or resume_state["plateau_reached"] != expected_plateau:
                raise ValueError("invalid continuation plateau state")
    with _deterministic_training(config.seed, device):
        model = LaplaceNetOperator(
            **dimensions,
            hidden_dim=config.hidden_dim,
            laplace_points=config.laplace_points,
            sigma=config.laplace_sigma,
            sampling_time_seconds=config.sampling_time_seconds,
            transfer_mode=config.transfer_mode,
        ).to(device)
        if initial_fit is not None:
            model.load_state_dict(_cpu_copy(initial_fit.model.state_dict()))
            if config.training_strategy == "shrink_perturb":
                with torch.no_grad():
                    for parameter in model.parameters():
                        parameter.mul_(config.shrink_factor).add_(config.perturb_std * torch.randn_like(parameter))
        digest = hashlib.sha256()
        for name, parameter in model.state_dict().items():
            digest.update(name.encode())
            digest.update(parameter.detach().cpu().numpy().tobytes())
        initialization_digest = digest.hexdigest()
        optimizer = torch.optim.Adam(model.parameters(), lr=config.learning_rate, weight_decay=config.weight_decay)
        generator = np.random.default_rng(config.seed)
        _finite_parameters(model)
        monitor_name = "validation_mse" if validation is not None else "train_mse"
        if resume_state is None:
            candidate, best_mse, best_score, readout_status = _completed_candidate(
                model, data, validation, config, sample_weights
            )
            best_epoch = 0
            best_state = _cpu_copy(candidate.state_dict())
            best_optimizer = _optimizer_checkpoint(optimizer, refined=config.linear_readout_refinement)
            candidate_workspace = candidate if config.linear_readout_refinement else None
            log = [{"epoch": 0.0, "train_mse": best_mse}]
            if config.linear_readout_refinement:
                log[0]["gradient_train_mse"] = readout_status["before_train_mse"]
                log[0]["gradient_selection_mse"] = readout_status["before_selection_mse"]
            del candidate
            if validation is not None:
                log[0]["validation_mse"] = best_score
            significant_mse = best_score
            last_significant_epoch = 0
            plateau_reached = False
            completed = 0
        else:
            state = resume_state
            model.load_state_dict(state["gradient_model"])
            optimizer.load_state_dict(_cpu_copy(state["gradient_optimizer"]))
            generator.bit_generator.state = copy.deepcopy(state["numpy_generator"])
            torch.random.set_rng_state(state["torch_rng"])
            best_epoch, best_mse, best_score = state["best_epoch"], state["best_mse"], state["best_score"]
            best_state, best_optimizer = _cpu_copy(state["best_state"]), _cpu_copy(state["best_optimizer"])
            readout_status, log = copy.deepcopy(state["readout_status"]), copy.deepcopy(state["log"])
            significant_mse, last_significant_epoch = state["significant_mse"], state["last_significant_epoch"]
            plateau_reached = state["plateau_reached"]
            initialization_digest = state["initialization_digest"]
            candidate_workspace = None
            _finite_parameters(model)

        def emit_epoch(epoch):
            if epoch_callback is not None:
                callback_rng = torch.random.get_rng_state().clone()
                callback_np_rng = np.random.get_state()
                snapshot = {
                    "binding": copy.deepcopy(resume_binding), "epoch": epoch,
                    "gradient_model": _cpu_copy(model.state_dict()),
                    "gradient_optimizer": _cpu_copy(optimizer.state_dict()),
                    "numpy_generator": copy.deepcopy(generator.bit_generator.state),
                    "torch_rng": torch.random.get_rng_state().clone(),
                    "best_epoch": best_epoch, "best_mse": best_mse, "best_score": best_score,
                    "best_state": _cpu_copy(best_state), "best_optimizer": _cpu_copy(best_optimizer),
                    "readout_status": copy.deepcopy(readout_status), "log": copy.deepcopy(log),
                    "significant_mse": significant_mse, "last_significant_epoch": last_significant_epoch,
                    "plateau_reached": plateau_reached, "initialization_digest": initialization_digest,
                }
                try:
                    epoch_callback(snapshot)
                finally:
                    torch.random.set_rng_state(callback_rng)
                    np.random.set_state(callback_np_rng)

        if resume_state is None:
            emit_epoch(0)
        for epoch in range(completed + 1, config.epochs + 1):
            if plateau_reached:
                break
            model.train()
            permutation = generator.permutation(len(data))
            for start in range(0, len(data), config.batch_size):
                indices = permutation[start : start + config.batch_size]
                history_tensor, u_tensor, y_tensor = _tensor_batch(data, indices, device)
                optimizer.zero_grad(set_to_none=True)
                prediction = model(history_tensor, u_tensor)
                if sample_weights is not None:
                    weights = torch.as_tensor(sample_weights[indices], dtype=torch.float32, device=device)
                    loss = torch.mean(torch.mean((prediction - y_tensor) ** 2, dim=(1, 2)) * weights)
                else:
                    loss = torch.mean((prediction - y_tensor) ** 2)
                if not torch.isfinite(loss):
                    raise FloatingPointError(f"non-finite Laplace-Net training loss at epoch {epoch}")
                loss.backward()
                finite_gradients = torch.stack(
                    [
                        torch.isfinite(parameter.grad).all()
                        for parameter in model.parameters()
                        if parameter.grad is not None
                    ]
                )
                if not finite_gradients.all():
                    raise FloatingPointError(f"non-finite Laplace-Net gradient at epoch {epoch}")
                torch.nn.utils.clip_grad_norm_(model.parameters(), config.gradient_clip, error_if_nonfinite=True)
                optimizer.step()
                _finite_parameters(model)
            candidate, mse, score, candidate_readout = _completed_candidate(
                model, data, validation, config, sample_weights, workspace=candidate_workspace
            )
            if config.linear_readout_refinement:
                candidate_workspace = candidate
            squared_norm = float(
                torch.stack([torch.sum(parameter.detach().double() ** 2) for parameter in candidate.parameters()])
                .sum()
                .item()
            )
            log.append(
                {"epoch": float(epoch), "train_mse": mse, "l2_penalty": 0.5 * config.weight_decay * squared_norm}
            )
            if validation is not None:
                log[-1]["validation_mse"] = score
            if config.linear_readout_refinement:
                log[-1]["gradient_train_mse"] = candidate_readout["before_train_mse"]
                log[-1]["gradient_selection_mse"] = candidate_readout["before_selection_mse"]
            if score < best_score:
                best_mse, best_epoch = mse, epoch
                best_score = score
                best_state = _cpu_copy(candidate.state_dict())
                best_optimizer = _optimizer_checkpoint(optimizer, refined=config.linear_readout_refinement)
                readout_status = candidate_readout
            del candidate
            improvement = significant_mse - best_score
            relative_scale = max(abs(significant_mse), float(np.finfo(np.float64).tiny))
            if improvement > config.convergence_relative_tolerance * relative_scale:
                significant_mse = best_score
                last_significant_epoch = epoch
            if (
                config.convergence_patience is not None
                and epoch >= config.min_epochs
                and epoch - last_significant_epoch >= config.convergence_patience
            ):
                plateau_reached = True
            emit_epoch(epoch)
            if plateau_reached:
                break
        model.load_state_dict(best_state)
        model.eval()
        model.requires_grad_(False)
    epochs_completed = len(log) - 1
    trailing_window = min(config.convergence_patience or 10, epochs_completed)
    window_start = epochs_completed - trailing_window
    previous_best = min(row[monitor_name] for row in log[: window_start + 1])
    trailing_improvement = (previous_best - best_score) / max(abs(previous_best), float(np.finfo(np.float64).tiny))
    examples_processed = epochs_completed * len(data)
    parent_work = 0 if initial_fit is None else int(initial_fit.training_status["cumulative_examples_processed"])
    training_status = {
        "training_weighting": "inverse_inclusion_probability" if sample_weights is not None else "equal_window",
        "stop_reason": (
            ("validation_plateau" if validation is not None else "training_plateau")
            if plateau_reached
            else "epoch_budget_exhausted"
        ),
        "plateau_reached": plateau_reached,
        "epochs_completed": epochs_completed,
        "epochs_budget": config.epochs,
        "min_epochs": config.min_epochs,
        "convergence_patience": config.convergence_patience,
        "convergence_relative_tolerance": config.convergence_relative_tolerance,
        "last_significant_improvement_epoch": last_significant_epoch,
        "trailing_window_epochs": trailing_window,
        "trailing_relative_best_mse_improvement": float(trailing_improvement),
        "criterion_data": "internal_validation" if validation is not None else "training_only",
        "checkpoint_selection": "minimum internal-validation MSE"
        if validation is not None
        else "minimum full-training MSE, no evidence or test data",
        "best_selection_mse": best_score,
        "training_windows": len(data),
        "internal_validation_windows": 0 if validation is None else len(validation),
        "initialization_digest": initialization_digest,
        "training_strategy": config.training_strategy,
        "warm_start_used": initial_fit is not None,
        "optimizer_reset": True,
        "examples_processed": examples_processed,
        "gradient_updates": epochs_completed * math.ceil(len(data) / config.batch_size),
        "cumulative_examples_processed": parent_work + examples_processed,
        "convergence_guarantee": False,
        "linear_readout_refinement": readout_status,
        "checkpoint_candidates": epochs_completed + 1,
        "checkpoint_refinement_order": "fit_then_readout_then_score"
        if config.linear_readout_refinement
        else "fit_then_score",
        "readout_solves": epochs_completed + 1 if config.linear_readout_refinement else 0,
        "readout_training_windows_processed": (epochs_completed + 1) * len(data)
        if config.linear_readout_refinement
        else 0,
        "optimizer_checkpoint_scope": "reset_after_readout" if config.linear_readout_refinement else "selected_epoch",
        "checkpoint_score_device": "cpu" if config.linear_readout_refinement else str(device),
    }
    LOGGER.info(
        "Laplace-Net fit: windows=%d best_epoch=%d training_mse=%.8g device=%s stop_reason=%s epochs_completed=%d",
        len(data),
        best_epoch,
        best_mse,
        device,
        training_status["stop_reason"],
        epochs_completed,
    )
    return LaplaceFitResult(model, config, log, best_epoch, best_mse, best_optimizer, dimensions, training_status)


def predict_laplace(model: LaplaceNetOperator, data: ModelData, batch_size: int = 256) -> np.ndarray:
    """Predict windows in caller order, without modifying data or model weights."""

    if not isinstance(model, LaplaceNetOperator):
        raise TypeError("prediction requires an actual LaplaceNetOperator")
    if not isinstance(batch_size, int) or isinstance(batch_size, bool) or batch_size < 1:
        raise ValueError("batch_size must be a positive integer")
    if data.future_u.shape[1:] != (model.horizon, model.input_dim):
        raise ValueError("future_u shape does not match the Laplace-Net horizon and input dimensions")
    if data.future_y.shape[1:] != (model.horizon, model.output_dim):
        raise ValueError("future_y shape does not match the Laplace-Net horizon and output dimensions")
    device = next(model.parameters()).device
    predictions: list[np.ndarray] = []
    model.eval()
    with torch.inference_mode():
        for start in range(0, len(data), batch_size):
            selected = slice(start, start + batch_size)
            history_tensor = torch.as_tensor(data.history[selected], dtype=torch.float32, device=device)
            u_tensor = torch.as_tensor(data.future_u[selected], dtype=torch.float32, device=device)
            prediction = model(history_tensor, u_tensor)
            if not torch.isfinite(prediction).all():
                raise FloatingPointError("Laplace-Net produced non-finite predictions")
            predictions.append(prediction.cpu().numpy().copy())
    return np.concatenate(predictions, axis=0)


def window_rmse(model: LaplaceNetOperator, data: ModelData, batch_size: int = 256) -> np.ndarray:
    """Return one root mean squared error across horizon and channels per window."""

    errors = predict_laplace(model, data, batch_size).astype(np.float64) - data.future_y
    return np.sqrt(np.mean(errors**2, axis=(1, 2)))


@dataclass(frozen=True)
class NoiseEstimate:
    """Heuristic noise scale, never a deterministic bound on disturbances."""

    delta: float
    per_channel: np.ndarray
    raw_per_channel: np.ndarray
    sampled_windows: tuple[dict[str, Any], ...]
    seed: int
    window_length: int

    def to_dict(self) -> dict[str, Any]:
        """Return JSON-compatible provenance and unambiguous units."""

        return {
            "delta": self.delta,
            "per_channel": self.per_channel.tolist(),
            "raw_per_channel": self.raw_per_channel.tolist(),
            "sampled_windows": copy.deepcopy(list(self.sampled_windows)),
            "seed": self.seed,
            "window_length": self.window_length,
            "method": "median window MAD after local linear detrending, Gaussian MAD factor and approximate degrees-of-freedom correction",
            "units": "delta is RMS of per-channel standard-deviation estimates divided by training output_scale, matching normalized block RMSE units",
            "hard_bound": False,
            "limitations": [
                "rapid dynamics and mode changes can inflate the estimate",
                "correlated or non-Gaussian noise changes calibration",
                "not a confidence bound on prediction error",
            ],
        }


def estimate_noise_delta(
    trajectories: Sequence[np.ndarray],
    output_scale: np.ndarray,
    seed: int = 0,
    windows_per_trajectory: int = 12,
    window_length: int = 9,
) -> NoiseEstimate:
    """Sample each training trajectory and robustly summarize detrended noise.

    Every trajectory receives the same requested sample budget. Window starts
    are sampled without replacement within a trajectory. Overlap is allowed
    and no independence or finite-sample confidence guarantee is claimed.
    """

    if len(trajectories) < 1:
        raise ValueError("at least one training trajectory is required for delta estimation")
    for name, value, minimum in (
        ("windows_per_trajectory", windows_per_trajectory, 1),
        ("window_length", window_length, 5),
    ):
        if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
            raise ValueError(f"{name} must be an integer >= {minimum}")
    if isinstance(seed, bool) or not isinstance(seed, int) or not 0 <= seed < 2**32:
        raise ValueError("seed must be an integer in [0, 2**32)")
    scale = np.asarray(output_scale, dtype=np.float64)
    if scale.ndim != 1 or len(scale) == 0 or not np.isfinite(scale).all() or np.any(scale <= 0):
        raise ValueError("output_scale must be a finite, positive one-dimensional channel scale")
    generator = np.random.default_rng(seed)
    time = np.linspace(-1.0, 1.0, window_length)
    design = np.column_stack((np.ones(window_length), time))
    gaussian_mad_factor = 1.0 / 0.6744897501960817
    dof_correction = math.sqrt(window_length / (window_length - 2))
    trajectory_scales: list[np.ndarray] = []
    positions: list[dict[str, Any]] = []
    for trajectory_index, values in enumerate(trajectories):
        array = np.asarray(values, dtype=np.float64)
        if array.ndim != 2 or array.shape[1] != len(scale) or len(array) < window_length:
            raise ValueError(
                f"trajectory {trajectory_index} must have at least {window_length} samples and {len(scale)} channels"
            )
        if not np.isfinite(array).all():
            raise ValueError(f"trajectory {trajectory_index} contains NaN or infinity")
        count = len(array) - window_length + 1
        starts = np.sort(generator.choice(count, size=min(count, windows_per_trajectory), replace=False))
        window_scales: list[np.ndarray] = []
        for start_value in starts:
            start = int(start_value)
            window = array[start : start + window_length]
            coefficient = np.linalg.lstsq(design, window, rcond=None)[0]
            residual = window - design @ coefficient
            centered = residual - np.median(residual, axis=0)
            sigma = gaussian_mad_factor * dof_correction * np.median(np.abs(centered), axis=0)
            window_scales.append(sigma)
            positions.append(
                {
                    "trajectory": trajectory_index,
                    "start": start,
                    "stop_exclusive": start + window_length,
                    "raw_per_channel": sigma.tolist(),
                }
            )
        trajectory_scales.append(np.median(np.stack(window_scales), axis=0))
    raw = np.median(np.stack(trajectory_scales), axis=0)
    normalized = raw / scale
    delta = float(np.sqrt(np.mean(normalized**2)))
    if not np.isfinite(normalized).all() or not math.isfinite(delta):
        raise FloatingPointError("noise estimation produced non-finite scaled values")
    LOGGER.info(
        "Heuristic delta=%.8g from %d windows over %d trajectories, not a hard bound",
        delta,
        len(positions),
        len(trajectories),
    )
    return NoiseEstimate(delta, normalized, raw, tuple(positions), seed, window_length)


def _indices(indices: np.ndarray | Sequence[int], size: int) -> np.ndarray:
    array = np.asarray(indices)
    if array.ndim != 1 or array.dtype.kind not in "iu" or len(array) < 1:
        raise ValueError("indices must be a nonempty integer vector")
    if np.any(array < 0) or np.any(array >= size) or len(np.unique(array)) != len(array):
        raise ValueError("indices must be unique and within the data bounds")
    return array.astype(np.int64, copy=True)


@dataclass(frozen=True)
class PurgedSplit:
    """Original data indices, with every train/evidence raw overlap removed."""

    train: np.ndarray
    evidence: np.ndarray
    purged: np.ndarray


def purged_blocked_split(
    data: ModelData,
    indices: np.ndarray | Sequence[int],
    history: int,
    horizon: int,
    evidence_fraction: float = 0.25,
) -> PurgedSplit:
    """Reserve each sequence's last block and purge overlapping training windows.

    The caller provides indices of an already selected segment or group.
    Sequence and prediction-origin metadata are mandatory. Too little
    support raises an error rather than silently accepting a merge.
    """

    if data.sequence is None or data.time is None:
        raise ValueError("purged splitting requires sequence and time metadata")
    for name, value in (("history", history), ("horizon", horizon)):
        if isinstance(value, bool) or not isinstance(value, int) or value < 1:
            raise ValueError(f"{name} must be a positive integer")
    if horizon != data.future_u.shape[1]:
        raise ValueError("horizon must match the data horizon")
    if not math.isfinite(evidence_fraction) or not 0 < evidence_fraction < 1:
        raise ValueError("evidence_fraction must lie strictly between zero and one")
    chosen = _indices(indices, len(data))
    train: list[int] = []
    evidence: list[int] = []
    purged: list[int] = []
    for sequence_id in np.unique(data.sequence[chosen]):
        group = chosen[data.sequence[chosen] == sequence_id]
        group = group[np.argsort(data.time[group], kind="stable")]
        if len(np.unique(data.time[group])) != len(group):
            raise ValueError(f"sequence {sequence_id} has duplicate prediction origins")
        evidence_count = max(1, math.ceil(len(group) * evidence_fraction))
        fit_candidates = group[:-evidence_count]
        held = group[-evidence_count:]
        first_evidence_raw_time = int(np.min(data.time[held])) - history
        keep = data.time[fit_candidates] < first_evidence_raw_time - horizon
        fitting = fit_candidates[keep]
        if len(fitting) < 1:
            raise ValueError(f"sequence {sequence_id} has insufficient support for a purged training/evidence split")
        train.extend(fitting.tolist())
        evidence.extend(held.tolist())
        purged.extend(fit_candidates[~keep].tolist())
    return PurgedSplit(
        np.array(train, dtype=np.int64), np.array(evidence, dtype=np.int64), np.array(purged, dtype=np.int64)
    )
