"""Bound frozen-model adapter. Derived from the audited TEP NumPy reader."""
from pathlib import Path
from collections import OrderedDict
import io,pickle,zipfile,json
import numpy as np

def read_torch_float_checkpoint(path):
    """Decode this bound, float-only Torch ZIP without importing Torch.

    Only three explicitly permitted pickle globals can be reconstructed.
    Optimizers and custom classes cannot be executed by this reader.
    """
    with zipfile.ZipFile(path) as archive:
        prefix = next(n[:-8] for n in archive.namelist() if n.endswith('data.pkl'))
        assert archive.read(prefix+'byteorder') == b'little'

        def rebuild(storage, offset, size, stride, requires_grad, hooks, *extra):
            return np.lib.stride_tricks.as_strided(
                storage[offset:], shape=size,
                strides=tuple(4*s for s in stride), writeable=False).copy()

        class Reader(pickle.Unpickler):
            def find_class(self, module, name):
                permitted = {('collections', 'OrderedDict'): OrderedDict,
                             ('torch', 'FloatStorage'): 'float32',
                             ('torch._utils', '_rebuild_tensor_v2'): rebuild}
                if (module, name) not in permitted:
                    raise ValueError('Unsupported checkpoint global: '+module+'.'+name)
                return permitted[module, name]

            def persistent_load(self, item):
                kind, dtype, key, device, length = item
                assert kind == 'storage' and dtype == 'float32'
                value = np.frombuffer(archive.read(prefix+'data/'+key), dtype='<f4')
                assert len(value) == length
                return value

        return Reader(io.BytesIO(archive.read(prefix+'data.pkl'))).load()

class FrozenModel:
    def __init__(self, base):
        base = Path(base)
        saved = read_torch_float_checkpoint(base/'model.pt')
        assert saved['architecture_version'] == 'causal_laplace_convolution_v3'
        assert saved['dimensions']['horizon'] == 1
        assert saved['config']['transfer_mode'] == 'fixed'
        self.w = saved['state_dict']
        self.scaler = dict(np.load(base/'scaler.npz', allow_pickle=False))
        self.frozen = json.loads((base/'frozen.json').read_text())
        cfg = saved['config']
        self.dt = cfg['sampling_time_seconds']
        frequencies = np.arange(cfg['laplace_points'], dtype=np.float32) * np.float32(np.pi/self.dt)
        s = np.full_like(frequencies, cfg['laplace_sigma']) + np.complex64(1j)*frequencies
        inverse = np.exp(s*np.float32(self.dt)).astype(np.complex64)
        inverse[0] *= np.float32(.5)
        self.inverse = inverse
        transfer = self.w['fixed_transfer']
        z = transfer[..., 0] + np.complex64(1j)*transfer[..., 1]
        self.g = np.float32(2)*np.einsum('koi,k->oi', z, inverse).real
        self.error = np.asarray(self.frozen['error_scale']).reshape(-1)*self.frozen['threshold']

    def at(self, u, y, target):
        """Original one-based target sample. u[t] predicts y[t+1]."""
        origin = target-2
        s = self.scaler
        un, yn = (u-s['um'])/s['us'], (y-s['ym'])/s['ys']
        history = np.r_[un[origin-10:origin].ravel(), yn[origin-10:origin+1].ravel()].astype('f4')
        x = np.tanh(self.w['encoder.0.weight'] @ history + self.w['encoder.0.bias'])
        x = np.tanh(self.w['encoder.3.weight'] @ x + self.w['encoder.3.bias'])
        free = (self.w['free_head.weight'] @ x + self.w['free_head.bias']).reshape(-1, 22, 2)
        z = free[..., 0] + np.complex64(1j)*free[..., 1]
        b = np.float32(2/self.dt)*np.einsum('ko,k->o', z, self.inverse).real
        current_u = un[origin].astype('f4')
        target_y = yn[origin+1].astype('f4')
        pred = b + self.g @ current_u
        return {'history': history, 'u': current_u, 'y': target_y,
                'b': b, 'prediction': pred, 'residual': target_y-pred}
