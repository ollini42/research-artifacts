"""Full healthy training, validation selection, exact epoch continuation."""
import copy
import os
from pathlib import Path
import time
import numpy as np
import torch
from common import ROOT, read, save, atomic_json, dataset, experiment_binding, sha, validate_candidate
from model import PlantLSTM, configure


def runtime(device):
    return dict(torch=str(torch.__version__),cuda=torch.version.cuda,device=str(device),
                gpu=torch.cuda.get_device_name(0) if str(device).startswith('cuda') else None)


def checkpoint(path,value):
    temporary=Path(path).with_suffix('.tmp')
    torch.save(value,temporary)
    with temporary.open('rb') as stream:
        os.fsync(stream.fileno())
    os.replace(temporary,path)


def fit(train,valid,seed,lr,epochs,path,device='cuda',binding=None,budget_seconds=None):
    path=Path(path)
    configure()
    torch.manual_seed(seed)
    if str(device).startswith('cuda'):
        torch.cuda.manual_seed_all(seed)
    model=PlantLSTM().to(device)
    opt=torch.optim.Adam(model.parameters(),lr=lr,weight_decay=1e-5)
    generator=torch.Generator().manual_seed(seed+1)
    data=[tuple(torch.tensor(w[k],device=device) for k in ('history','command','target')) for w in (train,valid)]
    identity=dict(seed=seed,lr=lr,epochs=epochs,binding=binding,runtime=runtime(device),
                  training_windows=len(train['history']),validation_windows=len(valid['history']))
    def measure(w):
        model.eval()
        with torch.no_grad():
            return float(torch.mean((model(w[0],w[1])-w[2])**2).item())
    start=0
    trace=[]
    best_epoch=0
    best_loss=measure(data[1])
    trace.append(dict(epoch=0,training_mse=measure(data[0]),validation_mse=best_loss))
    best={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
    if path.exists():
        saved=torch.load(path,map_location='cpu',weights_only=False)
        if saved['identity']!=identity:
            raise ValueError('checkpoint identity or hardware differs')
        model.load_state_dict(saved['model'])
        opt.load_state_dict(saved['optimizer'])
        generator.set_state(saved['shuffle'])
        torch.set_rng_state(saved['rng_cpu'])
        if str(device).startswith('cuda'):
            torch.cuda.set_rng_state_all(saved['rng_cuda'])
        start=saved['epoch']
        trace=saved['trace']
        best_epoch=saved['best_epoch']
        best_loss=saved['best_loss']
        best=saved['best']
    begin=time.monotonic()
    for epoch in range(start+1,epochs+1):
        model.train()
        order=torch.randperm(len(data[0][0]),generator=generator).to(device)
        for idx in order.split(4096):
            opt.zero_grad(set_to_none=True)
            pred=model(data[0][0][idx],data[0][1][idx])
            loss=torch.mean((pred-data[0][2][idx])**2)
            if not torch.isfinite(loss):
                raise ValueError('nonfinite training loss')
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),5.)
            opt.step()
        val=measure(data[1])
        training=measure(data[0])
        if not np.isfinite(val):raise ValueError('nonfinite validation loss')
        trace.append(dict(epoch=epoch,training_mse=training,validation_mse=val))
        if val<best_loss:
            best_loss=val
            best_epoch=epoch
            best={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
        pause=budget_seconds is not None and time.monotonic()-begin>=budget_seconds
        if epoch%20==0 or epoch==epochs or pause:
            checkpoint(path,dict(identity=identity,epoch=epoch,model=model.state_dict(),optimizer=opt.state_dict(),
                shuffle=generator.get_state(),rng_cpu=torch.get_rng_state(),
                rng_cuda=torch.cuda.get_rng_state_all() if str(device).startswith('cuda') else [],
                trace=trace,best_epoch=best_epoch,best_loss=best_loss,best=best))
            atomic_json(path.with_suffix('.progress.json'),dict(seed=seed,lr=lr,epoch=epoch,
                best_epoch=best_epoch,best_validation_mse=best_loss,seconds=time.monotonic()-begin,
                start_epoch=start,complete=epoch==epochs,updated_unix=time.time()))
        if pause and epoch<epochs:return None
    return dict(identity=identity,epochs_completed=epochs,validation_mse=best_loss,best_epoch=best_epoch,
                state_dict={k:v.tolist() for k,v in best.items()},trace=trace)


def run_seed(seed):
    plan=read(ROOT/'plan.json')
    folder=ROOT/'training'/str(seed)
    folder.mkdir(parents=True,exist_ok=True,mode=0o700)
    import fcntl
    with (folder/'lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        train=dataset(seed,'train')
        valid=dataset(seed,'validation')
        if (len(train['history']),len(valid['history']))!=(73350,24450):
            raise ValueError('training or validation window loss')
        choices=[]
        job_start=time.monotonic()
        for i,lr in enumerate(plan['training']['learning_rates']):
            target=folder/f'candidate_{i}.json'
            if target.exists():
                result=read(target)
                validate_candidate(result,seed,lr)
            else:
                result=fit(train,valid,seed,lr,2560,folder/f'checkpoint_{i}.pt',binding=experiment_binding(),
                           budget_seconds=max(0,plan['training']['pause_seconds']-(time.monotonic()-job_start)))
                if result is None:return False
                validate_candidate(result,seed,lr)
                save(target,result)
            choices.append(result)
        chosen=min(range(len(choices)),key=lambda i:(choices[i]['validation_mse'],i))
        if not (folder/'selected.json').exists():
            save(folder/'selected.json',dict(candidate=chosen,validation_mse=choices[chosen]['validation_mse'],
                best_epoch=choices[chosen]['best_epoch'],candidate_sha256=sha(folder/f'candidate_{chosen}.json'),
                **experiment_binding()))
    return True
