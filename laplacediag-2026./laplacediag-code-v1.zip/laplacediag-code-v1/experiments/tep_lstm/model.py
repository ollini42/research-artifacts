"""Independent one-step LSTM. No LaplaceNet operator or predictions as inputs."""
import torch
from torch import nn

class PlantLSTM(nn.Module):
    def __init__(self):
        super().__init__()
        self.encoder=nn.LSTM(34,22,batch_first=True)
        self.decoder=nn.LSTM(11,22,batch_first=True)
        self.output=nn.Linear(22,22)

    def forward(self,history,command):
        _,state=self.encoder(history)
        values,_=self.decoder(command,state)
        return self.output(values)

def configure(threads=2):
    torch.set_num_threads(threads)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.deterministic=True
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
