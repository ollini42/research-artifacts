"""Read only the existing, hash-bound TEP files. No R code is executed."""
import gzip
import numpy as np
import read_rdata as prior

class StreamingReader:
    def __init__(self, stream, faults, runs):
        self.faults, self.runs = faults, runs
        self.stream, self.refs, self.pos = stream, [], 0
        self.large_index = 0
        self.keep = None

    def take(self, n):
        if n < 0:
            raise ValueError("Negative length")
        value = self.stream.read(n)
        self.pos += len(value)
        if len(value) != n:
            raise ValueError("Truncated stream")
        return value

    integer = prior.Reader.integer

    def item(self):
        flags = self.integer()
        kind = flags & 255
        if kind == 254:
            return None
        if kind == 255:
            index = flags >> 8 or self.integer()
            if not 1 <= index <= len(self.refs):
                raise ValueError("Invalid reference")
            return self.refs[index-1]
        if kind == 1:
            value = self.item()
            assert isinstance(value, str)
            self.refs.append(value)
            return value
        attr, tag = bool(flags & 512), bool(flags & 1024)
        if kind == 2:
            attrs = self.item() if attr else None
            name = self.item() if tag else None
            return ("pair", name, self.item(), self.item(), attrs)
        if tag:
            raise ValueError("Unexpected tag")
        n = self.integer()
        if n < 0:
            raise ValueError("Unsupported long vector")
        if kind == 9:
            value = self.take(n).decode("utf8")
        elif kind in (13, 14):
            dtype = ">i4" if kind == 13 else ">f8"
            value = np.frombuffer(self.take(n*np.dtype(dtype).itemsize), dtype=dtype)
            if n == 9600000:
                idx = self.large_index
                self.large_index += 1
                if idx == 0:
                    self.keep = np.isin(value, self.faults)
                    self.first = value
                elif idx == 1:
                    self.keep &= np.isin(value, self.runs)
                    self.selected_first = self.first[self.keep].copy()
                    del self.first
                if idx != 0:
                    value = value[self.keep].copy()
            elif n > 1000000:
                raise ValueError("Unexpected large vector length")
        elif kind in (16, 19):
            value = [self.item() for _ in range(n)]
        else:
            raise ValueError("Unsupported inert kind " + str(kind))
        return ("attributed", value, self.item()) if attr else value

def load_frame(path, name, faults=None, runs=None):
    if faults is None:
        return prior.read_frame(path, name)[0]
    with gzip.open(path, "rb") as stream:
        reader = StreamingReader(stream, faults, runs)
        if reader.take(7) != b"RDX2\nX\n" or reader.integer() != 2:
            raise ValueError("Unexpected R serialization")
        reader.integer()
        reader.integer()
        objects = prior.pairs(reader.item())
        if stream.read(1) or set(objects) != {name}:
            raise ValueError("Unexpected R object or trailing data")
    obj = objects[name]
    names = prior.pairs(obj[2])["names"]
    expected = ["faultNumber", "simulationRun", "sample"] + [f"xmeas_{j}" for j in range(1,42)] + [f"xmv_{j}" for j in range(1,12)]
    if names != expected or reader.large_index != 55:
        raise ValueError("Unexpected TEP schema")
    frame = dict(zip(names, obj[1]))
    frame["faultNumber"] = reader.selected_first
    if any(len(v) != len(runs)*len(faults)*960 or not np.isfinite(v).all() for v in frame.values()):
        raise ValueError("Incomplete or invalid test population")
    return frame

def signals(frame, run, fault, length):
    mask = (frame["faultNumber"]==fault) & (frame["simulationRun"]==run)
    if not np.array_equal(frame["sample"][mask], np.arange(1,length+1)):
        raise ValueError("Wrong sample sequence")
    u = np.column_stack([frame[f"xmv_{j}"][mask] for j in range(1,12)])
    y = np.column_stack([frame[f"xmeas_{j}"][mask] for j in range(1,23)])
    if not np.isfinite(u).all() or not np.isfinite(y).all():
        raise ValueError("Nonfinite observations")
    return u[:-1], y
