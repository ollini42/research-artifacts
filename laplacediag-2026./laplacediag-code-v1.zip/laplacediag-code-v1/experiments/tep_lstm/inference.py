"""Optimizer-free NumPy reconstruction of the independently trained LSTM."""
import numpy as np

def predict(state,history,command):
    state={k:np.asarray(v,dtype=float) for k,v in state.items()}
    n=len(history)
    hidden=state['output.weight'].shape[1]
    h=np.zeros((n,hidden)); c=np.zeros_like(h)
    def step(x,h,c,prefix):
        a=x@state[prefix+'.weight_ih_l0'].T+h@state[prefix+'.weight_hh_l0'].T
        a+=state[prefix+'.bias_ih_l0']+state[prefix+'.bias_hh_l0']
        i,f,g,o=np.split(a,4,axis=1)
        sig=lambda z:1/(1+np.exp(-np.clip(z,-700,700)))
        c=sig(f)*c+sig(i)*np.tanh(g)
        return sig(o)*np.tanh(c),c
    for t in range(history.shape[1]): h,c=step(history[:,t],h,c,'encoder')
    result=[]
    for t in range(command.shape[1]):
        h,c=step(command[:,t],h,c,'decoder')
        result.append(h@state['output.weight'].T+state['output.bias'])
    return np.stack(result,axis=1)

def signatures(state,history,command,epsilon=.001):
    pred=predict(state,history,command)
    columns=[]
    for actor in (3,9):
        plus=command.astype(float).copy(); minus=plus.copy()
        plus[:,:,actor]*=1+epsilon; minus[:,:,actor]*=1-epsilon
        columns.append((predict(state,history,plus)-predict(state,history,minus))/(2*epsilon))
    return pred[:,0],np.stack(columns,axis=-1)[:,0]
