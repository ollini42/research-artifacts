"""Narrow read-only RDX2 numeric-data-frame decoder for the bound TEP file.

R Core Team, R Internals, section 1.8 documents flags, ordering and XDR.
Only inert data types are accepted. No R evaluation or object hooks occur.
"""
import gzip
import struct
import numpy as np


class Reader:
    def __init__(self, data):
        self.data, self.pos, self.refs = memoryview(data), 0, []

    def take(self, n):
        if n < 0 or self.pos+n > len(self.data):
            raise ValueError('Truncated or invalid serialized length')
        result = self.data[self.pos:self.pos+n]
        self.pos += n
        return result

    def integer(self):
        return struct.unpack('>i', self.take(4))[0]

    def item(self):
        flags = self.integer()
        kind = flags & 255
        if kind == 254:
            return None
        if kind == 255:
            index = flags >> 8 or self.integer()
            if not 1 <= index <= len(self.refs):
                raise ValueError('Invalid reference')
            return self.refs[index-1]
        if kind == 1:
            value = self.item()
            if not isinstance(value, str):
                raise ValueError('Non-string symbol')
            self.refs.append(value)
            return value
        attr, tag = bool(flags & 512), bool(flags & 1024)
        if kind == 2:
            attrs = self.item() if attr else None
            name = self.item() if tag else None
            return ('pair', name, self.item(), self.item(), attrs)
        if tag:
            raise ValueError('Unexpected tag')
        n = self.integer()
        if n < 0:
            raise ValueError('Missing or long vectors unsupported')
        if kind == 9:
            value = bytes(self.take(n)).decode('utf8')
        elif kind in (13, 14):
            dtype = '>i4' if kind == 13 else '>f8'
            value = np.frombuffer(self.take(n*np.dtype(dtype).itemsize), dtype=dtype)
        elif kind in (16, 19):
            value = [self.item() for _ in range(n)]
        else:
            raise ValueError('Unsupported inert data type: '+str(kind))
        return ('attributed', value, self.item()) if attr else value


def pairs(value):
    result = {}
    while value is not None:
        if not isinstance(value, tuple) or value[0] != 'pair':
            raise ValueError('Expected pair list')
        _, name, car, value, attrs = value
        if name in result or attrs is not None:
            raise ValueError('Duplicate tag or unsupported attributes')
        result[name] = car
    return result


def read_frame(path, expected_name):
    with gzip.open(path, 'rb') as stream:
        data = stream.read()
    reader = Reader(data)
    if bytes(reader.take(7)) != b'RDX2\nX\n' or reader.integer() != 2:
        raise ValueError('Expected RDX2 XDR version 2')
    versions = [reader.integer(), reader.integer()]
    objects = pairs(reader.item())
    if reader.pos != len(reader.data) or set(objects) != {expected_name}:
        raise ValueError('Unexpected object or trailing bytes')
    obj = objects[expected_name]
    if not isinstance(obj, tuple) or obj[0] != 'attributed':
        raise ValueError('Expected attributed data frame')
    attrs = pairs(obj[2])
    if 'data.frame' not in attrs['class']:
        raise ValueError('Not a data frame')
    names = attrs['names']
    if len(names) != len(set(names)) or len(names) != len(obj[1]):
        raise ValueError('Invalid column names')
    frame = dict(zip(names, obj[1]))
    lengths = {len(x) for x in frame.values()}
    if len(lengths) != 1 or any(not isinstance(x, np.ndarray) for x in frame.values()):
        raise ValueError('Invalid numeric columns')
    return frame, {'r_versions_packed': versions, 'rows': lengths.pop(),
                   'columns': names, 'complete_stream_consumed': True}
