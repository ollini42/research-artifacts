"""Native parity and exact epoch continuation for the production training loop."""
import numpy as np
import pytest
import torch
from model import PlantLSTM,configure
from inference import predict,signatures
from train import fit

def tiny():
    rng=np.random.default_rng(13)
    return dict(history=rng.normal(size=(12,11,34)).astype('f4'),
                command=rng.normal(size=(12,1,11)).astype('f4'),target=rng.normal(size=(12,1,22)).astype('f4'))

@pytest.mark.parametrize('device',['cpu','cuda'])
def test_native_numpy_and_sensitivity(device):
    assert device!='cuda' or torch.cuda.is_available()
    configure();torch.manual_seed(52);m=PlantLSTM().to(device);d=tiny()
    with torch.no_grad(): out=m(torch.tensor(d['history'],device=device),torch.tensor(d['command'],device=device)).cpu().numpy()
    state={k:v.detach().cpu().numpy() for k,v in m.state_dict().items()}
    np.testing.assert_allclose(out,predict(state,d['history'],d['command']),rtol=1e-4,atol=1e-6)
    _,sig=signatures(state,d['history'],d['command'])
    h=torch.tensor(d['history'],device=device);c=torch.tensor(d['command'],device=device,requires_grad=True)
    y=m(h,c)
    for k in (0,7,21):
        gradient=torch.autograd.grad(y[:,0,k].sum(),c,retain_graph=True)[0].cpu().numpy()[:,0]
        for j,actor in enumerate((3,9)):
            np.testing.assert_allclose(sig[:,k,j],gradient[:,actor]*d['command'][:,0,actor],rtol=2e-3,atol=1e-6)

@pytest.mark.parametrize('device',['cpu','cuda'])
def test_exact_epoch_resume(tmp_path,device):
    d=tiny();v=tiny()
    full=fit(d,v,33,.003,3,tmp_path/'full.pt',device)
    assert fit(d,v,33,.003,3,tmp_path/'resume.pt',device,budget_seconds=0) is None
    resumed=fit(d,v,33,.003,3,tmp_path/'resume.pt',device)
    assert full==resumed

def test_capacity():
    assert sum(p.numel() for p in PlantLSTM().parameters())==8690
