"""Four-parameter effect changes and joint two-actuator projection."""
import numpy as np

def center(a): return np.asarray(a,dtype=float)-np.mean(a,axis=0)

def regression(x,z,audit=False):
    x,z=center(x),center(z)
    scale=np.sqrt(np.mean(x*x,axis=0))
    if np.any(scale<1e-8): return None
    xn=x/scale
    if np.linalg.cond(xn)>1e6: return None
    if audit:
        q,r=np.linalg.qr(xn,mode='reduced')
        b=np.linalg.solve(r,q.T@z)/scale[:,None]
    else: b=np.linalg.lstsq(x,z,rcond=None)[0]
    residual=z-x@b
    if audit:
        qx=np.linalg.qr(x,mode='reduced')[0]
        if not np.allclose(x@b,qx@(qx.T@z),rtol=1e-8,atol=1e-10):
            raise ValueError('matched projection identity failed')
    bread=np.linalg.inv(x.T@x)
    influence=np.einsum('ij,nj,nk->nik',bread,x,residual).reshape(len(x),-1)
    cov=influence.T@influence*(len(x)/(len(x)-x.shape[1]-1))
    return b,cov

def effect_reference(inputs,residual,error,nominal,audit=False):
    result=regression(inputs,residual,audit)
    if result is None: raise ValueError('unidentified healthy reference')
    raw=nominal+result[0]
    weighted=(raw/error).T
    if np.linalg.matrix_rank(weighted)!=2: raise ValueError('dependent healthy effects')
    q=np.linalg.qr(weighted,mode='reduced')[0]
    b,cov=regression(inputs,residual/error@q,audit)
    return dict(basis=q,coefficient=b,covariance=cov,raw=raw,error=error)

def effect_score(inputs,residual,reference,audit=False):
    q,error=np.asarray(reference['basis']),np.asarray(reference['error'])
    result=regression(inputs,residual/error@q,audit)
    if result is None: return dict(scores=None,relative_change=None)
    b,cov=result
    difference=b-np.asarray(reference['coefficient'])
    variance=np.diag(cov)+np.diag(reference['covariance'])
    scores=(difference.ravel()**2/np.maximum(variance,1e-12)).reshape(2,2).mean(1)
    raw=np.asarray(reference['raw'])
    delta=(difference@q.T)*error
    relative=np.linalg.norm(delta,axis=1)/np.maximum(np.linalg.norm(raw,axis=1),1e-12)
    return dict(scores=scores,relative_change=relative,coefficient=b,covariance_diagonal=np.diag(cov))

def projection(residual,signature,error,audit=False):
    r=(center(residual)/error).ravel()
    design=(center(signature)/np.asarray(error)[None,:,None]).reshape(-1,2)
    scale=np.linalg.norm(design,axis=0)
    if np.any(scale<1e-6): return None
    x=design/scale
    if np.linalg.cond(x)>1e6: return None
    b=np.linalg.lstsq(x,r,rcond=None)[0]
    if not audit: return b*b/np.diag(np.linalg.inv(x.T@x))/len(r)
    out=[]
    for j in range(2):
        other=x[:,1-j]
        unique=x[:,j]-other*(other@x[:,j])/(other@other)
        out.append((unique@r)**2/(unique@unique)/len(r))
    return np.asarray(out)

def decisions(scores,calibration):
    if scores is None: return dict(status='unavailable',candidates=[],p=None)
    p=(1+(np.asarray(calibration)[:,None]>=scores).sum(0))/(len(calibration)+1)
    cand=np.flatnonzero(p<=.05).tolist()
    return dict(status='assigned' if len(cand)==1 else 'ambiguous' if cand else 'no_assignment',candidates=cand,p=p)
