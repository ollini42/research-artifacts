"""Healthy calibration, paired actuator diagnosis and full read-only replay."""
import argparse
import time
from pathlib import Path
import numpy as np
from common import ROOT,read,save,sha,plain,verify,scaler,windows,load_record,dataset,experiment_binding,validate_candidate
from frozen_model import FrozenModel
from inference import predict,signatures
from diagnosis_math import center,effect_reference,effect_score,projection,decisions
from prepare import prepare
from audit_guard import report_only

METHODS=('LaplaceDiag','LSTM-Projektion','VARX-Aktorzuordnung','LaplaceNet-Projektion')

def parent_prediction(model,w):
    h=w['old_history']; weights=model.w
    x=np.tanh(h@weights['encoder.0.weight'].T+weights['encoder.0.bias'])
    x=np.tanh(x@weights['encoder.3.weight'].T+weights['encoder.3.bias'])
    f=(x@weights['free_head.weight'].T+weights['free_head.bias']).reshape(-1,4,22,2)
    b=np.float32(2/model.dt)*np.einsum('nko,k->no',f[...,0]+np.complex64(1j)*f[...,1],model.inverse).real
    return b+w['command'][:,0]@model.g.T

def compare(a,b):
    """Only finite numerical tolerances, exact populations and decisions."""
    if isinstance(a,dict):
        if not isinstance(b,dict) or set(a)!=set(b): raise ValueError('replay keys differ')
        for k in a:
            if k not in ('timing_seconds',): compare(a[k],b[k])
    elif isinstance(a,list):
        if not isinstance(b,list) or len(a)!=len(b): raise ValueError('replay population differs')
        for x,y in zip(a,b): compare(x,y)
    elif isinstance(a,float):
        if not np.isclose(a,b,rtol=1e-5,atol=1e-7): raise ValueError('replay value differs')
    elif a!=b: raise ValueError('replay exact value differs')

class Evaluation:
    def __init__(self,seed,audit=False):
        self.seed=seed; self.audit=audit
        self.plan=read(ROOT/'plan.json'); self.s=scaler(seed)
        self.lap=FrozenModel(ROOT/'models'/str(seed))
        z=np.load(ROOT/'models'/str(seed)/'varx.npz',allow_pickle=False)
        self.varx=z['coefficient'].copy(); z.close()
        folder=ROOT/'training'/str(seed)
        choice=read(folder/'selected.json')
        candidates=[read(folder/f'candidate_{i}.json') for i in range(2)]
        chosen=min(range(2),key=lambda i:(candidates[i]['validation_mse'],i))
        if choice['candidate']!=chosen or choice['candidate_sha256']!=sha(folder/f'candidate_{chosen}.json'):
            raise ValueError('wrong validation selection')
        if any(choice.get(k)!=v for k,v in experiment_binding().items()) or any(
            choice[k]!=candidates[chosen][k] for k in ('best_epoch','validation_mse')):
            raise ValueError('selected model summary differs')
        for index,c in enumerate(candidates):
            validate_candidate(c,seed,self.plan['training']['learning_rates'][index])
            best=min(c['trace'],key=lambda x:(x['validation_mse'],x['epoch']))
            if best['epoch']!=c['best_epoch'] or best['validation_mse']!=c['validation_mse']:
                raise ValueError('checkpoint not validation minimum')
            # Recompute every candidate's selected validation loss, not just the winner.
            valid=dataset(seed,'validation')
            got=predict(c['state_dict'],valid['history'],valid['command'])
            mse=float(np.mean((got-valid['target'])**2))
            if not np.isclose(mse,c['validation_mse'],rtol=2e-4,atol=1e-7):
                raise ValueError('selected checkpoint validation replay differs')
        self.state=candidates[chosen]['state_dict']
        self.selection=choice
        refs=[self.prepare_record('train',r,full=False) for r in range(201,301)]
        cat=lambda k:np.concatenate([r[k] for r in refs])
        self.errors={m:np.maximum(np.sqrt(np.mean(cat(m+'_residual')**2,0)),1e-6)
                     for m in ('lap','lstm','varx')}
        x=np.concatenate([center(r['u']) for r in refs])
        residual=np.concatenate([center(r['lap_residual']) for r in refs])
        self.reference=effect_reference(x,residual,self.errors['lap'],self.lap.g[:,[3,9]].T,audit)
        # Every model sees the same validation observations and training normalization.
        validation=[self.prepare_record('train',r,full=False) for r in range(151,201)]
        self.validation_mse={m:float(np.mean(np.concatenate([r[m+'_residual'] for r in validation])**2))
                             for m in ('lap','lstm','varx')}
        sample=windows(*load_record('train',201),self.s)
        _,a=signatures(self.state,sample['history'][:64],sample['command'][:64],.001)
        _,b=signatures(self.state,sample['history'][:64],sample['command'][:64],.0005)
        self.sensitivity_stable=bool(np.allclose(a,b,rtol=.05,atol=1e-5))
        self.binding=dict(**experiment_binding(),selected_model_sha256=choice['candidate_sha256'])

    def prepare_record(self,kind,run,fault=0,full=True):
        w=windows(*load_record(kind,run,fault),self.s)
        target=w['target'][:,0]
        lap=parent_prediction(self.lap,w)
        varx=np.c_[np.ones(len(target)),w['old_history'],w['command'][:,0]]@self.varx
        t=time.perf_counter()
        if full:
            lstm,sig=signatures(self.state,w['history'],w['command'])
        else: lstm=predict(self.state,w['history'],w['command'])[:,0];sig=None
        elapsed=time.perf_counter()-t
        u=w['command'][:,0,[3,9]]
        return dict(u=u,target=w['target_sample'],lap_residual=target-lap,
            lstm_residual=target-lstm,varx_residual=target-varx,lstm_signature=sig,
            lap_signature=np.einsum('ni,oi->noi',u,self.lap.g[:,[3,9]]),
            varx_signature=np.einsum('ni,io->noi',u,self.varx[-11:][[3,9]]),
            timing_seconds=elapsed)

    def record(self,kind,run,fault=0):
        p=self.prepare_record(kind,run,fault)
        count=len(p['target']); width=self.plan['window_predictions']
        ends=list(range(width,count+1,self.plan['decision_stride']))
        if ends[-1]!=count: ends.append(count)
        rows=[]
        for end in ends:
            a=slice(end-width,end)
            e=effect_score(p['u'][a],p['lap_residual'][a],self.reference,self.audit)
            scores={'LaplaceDiag':e['scores']}
            for method,key in [('LSTM-Projektion','lstm'),('VARX-Aktorzuordnung','varx'),('LaplaceNet-Projektion','lap')]:
                scores[method]=projection(p[key+'_residual'][a],p[key+'_signature'][a],self.errors[key],self.audit)
            rows.append(dict(sample=int(p['target'][end-1]),first_target_sample=int(p['target'][a.start]),scores=scores,
                             relative_effect_change=e['relative_change']))
        return plain(dict(seed=self.seed,kind=kind,run=run,fault=fault,checks=rows,binding=self.binding,
                          timing_seconds=p['timing_seconds']))

def write_or_replay(path,value,audit):
    if audit: compare(read(path),plain(value))
    elif path.exists(): compare(read(path),plain(value))
    else: save(path,value)

def score_summary(record,calibration):
    result={}; onset=161
    truth={7:0,14:1}.get(record['fault'])
    reports=[]
    for row in record['checks']:
        reports.append(dict(sample=row['sample'],first_target_sample=row['first_target_sample'],
            methods={m:decisions(row['scores'][m],calibration[m]) for m in METHODS}))
    for m in METHODS:
        end=reports[-1]['methods'][m]
        alarm=[r for r in reports if r['methods'][m]['candidates']]
        correct=[r for r in reports if truth is not None and r['methods'][m]['candidates']==[truth]]
        wrong=[r for r in reports if len(r['methods'][m]['candidates'])==1 and r['methods'][m]['candidates']!=[truth]]
        result[m]=dict(end_status=end['status'],end_candidates=end['candidates'],
            correct=truth is not None and end['candidates']==[truth],
            wrong=len(end['candidates'])==1 and end['candidates']!=[truth],
            ever_alarm=bool(alarm),ever_wrong=bool(wrong),ever_correct=bool(correct),
            first_alarm_delay_seconds=(alarm[0]['sample']-onset)*180 if alarm else None,
            first_correct_delay_seconds=(correct[0]['sample']-onset)*180 if correct else None,
            fully_post_fault_checks=sum(r['first_target_sample']>onset for r in reports),
            correct_fully_post_fault_checks=sum(r['first_target_sample']>onset and r['methods'][m]['candidates']==[truth]
                                               for r in reports) if truth is not None else 0,
            available_checks=sum(r['methods'][m]['status']!='unavailable' for r in reports),total_checks=len(reports))
    return plain(dict(seed=record['seed'],run=record['run'],fault=record['fault'],methods=result,decisions=reports,binding=record['binding']))

def healthy(seed,audit=False):
    ev=Evaluation(seed,audit); out=ROOT/'results'/str(seed)
    cal={m:[] for m in METHODS}; coverage={m:[] for m in METHODS}
    for run in ev.plan['calibration_runs']:
        r=ev.record('healthy',run)
        write_or_replay(out/f'calibration/{run}.json',r,audit)
        for m in METHODS:
            available=[c['scores'][m] for c in r['checks'] if c['scores'][m] is not None]
            cal[m].append(max(max(s) for s in available) if available else 0.)
            coverage[m].append(len(available)/len(r['checks']))
    write_or_replay(out/'calibration.json',dict(maxima=cal,binding=ev.binding),audit)
    development=[]; changes=[]
    for run in ev.plan['qualification_runs']:
        r=ev.record('healthy',run)
        d=score_summary(r,cal)
        write_or_replay(out/f'development/{run}.json',dict(raw=r,summary=d),audit)
        development.append(d)
        changes += [c['relative_effect_change'] for c in r['checks'] if c['relative_effect_change'] is not None]
    fpr={m:float(np.mean([r['methods'][m]['ever_alarm'] for r in development])) for m in METHODS}
    cover={m:min([r['methods'][m]['available_checks']/r['methods'][m]['total_checks'] for r in development]+coverage[m]) for m in METHODS}
    checks=dict(complete_calibration=all(len(v)==150 for v in cal.values()),
        coverage=all(v>=.9 for v in cover.values()),
        healthy_false_assignment_control=all(v<=.1 for v in fpr.values()),
        lstm_predictive_quality=ev.validation_mse['lstm']<=2*ev.validation_mse['lap'],
        sensitivity_stable=ev.sensitivity_stable)
    # This precision assessment stays separate, it is never silently declared passed.
    median=np.median(changes,axis=0) if changes else np.array([1e99,1e99])
    result=plain(dict(checks=checks,comparison_released=all(checks.values()),validation_mse=ev.validation_mse,
        historical_precision_threshold=.5,median_relative_effect_change=median,
        historical_precision_passed=bool(np.all(median<=.5)),exploratory=True,
        development_episode_false_assignment=fpr,minimum_coverage=cover,reference=ev.reference,binding=ev.binding))
    write_or_replay(out/'healthy.json',result,audit)
    return result

def fault_evaluation(seed,audit=False):
    ev=Evaluation(seed,audit); out=ROOT/'results'/str(seed)
    cal=read(out/'calibration.json')['maxima']; rows=[]
    for run in ev.plan['test_runs']:
        for fault in (0,7,14):
            record=ev.record('healthy' if fault==0 else 'fault',run,fault)
            report=score_summary(record,cal)
            write_or_replay(out/f'test/{run}_{fault}.json',dict(raw=record,summary=report),audit)
            rows.append(report)
    return rows

def aggregate(rows):
    p=read(ROOT/'plan.json'); result={}
    expected={(s,r,f) for s in p['seeds'] for r in p['test_runs'] for f in (0,7,14)}
    if len(rows)!=720 or {(r['seed'],r['run'],r['fault']) for r in rows}!=expected:
        raise ValueError('test population incomplete or duplicated')
    for fault in (0,7,14):
        chosen=[r for r in rows if r['fault']==fault]
        result[str(fault)]={}
        for m in METHODS:
            vals=[r['methods'][m] for r in chosen]
            delays=[r['first_correct_delay_seconds'] for r in vals if r['first_correct_delay_seconds'] is not None]
            result[str(fault)][m]=dict(n=len(vals),correct=sum(v['correct'] for v in vals),wrong=sum(v['wrong'] for v in vals),
                ambiguous=sum(v['end_status']=='ambiguous' for v in vals),none=sum(v['end_status']=='no_assignment' for v in vals),
                unavailable=sum(v['end_status']=='unavailable' for v in vals),ever_alarm=sum(v['ever_alarm'] for v in vals),
                ever_wrong=sum(v['ever_wrong'] for v in vals),correct_delay_median_seconds=float(np.median(delays)) if delays else None)
    differences={}
    for m in METHODS[1:]:
        groups=[]
        for run in p['test_runs']:
            sub=[r for r in rows if r['run']==run and r['fault']!=0]
            groups.append(np.mean([int(r['methods']['LaplaceDiag']['correct'])-int(r['methods'][m]['correct']) for r in sub]))
        rng=np.random.default_rng(771510)
        draws=np.mean(np.asarray(groups)[rng.integers(0,80,size=(10000,80))],axis=1)
        differences[m]=dict(difference=float(np.mean(groups)),ci95=np.quantile(draws,[.025,.975]).tolist())
    return dict(exploratory=True,counts_by_fault=result,paired_correct_difference=differences,
                original_recordings=240,model_recording_evaluations=720,independent_base_runs=80,**experiment_binding())

def run(audit=False):
    p=verify()
    native=read(ROOT/'native_quality.json')
    if any(native.get(k)!=v for k,v in experiment_binding().items()):
        raise ValueError('native quality source binding differs')
    if {r['seed'] for r in native['reports']}!=set(p['seeds']) or len(native['reports'])!=3:
        raise ValueError('native quality seed population differs')
    for report in native['reports']:
        selected=read(ROOT/'training'/str(report['seed'])/'selected.json')
        if report['candidate_sha256']!=selected['candidate_sha256'] or {x['device'] for x in report['models']}!={'cpu','cuda'}:
            raise ValueError('native quality model or platform differs')
    original_models={n:sha(ROOT/n) for n in read(ROOT/'model_manifest.json')}
    candidates={str(f.relative_to(ROOT)):sha(f) for f in (ROOT/'training').glob('*/candidate_*.json')}
    if len(candidates)!=6: raise ValueError('expected exactly six trained candidates')
    candidate_receipt=ROOT/'trained_models.json'
    if audit: compare(read(candidate_receipt),candidates)
    elif candidate_receipt.exists(): compare(read(candidate_receipt),candidates)
    else: save(candidate_receipt,candidates)
    if audit:
        compare(read(ROOT/'healthy_inputs.json'),prepare(False,True))
    healthy_results=[healthy(s,audit) for s in p['seeds']]
    release=all(x['comparison_released'] for x in healthy_results)
    if release:
        inputs=prepare(True,audit)
        write_or_replay(ROOT/'fault_inputs.json',inputs,audit)
        rows=[]
        for s in p['seeds']: rows+=fault_evaluation(s,audit)
        summary=aggregate(rows)
    else:
        summary=dict(exploratory=True,fault_comparison_reached=False,healthy_checks=[x['checks'] for x in healthy_results],**experiment_binding())
    summary['fault_comparison_reached']=release
    write_or_replay(ROOT/'results/summary.json',summary,audit)
    if audit:
        if original_models!={n:sha(ROOT/n) for n in original_models}: raise ValueError('parent changed during audit')
        if candidates!={n:sha(ROOT/n) for n in candidates}: raise ValueError('trained candidate changed during audit')
        save(ROOT/'audit/final_integrity_review.json',dict(integrity_status='passed',new_fits=0,new_transition_fits=0,
            new_observations=0,originals_unchanged=True,models_replayed=6,healthy_originals_reconstructed=580,
            model_replays_by_family={'lstm_candidates':6,'laplace_parents':3,'varx_parents':3},
            fault_originals_reconstructed=160 if release else 0,test_evaluations=720 if release else 0,
            calibration_evaluations=450,development_evaluations=150,comparison_released=release,
            trained_models_sha256=sha(candidate_receipt),matched_four_parameter_projection_verified=True,
            native_quality_sha256=sha(ROOT/'native_quality.json'),
            summary_sha256=sha(ROOT/'results/summary.json'),**experiment_binding()))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--audit',action='store_true');args=parser.parse_args()
    if args.audit:
        (ROOT/'audit').mkdir(mode=0o700,exist_ok=False)
        with report_only(ROOT/'audit'): run(True)
    else: run(False)
