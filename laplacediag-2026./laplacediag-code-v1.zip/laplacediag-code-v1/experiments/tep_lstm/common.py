"""Immutable experiment inputs and complete causal TEP training windows."""
import hashlib
import json
import os
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1048576), b''):
            h.update(b)
    return h.hexdigest()

def plain(v):
    if isinstance(v, np.ndarray): return plain(v.tolist())
    if isinstance(v, np.generic): return plain(v.item())
    if isinstance(v, dict): return {k:plain(x) for k,x in v.items()}
    if isinstance(v, (list,tuple)): return [plain(x) for x in v]
    return v

def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
    with path.open('x') as f:
        json.dump(plain(value), f, sort_keys=True, allow_nan=False)
        f.write('\n')

def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix('.tmp')
    with temporary.open('w') as f:
        json.dump(plain(value), f, sort_keys=True, allow_nan=False)
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporary,path)

def experiment_binding():
    return dict(manifest_sha256=sha(ROOT/'manifest.json'),plan_sha256=sha(ROOT/'plan.json'),
                models_sha256=sha(ROOT/'model_manifest.json'))

def verify():
    for n,h in read(ROOT/'manifest.json')['files'].items():
        if sha(ROOT/n)!=h: raise ValueError('source changed: '+n)
    for n,h in read(ROOT/'model_manifest.json').items():
        if sha(ROOT/n)!=h: raise ValueError('parent changed: '+n)
    p=read(ROOT/'plan.json')
    groups=[set(p[n]) for n in ('calibration_runs','qualification_runs','test_runs')]
    if [len(x) for x in groups]!=[150,50,80] or any(groups[i]&groups[j] for i in range(3) for j in range(i)):
        raise ValueError('invalid split')
    if p['candidate_channels_zero_based']!=[3,9] or p['window_predictions']!=384:
        raise ValueError('invalid scientific configuration')
    return p

def record_path(kind, run, fault=0):
    return ROOT/'cache'/f'{kind}_{run}_{fault}.npz'

def load_record(kind, run, fault=0):
    with np.load(record_path(kind,run,fault),allow_pickle=False) as z:
        return z['u'],z['y']

def windows(u,y,s):
    u,y=np.asarray(u),np.asarray(y)
    if u.shape!=(len(y)-1,11) or y.shape[1]!=22: raise ValueError('TEP dimensions')
    un,yn=(u-s['um'])/s['us'],(y-s['ym'])/s['ys']
    t=np.arange(10,len(u))
    # All eleven sensor vectors and ten past commands from the parent model.
    # The last command slot is masked and zero. Current command goes only to decoder.
    h=np.zeros((len(t),11,34),dtype='f4')
    h[:,:10,:11]=un[t[:,None]-10+np.arange(10)]
    h[:,:,11:33]=yn[t[:,None]-10+np.arange(11)]
    h[:,:10,33]=1
    old_h=np.c_[h[:,:10,:11].reshape(len(t),-1),h[:,:,11:33].reshape(len(t),-1)]
    return dict(history=h,command=un[t,None].astype('f4'),target=yn[t+1,None].astype('f4'),
                old_history=old_h,target_sample=t+2)

def scaler(seed):
    return dict(np.load(ROOT/'models'/str(seed)/'scaler.npz',allow_pickle=False))

def dataset(seed,split):
    runs=range(1,151) if split=='train' else range(151,201) if split=='validation' else None
    if runs is None: raise ValueError('training split forbidden')
    parts=[windows(*load_record('train',r),scaler(seed)) for r in runs]
    return {k:np.concatenate([x[k] for x in parts]) for k in ('history','command','target')}

def validate_candidate(result,seed,lr):
    expected=dict(seed=seed,lr=lr,epochs=2560,binding=experiment_binding(),
                  training_windows=73350,validation_windows=24450)
    identity=result['identity']
    if any(identity.get(k)!=v for k,v in expected.items()):
        raise ValueError('candidate identity does not match seed, training or configuration')
    if identity['runtime']['device']!='cuda' or not identity['runtime']['gpu']:
        raise ValueError('candidate not from the registered GPU training')
    if result['epochs_completed']!=2560 or [x['epoch'] for x in result['trace']]!=list(range(2561)):
        raise ValueError('candidate does not have all completed epochs')
    best=min(result['trace'],key=lambda x:(x['validation_mse'],x['epoch']))
    if best['epoch']!=result['best_epoch'] or best['validation_mse']!=result['validation_mse']:
        raise ValueError('candidate is not its recorded validation minimum')
