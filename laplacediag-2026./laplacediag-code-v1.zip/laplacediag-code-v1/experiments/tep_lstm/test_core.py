"""Independent scientific invariants before any production fit."""
import numpy as np
import pytest
from common import windows,ROOT,read
from diagnosis_math import regression,effect_reference,effect_score,projection,decisions
from audit_guard import report_only

def sample():
    rng=np.random.default_rng(53)
    x=rng.normal(size=(384,2)); a=rng.normal(size=(2,22))
    y=x@a+rng.normal(size=(384,22))*.01
    return rng,x,a,y

def test_windows_full_and_causal():
    rng=np.random.default_rng(1)
    u=rng.normal(size=(499,11));y=rng.normal(size=(500,22))
    s=dict(um=np.zeros(11),us=np.ones(11),ym=np.zeros(22),ys=np.ones(22))
    w=windows(u,y,s)
    assert len(w['history'])==489 and w['target_sample'][0]==12 and w['target_sample'][-1]==500
    np.testing.assert_array_equal(w['history'][0,:10,:11],u[:10].astype('f4'))
    np.testing.assert_array_equal(w['history'][0,:,11:33],y[:11].astype('f4'))
    assert np.all(w['history'][0,-1,:11]==0) and w['history'][0,-1,-1]==0
    np.testing.assert_array_equal(w['command'][0,0],u[10].astype('f4'))
    np.testing.assert_array_equal(w['target'][0,0],y[11].astype('f4'))
    y[12:]+=100
    np.testing.assert_array_equal(w['history'][0],windows(u,y,s)['history'][0])

def test_regression_independent_qr():
    _,x,a,y=sample()
    b,c=regression(x,y); q,d=regression(x,y,True)
    np.testing.assert_allclose(b,q,atol=1e-10)
    np.testing.assert_allclose(c,d,atol=1e-10)
    np.testing.assert_allclose(b,a,atol=.003)

def test_effect_detects_rotation_not_only_gain():
    rng,x,a,y=sample()
    ref=effect_reference(x,y-x@a,np.ones(22),a)
    nominal=effect_score(x,y-x@a,ref)
    changed=effect_score(x,y-x@a+.5*x[:,[0]]*a[1],ref)
    assert changed['scores'][0]>100 and changed['scores'][0]>nominal['scores'][0]+100
    assert changed['scores'][1]<changed['scores'][0]*.01

def test_joint_projection_matches_partial_formula():
    _,x,a,y=sample()
    sig=np.einsum('ni,io->noi',x,a)
    np.testing.assert_allclose(projection(y,sig,np.ones(22)),projection(y,sig,np.ones(22),True),rtol=1e-10)

def test_no_identification_when_commands_coupled():
    _,x,a,y=sample();x[:,1]=x[:,0]
    assert regression(x,y) is None
    sig=np.stack([y,y],axis=-1)
    assert projection(y,sig,np.ones(22)) is None

def test_rank_calibration_ties_and_unavailable():
    assert decisions([1,1],[1.]*150)['candidates']==[]
    assert decisions([2,1],[1.]*150)['candidates']==[0]
    assert decisions([2,2],[1.]*150)['status']=='ambiguous'
    assert decisions(None,[1.]*150)['status']=='unavailable'

def test_plan_keeps_prior_failed_qualification_and_pairing():
    p=read(ROOT/'plan.json')
    assert 'exploratory' in p['comparison_status'] and p['qualification']['maximum_median_effect_relative_change']==.5
    assert p['test_faults']==[0,7,14] and len(p['test_runs'])==80
    assert not(set(p['test_runs'])&set(p['calibration_runs']))
    assert len(set(p['seeds']))==3 and p['training']['epochs']==2560

def test_audit_forbids_cache_write_and_training_import(tmp_path):
    out=tmp_path/'audit';out.mkdir()
    with report_only(out):
        with pytest.raises(PermissionError): (tmp_path/'model').write_text('invalid')
        with pytest.raises(PermissionError): __import__('torch')

def test_candidate_identity_rejects_other_seed_or_candidate(monkeypatch):
    import common
    monkeypatch.setattr(common,'experiment_binding',lambda:{'source':'test'})
    result=dict(identity=dict(seed=882701,lr=.003,epochs=2560,binding={'source':'test'},
                training_windows=73350,validation_windows=24450,runtime={'device':'cuda','gpu':'test GPU'}),
                epochs_completed=2560,trace=[dict(epoch=i,validation_mse=1.) for i in range(2561)],
                best_epoch=0,validation_mse=1.)
    common.validate_candidate(result,882701,.003)
    with pytest.raises(ValueError): common.validate_candidate(result,882702,.003)
    with pytest.raises(ValueError): common.validate_candidate(result,882701,.001)
