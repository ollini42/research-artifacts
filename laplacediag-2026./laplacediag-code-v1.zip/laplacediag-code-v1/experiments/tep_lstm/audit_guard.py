"""Enforce report-only writes and reject training imports in replay workers."""
from contextlib import contextmanager
import builtins
import io
import os
from pathlib import Path
import subprocess
import sys

@contextmanager
def report_only(directory):
    allowed=Path(directory).resolve()
    original_open, original_io, original_os_open = builtins.open, io.open, os.open
    original_import=builtins.__import__
    original_popen=subprocess.Popen
    old_bytecode=sys.dont_write_bytecode
    original_ops={n:getattr(os,n) for n in ('mkdir','remove','unlink','rename','replace','rmdir','chmod','truncate')}
    def permit(path):
        if isinstance(path,int):
            raise PermissionError('Replay may not write through inherited descriptors')
        resolved=Path(path).resolve()
        if resolved != allowed and allowed not in resolved.parents:
            raise PermissionError('Replay write outside new audit reports: '+str(path))
    def opener(base):
        def wrapped(file,mode='r',*args,**kwargs):
            if any(c in mode for c in 'wax+'):
                permit(file)
            return base(file,mode,*args,**kwargs)
        return wrapped
    def low_open(path,flags,*args,**kwargs):
        if flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):
            permit(path)
        return original_os_open(path,flags,*args,**kwargs)
    def importer(name,*args,**kwargs):
        if name.split('.')[0] in ('torch','tensorflow','keras','sklearn'):
            raise PermissionError('Replay forbids training runtime imports')
        return original_import(name,*args,**kwargs)
    def forbidden(*args,**kwargs):
        raise PermissionError('Replay forbids child processes')
    def mutation(name,fn):
        def wrapped(path,*args,**kwargs):
            permit(path)
            if name in ('rename','replace'):
                permit(args[0])
            return fn(path,*args,**kwargs)
        return wrapped
    try:
        sys.dont_write_bytecode=True
        builtins.open=opener(original_open);io.open=opener(original_io);os.open=low_open
        builtins.__import__=importer;subprocess.Popen=forbidden
        for name,fn in original_ops.items():setattr(os,name,mutation(name,fn))
        yield
    finally:
        builtins.open=original_open;io.open=original_io;os.open=original_os_open
        builtins.__import__=original_import;subprocess.Popen=original_popen
        sys.dont_write_bytecode=old_bytecode
        for name,fn in original_ops.items():setattr(os,name,fn)
