"""Validate the exported files and immutable synthetic observations."""
import hashlib
import json
from collections import Counter
from pathlib import Path


def read(path: Path):
    return json.loads(Path(path).read_text())


def digest(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_archive(folder: Path) -> int:
    folder=Path(folder).resolve()
    manifest=read(folder/'MANIFEST.json')
    for row in manifest['files']:
        path=(folder/row['path']).resolve()
        if not path.is_relative_to(folder) or digest(path)!=row['sha256']:
            raise ValueError('Changed or unsafe archive payload: '+row['path'])
        notice=(folder/row['notice']).resolve()
        if not notice.is_relative_to(folder) or not notice.is_file():
            raise ValueError('Missing or unsafe copyright notice')
    return len(manifest['files'])


def verify_data(folder: Path) -> list[dict]:
    import numpy as np
    folder=Path(folder).resolve()
    rows=read(folder/'recordings.json')['records']
    expected=Counter({(s,k):n for s in (993101,993102,993103) for k,n in
        [('train',5),('validation',2),('reference',8),('model_check',8),('calibration',43),('test',80)]})
    if len(rows)!=438 or len({r['id'] for r in rows})!=438 or Counter((r['seed'],r['split']) for r in rows)!=expected:
        raise ValueError('Wrong recording population')
    for row in rows:
        path=(folder/row['path']).resolve()
        if not path.is_relative_to(folder) or digest(path)!=row['sha256']:
            raise ValueError('Changed or unsafe recording: '+row['id'])
        with np.load(path,allow_pickle=False) as arrays:
            if set(arrays.files)!={'command','y','confirmation','time'}:
                raise ValueError('Wrong array schema')
            n=len(arrays['command'])
            shapes={'command':(n,2),'y':(n+1,3),'confirmation':(n+1,3),'time':(n+1,)}
            for k,shape in shapes.items():
                if arrays[k].shape!=shape or arrays[k].dtype!=np.float64 or not np.isfinite(arrays[k]).all():
                    raise ValueError('Invalid array '+row['id']+'/'+k)
            np.testing.assert_allclose(np.diff(arrays['time']),5.,rtol=0.,atol=1e-12)
    return rows
