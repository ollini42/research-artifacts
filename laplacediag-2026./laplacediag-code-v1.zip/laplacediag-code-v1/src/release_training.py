"""Explicit full-training recipes. These are never called by verification."""
from pathlib import Path
import json
import sys

PACKAGE=Path(__file__).resolve().parents[1]


def train(command: str, data: Path, output: Path, seed: int, device: str) -> None:
    import numpy as np
    import torch
    # Historical paper fits use the historical modules, never the new estimator.
    sys.path.insert(0,str(PACKAGE/'experiments/pump_frozen'))
    from high_level_control.laplace_diag_experiment import load_record,training_scaler,make_windows,concatenate_windows
    from release_io import read,digest
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    rows=read(data/'recordings.json')['records']
    def records(split):
        return [load_record(data/r['path']) for r in rows if r['seed']==seed and r['split']==split]
    scaler=training_scaler(records('train'))
    def windows(split):
        return concatenate_windows([make_windows(r,scaler,12,12) for r in records(split)])
    tr,va=windows('train'),windows('validation')
    if (len(tr['u']),len(va['u']))!=(1277,530):
        raise ValueError('Full training or validation support differs')
    binding={'data_sha256':digest(data/'recordings.json'),'code_sha256':digest(PACKAGE/'MANIFEST.json'),'seed':seed}
    np.savez_compressed(output/'scaler.npz',**scaler)
    if command=='train-pump-parent':
        from high_level_control.two_phase_learning import LaplaceFitConfig,ModelData,fit_laplace
        config=read(PACKAGE/'configs/parent_training.json')[str(seed)]
        config['device']=device
        def as_model_data(w):
            return ModelData(w['history'],w['u'],w['y'],w['sequence'],w['origins'])
        fitted=fit_laplace(as_model_data(tr),LaplaceFitConfig(**config),validation=as_model_data(va))
        torch.save(fitted.checkpoint(),output/'model.pt')
    elif command=='train-pump-lstm':
        sys.path.insert(0,str(PACKAGE/'experiments/pump_lstm'))
        from train import fit
        def lstm_windows(w):
            return {'history':np.concatenate([w['history'][:,:24].reshape(-1,12,2),w['history'][:,24:].reshape(-1,12,3)],axis=2),
                    'command':w['u'],'target':w['y']}
        candidates=[]
        for i,lr in enumerate(read(PACKAGE/'configs/pump_lstm.json')['training']['learning_rates']):
            result=fit(lstm_windows(tr),lstm_windows(va),seed,lr,2560,output/f'checkpoint_{i}.pt',device=device,binding=binding)
            (output/f'candidate_{i}.json').write_text(json.dumps(result,allow_nan=False)+'\n')
            candidates.append(result)
        choice=min(range(len(candidates)),key=lambda i:(candidates[i]['validation_mse'],i))
        (output/'selected.json').write_text(json.dumps({'candidate':choice,'validation_mse':candidates[choice]['validation_mse']})+'\n')
    elif command=='train-pump-history':
        from high_level_control.models import LaplaceNetOperator
        from high_level_control.laplace_diag import EffectBasis
        from high_level_control.laplace_diag_history import FrozenForcingHistory,fit_history
        from high_level_control.laplace_diag_experiment import estimate_from_dict
        p=read(PACKAGE/'assets/pump_parent_models.json')[str(seed)]
        config=p['config']
        model=LaplaceNetOperator(**p['dimensions'],hidden_dim=config['hidden_dim'],laplace_points=config['laplace_points'],
            sigma=config['laplace_sigma'],sampling_time_seconds=config['sampling_time_seconds'],transfer_mode='fixed',architecture_version=p['architecture_version'])
        model.load_state_dict({k:torch.as_tensor(v,dtype=torch.float32) for k,v in p['state_dict'].items()})
        reference=read(PACKAGE/'assets'/str(seed)/'reference.json')
        basis=EffectBasis(np.asarray(reference['temporal_basis']),2,3)
        forcing={'history_original_forcing':np.asarray(reference['neural_operator']),
                 'history_reference_forcing':basis.operator(estimate_from_dict(reference['estimate']).coefficients)}
        for arm,operator in forcing.items():
            fitted,receipt=fit_history(FrozenForcingHistory(model,operator),tr,va,read(PACKAGE/'configs/pump_series.json')['training'],
                seed=seed,device=device,deadline=float('inf'),progress_path=output/(arm+'_progress.pt'),identity=binding|{'arm':arm})
            torch.save({'state_dict':fitted.base.state_dict(),'forcing':fitted.forcing.cpu(),'config':config,'dimensions':p['dimensions'],'architecture_version':p['architecture_version']},output/(arm+'.pt'))
            (output/(arm+'_receipt.json')).write_text(json.dumps(receipt,allow_nan=False)+'\n')
    (output/'reproduction_identity.json').write_text(json.dumps(binding|{'command':command,'device':device,'torch':str(torch.__version__),'numpy':np.__version__},indent=2)+'\n')
