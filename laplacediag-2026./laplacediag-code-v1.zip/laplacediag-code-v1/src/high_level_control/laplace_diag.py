"""Online plant-effect estimation with finite-episode, healthy-data calibration.

No controller is learned or constructed. The neural free response stays frozen.
The estimated coefficients span only the observable real Laplace impulse basis.
Cluster standard errors are descriptive approximations. Significance uses ranks
against maxima of complete held-out healthy episodes, not a chi-square shortcut.
Its finite-episode guarantee requires exchangeable healthy episodes conditional
on the frozen model, reference, acquisition protocol and selected state.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
from typing import Any

import numpy as np


def _array(value: Any, ndim: int, name: str) -> np.ndarray:
    if np.iscomplexobj(value):
        raise ValueError(f"{name} must be real")
    result = np.array(value, dtype=np.float64, copy=True)
    if result.ndim != ndim or not result.size or not np.isfinite(result).all():
        raise ValueError(f"{name} must be a finite, nonempty {ndim}-dimensional array")
    return result


@dataclass(frozen=True)
class EffectBasis:
    """Identifiable real impulse basis for a fixed-transfer LaplaceNet model.

    Coefficients have shape [basis_rank * inputs, outputs]. The corresponding
    operator maps time-major flattened inputs to time-major flattened outputs.
    Redundant complex coefficients, including the zero-frequency imaginary part,
    are excluded without discarding observable impulse directions.
    """

    temporal: np.ndarray
    inputs: int
    outputs: int

    def __post_init__(self) -> None:
        temporal = _array(self.temporal, 2, "temporal basis")
        if any(type(x) is not int or x < 1 for x in (self.inputs, self.outputs)):
            raise ValueError("input and output counts must be positive integers")
        if not np.allclose(
            temporal.T @ temporal, np.eye(temporal.shape[1]), atol=1e-10
        ):
            raise ValueError("temporal basis must have orthonormal columns")
        temporal.setflags(write=False)
        object.__setattr__(self, "temporal", temporal)

    @classmethod
    def laplace(
        cls,
        horizon: int,
        points: int,
        sigma: float,
        dt: float,
        inputs: int,
        outputs: int,
    ) -> EffectBasis:
        """Match LaplaceNetOperator's quadrature without importing a trainer."""
        if any(type(x) is not int or x < 1 for x in (horizon, points)):
            raise ValueError("horizon and points must be positive integers")
        if not np.isfinite(sigma) or not np.isfinite(dt) or dt <= 0:
            raise ValueError("sigma must be finite and sampling time must be positive")
        frequency = np.arange(points) * np.pi / (horizon * dt)
        time = np.arange(1, horizon + 1) * dt
        weights = np.ones(points)
        weights[0] = 0.5
        with np.errstate(over="raise", invalid="raise"):
            inverse = (
                np.exp((sigma + 1j * frequency[:, None]) * time) * weights[:, None]
            )
        real_map = (2 / horizon) * np.concatenate(
            (inverse.real.T, -inverse.imag.T), axis=1
        )
        left, singular, _ = np.linalg.svd(real_map, full_matrices=False)
        rank = int(
            np.sum(singular > singular[0] * max(real_map.shape) * np.finfo(float).eps)
        )
        return cls(left[:, :rank], inputs, outputs)

    @property
    def horizon(self) -> int:
        return len(self.temporal)

    @property
    def parameters_per_output(self) -> int:
        return self.temporal.shape[1] * self.inputs

    def design(self, inputs: np.ndarray) -> np.ndarray:
        """Build a causal convolution design of shape [windows, horizon, parameters]."""
        values = _array(inputs, 3, "inputs")
        if values.shape[1:] != (self.horizon, self.inputs):
            raise ValueError(
                "input horizon or channel count differs from the frozen basis"
            )
        design = np.zeros(
            (len(values), self.horizon, self.temporal.shape[1], self.inputs)
        )
        for lag in range(self.horizon):
            design[:, lag:] += (
                values[:, : self.horizon - lag, None, :] * self.temporal[lag, :, None]
            )
        return design.reshape(len(values), self.horizon, self.parameters_per_output)

    def impulse(self, coefficients: np.ndarray) -> np.ndarray:
        """Return lag-by-output-by-input impulse coefficients in the supplied units."""
        coefficients = _array(coefficients, 2, "effect coefficients")
        if coefficients.shape != (self.parameters_per_output, self.outputs):
            raise ValueError("coefficient shape differs from the frozen basis")
        return np.einsum(
            "lr,rio->loi",
            self.temporal,
            coefficients.reshape(-1, self.inputs, self.outputs),
        )

    def operator(self, coefficients: np.ndarray) -> np.ndarray:
        """Return the block-lower-triangular, time-invariant finite-horizon operator."""
        impulse = self.impulse(coefficients)
        result = np.zeros((self.horizon, self.outputs, self.horizon, self.inputs))
        for row in range(self.horizon):
            for column in range(row + 1):
                result[row, :, column, :] = impulse[row - column]
        return result.reshape(self.horizon * self.outputs, self.horizon * self.inputs)

    def coefficients(self, operator: np.ndarray, tolerance: float = 2e-5) -> np.ndarray:
        """Validate and convert a frozen neural operator, rejecting changing transfers."""
        matrix = _array(operator, 2, "operator")
        if matrix.shape != (self.horizon * self.outputs, self.horizon * self.inputs):
            raise ValueError("operator dimensions differ")
        impulse = matrix.reshape(self.horizon, self.outputs, self.horizon, self.inputs)[
            :, :, 0, :
        ]
        coefficients = np.einsum("lr,loi->rio", self.temporal, impulse).reshape(
            -1, self.outputs
        )
        if not np.allclose(
            matrix, self.operator(coefficients), atol=tolerance, rtol=tolerance
        ):
            raise ValueError("operator is outside the fixed causal Laplace subspace")
        return coefficients


@dataclass(frozen=True)
class EstimationPolicy:
    """Predeclared excitation requirements, shared by reference and online fitting."""

    minimum_windows: int = 8
    maximum_condition: float = 1e6
    minimum_column_rms: float = 1e-7

    def __post_init__(self) -> None:
        if type(self.minimum_windows) is not int or self.minimum_windows < 3:
            raise ValueError("at least three windows are required")
        if not np.isfinite(self.maximum_condition) or self.maximum_condition <= 1:
            raise ValueError("maximum condition must exceed one")
        if not np.isfinite(self.minimum_column_rms) or self.minimum_column_rms <= 0:
            raise ValueError("minimum column RMS must be positive")


@dataclass(frozen=True)
class EffectEstimate:
    """A separate current estimate. An unavailable estimate never means healthy."""

    status: str
    coefficients: np.ndarray | None
    covariance: np.ndarray | None
    free_offset: np.ndarray | None
    residual_rmse: np.ndarray | None
    rank: int
    condition: float | None
    windows: int
    design_mean: np.ndarray | None = None
    target_mean: np.ndarray | None = None
    basis_signature: str | None = None
    is_healthy_reference: bool = False
    estimation_schema: int = 2

    def __post_init__(self) -> None:
        if self.estimation_schema != 2 or type(self.is_healthy_reference) is not bool:
            raise ValueError("a current fixed-reference estimate is required")
        allowed = {
            "estimated",
            "insufficient_windows",
            "unexcited_effect_direction",
            "unidentified_effect_directions",
        }
        if (
            self.status not in allowed
            or type(self.windows) is not int
            or self.windows < 1
        ):
            raise ValueError("invalid estimate status or window count")
        if type(self.rank) is not int or self.rank < 0:
            raise ValueError("invalid estimate rank")
        if self.condition is not None and (
            not np.isfinite(self.condition) or self.condition < 1
        ):
            raise ValueError("invalid estimate condition")
        fields = (
            ("coefficients", 2),
            ("covariance", 2),
            ("free_offset", 2),
            ("residual_rmse", 1),
            ("design_mean", 2),
            ("target_mean", 2),
        )
        if self.status != "estimated":
            if any(getattr(self, name) is not None for name, _ in fields):
                raise ValueError("an unavailable estimate cannot contain fitted arrays")
            return
        for name, ndim in fields:
            value = _array(getattr(self, name), ndim, name)
            value.setflags(write=False)
            object.__setattr__(self, name, value)
        assert self.coefficients is not None and self.covariance is not None
        assert self.free_offset is not None and self.residual_rmse is not None
        if not isinstance(self.basis_signature, str) or len(self.basis_signature) != 64:
            raise ValueError("the frozen basis binding is missing")
        dimension, outputs = self.coefficients.shape
        if (
            self.rank != dimension
            or self.condition is None
            or self.covariance.shape != (dimension * outputs, dimension * outputs)
            or self.free_offset.shape[1] != outputs
            or self.residual_rmse.shape != (outputs,)
            or self.design_mean.shape != (len(self.free_offset), dimension)
            or self.target_mean.shape != self.free_offset.shape
            or np.any(self.residual_rmse < 0)
        ):
            raise ValueError("inconsistent estimate arrays")
        tolerance = 1e-10 * max(1.0, float(np.max(np.abs(self.covariance))))
        if (
            not np.allclose(
                self.covariance, self.covariance.T, atol=tolerance, rtol=1e-10
            )
            or np.linalg.eigvalsh(self.covariance).min() < -tolerance
            or np.any(np.diag(self.covariance) < 0)
        ):
            raise ValueError("covariance must be symmetric positive semidefinite")


def _basis_signature(basis: EffectBasis) -> str:
    shape = np.asarray([basis.horizon, basis.inputs, basis.outputs], dtype="<i8")
    return hashlib.sha256(shape.tobytes() + basis.temporal.astype("<f8").tobytes()).hexdigest()


def estimate_healthy_reference(
    basis: EffectBasis,
    inputs: np.ndarray,
    measured_outputs: np.ndarray,
    frozen_free_response: np.ndarray,
    policy: EstimationPolicy = EstimationPolicy(),
) -> EffectEstimate:
    """Freeze means and coefficients from separate, known healthy observations.

    Only this explicit reference-construction step estimates nuisance means.
    Recalibrate complete healthy episodes after changing this reference.
    """
    return _estimate_effect(basis, inputs, measured_outputs, frozen_free_response,
                            policy, reference=None)


def estimate_effect(
    basis: EffectBasis,
    inputs: np.ndarray,
    measured_outputs: np.ndarray,
    frozen_free_response: np.ndarray,
    policy: EstimationPolicy = EstimationPolicy(),
    *,
    reference: EffectEstimate,
) -> EffectEstimate:
    """Estimate current effects relative to frozen healthy means.

    No current-window intercept is fitted. Persistent changes from healthy
    operation are retained. A shifted free-response error can still resemble an
    effect change. Cluster errors remain descriptive, with empirical calibration
    on separate complete healthy episodes required for significance statements.
    """
    if not reference.is_healthy_reference:
        raise ValueError("online estimates cannot replace the healthy reference")
    if reference.status == "estimated" and reference.basis_signature != _basis_signature(basis):
        raise ValueError("healthy reference belongs to a different effect basis")
    return _estimate_effect(basis, inputs, measured_outputs, frozen_free_response,
                            policy, reference=reference)


def _estimate_effect(
    basis: EffectBasis,
    inputs: np.ndarray,
    measured_outputs: np.ndarray,
    frozen_free_response: np.ndarray,
    policy: EstimationPolicy,
    reference: EffectEstimate | None,
) -> EffectEstimate:
    design = basis.design(inputs)
    observed = _array(measured_outputs, 3, "measured outputs")
    free = _array(frozen_free_response, 3, "frozen free response")
    if (
        observed.shape != (len(design), basis.horizon, basis.outputs)
        or free.shape != observed.shape
    ):
        raise ValueError("outputs and frozen free response must match input windows")
    count, horizon, dimension = design.shape

    def unavailable(
        reason: str, rank: int = 0, condition: float | None = None
    ) -> EffectEstimate:
        return EffectEstimate(reason, None, None, None, None, rank, condition, count,
                              is_healthy_reference=reference is None)

    nuisance_parameters = horizon if reference is None else 0
    if count < policy.minimum_windows or count * horizon <= dimension + nuisance_parameters:
        return unavailable("insufficient_windows")
    target = observed - free
    if reference is not None and reference.status != "estimated":
        return unavailable(reference.status, reference.rank, reference.condition)
    design_mean = design.mean(axis=0) if reference is None else reference.design_mean
    target_mean = target.mean(axis=0) if reference is None else reference.target_mean
    centered = design - design_mean
    centered_target = target - target_mean
    x = centered.reshape(-1, dimension)
    y = centered_target.reshape(-1, basis.outputs)
    scale = np.sqrt(np.mean(x * x, axis=0))
    if np.any(scale < policy.minimum_column_rms):
        return unavailable("unexcited_effect_direction")
    normalized = x / scale
    left, singular, right = np.linalg.svd(normalized, full_matrices=False)
    rank = int(
        np.sum(singular > singular[0] * max(normalized.shape) * np.finfo(float).eps)
    )
    condition = float(singular[0] / singular[-1]) if singular[-1] > 0 else None
    if rank != dimension or condition is None or condition > policy.maximum_condition:
        return unavailable("unidentified_effect_directions", rank, condition)
    coefficients = (right.T @ ((left.T @ y) / singular[:, None])) / scale[:, None]
    residual = centered_target - np.einsum("bhd,do->bho", centered, coefficients)
    bread = ((right.T / singular**2) @ right) / scale[:, None] / scale[None, :]
    scores = np.einsum("bhd,bho->bdo", centered, residual)
    influence = np.einsum("de,beo->bdo", bread, scores).reshape(count, -1)
    correction = (count / (count - 1)) * (
        (count * horizon - 1) / (count * horizon - dimension - nuisance_parameters)
    )
    covariance = influence.T @ influence * correction
    offset = target_mean - design_mean @ coefficients
    return EffectEstimate(
        "estimated",
        coefficients,
        covariance,
        offset,
        np.sqrt(np.mean(residual**2, axis=(0, 1))),
        rank,
        condition,
        count,
        design_mean,
        target_mean,
        _basis_signature(basis),
        reference is None,
    )


def change_scores(
    basis: EffectBasis,
    reference: EffectEstimate,
    current: EffectEstimate,
    standard_error_floor: float = 1e-6,
) -> np.ndarray | None:
    """Return one studentized change score per actuator, not chi-square p-values.

    The reference is estimated on separate healthy data before calibration.
    Both estimates use its frozen means. Shared reference uncertainty and
    correlated windows make the summed marginal variances an approximate
    studentization, not an exact covariance of the difference. Calibration
    uses separate complete healthy episodes with this same frozen procedure.
    Both deviations from the neural G must also be reported by the caller.
    """
    if not np.isfinite(standard_error_floor) or standard_error_floor <= 0:
        raise ValueError("standard error floor must be positive")
    if reference.status != "estimated" or current.status != "estimated":
        return None
    assert reference.coefficients is not None and current.coefficients is not None
    assert reference.covariance is not None and current.covariance is not None
    if reference.basis_signature != _basis_signature(basis) or current.basis_signature != reference.basis_signature:
        raise ValueError("effect basis binding differs")
    if not np.array_equal(reference.design_mean, current.design_mean) or not np.array_equal(reference.target_mean, current.target_mean):
        raise ValueError("effects must use the same frozen healthy means")
    expected = (basis.parameters_per_output, basis.outputs)
    if (
        reference.coefficients.shape != expected
        or current.coefficients.shape != expected
    ):
        raise ValueError("estimate dimensions differ from basis")
    difference = (current.coefficients - reference.coefficients).reshape(-1)
    variance = np.diag(reference.covariance) + np.diag(current.covariance)
    standardized = difference**2 / np.maximum(variance, standard_error_floor**2)
    return standardized.reshape(-1, basis.inputs, basis.outputs).mean(axis=(0, 2))


@dataclass(frozen=True)
class EpisodeCalibration:
    """Frozen maxima over every scheduled check and actuator of healthy episodes.

    All calibration episodes must follow the same complete acquisition and
    monitoring protocol as a new episode. Unidentified windows contribute zero
    score and remain unavailable in the separate coverage report. They must not
    be removed to obtain a favorable calibration set. No fault data enter here.
    """

    maxima: np.ndarray
    maximum_checks: int
    alpha: float = 0.05
    state_families: int = 1

    def __post_init__(self) -> None:
        values = _array(self.maxima, 1, "healthy episode maxima")
        if np.any(values < 0):
            raise ValueError("scores cannot be negative")
        if type(self.maximum_checks) is not int or self.maximum_checks < 1:
            raise ValueError("maximum checks must be a positive integer")
        if (
            type(self.state_families) is not int
            or self.state_families < 1
            or not 0 < self.alpha < 1
        ):
            raise ValueError("invalid family count or significance level")
        values.setflags(write=False)
        object.__setattr__(self, "maxima", values)

    @property
    def resolution_sufficient(self) -> bool:
        return 1 / (len(self.maxima) + 1) <= self.alpha / self.state_families

    def p_values(self, scores: np.ndarray) -> np.ndarray:
        """Conservative rank p-values, including ties and the finite-sample +1."""
        values = _array(scores, 1, "scores")
        if np.any(values < 0):
            raise ValueError("scores cannot be negative")
        return (1 + np.sum(self.maxima[:, None] >= values[None, :], axis=0)) / (
            len(self.maxima) + 1
        )


class EpisodeMonitor:
    """Keep persistent alarms separate from a current actuator assignment.

    Calls are irreversible within an episode, including unavailable estimates.
    A new object denotes a new prespecified acquisition episode, not permission
    to restart after an alarm or after exhausting the budget. Historical
    candidates must never be substituted for an unavailable current estimate.
    """

    def __init__(self, calibration: EpisodeCalibration, actuators: int) -> None:
        if type(actuators) is not int or actuators < 1:
            raise ValueError("actuator count must be positive")
        self.calibration = calibration
        self.running_maxima = np.zeros(actuators)
        self.checks = 0
        self.last_time: int | None = None
        self.first_alarm_time: int | None = None

    def update(
        self, scores: np.ndarray | None, *, observed_until: int,
        assignment_reason: str | None = None,
    ) -> dict[str, Any]:
        """Advance only after all observations for the current block are available."""
        if type(observed_until) is not int or (
            self.last_time is not None and observed_until <= self.last_time
        ):
            raise ValueError("observation times must be strictly increasing integers")
        if self.checks >= self.calibration.maximum_checks:
            return self._result("episode_budget_exhausted", None, observed_until)
        if assignment_reason is not None and assignment_reason not in {
            "window_not_stationary", "stationarity_not_determined"
        }:
            raise ValueError("unknown assignment restriction")
        values = None if scores is None else _array(scores, 1, "scores")
        if values is not None and (
            values.shape != self.running_maxima.shape or np.any(values < 0)
        ):
            raise ValueError("scores must match the actuator count and be nonnegative")
        self.checks += 1
        self.last_time = observed_until
        if values is None:
            return self._result("not_determined", None, observed_until)
        self.running_maxima = np.maximum(self.running_maxima, values)
        historical = self.calibration.p_values(self.running_maxima)
        if self.first_alarm_time is None and np.any(
            historical <= self.calibration.alpha / self.calibration.state_families
        ):
            self.first_alarm_time = observed_until
        status = (
            "calibration_resolution_insufficient"
            if not self.calibration.resolution_sufficient
            else assignment_reason or "tested"
        )
        return self._result(status, values, observed_until)

    def _result(self, status: str, values: np.ndarray | None, observed_until: int) -> dict[str, Any]:
        """Return explicit histories and current results, without ambiguous aliases."""
        historical_p = self.calibration.p_values(self.running_maxima)
        historical = (
            historical_p <= self.calibration.alpha / self.calibration.state_families
        )
        current_p = None if values is None else self.calibration.p_values(values)
        current = np.zeros_like(historical) if status != "tested" else (
            current_p <= self.calibration.alpha / self.calibration.state_families
        )
        return {
            "decision_schema": 2,
            "alarm_history": {
                "ever_alarm": bool(np.any(historical)),
                "first_alarm_at": self.first_alarm_time,
                "actuators_ever_flagged": np.flatnonzero(historical).tolist(),
                "p_values_of_maxima": historical_p.tolist(),
            },
            "current_assignment": {
                "status": status,
                "alarm": bool(np.any(current)),
                "p_values": None if current_p is None else current_p.tolist(),
                "candidate_actuators": np.flatnonzero(current).tolist(),
                "observed_until": observed_until,
            },
            "checks": self.checks,
            "last_processed_at": self.last_time,
        }
