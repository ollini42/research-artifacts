# External TEP experiment

The second evaluation uses separately published Tennessee Eastman Process
simulation records. These records are not part of the synthetic pump archive.
This export provides the exact run selections in configs/tep_lstm.json and
configs/tep_fixed_reference.json, the readers, model definition, training and
inference functions, and the fixed-reference mathematical comparison.

The configured fault-free data, IDV7 and IDV14 data files must be obtained from
the original source under its own terms. Match the raw file SHA256 values in the
configuration, rather than using a different TEP simulator or an arbitrary split.
The exported reader documentation describes the actuator and sensor columns.
The frozen TEP candidate checkpoints and the external raw data are not included.
Consequently this ZIP is not a complete standalone replay package for the TEP
table. This limitation must remain visible when hosting the release.

The reported fixed-reference comparison uses 83 additional base runs and three
trained seeds, giving 249 model-recording evaluations per fault type. These are
not 249 independent simulation runs. The fixed reference retains persistent
controller compensation. The optional filter based on two window halves is not
the adopted default because it increased false intermediate assignments.
