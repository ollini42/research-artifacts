# DATA_DICTIONARY

u: 11 actuator commands, y: first 22 measured sensor channels. u[t] predicts y[t+1]. All original records remain unchanged. plan.json records exact split IDs and raw SHA256.
