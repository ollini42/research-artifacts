# EXPERIMENT_PROTOCOL

The resolved frozen protocol is plan.json. Human-readable scientific justification is md/TEP_LAPLACEDIAG_LSTM_V1_2026-11-02.md.
