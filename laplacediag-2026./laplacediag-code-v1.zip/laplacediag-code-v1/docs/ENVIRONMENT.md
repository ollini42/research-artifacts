# Recorded environment and reproducibility

The portable CPU replay uses Python 3.12 and NumPy. The pinned requirements are
an installation recipe, not a claim that every scientific job used one environment.

The original ASUS history-refit series used Python 3.12.3, PyTorch
2.14.0a0+b2c75dd062.nv26.09, CUDA 13.4 and an NVIDIA GB10. The exact image was:

```
nvcr.io/nvidia/pytorch@sha256:6e8ccc607fc2a51e3741667b86316a0889418ba8b78ed0ba96e8d282b648a7a6
```

TF32 was disabled for both matrix multiplication and cuDNN. The original
three-model CPU/CUDA comparison passed its frozen tolerance. Reproducing a
training seed on another architecture need not reproduce identical floating-point
weights. This export does not include the container or any Python environment.

The recorded Workstation LSTM comparison used one NVIDIA RTX PRO 6000 Blackwell
GPU, three seeds, two fixed candidate learning rates per seed, two CPU threads
per worker, full validation and six complete 2560-epoch fits. No training or
benchmark timing was rerun while creating the ZIP files.

Use a distinct output directory for each reproduction. Keep its environment,
model, configuration and data checksums with the resulting metrics. Do not use
historical absolute deadlines or host-specific launch assumptions for a new run.

The fresh export replay passed on macOS arm64, Python 3.12.14 and NumPy 2.3.5.
requirements-replay.txt pins this verified NumPy version. The separate training
recipe retains the source project's NumPy 2.4.6 and PyTorch 2.13.0 pins.
Use separate virtual environments for replay and new training. The training
recipe was not reinstalled or empirically validated during this export.
