"""Portable entry point. Verification never trains a model or simulates data."""
import argparse
import json
import os
from pathlib import Path
import sys

sys.dont_write_bytecode=True

PACKAGE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PACKAGE/'src'))
from release_io import verify_archive,verify_data


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['verify','replay-pump-control','train-pump-parent','train-pump-lstm','train-pump-history'])
    parser.add_argument('--data',type=Path,default=PACKAGE.parent/'laplacediag-synthetic-data-v1')
    parser.add_argument('--output',type=Path)
    parser.add_argument('--seed',type=int,choices=[993101,993102,993103],default=993101)
    parser.add_argument('--device',choices=['cpu','cuda:0'],default='cpu')
    args=parser.parse_args()
    # Verify licenses, code, model arrays and every observation before any work.
    checked=verify_archive(PACKAGE)+verify_archive(args.data)
    rows=verify_data(args.data)
    if args.command=='verify':
        print(json.dumps({'files_verified':checked,'recordings':len(rows),'new_fits':0,'new_observations':0}))
        return
    if args.output is None:
        parser.error('--output must name a new directory')
    output=args.output.resolve()
    if output.exists() or output.is_relative_to(PACKAGE) or output.is_relative_to(args.data.resolve()):
        parser.error('output must be new and outside both immutable packages')
    output.mkdir(parents=True)
    if args.command=='replay-pump-control':
        os.environ['HLC_READ_ONLY']='1'
        sys.dont_write_bytecode=True
        sys.path.insert(0,str(PACKAGE/'experiments/pump_control'))
        import compare
        compare.ROOT=output
        compare.BASE=args.data.resolve()
        compare.run(False)
        compare.run(True)
    else:
        from release_training import train
        train(args.command,args.data.resolve(),output,args.seed,args.device)


if __name__=='__main__':
    main()
