"""Independent hydraulic benchmark with hidden causes and downstream sensors.

This module contains physics and durable observations only. It neither trains a
predictor nor selects diagnostic methods or scientific success criteria.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
import os
from pathlib import Path

import numpy as np


PROTOCOL = "hidden_pump_propagation_physics_v1"
STATE_NAMES = ("source_1", "source_2", "path_1", "path_2", "tank_1", "tank_2", "tank_3")
OBSERVED = (4, 5, 6)


@dataclass(frozen=True)
class PumpSpec:
    """Levels in metres, areas in m2, conductances in m2/s, flows in m3/s."""

    sampling_seconds: float = 1.0
    sensor_std_m: float = 0.0005
    areas_m2: tuple[float, ...] = (0.04, 0.07, 0.06, 0.08, 0.15, 0.13, 0.12)
    drains_m2_per_s: tuple[float, ...] = (0.0002, 0.0002, 0.0003, 0.0003, 0.0015, 0.0015, 0.0015)
    pump_max_m3_per_s: tuple[float, float] = (0.0008, 0.0008)
    maximum_level_m: float = 1.5
    topology: str = "coupled_v1"
    observed_state_indices: tuple[int, ...] = OBSERVED
    mode_actuator_gains: tuple[tuple[float, float], ...] = ((1., 1.), (1., 1.), (1., 1.))
    mode_count: int = 3

    def validate(self) -> None:
        if self.topology not in {"coupled_v1", "routed_v2"}:
            raise ValueError("unknown hydraulic topology")
        if type(self.mode_count) is not int or self.mode_count not in (2, 3):
            raise ValueError("exactly two or three declared configurations required")
        observed = self.observed_state_indices
        if (not isinstance(observed, tuple) or len(observed) < 1 or len(set(observed)) != len(observed)
                or any(type(i) is not int or i not in range(2, 7) for i in observed)):
            raise ValueError("unique measured state indices must keep both source states hidden")
        gains = np.asarray(self.mode_actuator_gains, dtype=float)
        if gains.shape != (self.mode_count, 2) or not np.isfinite(gains).all() or np.any(gains <= 0):
            raise ValueError("one positive two-actuator gain per declared configuration required")
        for values, shape in ((self.areas_m2, (7,)), (self.drains_m2_per_s, (7,)),
                              (self.pump_max_m3_per_s, (2,))):
            a = np.asarray(values)
            if a.shape != shape or not np.isfinite(a).all() or np.any(a <= 0):
                raise ValueError("physical coefficients must be finite and positive")
        if not np.isfinite((self.sampling_seconds, self.sensor_std_m, self.maximum_level_m)).all():
            raise ValueError("nonfinite acquisition setting")
        if self.sampling_seconds <= 0 or self.sensor_std_m < 0 or self.maximum_level_m <= 0:
            raise ValueError("invalid acquisition setting")


@dataclass(frozen=True)
class Fault:
    kind: str
    channel: int
    magnitude: float
    start: int
    stop: int

    def validate(self, length: int, *, output_channels: int = 3) -> None:
        if self.kind not in ("pump_loss", "sensor_bias", "downstream_leak"):
            raise ValueError("unknown physical intervention")
        channels = 2 if self.kind == "pump_loss" else 3 if self.kind == "downstream_leak" else output_channels
        if not isinstance(self.channel, int) or not 0 <= self.channel < channels:
            raise ValueError("invalid intervention channel")
        if not isinstance(self.start, int) or not isinstance(self.stop, int) or not 0 <= self.start < self.stop <= length:
            raise ValueError("invalid intervention interval")
        if not np.isfinite(self.magnitude):
            raise ValueError("nonfinite intervention")
        if self.kind == "pump_loss" and not 0 < self.magnitude <= 1:
            raise ValueError("pump loss must be a relative fraction in (0,1]")
        if self.kind == "downstream_leak" and self.magnitude <= 0:
            raise ValueError("leak conductance must be positive")


def matrices(spec: PumpSpec, mode: int, *, leak: tuple[int, float] | None = None):
    """Return A, B, C for a passive network driven at two unmeasured sources."""
    spec.validate()
    if isinstance(mode, (bool, np.bool_)) or not isinstance(mode, (int, np.integer)) or not 0 <= mode < spec.mode_count:
        raise ValueError("undeclared valve configuration")
    weights = (
        ((0.006, 0.004, 0.002), (0.004, 0.006, 0.002)),
        ((0.002, 0.006, 0.004), (0.006, 0.002, 0.004)),
        ((0.006, 0.002, 0.004), (0.002, 0.004, 0.006)),
    )[mode]
    if spec.topology == "routed_v2":
        # Distinct valve routes remain hidden. Only downstream tanks are measured.
        weights = (
            ((0.018, 0.00015, 0.001), (0.00015, 0.018, 0.003)),
            ((0.001, 0.00015, 0.024), (0.010, 0.003, 0.00015)),
            ((0.00015, 0.010, 0.002), (0.002, 0.00015, 0.020)),
        )[mode]
    k = -np.diag(np.asarray(spec.drains_m2_per_s))

    def connect(i: int, j: int, conductance: float) -> None:
        k[i, j] += conductance
        k[j, i] += conductance
        k[i, i] -= conductance
        k[j, j] -= conductance

    source_paths = ((0.010, 0.004),) * 3 if spec.topology == "coupled_v1" else (
        (0.006, 0.003), (0.018, 0.008), (0.003, 0.014))
    connect(0, 2, source_paths[mode][0])
    connect(1, 3, source_paths[mode][1])
    for path, row in zip((2, 3), weights):
        for tank, conductance in zip(OBSERVED, row):
            connect(path, tank, conductance)
    tank_coupling = 0.001 if spec.topology == "coupled_v1" else 0.0001
    connect(4, 5, tank_coupling)
    connect(5, 6, tank_coupling)
    if leak is not None:
        j, conductance = leak
        if j not in range(3) or not np.isfinite(conductance) or conductance <= 0:
            raise ValueError("invalid downstream leak")
        k[OBSERVED[j], OBSERVED[j]] -= conductance
    areas = np.asarray(spec.areas_m2)
    b = np.zeros((7, 2))
    b[0, 0], b[1, 1] = np.asarray(spec.pump_max_m3_per_s) * np.asarray(spec.mode_actuator_gains[mode]) / areas[:2]
    return k / areas[:, None], b, np.eye(7)[list(spec.observed_state_indices)]


def discrete(spec: PumpSpec, mode: int, *, leak: tuple[int, float] | None = None):
    """Exact zero-order hold using the symmetric hydraulic similarity transform."""
    a, b, c = matrices(spec, mode, leak=leak)
    scale = np.sqrt(spec.areas_m2)
    symmetric = scale[:, None] * a / scale[None, :]
    eigenvalues, vectors = np.linalg.eigh(symmetric)
    if np.any(eigenvalues >= 0):
        raise ValueError("passive network must be asymptotically stable")
    exponential = (vectors * np.exp(eigenvalues * spec.sampling_seconds)) @ vectors.T
    integral = (vectors * (np.expm1(eigenvalues * spec.sampling_seconds) / eigenvalues)) @ vectors.T
    ad = exponential * scale[None, :] / scale[:, None]
    bd = integral @ (scale[:, None] * b) / scale[:, None]
    return ad, bd, c


def sensor_noise(spec: PumpSpec, seed: int, stream: int, count: int):
    """Preserve original tank measurements when additional sensors are enabled."""
    spec.validate()
    if type(count) is not int or count < 1 or stream not in (13, 29):
        raise ValueError("positive sample count and a declared sensor stream required")
    original = np.random.default_rng(np.random.SeedSequence([seed, stream])).normal(
        0, spec.sensor_std_m, (count, 3))
    result = np.empty((count, len(spec.observed_state_indices)))
    for column, state in enumerate(spec.observed_state_indices):
        if state in OBSERVED:
            result[:, column] = original[:, OBSERVED.index(state)]
        else:
            rng = np.random.default_rng(np.random.SeedSequence([seed, stream, 1220129, state]))
            result[:, column] = rng.normal(0, spec.sensor_std_m, count)
    return result


def recording(spec: PumpSpec, command: np.ndarray, modes: np.ndarray, *, seed: int,
              fault: Fault | None = None, initial_level_m: np.ndarray | None = None):
    """Simulate held commands. A fault never supplies additional measured channels."""
    spec.validate()
    command = np.asarray(command, dtype=float)
    modes = np.asarray(modes)
    n = len(command)
    if command.shape != (n, 2) or n < 1 or not np.isfinite(command).all():
        raise ValueError("finite two-channel commands required")
    if np.any(command < 0) or np.any(command > 1):
        raise ValueError("pump commands must lie in [0,1]")
    if modes.shape != (n,) or not np.issubdtype(modes.dtype, np.integer) or not np.isin(modes, np.arange(spec.mode_count)).all():
        raise ValueError("one declared physical mode per held input required")
    if fault is not None:
        fault.validate(n, output_channels=len(spec.observed_state_indices))
    x = np.full(7, 0.1) if initial_level_m is None else np.asarray(initial_level_m, dtype=float).copy()
    if x.shape != (7,) or not np.isfinite(x).all() or np.any(x < 0) or np.any(x > spec.maximum_level_m):
        raise ValueError("invalid physical initial state")
    primary_noise = sensor_noise(spec, seed, 13, n + 1)
    confirmation_noise = sensor_noise(spec, seed, 29, n + 1)
    states = np.empty((n + 1, 7))
    states[0] = x
    effective = command.copy()
    active = np.zeros(n, dtype=bool)
    if fault is not None:
        active[fault.start:fault.stop] = True
        if fault.kind == "pump_loss":
            effective[active, fault.channel] *= 1 - fault.magnitude
    operators = {q: discrete(spec, q) for q in range(spec.mode_count)}
    leaking = None
    if fault is not None and fault.kind == "downstream_leak":
        leaking = {q: discrete(spec, q, leak=(fault.channel, fault.magnitude)) for q in range(spec.mode_count)}
    for t, mode in enumerate(modes):
        ad, bd, _ = (leaking if leaking is not None and active[t] else operators)[int(mode)]
        x = ad @ x + bd @ effective[t]
        if not np.isfinite(x).all() or np.any(x < -1e-12) or np.any(x > spec.maximum_level_m):
            raise ValueError("trajectory outside the declared physical level range")
        states[t + 1] = x
    clean = states[:, list(spec.observed_state_indices)]
    bias = np.zeros_like(clean)
    if fault is not None and fault.kind == "sensor_bias":
        bias[fault.start + 1:fault.stop + 1, fault.channel] = fault.magnitude
    signals = {"command": command.copy(), "y": clean + primary_noise + bias,
               "confirmation": clean + confirmation_noise + bias,
               "time": np.arange(n + 1) * spec.sampling_seconds}
    reference = {"latent_state": states, "clean_y": clean.copy(), "effective_command": effective,
                 "physical_mode": modes.copy(), "fault_active": active}
    return signals, reference


def save_recording(directory: Path, signals: dict, reference: dict, *, spec: PumpSpec,
                   seed: int, fault: Fault | None, purpose: str) -> dict:
    """Create immutable observations and a separate evaluation-only reference."""
    directory = Path(directory)
    directory.mkdir(mode=0o700, parents=True, exist_ok=False)
    entries = {}
    for name, values in (("observations.npz", signals), ("reference_only.npz", reference)):
        path = directory / name
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "wb") as stream:
            np.savez_compressed(stream, **values)
        entries[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    report = {"protocol": PROTOCOL, "spec": asdict(spec), "seed": seed,
              "fault_reference_only": None if fault is None else asdict(fault), "purpose": purpose,
              "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "files": entries, "reference_used_for_learning": False,
              "primary_and_confirmation_noise_streams_distinct": True}
    fd = os.open(directory / "manifest.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    return report
