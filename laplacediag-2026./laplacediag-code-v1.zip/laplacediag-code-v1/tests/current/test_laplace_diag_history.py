"""Analytical history-training tests, without plant simulation."""
import copy, tempfile, time, unittest, subprocess, sys, os
from pathlib import Path
from unittest.mock import patch
import numpy as np
import torch
from high_level_control.models import LaplaceNetOperator
from high_level_control.laplace_diag_history import FrozenForcingHistory, fit_history, tensor_digest

class HistoryTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1);torch.manual_seed(17)
        self.parent=LaplaceNetOperator(history_dim=10,input_dim=2,output_dim=3,horizon=4,hidden_dim=8,laplace_points=2,sigma=.02,sampling_time_seconds=1.,transfer_mode='fixed',architecture_version='causal_laplace_convolution_v3')
        rng=np.random.default_rng(99)
        self.train={'history':rng.normal(size=(17,10)).astype('float32'),'u':rng.normal(size=(17,4,2)).astype('float32'),'y':rng.normal(size=(17,4,3)).astype('float32')}
        self.val={k:v[:7].copy()+.3 for k,v in self.train.items()}
        self.forcing=np.zeros((12,8),dtype='float32')
        self.config=dict(learning_rate=.003,weight_decay=1e-5,batch_size=5,epochs_per_new_fit=3,gradient_clip=5.)
        self.device='cuda:0' if torch.cuda.is_available() else 'cpu'
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
    def fit(self,model,path='progress.pt',deadline=None):
        return fit_history(model,self.train,self.val,self.config,seed=13,device=self.device,deadline=time.time()+60 if deadline is None else deadline,progress_path=Path(self.temp.name)/path,identity={'test':1})
    def test_laplace_import_does_not_require_optional_clustering(self):
        code="""import torch,importlib.abc,sys
class Block(importlib.abc.MetaPathFinder):
    def find_spec(self,fullname,path=None,target=None):
        if fullname=='sklearn' or fullname.startswith('sklearn.'):
            raise ImportError('optional clustering deliberately unavailable')
sys.meta_path.insert(0,Block())
from high_level_control.models import LaplaceNetOperator
model=LaplaceNetOperator(history_dim=10,input_dim=2,output_dim=3,horizon=4,hidden_dim=8,laplace_points=2,sigma=.02,sampling_time_seconds=1.,transfer_mode='fixed',architecture_version='causal_laplace_convolution_v3')
assert model(torch.zeros(2,10),torch.zeros(2,4,2)).shape==(2,4,3)
"""
        subprocess.run([sys.executable,'-B','-c',code],check=True,capture_output=True,text=True,env=os.environ.copy())
    def test_only_history_parameters_trainable(self):
        model=FrozenForcingHistory(self.parent,self.forcing)
        names=[n for n,p in model.named_parameters() if p.requires_grad]
        self.assertTrue(names);self.assertTrue(all(n.startswith(('base.encoder.','base.free_head.')) for n in names))
        before={n:tensor_digest(p) for n,p in self.parent.named_parameters()}
        trained,receipt=self.fit(model)
        self.assertEqual(before,{n:tensor_digest(p) for n,p in self.parent.named_parameters()})
        self.assertEqual(tensor_digest(trained.base.fixed_transfer),tensor_digest(self.parent.fixed_transfer))
        np.testing.assert_array_equal(trained.forcing.detach().numpy(),self.forcing)
    def test_all_examples_and_separate_validation_minimum(self):
        model,receipt=self.fit(FrozenForcingHistory(self.parent,self.forcing))
        self.assertEqual([r['epoch'] for r in receipt['trace']],[0,1,2,3])
        self.assertEqual([r['examples'] for r in receipt['trace'][1:]],[17,17,17])
        self.assertEqual(receipt['selected_epoch'],min(receipt['trace'],key=lambda x:x['validation_mse'])['epoch'])
        with torch.no_grad():
            val=((model(torch.tensor(self.val['history']),torch.tensor(self.val['u']))-torch.tensor(self.val['y']).flatten(1))**2).mean().item()
        self.assertAlmostEqual(val,receipt['minimum_validation_mse'],places=5)
    def test_paired_order_independent_of_operator(self):
        _,a=self.fit(FrozenForcingHistory(self.parent,self.forcing),'a.pt')
        _,b=self.fit(FrozenForcingHistory(self.parent,self.forcing+.1),'b.pt')
        self.assertEqual([r['order_sha256'] for r in a['trace'][1:]],[r['order_sha256'] for r in b['trace'][1:]])
    def test_deadline_checkpoint_and_resume(self):
        model=FrozenForcingHistory(self.parent,self.forcing)
        with self.assertRaises(TimeoutError):self.fit(model,deadline=time.time()-1)
        resumed,receipt=self.fit(FrozenForcingHistory(self.parent,self.forcing))
        direct,other=self.fit(FrozenForcingHistory(self.parent,self.forcing),'direct.pt')
        self.assertEqual(receipt['selected_epoch'],other['selected_epoch'])
        for key,value in resumed.state_dict().items():torch.testing.assert_close(value,direct.state_dict()[key],rtol=0,atol=0)
    def test_resume_after_completed_optimizer_updates(self):
        with patch('high_level_control.laplace_diag_history.time.time',side_effect=[0.,0.,100.]):
            with self.assertRaises(TimeoutError):self.fit(FrozenForcingHistory(self.parent,self.forcing),deadline=50.)
        saved=torch.load(Path(self.temp.name)/'progress.pt',weights_only=False,map_location='cpu')
        self.assertEqual(saved['epoch'],2)
        self.assertTrue(saved['optimizer']['state'])
        resumed,receipt=self.fit(FrozenForcingHistory(self.parent,self.forcing))
        direct,other=self.fit(FrozenForcingHistory(self.parent,self.forcing),'direct.pt')
        self.assertEqual(receipt['selected_epoch'],other['selected_epoch'])
        for key,value in resumed.state_dict().items():torch.testing.assert_close(value,direct.state_dict()[key],rtol=0,atol=0)
    def test_changed_resume_identity_rejected(self):
        with self.assertRaises(TimeoutError):self.fit(FrozenForcingHistory(self.parent,self.forcing),deadline=time.time()-1)
        with self.assertRaises(ValueError):self.fit(FrozenForcingHistory(self.parent,self.forcing+.1))
    def test_no_validation_fails(self):
        self.val={k:v[:0] for k,v in self.val.items()}
        with self.assertRaises(ValueError):self.fit(FrozenForcingHistory(self.parent,self.forcing))
    def test_component_and_forward_agree_on_available_device(self):
        wrapped=FrozenForcingHistory(self.parent,self.forcing).to(self.device)
        h=torch.tensor(self.train['history'],device=self.device);u=torch.tensor(self.train['u'],device=self.device)
        b,g=wrapped.components(h)
        torch.testing.assert_close(wrapped(h,u),b+torch.bmm(g,u.flatten(1).unsqueeze(2)).squeeze(2))
        self.assertEqual(g.shape,(17,12,8))
