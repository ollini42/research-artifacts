"""Causal input, training/validation and baseline checks for LaplaceDiag."""

import unittest

import numpy as np

from high_level_control.laplace_diag import EffectBasis, estimate_effect
from high_level_control.laplace_diag_experiment import (
    aggregate_reports,
    attach_decisions,
    concatenate_windows,
    estimate_dict,
    fit_varx,
    make_windows,
    neural_components,
    projection_scores,
    score_record,
    training_scaler,
    varx_prediction,
    verify_varx_normal_equations,
    window_consistency,
)


class DataAndBaselineTests(unittest.TestCase):
    def test_exact_window_timing(self):
        record = {
            "u": np.arange(40.0).reshape(20, 2),
            "y": np.arange(63.0).reshape(21, 3),
        }
        scaler = {
            k: np.zeros(n) if k.endswith("mean") else np.ones(n)
            for k, n in [("u_mean", 2), ("u_scale", 2), ("y_mean", 3), ("y_scale", 3)]
        }
        window = make_windows(record, scaler, 3, 4)
        np.testing.assert_array_equal(
            window["history"][0],
            np.r_[record["u"][:3].ravel(), record["y"][1:4].ravel()],
        )
        np.testing.assert_array_equal(window["u"][0], record["u"][3:7])
        np.testing.assert_array_equal(window["y"][0], record["y"][4:8])
        self.assertEqual(window["origins"][-1], 16)

    def test_normalization_and_all_windows(self):
        rng = np.random.default_rng(4)
        records = [
            {"u": rng.normal(size=(70, 2)), "y": rng.normal(size=(71, 3))}
            for _ in range(3)
        ]
        scaler = training_scaler(records[:2])
        np.testing.assert_allclose(
            scaler["u_mean"], np.concatenate([x["u"] for x in records[:2]]).mean(0)
        )
        windows = [make_windows(r, scaler, 12, 12) for r in records[:2]]
        combined = concatenate_windows(windows)
        self.assertEqual(len(combined["u"]), 2 * (70 - 12 - 12 + 1))
        np.testing.assert_array_equal(np.unique(combined["sequence"]), [0, 1])

    def test_dynamic_baseline_recovers_causal_linear_map(self):
        rng = np.random.default_rng(13)
        h, u = rng.normal(size=(220, 5)), rng.normal(size=(220, 4, 2))
        coefficients = [rng.normal(size=(6 + 2 * (i + 1), 3)) for i in range(4)]
        y = np.stack(
            [
                np.c_[np.ones(220), h, u[:, : i + 1].reshape(220, -1)] @ coefficients[i]
                for i in range(4)
            ],
            axis=1,
        )
        windows = {"history": h, "u": u, "y": y}
        model = fit_varx(windows, 1e-12)
        verify_varx_normal_equations(model, windows, 1e-12)
        broken = {key: value.copy() for key, value in model.items()}
        broken["free"][0, 0, 0] += 0.01
        with self.assertRaises(AssertionError):
            verify_varx_normal_equations(broken, windows, 1e-12)
        np.testing.assert_allclose(varx_prediction(model, windows), y, atol=1e-9)
        changed = {**windows, "u": u.copy()}
        changed["u"][:, -1] += 100
        np.testing.assert_allclose(
            varx_prediction(model, changed)[:, :-1], y[:, :-1], atol=1e-9
        )

    def test_projection_uses_nominal_effect_signatures(self):
        rng = np.random.default_rng(5)
        u = rng.normal(size=(30, 2, 2))
        operator = np.eye(4)
        residual = np.zeros((30, 2, 2))
        residual[:, :, 1] = -0.4 * u[:, :, 1]
        scores = projection_scores(residual, u, operator, np.ones(2))
        self.assertGreater(scores[1], scores[0])

    def test_all_methods_keep_identical_timing_and_no_ground_truth(self):
        scored = {
            "checks": [
                {
                    "observed_until": i,
                    "scores": {
                        "laplacediag": [100.0, 0.0],
                        "projection": [100.0, 0.0],
                        "varx": [100.0],
                    },
                }
                for i in (20, 40)
            ]
        }
        calibration = {
            name: list(np.arange(39.0))
            for name in ("laplacediag", "projection", "varx")
        }
        calibration.update(maximum_checks=2, alpha=0.05)
        result = attach_decisions(scored, calibration)
        self.assertTrue(
            all(x["alarm_history"]["ever_alarm"] for c in result["checks"] for x in c["decisions"].values())
        )

    def test_preexisting_alarm_is_not_counted_as_new_fault_detection(self):
        checks = []
        for time in (20, 40):
            checks.append(
                {
                    "observed_until": time,
                    "seconds_wall_cpu": {
                        n: [1.0, 1.0] for n in ("laplacediag", "projection", "varx")
                    },
                    "decisions": {
                        n: {
                            "decision_schema": 2,
                            "alarm_history": {"ever_alarm": True, "first_alarm_at": 20},
                            "current_assignment": {"status": "tested", "candidate_actuators": [0]},
                        }
                        for n in ("laplacediag", "projection", "varx")
                    },
                }
            )
        summary = aggregate_reports(
            [
                (
                    {"condition": "pump0_loss40", "onset": 30, "actuator": 0},
                    {"checks": checks},
                )
            ]
        )
        self.assertEqual(
            summary["laplacediag"]["pump0_loss40"]["detected_after_onset"], 0
        )
        self.assertEqual(summary["laplacediag"]["pump0_loss40"]["pre_onset_alarms"], 1)

    def test_current_summary_does_not_reuse_previous_cause(self):
        scored = {"checks": [
            {"observed_until": t, "scores": {"laplacediag": v, "projection": v, "varx": [100.]},
             "seconds_wall_cpu": {m: [0., 0.] for m in ("laplacediag", "projection", "varx")}}
            for t, v in ((20, [100., 0.]), (40, [0., 100.]), (60, None))]}
        calibration = {m: list(np.arange(39.)) for m in ("laplacediag", "projection", "varx")}
        calibration.update(maximum_checks=3, alpha=.05)
        report = attach_decisions(scored, calibration)
        summary = aggregate_reports([({"condition": "pump1_loss40", "onset": 10, "actuator": 1}, report)])
        times = summary["laplacediag"]["pump1_loss40"]["current_assignment_by_step"]
        self.assertEqual(times["20"]["unique_wrong"], 1)
        self.assertEqual(times["40"]["unique_correct"], 1)
        self.assertEqual(times["60"]["not_determined"], 1)
        self.assertEqual(summary["varx"]["pump1_loss40"]["current_assignment_by_step"]["40"]["anomaly_without_localization"], 1)

    def test_fixed_halves_reject_a_gain_change_but_not_a_constant_effect(self):
        rng = np.random.default_rng(12)
        basis = EffectBasis.laplace(12, 4, .02, 5., 2, 3)
        u = rng.normal(size=(16, 12, 2))
        free = rng.normal(size=(16, 12, 3))
        coefficients = rng.normal(size=(14, 3))
        y = free + np.einsum("bhd,do->bho", basis.design(u), coefficients)
        stable = window_consistency(basis, u, y, free)
        self.assertEqual(stable["status"], "estimated")
        self.assertLess(stable["score"], 1e-12)
        changed = y.copy()
        changed[8:] = free[8:] + .5*(y[8:] - free[8:])
        mixed = window_consistency(basis, u, changed, free)
        self.assertGreater(mixed["score"], 1e8)

    def test_consistency_gate_is_shared_and_keeps_alarm_evidence(self):
        scored = {"checks": [{
            "observed_until": 204,
            "scores": {"laplacediag": [100., 0.], "projection": [100., 0.], "varx": [100.]},
            "window_consistency": {"status": "estimated", "score": 100.}
        }]}
        calibration = {m: list(np.arange(39.)) for m in ("laplacediag", "projection", "varx", "window_consistency")}
        calibration.update(maximum_checks=1, alpha=.05)
        result = attach_decisions(scored, calibration, consistency_gate=True)
        for name in ("laplacediag", "projection"):
            decision = result["checks"][0]["decisions"][name]
            self.assertTrue(decision["alarm_history"]["ever_alarm"])
            self.assertEqual(decision["current_assignment"]["candidate_actuators"], [])
            self.assertEqual(decision["current_assignment"]["status"], "window_not_stationary")
        self.assertTrue(result["checks"][0]["decisions"]["varx"]["current_assignment"]["alarm"])

    def test_undetermined_consistency_never_declares_stationarity(self):
        rng = np.random.default_rng(14)
        basis = EffectBasis.laplace(12, 4, .02, 5., 2, 3)
        y = rng.normal(size=(16, 12, 3))
        check = window_consistency(basis, np.ones((16, 12, 2)), y, np.zeros_like(y))
        self.assertIsNone(check["score"])
        self.assertEqual(check["status"], "not_determined")


class TorchIntegrationTests(unittest.TestCase):
    def setUp(self):
        try:
            import torch
        except ImportError:
            self.skipTest("PyTorch unavailable in this local NumPy-only check")
        self.torch = torch
        torch.set_num_threads(1)

    def test_exact_neural_laplace_basis(self):
        from high_level_control.models import LaplaceNetOperator

        torch = self.torch
        for horizon, points in ((1, 4), (6, 3), (12, 4)):
            model = LaplaceNetOperator(
                5, 2, 3, horizon, 8, points, 0.02, 5.0, transfer_mode="fixed"
            )
            history = torch.randn(7, 5)
            with torch.no_grad():
                _, operators = model.components(history)
            basis = EffectBasis.laplace(horizon, points, 0.02, 5.0, 2, 3)
            coefficients = basis.coefficients(operators[0].numpy())
            np.testing.assert_allclose(
                basis.operator(coefficients), operators[0].numpy(), atol=2e-6
            )

    def test_corrected_training_uses_separate_validation(self):
        from high_level_control.two_phase_learning import (
            LaplaceFitConfig,
            ModelData,
            fit_laplace,
        )

        rng = np.random.default_rng(24)

        def data(count):
            h = rng.normal(size=(count, 3)).astype("float32")
            u = rng.normal(size=(count, 1, 2)).astype("float32")
            return ModelData(h, u, (h[:, :1, None] + u[:, :, :1]).astype("float32"))

        train, validation = data(37), data(19)
        result = fit_laplace(
            train,
            LaplaceFitConfig(
                hidden_dim=4,
                laplace_points=1,
                epochs=3,
                batch_size=8,
                seed=2,
                validation_fraction=0.2,
            ),
            validation=validation,
        )
        self.assertEqual(result.training_status["training_windows"], 37)
        self.assertEqual(result.training_status["internal_validation_windows"], 19)
        self.assertEqual(result.training_status["examples_processed"], 37 * 3)
        self.assertEqual(
            result.best_epoch,
            min(range(len(result.log)), key=lambda i: result.log[i]["validation_mse"]),
        )

    def test_online_scores_do_not_read_future_suffix_or_mutate_model(self):
        from high_level_control.models import LaplaceNetOperator

        rng = np.random.default_rng(32)
        record = {"u": rng.normal(size=(120, 2)), "y": rng.normal(size=(121, 3))}
        scaler = training_scaler([record])
        model = LaplaceNetOperator(15, 2, 3, 3, 8, 2, 0.02, 0.1, transfer_mode="fixed")
        windows = make_windows(record, scaler, 3, 3, 3)
        free, _, _ = neural_components(model, windows)
        basis = EffectBasis.laplace(3, 2, 0.02, 0.1, 2, 3)
        estimate = estimate_effect(basis, windows["u"], windows["y"], free)
        reference = {
            "temporal_basis": basis.temporal.tolist(),
            "estimate": estimate_dict(estimate),
            "neural_error_scale": [1.0, 1.0, 1.0],
            "linear_error_scale": [1.0, 1.0, 1.0],
        }
        linear = fit_varx(windows)
        settings = {"history": 3, "horizon": 3, "block_windows": 8}
        before = {k: v.clone() for k, v in model.state_dict().items()}
        original = score_record(record, scaler, model, linear, reference, settings)
        changed = {k: v.copy() for k, v in record.items()}
        changed["u"][80:] += 100
        changed["y"][81:] -= 100
        future = score_record(changed, scaler, model, linear, reference, settings)
        for left, right in zip(original["checks"], future["checks"], strict=True):
            if left["observed_until"] <= 80:
                for method in left["scores"]:
                    np.testing.assert_allclose(
                        left["scores"][method], right["scores"][method], atol=1e-8
                    )
        for key, value in model.state_dict().items():
            self.torch.testing.assert_close(value, before[key], rtol=0, atol=0)


if __name__ == "__main__":
    unittest.main()
