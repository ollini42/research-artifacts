"""Analytical fixtures for plant-effect estimation, not simulated experiments."""

import unittest
from dataclasses import replace

import numpy as np

from high_level_control.laplace_diag import (
    EffectBasis,
    EpisodeCalibration,
    EpisodeMonitor,
    EstimationPolicy,
    change_scores,
    estimate_effect,
)


class LaplaceDiagTests(unittest.TestCase):
    def setUp(self):
        self.rng = np.random.default_rng(713)
        self.basis = EffectBasis.laplace(6, 3, 0.02, 0.2, 2, 3)
        self.u = self.rng.normal(size=(80, 6, 2))
        self.c = self.rng.normal(size=(self.basis.parameters_per_output, 3))
        self.free = self.rng.normal(size=(80, 6, 3))
        self.y = self.free + np.einsum("bhd,do->bho", self.basis.design(self.u), self.c)

    def test_estimate_known_effect_and_preserve_callers(self):
        before = [x.copy() for x in (self.u, self.y, self.free)]
        result = estimate_effect(self.basis, self.u, self.y, self.free)
        self.assertEqual(result.status, "estimated")
        np.testing.assert_allclose(result.coefficients, self.c, atol=1e-12)
        for old, current in zip(before, (self.u, self.y, self.free), strict=True):
            np.testing.assert_array_equal(old, current)

    def test_causal_convolution_round_trip(self):
        operator = self.basis.operator(self.c)
        direct = self.u.reshape(80, -1) @ operator.T
        reference = np.einsum("bhd,do->bho", self.basis.design(self.u), self.c)
        np.testing.assert_allclose(
            direct.reshape(reference.shape), reference, atol=1e-12
        )
        np.testing.assert_allclose(
            self.basis.coefficients(operator), self.c, atol=1e-12
        )
        changed = self.u.copy()
        changed[:, -1] += 100
        predictions = np.einsum("bhd,do->bho", self.basis.design(changed), self.c)
        np.testing.assert_allclose(predictions[:, :-1], reference[:, :-1], atol=1e-12)

    def test_one_step_does_not_test_redundant_complex_weights(self):
        basis = EffectBasis.laplace(1, 4, 0.2, 1.0, 2, 3)
        self.assertEqual(basis.temporal.shape, (1, 1))
        self.assertEqual(basis.parameters_per_output, 2)

    def test_operator_outside_causal_subspace_is_rejected(self):
        operator = self.basis.operator(self.c)
        operator[0, -1] = 0.1
        with self.assertRaises(ValueError):
            self.basis.coefficients(operator)

    def test_constant_bias_is_nuisance_not_effect_change(self):
        shift = self.rng.normal(size=(6, 3)) * 10
        result = estimate_effect(self.basis, self.u, self.y + shift, self.free)
        np.testing.assert_allclose(result.coefficients, self.c, atol=1e-12)
        np.testing.assert_allclose(result.free_offset, shift, atol=1e-12)

    def test_constant_or_dependent_actuation_abstains(self):
        constant = np.ones_like(self.u)
        result = estimate_effect(self.basis, constant, self.y, self.free)
        self.assertEqual(result.status, "unexcited_effect_direction")
        correlated = self.u.copy()
        correlated[:, :, 1] = 2 * correlated[:, :, 0]
        result = estimate_effect(self.basis, correlated, self.y, self.free)
        self.assertEqual(result.status, "unidentified_effect_directions")
        self.assertIsNone(result.coefficients)

    def test_too_few_windows_abstains(self):
        result = estimate_effect(self.basis, self.u[:2], self.y[:2], self.free[:2])
        self.assertEqual(result.status, "insufficient_windows")

    def test_joint_covariance_is_symmetric_positive_semidefinite(self):
        noise = self.rng.normal(size=(80, 6, 1)) * np.array([0.03, -0.02, 0.06])
        result = estimate_effect(self.basis, self.u, self.y + noise, self.free)
        np.testing.assert_allclose(result.covariance, result.covariance.T, atol=1e-12)
        self.assertGreater(np.linalg.norm(result.covariance), 0)
        self.assertGreater(np.linalg.eigvalsh(result.covariance).min(), -1e-12)

    def test_reference_is_immutable_and_rejects_corrupted_covariance(self):
        result = estimate_effect(self.basis, self.u, self.y, self.free)
        with self.assertRaises(ValueError):
            result.coefficients[0, 0] = 100
        with self.assertRaises(ValueError):
            replace(result, covariance=np.full_like(result.covariance, np.inf))
        with self.assertRaises(ValueError):
            replace(result, covariance=np.zeros((1, 1)))

    def test_true_actuator_change_localizes_without_inversion(self):
        ref = estimate_effect(self.basis, self.u, self.y, self.free)
        coefficients = self.c.copy().reshape(-1, 2, 3)
        coefficients[:, 1] *= 0.6
        outputs = self.free + np.einsum(
            "bhd,do->bho", self.basis.design(self.u), coefficients.reshape(-1, 3)
        )
        new = estimate_effect(self.basis, self.u, outputs, self.free)
        scores = change_scores(self.basis, ref, new)
        self.assertLess(scores[0], 1e-10)
        self.assertGreater(scores[1], 1e8)

    def test_nonfinite_and_mismatched_inputs_are_rejected(self):
        with self.assertRaises(ValueError):
            self.basis.design(self.u.astype(complex) + 1j)
        with self.assertRaises(ValueError):
            estimate_effect(self.basis, self.u, self.y[:, :-1], self.free)
        bad = self.y.copy()
        bad[0, 0, 0] = np.nan
        with self.assertRaises(ValueError):
            estimate_effect(self.basis, self.u, bad, self.free)
        with self.assertRaises(ValueError):
            EstimationPolicy(maximum_condition=0.5)

    def test_calibration_uses_ties_and_plus_one(self):
        calibration = EpisodeCalibration(
            np.arange(39.0), maximum_checks=10, state_families=2
        )
        np.testing.assert_allclose(
            calibration.p_values(np.array([38.0, 39.0])), [2 / 40, 1 / 40]
        )
        self.assertTrue(calibration.resolution_sufficient)
        self.assertFalse(
            EpisodeCalibration(
                np.arange(38.0), 10, state_families=2
            ).resolution_sufficient
        )

    def test_episode_budget_never_restarts_after_missing_check_or_alarm(self):
        monitor = EpisodeMonitor(EpisodeCalibration(np.arange(39.0), 3), 2)
        self.assertEqual(
            monitor.update(None, observed_until=20)["current_assignment"]["status"], "not_determined"
        )
        result = monitor.update(np.array([100.0, 0.0]), observed_until=30)
        self.assertTrue(result["alarm_history"]["ever_alarm"])
        self.assertTrue(monitor.update(np.zeros(2), observed_until=40)["alarm_history"]["ever_alarm"])
        exhausted = monitor.update(np.zeros(2), observed_until=50)
        self.assertEqual(exhausted["current_assignment"]["status"], "episode_budget_exhausted")
        self.assertTrue(exhausted["alarm_history"]["ever_alarm"])
        self.assertEqual(exhausted["current_assignment"]["candidate_actuators"], [])

    def test_unavailable_check_keeps_existing_alarm(self):
        monitor = EpisodeMonitor(EpisodeCalibration(np.arange(39.0), 3), 2)
        monitor.update(np.array([100.0, 0.0]), observed_until=10)
        result = monitor.update(None, observed_until=20)
        self.assertEqual(result["current_assignment"]["status"], "not_determined")
        self.assertTrue(result["alarm_history"]["ever_alarm"])
        self.assertIsNone(result["current_assignment"]["p_values"])
        self.assertEqual(result["current_assignment"]["candidate_actuators"], [])

    def test_current_cause_changes_without_carrying_old_candidates(self):
        monitor = EpisodeMonitor(EpisodeCalibration(np.arange(39.0), 3), 2)
        first = monitor.update(np.array([100.0, 0.0]), observed_until=10)
        second = monitor.update(np.array([0.0, 100.0]), observed_until=20)
        self.assertEqual(first["current_assignment"]["candidate_actuators"], [0])
        self.assertEqual(second["current_assignment"]["candidate_actuators"], [1])
        self.assertEqual(second["alarm_history"]["actuators_ever_flagged"], [0, 1])
        self.assertEqual(second["alarm_history"]["first_alarm_at"], 10)
        third = monitor.update(np.zeros(2), observed_until=30)
        self.assertFalse(third["current_assignment"]["alarm"])
        self.assertTrue(third["alarm_history"]["ever_alarm"])

    def test_nonstationarity_blocks_assignment_without_erasing_alarm(self):
        monitor = EpisodeMonitor(EpisodeCalibration(np.arange(39.0), 3), 2)
        value = monitor.update(np.array([100.0, 0.0]), observed_until=10,
                               assignment_reason="window_not_stationary")
        self.assertTrue(value["alarm_history"]["ever_alarm"])
        self.assertEqual(value["current_assignment"]["candidate_actuators"], [])
        self.assertEqual(value["current_assignment"]["status"], "window_not_stationary")
        with self.assertRaises(ValueError):
            monitor.update(np.zeros(2), observed_until=20, assignment_reason="unknown")
        self.assertEqual(monitor.checks, 1)

    def test_invalid_update_does_not_consume_budget(self):
        monitor = EpisodeMonitor(EpisodeCalibration(np.arange(39.0), 3), 2)
        with self.assertRaises(ValueError):
            monitor.update(np.array([-1.0, 0.0]), observed_until=20)
        self.assertEqual(monitor.checks, 0)
        monitor.update(np.zeros(2), observed_until=20)
        with self.assertRaises(ValueError):
            monitor.update(np.zeros(2), observed_until=20)

    def test_rank_bound_for_every_possible_heldout_exchangeable_episode(self):
        # Exact enumeration of ranks, not a Monte Carlo claim. Prefix maxima
        # never exceed a complete episode maximum, however dependent the checks.
        maxima = np.arange(40.0)
        alarms = 0
        for index, value in enumerate(maxima):
            calibration = EpisodeCalibration(np.delete(maxima, index), 3, alpha=0.05)
            monitor = EpisodeMonitor(calibration, 1)
            outcomes = [
                monitor.update(np.array([value * fraction]), observed_until=t)
                for t, fraction in enumerate((0.1, 0.5, 1.0), start=1)
            ]
            alarms += any(x["alarm_history"]["ever_alarm"] for x in outcomes)
        self.assertEqual(alarms, 2)


if __name__ == "__main__":
    unittest.main()
