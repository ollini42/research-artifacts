"""Array-level diagnosis adapter for an explicitly supplied healthy reference.

No generic next-step forecasting interface is claimed. LaplaceDiag consumes the
plant model's free response and already completed input/output windows.
"""
from high_level_control.laplace_diag import estimate_effect,change_scores


class ActuatorEffectAdapter:
    """Compare a current effect estimate with one fixed healthy reference."""
    def __init__(self,basis,reference):
        self.basis=basis
        self.reference=reference

    def estimate(self,inputs,outputs,free_response):
        """Return the fixed-reference effect estimate and actuator scores."""
        current=estimate_effect(self.basis,inputs,outputs,free_response,reference=self.reference)
        return current,change_scores(self.basis,self.reference,current)
