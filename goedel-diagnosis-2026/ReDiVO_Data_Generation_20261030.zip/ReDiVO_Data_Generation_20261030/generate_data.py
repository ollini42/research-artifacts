#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Oliver Niggemann
# Affiliation: Helmut Schmidt University / University of the Federal Armed Forces Hamburg
# SPDX-License-Identifier: AGPL-3.0-or-later
# Use at your own risk. No warranty. Liability is excluded where law permits.
# See NOTICE and LICENSES/AGPL-3.0-or-later.txt.
"""Generate explicitly selected artificial data. No training or remote execution."""
from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
NOTICE = ("Copyright (c) 2026 Oliver Niggemann.\n"
          "Affiliation: Helmut Schmidt University / University of the Federal Armed Forces Hamburg, Germany.\n"
          "SPDX-License-Identifier: CC-BY-SA-4.0\n"
          "No warranties or guarantees. Use at your own risk. Liability is excluded as far as applicable law allows.\n"
          "Legally mandatory liabilities remain unaffected. See the supplied NOTICE and CC-BY-SA-4.0 license.\n")


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def generate_linear(args, job):
    import numpy as np
    generator = load_module('linear_generator', ROOT/'linear/generator.py')
    p = job['payload']
    config = generator.StateSpaceConfig(**{
        **p['data'], 'seed': args.seed,
        'normal_validation_cases': p['selection_cases'] + p['calibration_cases'],
    })
    system = generator.generate_state_space_system(config)
    specs = []
    for split_id, (split, count) in enumerate((
        ('train', config.normal_train_cases),
        ('val', config.normal_validation_cases),
        ('test', config.normal_test_cases),
    )):
        for i in range(count):
            role = split if split != 'val' else ('selection' if i < p['selection_cases'] else 'calibration')
            specs.append(dict(case=f'{split}_normal_{i:03d}', split=split, role=role,
                              seed=int(np.random.SeedSequence([config.seed, split_id, i, 81]).generate_state(1)[0]),
                              fault_component=None))
    for component in range(config.component_count):
        for replicate in range(config.fault_replicates):
            specs.append(dict(case=f'test_fault_{component:03d}_{replicate:02d}', split='test', role='fault',
                              seed=int(np.random.SeedSequence([config.seed, component, replicate, 82]).generate_state(1)[0]),
                              fault_component=component))
    metadata = dict(data_version=generator.DATA_VERSION, condition_id=p['condition_id'],
                    system=system.manifest(), configuration=asdict(config),
                    columns=system.feature_columns, episodes={}, numpy_version=np.__version__)
    for item in specs:
        episode = generator.simulate_episode(system, item['seed'], fault_component=item['fault_component'],
                                             split=item['split'], case_id=item['case'])
        path = args.output/(item['case']+'.npz')
        with path.open('xb') as handle:
            np.savez_compressed(handle, values=episode.values, clean=episode.clean_values,
                                counterfactual=episode.counterfactual, seed=episode.seed,
                                times=np.arange(config.duration_steps)*config.sample_period_seconds,
                                fault_component=-1 if episode.fault_component is None else episode.fault_component,
                                fault_onset=-1 if episode.fault_onset is None else episode.fault_onset)
        metadata['episodes'][item['case']] = dict(**item, sha256=sha(path), bytes=path.stat().st_size)
    (args.output/'manifest.json').write_text(json.dumps(metadata, indent=2, sort_keys=True)+'\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('list', 'generate'))
    parser.add_argument('--family', choices=('linear', 'hybrid'), required=True)
    parser.add_argument('--condition', help='Required for a linear graph-condition job')
    parser.add_argument('--seed', type=int)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--execute', action='store_true', help='Explicitly authorize local data generation')
    args = parser.parse_args()
    manifest = json.loads((ROOT/'configs/linear_campaign_manifest.json').read_text())
    protocol = json.loads((ROOT/'hybrid/configs/hybrid_automata_20261027.json').read_text())
    if args.action == 'list':
        if args.family == 'linear':
            print(json.dumps([dict(condition=j['payload']['condition_id'], seed=j['payload']['seeds'][0],
                                   components=j['component_count']) for j in manifest['jobs']], indent=2))
        else:
            print(json.dumps(dict(main=list(range(27101, 27109)), development=[27001, 27002],
                                  larger_exploratory=list(range(27201, 27205))), indent=2))
        return
    if not args.execute or args.seed is None or args.output is None:
        parser.error('Generation requires --execute, --seed, and --output. No data have been generated.')
    job = None
    if args.family == 'linear':
        jobs = [j for j in manifest['jobs'] if j['payload']['condition_id'] == args.condition
                and j['payload']['seeds'] == [args.seed]]
        if len(jobs) != 1:
            parser.error('Choose one exact linear condition and seed from the list.')
        job = jobs[0]
    elif args.seed not in protocol['system_seeds']:
        parser.error('Hybrid seed is outside the frozen protocol.')
    if args.output.exists() and any(args.output.iterdir()):
        parser.error('Output directory must be new or empty.')
    args.output.mkdir(mode=0o700, parents=True, exist_ok=True)
    if args.family == 'linear':
        generate_linear(args, job)
    else:
        generator = load_module('hybrid_generator', ROOT/'hybrid/src/lgb_diagnosis/hybrid_automata.py')
        complete = generator.generate_dataset(args.output, generator.generate_system(args.seed))
        if not complete:
            raise RuntimeError('Generation is incomplete')
    for path in sorted(args.output.iterdir()):
        if path.is_file() and not path.name.endswith('.license'):
            path.with_name(path.name+'.license').write_text(NOTICE)
    for name in ('README.md', 'NOTICE'):
        (args.output/name).write_text(NOTICE+'\nGenerated with the supplied ReDiVO data-generation package.\n')
    licenses = args.output/'LICENSES'
    licenses.mkdir(exist_ok=True)
    (licenses/'CC-BY-SA-4.0.txt').write_bytes((ROOT/'LICENSES/CC-BY-SA-4.0.txt').read_bytes())
    print(json.dumps(dict(output=str(args.output), family=args.family, seed=args.seed, complete=True)))


if __name__ == '__main__':
    main()
