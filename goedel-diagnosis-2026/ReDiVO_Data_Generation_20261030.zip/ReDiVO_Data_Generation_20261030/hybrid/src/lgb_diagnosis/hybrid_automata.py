"""Seed-bound hybrid automata with event-driven continuous-time integration.

This module generates synthetic research data only under explicit authorization.
It never runs through an import or through an unrelated test suite.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from itertools import combinations
from pathlib import Path
import hashlib
import json
import os

import numpy as np
import scipy
from scipy.integrate import solve_ivp

PROTOCOL_PATH = Path(__file__).resolve().parents[2]/'configs/hybrid_automata_20261027.json'
PROTOCOL = json.loads(PROTOCOL_PATH.read_text())
DATA_VERSION = PROTOCOL['data_version']
DT = PROTOCOL['sample_period_seconds']
TIMES = np.arange(round(PROTOCOL['duration_seconds']/DT)+1, dtype=np.float64) * DT
MODE_NAMES = ('rest', 'excite', 'recover')
SYSTEM_SEEDS = tuple(PROTOCOL['system_seeds'])


def derived_seed(seed, *parts):
    return int(np.random.SeedSequence([int(seed), *map(int, parts)]).generate_state(1)[0])


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def generation_contract():
    return dict(generator_sha256=sha256(__file__), protocol_sha256=sha256(PROTOCOL_PATH), data_version=DATA_VERSION,
                numpy_version=np.__version__,scipy_version=scipy.__version__,
                method='DOP853',float_precision='float64',max_step=.05,rtol=1e-7,atol=1e-9,
                sample_period=DT,duration_seconds=200.,event_samples='right_continuous')


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    with tmp.open('x') as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


@dataclass(frozen=True)
class HybridSystem:
    seed: int
    components: int
    damping: np.ndarray
    local_gain: np.ndarray
    adjacency: np.ndarray
    upper: np.ndarray
    lower: np.ndarray
    sensor_gains: np.ndarray
    reset: float

    @property
    def nonlinear(self):
        return self.seed % 2 == 0

    def names(self, component):
        return [f'component_{component:03d}.{kind}{j}'
                for kind, count in (('x', 2), ('u', 2), ('y', 6), ('q', 3))
                for j in range(count)]

    @property
    def columns(self):
        return [name for c in range(self.components) for name in self.names(c)]

    @property
    def commands(self):
        return [n for c in range(self.components) for n in self.names(c)[2:4]]

    @property
    def command_columns(self):
        return self.commands

    @property
    def modes(self):
        return [n for c in range(self.components) for n in self.names(c)[10:]]

    def sensor_matrix(self, c, q):
        return np.array([[1., 0.], [0., 1.], [1., 1.], [1., -1.],
                         [self.sensor_gains[c, q, 0], 0.],
                         [0., self.sensor_gains[c, q, 1]]])

    def mask(self, name):
        if name not in ('moderate', 'hard'):
            raise ValueError('Unknown observation mask')
        rng = np.random.default_rng(derived_seed(self.seed, 41, name == 'hard'))
        kept_count = 4 if name == 'moderate' else 2
        masked, audit = [], []
        for c in range(self.components):
            candidates = []
            for keep in combinations(range(6), kept_count):
                if name == 'hard' and set(keep).issubset({0, 1, 4, 5}):
                    continue
                matrices = [self.sensor_matrix(c, q)[list(keep)] for q in range(3)]
                if all(np.linalg.matrix_rank(m) == 2 and np.linalg.cond(m) <= 8 for m in matrices):
                    candidates.append(keep)
            if not candidates:
                raise ValueError('No admissible mask')
            keep = candidates[int(rng.integers(len(candidates)))]
            names = self.names(c)
            masked += names[:2] + [names[4+j] for j in range(6) if j not in keep]
            audit.append(dict(component=c, retained=list(keep),
                              ranks=[2]*3, conditions=[float(np.linalg.cond(self.sensor_matrix(c, q)[list(keep)])) for q in range(3)]))
        return masked, audit

    def manifest(self):
        value = {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in asdict(self).items()}
        margin = float(np.min(self.damping - self.local_gain - self.adjacency.sum(axis=1)[:, None]
                              - (.04 if self.nonlinear else 0)))
        if margin <= 0:
            raise ValueError('Common contraction reserve failed')
        return dict(data_version=DATA_VERSION, parameters=value, family='nonlinear' if self.nonlinear else 'affine',
                    contraction_margin=margin, contraction_norm='unweighted_infinity',
                    minimum_dwell_seconds=4., mode_names=list(MODE_NAMES), sample_period=DT,
                    reset_nonexpansive=0 < self.reset <= 1,
                    columns=self.columns, commands=self.commands, modes=self.modes,
                    masks={m: dict(columns=self.mask(m)[0], audit=self.mask(m)[1]) for m in ('moderate', 'hard')})


def generate_system(seed, *, components=None):
    if seed not in SYSTEM_SEEDS:
        raise ValueError('System seed is outside the frozen plan')
    n = 12 if seed >= 27200 else 6
    if components is not None:
        if seed not in (27001,27002) or components not in (6,12):
            raise ValueError('Size-only technical probes may use development seeds only')
        n = components
    rng = np.random.default_rng(derived_seed(seed, 1))
    adjacency = np.zeros((n, n))
    for c in range(n):
        parents = {(c-1) % n, int(rng.integers(n))} - {c}
        for p in sorted(parents):
            adjacency[c, p] = rng.uniform(.01, .025) / len(parents)
    system = HybridSystem(seed, n, rng.uniform(.65, .8, (n, 2)), rng.uniform(.08, .12, (n, 2)),
                          adjacency, rng.uniform(.48, .58, n), rng.uniform(.10, .16, n),
                          rng.uniform(.75, 1.25, (n, 3, 2)), .95 if seed % 3 == 0 else 1.)
    system.manifest()
    return system


def episode_inputs(system, seed):
    rng = np.random.default_rng(derived_seed(seed, 2))
    n = system.components
    initial = rng.uniform(.02, .12, (n, 2))
    # A piecewise constant exogenous command changes every 12 seconds.
    periods = rng.integers(2,5,n)
    phases = np.array([rng.integers(p) for p in periods])
    request = (((np.arange(18)[:,None]+phases) % periods) < ((periods+1)//2)).astype(float)
    amplitude = rng.uniform(.9, 1.1, (18, n))
    forcing = rng.uniform(-.002, .002, (101, n, 2))
    noise = np.random.default_rng(derived_seed(seed, 3)).uniform(-.005, .005, (1001, n, 6))
    return initial, request, amplitude, forcing, noise


def simulate(system, seed, *, fault=None, max_step=.05, rtol=1e-7, atol=1e-9):
    """Integrate true modes, guards and resets, splitting all input jumps.

    fault is (component, type, shape, onset_seconds). Its metadata never
    enters the values array, except through physical state evolution.
    """
    initial, request, amplitude, forcing, noise = episode_inputs(system, seed)
    n = system.components
    x, q, last = initial.copy(), np.zeros(n, dtype=int), np.full(n, -4.)
    states = np.full((len(TIMES), n, 2), np.nan)
    modes = np.full((len(TIMES), n), -1, dtype=int)
    states[0], modes[0] = x, q
    events, t, iterations = [], 0., 0
    while True:
        iterations += 1
        if iterations > 20000:
            raise RuntimeError('Finite hybrid event bound exceeded')
        cmd_index = min(int(np.floor((t+1e-8)/12)), len(request)-1)
        noise_index = min(int(np.floor((t+1e-8)/2)), len(forcing)-1)
        u, amp = request[cmd_index], amplitude[cmd_index]
        eligible = last + 4 <= t + 1e-8
        switched = False
        for c in range(n):
            if not eligible[c]:
                continue
            target = (1 if q[c] == 0 and u[c] > .5 else
                      2 if q[c] == 1 and (x[c, 0] >= system.upper[c]-1e-9 or u[c] < .5) else
                      0 if q[c] == 2 and x[c, 0] <= system.lower[c]+1e-9 else None)
            if target is not None:
                old = int(q[c])
                q[c], last[c] = target, t
                if old == 2 and target == 0:
                    x[c, 1] *= system.reset
                events.append(dict(time=float(t), component=c, source=old, target=int(target)))
                switched = True
        if switched:
            at = np.flatnonzero(np.abs(TIMES-t) < 1e-8)
            if len(at):
                states[at], modes[at] = x, q
            continue
        if t >= TIMES[-1] - 1e-9:
            break
        ends = [TIMES[-1], (cmd_index+1)*12., (noise_index+1)*2.]
        ends += [float(v) for v in last+4 if v > t+1e-8]
        if fault is not None:
            onset = fault[3]
            ends += [v for v in (onset, onset+5.) if v > t+1e-8]
        end = min(ends)
        fixed_modes = q.copy()

        def rhs(time, flat):
            v = flat.reshape(n, 2)
            mode_gain = np.where(fixed_modes == 1, 1., .03)
            drive = u*amp*mode_gain
            dx = -system.damping*v
            dx[:, 0] += system.local_gain[:, 0]*v[:, 1] + drive
            dx[:, 1] += system.local_gain[:, 1]*v[:, 0] + .18*(fixed_modes == 1)
            dx[:, 1] += system.adjacency @ v[:, 0]
            if system.nonlinear:
                dx += .04*np.tanh(v)
            dx += forcing[noise_index]
            if fault is not None and time >= fault[3]:
                c, kind, shape, onset = fault
                factor = 1. if shape == 'step' else min(1., max(0., (time-onset)/5))
                if kind == 'actuator_loss':
                    dx[c, 0] -= .3*drive[c]*factor
                elif kind == 'leakage':
                    dx[c, 1] -= .2*factor
                else:
                    raise ValueError('Unknown physical fault')
            return dx.ravel()

        guards, guard_components = [], []
        for c in range(n):
            if not eligible[c] or q[c] == 0:
                continue
            mode, threshold = int(q[c]), system.upper[c] if q[c] == 1 else system.lower[c]
            def guard(time, flat, c=c, threshold=threshold):
                return flat.reshape(n, 2)[c, 0] - threshold
            guard.terminal, guard.direction = True, 1 if mode == 1 else -1
            guards.append(guard)
            guard_components.append(c)
        result = solve_ivp(rhs, (t, end), x.ravel(), method='DOP853', rtol=rtol, atol=atol,
                           max_step=max_step, events=guards or None, dense_output=True)
        if not result.success or not np.isfinite(result.y).all():
            raise RuntimeError('Hybrid ODE integration failed')
        reached = float(result.t[-1])
        if reached <= t + 1e-11:
            raise RuntimeError('Non-advancing hybrid event')
        ix = np.flatnonzero((TIMES > t+1e-8) & (TIMES <= reached+1e-8))
        if len(ix):
            states[ix] = result.sol(np.clip(TIMES[ix], t, reached)).T.reshape(-1, n, 2)
            modes[ix] = q
        t, x = reached, result.y[:, -1].reshape(n, 2).copy()
    if not np.isfinite(states).all() or (modes < 0).any():
        raise RuntimeError('Incomplete sampled hybrid trajectory')
    values = np.empty((len(TIMES), n, 13), dtype=np.float32)
    ci = np.minimum((TIMES/12).astype(int), len(request)-1)
    for c in range(n):
        values[:, c, :2] = states[:, c]
        values[:, c, 2] = request[ci, c]
        values[:, c, 3] = amplitude[ci, c]
        for k in range(len(TIMES)):
            values[k, c, 4:10] = system.sensor_matrix(c, modes[k, c]) @ states[k, c] + noise[k, c]
        values[:, c, 10:] = np.eye(3)[modes[:, c]]
    return dict(values=values.reshape(len(TIMES), -1), states=states, modes=modes,
                times=TIMES.copy(), events=events, seed=int(seed), fault=fault)


def choose_onset(reference, component, context):
    transitions = [e['time'] for e in reference['events'] if e['component'] == component]
    if context == 'near':
        eligible = [t for t in transitions if 40 <= t <= 160]
        if not eligible:
            raise ValueError('No predeclared transition context')
        return float(min(eligible, key=lambda t: abs(t-80)))
    candidates = np.arange(40., 160., DT)
    distances = np.array([min([abs(t-s) for s in transitions] or [200]) for t in candidates])
    eligible = candidates[distances >= 3.2]
    if not len(eligible):
        raise ValueError('No predeclared stationary context')
    return float(eligible[np.argmin(abs(eligible-80))])


def episode_specs(system):
    for role, count in PROTOCOL['data_roles'].items():
        role_id = ('train', 'selection', 'calibration', 'healthy').index(role)
        for i in range(count):
            yield dict(case=f'{role}_{i:03d}', role=role, seed=derived_seed(system.seed, 81, role_id, i))
    for c in range(system.components):
        for ki, kind in enumerate(('actuator_loss', 'leakage')):
            for si, shape in enumerate(('step', 'ramp')):
                for ci, context in enumerate(('stationary', 'near')):
                    yield dict(case=f'fault_{c:03d}_{kind}_{shape}_{context}', role='fault',
                               seed=derived_seed(system.seed, 82, c, ki, si, ci),
                               component=c, kind=kind, shape=shape, context=context)


def save_episode(path, episode):
    path = Path(path)
    tmp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    metadata = {k: v for k, v in episode.items() if not isinstance(v, np.ndarray)}
    with tmp.open('xb') as handle:
        np.savez_compressed(handle, **{k:v for k,v in episode.items() if isinstance(v,np.ndarray)},
                            metadata=np.array(json.dumps(metadata)))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    return dict(sha256=sha256(path), bytes=path.stat().st_size, metadata=metadata)


def load_episode(path):
    with np.load(path, allow_pickle=False) as data:
        result = {k:data[k] for k in data.files if k != 'metadata'}
        result.update(json.loads(str(data['metadata'])))
    return result


def generate_dataset(directory, system, stop_requested=lambda: False):
    directory = Path(directory)
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    manifest_path = directory/'manifest.json'
    spec = system.manifest()
    protocol = generation_contract()
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else dict(system=spec, generation=protocol, episodes={})
    if manifest['system'] != spec or manifest.get('generation') != protocol:
        raise ValueError('Frozen data identity mismatch')
    for item in episode_specs(system):
        case = item['case']
        names = [case] + ([case+'_counterfactual'] if item['role'] == 'fault' else [])
        if all(name in manifest['episodes'] and sha256(directory/(name+'.npz')) == manifest['episodes'][name]['sha256'] for name in names):
            continue
        if stop_requested():
            return False
        ref = simulate(system, item['seed'])
        if item['role'] == 'fault':
            onset = choose_onset(ref, item['component'], item['context'])
            fault = (item['component'], item['kind'], item['shape'], onset)
            value = simulate(system, item['seed'], fault=fault)
            manifest['episodes'][case+'_counterfactual'] = save_episode(directory/(case+'_counterfactual.npz'), ref)
        else:
            value = ref
        manifest['episodes'][case] = save_episode(directory/(case+'.npz'), value)
        manifest['episodes'][case].update(item)
        atomic_json(manifest_path, manifest)
    manifest['complete'] = True
    atomic_json(manifest_path, manifest)
    return True
