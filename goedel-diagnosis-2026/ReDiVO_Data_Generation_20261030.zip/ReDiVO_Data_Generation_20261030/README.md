# ReDiVO: Artificial Data Generation

Copyright (c) 2026 Oliver Niggemann.

Affiliation: Helmut Schmidt University / University of the Federal Armed Forces Hamburg, Germany

## Scope

This package generates the two distinct artificial families in Section 4.1. It contains no large raw datasets, trained models, HPC scripts, or automatic remote actions.

- EXP-C046: linear, discrete-time component networks, two hidden states, six redundant measurements, known delayed connections, and the original fixed masking conditions. All 192 graph-condition configurations and their seeds are in `configs/linear_campaign_manifest.json`.
- EXP-C067-HA-CPU-R4: randomly parameterized hybrid automata with three modes and affine or nonlinear ODE dynamics. The original generator and numerical protocol are in `hybrid`. The eight primary system seeds are 27101 to 27108. Seeds 27001 and 27002 are development systems. Seeds 27201 to 27204 are larger exploratory systems. Do not pool them as additional primary replications.

The hybrid system seeds determine the system parameters and family. The original protocol defines the derived episode seeds, physical faults, operating contexts, and data roles. Model initialization seeds 28101 and 28102 concern training, not additional independent datasets.

## Installation

Use Python 3.11 or a compatible later version in an isolated environment.

```bash
python -m pip install -r requirements.txt
python verify_package.py
python generate_data.py list --family linear
python generate_data.py list --family hybrid
```

The pinned NumPy and SciPy versions match the recorded hybrid generation runtime. The historical NumPy version of the linear campaign was not established in the retained metadata. Do not interpret these pins as proof of bitwise reproduction of its historical files.

## Explicit Local Generation

The following commands perform simulation only when a user explicitly runs them. No simulation was run while preparing this archive. Each command creates the selected complete system dataset and may take substantial time. Use a new or empty output directory.

```bash
python generate_data.py generate --family linear --condition size_030 --seed 9901 --output generated/linear_size030_seed9901 --execute
python generate_data.py generate --family hybrid --seed 27101 --output generated/hybrid_seed27101 --execute
```

Choose another original condition or seed using the lists. The wrapper never starts training, contacts a server, or submits a job. The linear wrapper retains the original episode seed formulas and normal selection/calibration boundary. It exports the normal training, selection, calibration, healthy-test, and fault episodes without materializing overlapping neural-network windows. It also includes timestamps and a role manifest. The hybrid wrapper calls the unmodified original generator, including its matched fault-free references.

## Data Format and Information Boundaries

Each `.npz` file contains named NumPy arrays and can be read with `numpy.load(path, allow_pickle=False)`. In the linear files, `values` are the process values, `clean` contains the corresponding noise-free values, `counterfactual` is the matched fault-free reference, and `times` contains sample times in seconds. The manifest supplies column names, system parameters, episode roles, and seeds. The hybrid files contain `values`, internal `states`, discrete `modes`, `times`, and JSON `metadata`. Its manifest supplies columns, system definitions, masks, event metadata, roles, and seeds. For the exact original array definitions, see the supplied generator source.

Internal states, injected-fault identity, fault onset, and counterfactual references are offline targets or evaluation information. They must not be used as online diagnosis inputs. The fixed observation mask determines which process variables remain measured. Missing variables are reconstructed by the observer, not supplied from the offline reference arrays at diagnosis time.

## Original Source and Release Adaptation

The hybrid generator and its protocol are byte-identical to the verified frozen campaign files. File-level `.license` companions preserve the original generator hash used by its own identity checks.

`linear/generator.py` is a NumPy-only extraction of the original linear source. Only imports of ML data and knowledge classes, the knowledge-construction method, and neural-window preparation were removed. The original numerical functions, system definitions, masks, and random-seed logic remain unchanged. Their abstract syntax was checked against the original. `linear/original_synthetic_state_space.py` provides the unmodified audit source and is not the standalone entry point.

Generated NPZ container bytes need not match old files merely because the arrays agree. Compare arrays, system parameters, masks, roles, seeds, and the recorded numerical protocol. Cross-version numerical reproduction has not been tested by this export. Historical and reduced-release source digests are separately identified in `PROVENANCE.json` and `MANIFEST.json`.

## Copyright and Reuse

Generator software is licensed under AGPL-3.0-or-later. Original data, data documentation, and metadata are offered under CC-BY-SA-4.0 to the extent the relevant rights exist and can be licensed. Generated exports receive companion license notices. The full license texts are in `LICENSES`. See `NOTICE` and `LICENSING.md`. Confirm institutional and contributor publication permissions before uploading.

The software and data come without warranties or guarantees. Use is at your own risk. As far as applicable law allows, Oliver Niggemann, the identified rightsholders, contributors, and institution exclude liability for loss or damage connected with these materials. Legally mandatory liabilities remain unaffected. The applicable license contains the governing provisions.
