"""Versioned, observable state-space plants for synthetic diagnosis controls.

This is a new data protocol, not a reinterpretation of polynomial campaigns.
The simulator knows the equations. The learned observer receives ownership,
dependencies, selected invariant sensor relations and normal targets only.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

import numpy as np

from .data import PreparedData, Standardizer, WindowBundle, _window_storage
from .knowledge import (ConnectionSpec, ModuleSpec, PredicateSpec, RuleSpec,
                        SystemKnowledge, VirtualFaultSensorSpec, format_root_cause)


DATA_VERSION = "synthetic_state_space_v1"
# Two physical states, six redundant sensor equations. No sensor flag encodes a fault.
SENSOR_MATRIX = np.array([[1., 0.], [0., 1.], [1., 1.], [1., -1.],
                          [1., 0.], [0., -1.]])


@dataclass(frozen=True)
class StateSpaceConfig:
    component_count: int = 30
    duration_steps: int = 1000
    sample_period_seconds: float = 1.0
    fault_onset_step: int = 100
    min_out_degree: int = 2
    max_out_degree: int = 4
    min_delay_steps: int = 1
    max_delay_steps: int = 10
    coupling: float = 0.04
    process_noise: float = 0.002
    measurement_noise: float = 0.005
    command_scale: float = 0.4
    fault_magnitude: float = 1.5
    fault_shape: str = "step"
    mask_fraction: float = 0.3333333333333333
    hide_states: bool = True
    mask_policy: str = "observable"
    max_condition_number: float = 8.0
    normal_train_cases: int = 12
    normal_validation_cases: int = 4
    normal_test_cases: int = 3
    fault_replicates: int = 1
    window_size: int = 16
    train_stride: int = 4
    delta_t: int = 8
    seed: int = 9701

    def validate(self) -> None:
        integers = (self.component_count, self.duration_steps, self.fault_onset_step,
                    self.min_out_degree, self.max_out_degree, self.min_delay_steps,
                    self.max_delay_steps, self.normal_train_cases,
                    self.normal_validation_cases, self.normal_test_cases,
                    self.fault_replicates, self.window_size, self.train_stride, self.delta_t)
        if any(isinstance(v, bool) or not isinstance(v, int) for v in integers):
            raise ValueError("Counts, delays and horizons must be integers")
        if not 3 <= self.component_count <= 480:
            raise ValueError("component_count must lie in [3,480]")
        if not 1 <= self.min_out_degree <= self.max_out_degree < self.component_count:
            raise ValueError("Invalid out-degree interval")
        if not 1 <= self.min_delay_steps <= self.max_delay_steps:
            raise ValueError("Invalid delay interval")
        if not 1 <= self.delta_t < self.window_size <= self.fault_onset_step < self.duration_steps - 4:
            raise ValueError("Need delta_t < window <= onset < duration-4")
        if min(self.normal_train_cases, self.normal_validation_cases,
               self.normal_test_cases, self.fault_replicates, self.train_stride) < 1:
            raise ValueError("All split sizes and strides must be positive")
        numeric = (self.sample_period_seconds, self.coupling, self.process_noise,
                   self.measurement_noise, self.command_scale, self.fault_magnitude,
                   self.mask_fraction, self.max_condition_number)
        if not all(np.isfinite(v) for v in numeric):
            raise ValueError("All numeric parameters must be finite")
        if self.sample_period_seconds <= 0 or self.command_scale <= 0:
            raise ValueError("Sample period and normal excitation must be positive")
        if min(self.coupling, self.process_noise, self.measurement_noise, self.fault_magnitude) < 0:
            raise ValueError("Noise, coupling and fault magnitude must be nonnegative")
        if not 0 <= self.mask_fraction <= 1 or self.max_condition_number < 1:
            raise ValueError("Invalid mask fraction or conditioning bound")
        if self.mask_policy not in {"observable", "unobservable_control"}:
            raise ValueError("Unknown mask policy")
        if self.fault_shape not in {"step", "ramp"}:
            raise ValueError("Unknown state fault shape")


@dataclass(frozen=True)
class StateEdge:
    source: int
    target: int
    delay: int


@dataclass
class StateEpisode:
    case_id: str
    split: str
    values: np.ndarray
    clean_values: np.ndarray
    counterfactual: np.ndarray
    fault_component: int | None
    fault_onset: int | None
    seed: int


@dataclass
class StateSpaceSystem:
    config: StateSpaceConfig
    a: np.ndarray
    b: np.ndarray
    edges: list[StateEdge]

    @property
    def components(self) -> list[str]:
        return [f"component_{c:03d}" for c in range(self.config.component_count)]

    def local_names(self, c: int) -> list[str]:
        module = self.components[c]
        return [f"{module}.{kind}{i}" for kind, count in (("z", 2), ("u", 2), ("y", 6))
                for i in range(count)]

    def edge_names(self, e: StateEdge) -> list[str]:
        return [f"{self.components[e.target]}.in_from_{e.source:03d}_{i}" for i in range(2)]

    @property
    def feature_columns(self) -> list[str]:
        return [n for c in range(self.config.component_count) for n in self.local_names(c)] + [
            n for e in self.edges for n in self.edge_names(e)]

    @property
    def command_columns(self) -> list[str]:
        return [n for c in range(self.config.component_count) for n in self.local_names(c)[2:4]]

    def indices(self, names: list[str]) -> list[int]:
        index = {n: i for i, n in enumerate(self.feature_columns)}
        return [index[n] for n in names]

    @property
    def stability_bound(self) -> float:
        # A sufficient contraction bound for the entire delayed network.
        # Each incoming gain is coupling / indegree. Transmitted channels y0,y1
        # have unit row norm. Delays change convergence rate, not this bound.
        return float(np.abs(self.a).sum(-1).max() + self.config.coupling)

    def masked_columns(self) -> list[str]:
        """Select a fixed mask without looking at episodes, labels or fault onsets."""
        rng = np.random.default_rng(np.random.SeedSequence([self.config.seed, 41]))
        masked: list[str] = []
        count = int(round(6 * self.config.mask_fraction))
        for c in range(self.config.component_count):
            names = self.local_names(c)
            if self.config.hide_states:
                masked.extend(names[:2])
            if self.config.mask_policy == "unobservable_control":
                masked.extend(names[:2])
                masked.extend(names[4:])
                continue
            removed: list[int] = []
            for j in rng.permutation(6):
                if len(removed) >= count:
                    break
                keep = [i for i in range(6) if i not in removed + [int(j)]]
                matrix = SENSOR_MATRIX[keep]
                if (np.linalg.matrix_rank(matrix) == 2
                        and np.linalg.cond(matrix) <= self.config.max_condition_number):
                    removed.append(int(j))
            if len(removed) != count:
                raise ValueError("Requested mask cannot preserve instantaneous state observability")
            masked.extend(names[4 + j] for j in removed)
        if self.config.mask_policy == "unobservable_control":
            # Remove every propagated observation too. Remaining commands have
            # no fault input. This is a deliberately impossible negative control.
            masked.extend(n for e in self.edges for n in self.edge_names(e))
        return list(dict.fromkeys(masked))

    def observability_audit(self, masked: list[str]) -> dict[str, Any]:
        if set(masked).difference(self.feature_columns):
            raise ValueError("Unknown masked variable")
        rows = []
        for c in range(self.config.component_count):
            names = self.local_names(c)
            matrix = [SENSOR_MATRIX[i] for i in range(6) if names[4+i] not in masked]
            matrix += [np.eye(2)[i] for i in range(2) if names[i] not in masked]
            m = np.asarray(matrix).reshape(-1, 2)
            rank = int(np.linalg.matrix_rank(m)) if len(m) else 0
            singular = np.linalg.svd(m, compute_uv=False) if len(m) else np.array([])
            condition = float(np.linalg.cond(m)) if rank == 2 else None
            rows.append({"component": self.components[c], "rank": rank,
                         "smallest_singular_value": float(singular[-1]) if len(singular) == 2 else 0.,
                         "condition_number": condition,
                         "instantaneous_state_reconstruction": rank == 2,
                         "allowed_current_measurements": [n for n in names if n not in masked]})
        return {"data_version": DATA_VERSION, "stability_bound": self.stability_bound,
                "mask_uses_fault_labels": False, "mask_uses_test_values": False,
                "mask_policy": self.config.mask_policy, "components": rows,
                "all_states_instantaneously_observable": all(r["rank"] == 2 for r in rows),
                "masked_columns": masked,
                "output_mask_fraction": sum(".y" in n for n in masked)/(6*len(rows)),
                "overall_missing_fraction": len(masked)/len(self.feature_columns)}

    def knowledge(self) -> SystemKnowledge:
        modules, sensors, predicates, rules, connections = [], [], [], [], []
        certified = self.observability_audit(self.masked_columns())["all_states_instantaneously_observable"]
        for c, module in enumerate(self.components):
            names = self.local_names(c)
            incoming = [n for e in self.edges if e.target == c for n in self.edge_names(e)]
            modules.append(ModuleSpec(module, inputs=names[2:4] + incoming, outputs=names[4:],
                                      states=names[:2], local_fault_detectability_certified=False))
            sensors.append(VirtualFaultSensorSpec(
                name=f"{module}.state_disturbance", module=module,
                root_cause=format_root_cause(module, "state_disturbance"), physical_component=module,
                fault_type="state_disturbance", physical_quantity="physical_state_z0",
                component_variables=names[:2], primary_cause_sensitive_variable=names[0],
                measured_dependencies=names + incoming, causal_inputs=names[2:4] + incoming,
                observable_effects=names[4:], covered_fault_modes=["state_disturbance"],
                response_horizon_steps=0, response_horizon_source="y(k)=Cz(k), synchronous sampling",
                engineering_source=DATA_VERSION,
                detectability_claim=("state_observable_diagnosis_requires_validation" if certified
                                     else "deliberately_unobservable_negative_control")))
            # Physical identities hold for arbitrary states, including faulty states.
            for suffix, kind, source, target, relation, group in [
                ("state_sensor", "value_compatible", names[0], names[4], "equal", "value_compatibility"),
                ("duplicate_sensor", "value_compatible", names[4], names[8], "equal", "value_compatibility"),
                ("inverse_value", "value_compatible", names[1], names[9], "opposite", "value_compatibility"),
                ("same_change", "co_increase", names[0], names[8], "same_direction", "qualitative_relation"),
                ("inverse_change", "inverse_change", names[1], names[9], "opposite_direction", "qualitative_relation"),
            ]:
                pname = f"{module}.{suffix}"
                predicates.append(PredicateSpec(pname, kind, module, source=source, target=target,
                                                 relation=relation, group=group, tolerance=0.1,
                                                 description="Derived from invariant rows of C, not from fault labels"))
                rules.append(RuleSpec(pname + ".rule", "require", module, predicate=pname,
                                      group=group, role="training", fault_preserving=True))
        for e in self.edges:
            for i, target in enumerate(self.edge_names(e)):
                source = self.local_names(e.source)[4+i]
                pname = target + ".transport_sign"
                connections.append(ConnectionSpec(self.components[e.source], source, self.components[e.target],
                    target, relation="exact_delay_transport", min_latency_steps=e.delay,
                    max_latency_steps=e.delay, influence_sign=1, provenance=DATA_VERSION,
                    qualitative_relations=["co_increase"]))
                predicates.append(PredicateSpec(pname, "co_increase", self.components[e.target],
                    source=source, target=target, lag_steps=e.delay, group="latency_relation",
                    tolerance=0.1, description="Signed changes of a dedicated delayed channel, no mixed-input assertion"))
                rules.append(RuleSpec(pname + ".rule", "require", self.components[e.target],
                    predicate=pname, group="latency_relation", role="training", fault_preserving=True))
        knowledge = SystemKnowledge(modules, connections, predicates, rules, virtual_fault_sensors=sensors)
        knowledge.validate(self.feature_columns)
        return knowledge

    def manifest(self) -> dict[str, Any]:
        return {"data_version": DATA_VERSION, "config": asdict(self.config),
                "A": self.a.tolist(), "B": self.b.tolist(), "C": SENSOR_MATRIX.tolist(),
                "edges": [asdict(e) for e in self.edges], "stability_bound": self.stability_bound,
                "feature_columns": self.feature_columns, "command_columns": self.command_columns,
                "physical_equation": "z[k]=A*z[k-1]+B*u[k-1]+coupling*mean(in[k-1])+E*f[k]+w[k]",
                "measurement_equation": "y[k]=C*z[k]+v[k]",
                "transport_equation": "in_s_to_c[k]=y_clean_s[k-delay]",
                "time_convention": "fault injection changes state and local clean outputs at the declared sample",
                "exact_A_B_provided_to_neural_observer": False,
                "fault_labels_online": False, "counterfactual_online": False}


def generate_state_space_system(config: StateSpaceConfig) -> StateSpaceSystem:
    config.validate()
    rng = np.random.default_rng(config.seed)
    a = rng.uniform(0.02, 0.05, size=(config.component_count, 2, 2))
    a[:, 0, 0] = rng.uniform(0.55, 0.72, config.component_count)
    a[:, 1, 1] = rng.uniform(0.55, 0.72, config.component_count)
    b = np.broadcast_to(0.2*np.eye(2), a.shape).copy()
    edges = []
    for c in range(config.component_count):
        degree = int(rng.integers(config.min_out_degree, config.max_out_degree + 1))
        targets = [(c+1) % config.component_count]
        pool = [j for j in range(config.component_count) if j not in [c, *targets]]
        targets += rng.choice(pool, degree-1, replace=False).tolist()
        edges += [StateEdge(c, target, int(rng.integers(config.min_delay_steps, config.max_delay_steps+1)))
                  for target in targets]
    system = StateSpaceSystem(config, a, b, edges)
    if system.stability_bound >= 0.98:
        raise ValueError("The global delayed network fails the stability margin")
    system.masked_columns()  # Fail before generating any dataset.
    return system


def simulate_episode(system: StateSpaceSystem, seed: int, *, fault_component: int | None = None,
                     split: str = "test", case_id: str = "case") -> StateEpisode:
    cfg = system.config
    if fault_component is not None and not 0 <= fault_component < cfg.component_count:
        raise ValueError("Unknown fault component")
    rng = np.random.default_rng(seed)
    t, n = cfg.duration_steps, cfg.component_count
    # Every episode independently excites both state directions. Smooth commands
    # are exogenous and do not depend on fault identity, magnitude or onset.
    commands = np.zeros((t, n, 2))
    increments = rng.normal(0, cfg.command_scale, commands.shape)
    for k in range(1, t):
        commands[k] = .90*commands[k-1] + .25*increments[k]
    initial = rng.normal(0, .25, (n, 2))
    process_noise = rng.normal(0, cfg.process_noise, (t, n, 2))
    measurement_noise = rng.normal(0, cfg.measurement_noise, (t, len(system.feature_columns)))
    index = {name: i for i, name in enumerate(system.feature_columns)}
    link_indices = np.array([system.indices(system.edge_names(e)) for e in system.edges])
    target = np.array([e.target for e in system.edges])
    source = np.array([e.source for e in system.edges])
    delay = np.array([e.delay for e in system.edges])
    indegree = np.bincount(target, minlength=n)

    def trajectory(with_fault: bool) -> np.ndarray:
        states = np.zeros((t, n, 2))
        out = np.zeros((t, n, 6))
        links = np.zeros((t, len(system.edges), 2))
        values = np.zeros((t, len(index)))
        for k in range(t):
            if k == 0:
                states[k] = initial
            else:
                incoming = np.zeros((n, 2))
                np.add.at(incoming, target, links[k-1])
                states[k] = (np.einsum("nij,nj->ni", system.a, states[k-1])
                             + np.einsum("nij,nj->ni", system.b, commands[k-1])
                             + cfg.coupling*incoming/indegree[:, None] + process_noise[k])
            if with_fault and fault_component is not None and k >= cfg.fault_onset_step:
                shape = 1. if cfg.fault_shape == "step" else min(1., (k-cfg.fault_onset_step+1)/20.)
                states[k, fault_component, 0] += cfg.fault_magnitude*shape
            out[k] = states[k] @ SENSOR_MATRIX.T
            ready = k >= delay
            links[k, ready] = out[k-delay[ready], source[ready], :2]
            values[k, :10*n] = np.concatenate((states[k], commands[k], out[k]), axis=1).reshape(-1)
            values[k, link_indices.reshape(-1)] = links[k].reshape(-1)
        return values

    clean = trajectory(True)
    counterfactual = trajectory(False) if fault_component is not None else clean.copy()
    measured = clean + measurement_noise
    # States are offline simulator references when hidden. Commands are exact.
    protected = [i for c in range(n) for i in system.indices(system.local_names(c)[:4])]
    measured[:, protected] = clean[:, protected]
    return StateEpisode(case_id, split, measured.astype(np.float32), clean.astype(np.float32),
                        counterfactual.astype(np.float32), fault_component,
                        cfg.fault_onset_step if fault_component is not None else None, seed)


def reconstruct_states(system: StateSpaceSystem, values: np.ndarray, masked: list[str]) -> np.ndarray:
    """Known-C reference. Reads only available local sensors, never hidden states."""
    result = []
    for c in range(system.config.component_count):
        names = system.local_names(c)
        keep = [i for i in range(6) if names[4+i] not in masked]
        matrix = SENSOR_MATRIX[keep]
        if len(keep) < 2 or np.linalg.matrix_rank(matrix) < 2:
            raise ValueError("Insufficient sensor information for the known-C reference")
        result.append(values[:, system.indices([names[4+i] for i in keep])] @ np.linalg.pinv(matrix).T)
    return np.stack(result, axis=1)


def prepare_state_space_data(config: StateSpaceConfig, *, window_storage: str = "auto") -> tuple[PreparedData, StateSpaceSystem, list[str], list[StateEpisode]]:
    system = generate_state_space_system(config)
    episodes = []
    for split_id, (split, count) in enumerate((("train", config.normal_train_cases),
                                               ("val", config.normal_validation_cases),
                                               ("test", config.normal_test_cases))):
        for i in range(count):
            seed = int(np.random.SeedSequence([config.seed, split_id, i, 81]).generate_state(1)[0])
            episodes.append(simulate_episode(system, seed, split=split, case_id=f"{split}_normal_{i:03d}"))
    for c in range(config.component_count):
        for replicate in range(config.fault_replicates):
            seed = int(np.random.SeedSequence([config.seed, c, replicate, 82]).generate_state(1)[0])
            episodes.append(simulate_episode(system, seed, fault_component=c, split="test",
                                            case_id=f"test_fault_{c:03d}_{replicate:02d}"))
    scaler = Standardizer.fit(np.concatenate([e.values for e in episodes if e.split == "train"]))

    dataset = {"normal_labels": ["normal"], "source": {"name": DATA_VERSION},
               "windows": {"window_size": config.window_size, "stride": 1,
                           "storage": window_storage}}

    def bundle(split: str) -> WindowBundle:
        selected = [e for e in episodes if e.split == split]
        stride = config.train_stride if split == "train" else 1
        ends = range(config.window_size-1, config.duration_steps, stride)
        count = len(selected)*len(ends)
        windows = _window_storage((count, config.window_size, len(system.feature_columns)),
                                  dataset, purpose=f"state_space_{split}")
        targets = np.empty((count, len(system.feature_columns)), dtype=np.float32)
        rows, groups, times, labels, roots, faults = [], [], [], [], [], []
        position = 0
        for e in episodes:
            if e.split != split:
                continue
            scaled = scaler.transform(e.values)
            stride = config.train_stride if split == "train" else 1
            for k in range(config.window_size-1, config.duration_steps, stride):
                windows[position] = scaled[k-config.window_size+1:k+1]
                targets[position] = scaled[k]
                position += 1
                rows.append(f"{e.case_id}:{k}")
                groups.append(e.case_id)
                times.append(k*config.sample_period_seconds)
                labels.append("fault" if e.fault_onset is not None and k >= e.fault_onset else "normal")
                # The production adapter resolves module + physical fault type
                # to the canonical pair. Do not put pair syntax in its raw module field.
                roots.append(system.components[e.fault_component] if e.fault_component is not None else "")
                faults.append("state_disturbance" if e.fault_component is not None else "")
        return WindowBundle(windows, targets,
                            rows, groups, times, labels, roots, {"root_cause_fault": faults})

    prepared = PreparedData(bundle("train"), bundle("val"), bundle("test"), scaler,
                            system.feature_columns, [], dataset, [])
    return prepared, system, system.masked_columns(), episodes
