# Copyright and Licenses

Copyright (c) 2026 Oliver Niggemann.
Affiliation: Helmut Schmidt University / University of the Federal Armed Forces Hamburg, Germany

Software: GNU Affero General Public License, version 3 or later (AGPL-3.0-or-later).
Data and data documentation: Creative Commons Attribution-ShareAlike 4.0 International (CC-BY-SA-4.0).
See LICENSES for the full, unmodified license texts and MANIFEST.json for the file-level mapping.

The software and data come without warranties or guarantees. Use is at your own risk. As far as applicable law allows, Oliver Niggemann, the identified rightsholders, contributors, and institution exclude liability for loss or damage connected with these materials. Legally mandatory liabilities remain unaffected. The applicable license contains the governing provisions.

Preserve all existing notices and any additional rightsholders' rights.
Institutional affiliation does not by itself establish copyright ownership or endorsement.
Confirm the relevant institutional and contributor permissions before public publication.
Copyleft does not require publication of every private modification.

Original source files remain byte-identical and carry adjacent `.license` notices.
The standalone linear generator and publication helpers are identified as release adaptations.
Original source digests identify the historical experiments, not this reduced distribution.
No license is asserted over unprotected facts or over someone else's rights.
Redistribution and covered adaptations must follow the applicable copyleft license.
AGPL source-offer obligations also apply to modified network versions when section 13 applies.
