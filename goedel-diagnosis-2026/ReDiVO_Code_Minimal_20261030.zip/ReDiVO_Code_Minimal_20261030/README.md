# ReDiVO: Minimal Algorithm Code

Copyright (c) 2026 Oliver Niggemann.

Affiliation: Helmut Schmidt University / University of the Federal Armed Forces Hamburg, Germany

## Contents

This package contains the algorithmic Python modules used by the two artificial studies in Section 4.1 of "Reconstruction-Based Diagnosis through Goedel-Regularized Virtual Observability".

- `linear/src/lgb_diagnosis`: ALG-V18.2, the linear study EXP-C046.
- `hybrid/src/lgb_diagnosis`: ALG-V18.3-RECURSIVE-R2, the hybrid study EXP-C067-HA-CPU-R4.

Only the model, training, reconstruction, Goedel regularization, diagnosis, and their imported support modules are included. The import closure is retained to avoid broken imports. Some support files contain optional dataset helpers. No benchmark data, models, results, HPC scripts, schedulers, monitoring tools, campaign runners, or private host configuration are included.

## Use

Use Python 3.11 or a compatible later version in an isolated environment. Install `requirements.txt`. Add exactly one snapshot's `src` directory to `PYTHONPATH`.

```bash
python -m pip install -r requirements.txt
PYTHONPATH=hybrid/src python -c "from lgb_diagnosis.training import train_lgb, diagnose_from_checkpoint"
```

The main algorithm interfaces are in `training.py`. `train_lgb` trains the observer and `diagnose_from_checkpoint` evaluates a saved model. `model.py` and `structured_observer.py` define the network. `godel_trajectory.py` implements the training regularization. The hybrid snapshot also retains `one_step_pilot.py`, which contains the fitting interface used by its adapter, including recursive training. Its historical filename does not mean that this study used only one-step training.

These are algorithm modules, not a complete campaign command-line application. Callers provide the prepared sequences, system knowledge, and resolved configuration. The separate data-generation archive supplies the original artificial-system definitions and experiment settings. There is no automatic download, simulation, training, or job submission on package verification.

## Version and Verification

`PROVENANCE.json` identifies both historical versions. Every original algorithm module is byte-identical to its verified frozen source. Its adjacent `.license` file adds the publication notice without rewriting the historical file. The reduced export is not the full historical source tree and does not have its full-tree digest. `MANIFEST.json` records the export's own hashes.

```bash
python verify_package.py
```

Packaging checks verify syntax, the selected local-module dependency closure, checksums, archive integrity, notices, and the absence of private operational paths. No new scientific run, simulation, or ML runtime test was performed for this export. Dependencies are listed rather than presented as a complete historical environment lock.

## Copyright and Reuse

Software is licensed under AGPL-3.0-or-later. Data documentation and metadata are licensed under CC-BY-SA-4.0. The full texts are in `LICENSES`. See `NOTICE` and `LICENSING.md`. Paper authors are Oliver Niggemann, Jonas Ehrhardt, and Alexander Diedrich. Preserve any additional contributors' established rights. Confirm institutional and contributor publication permissions before uploading.

The software and data come without warranties or guarantees. Use is at your own risk. As far as applicable law allows, Oliver Niggemann, the identified rightsholders, contributors, and institution exclude liability for loss or damage connected with these materials. Legally mandatory liabilities remain unaffected. The applicable license contains the governing provisions.
