"""Causal recorded-command contract, distinct from future exogenous inputs."""
from __future__ import annotations

from dataclasses import dataclass
import math

import torch

from .config import ConfigError

METHOD = "v18_observed_command_conditioned_direct_residual_v1"
PROTOCOL = "recorded_current_sample_v1"
ONE_STEP_ALGORITHM = "ALG-V18.4-CMD-OS1-R1"
RECURSIVE_ALGORITHM = "ALG-V18.4-CMD-RECURSIVE-R1"


@dataclass(frozen=True)
class CommandContract:
    indices: tuple[int, ...]
    names: tuple[str, ...]
    off: tuple[float, ...]
    on: tuple[float, ...]
    age_cap_steps: int = 64
    transient_steps: int = 5


def command_contract(config, features, masked=()):
    cfg = config.get("diagnosis", {}).get("nominal_real_trajectory", {}).get("observed_commands")
    if cfg is None:
        if config.get("diagnosis", {}).get("method_identifier") == METHOD:
            raise ConfigError("The conditioned method requires explicit observed commands")
        return None
    if not isinstance(cfg, dict) or cfg.get("protocol") != PROTOCOL:
        raise ConfigError("Observed commands require recorded_current_sample_v1")
    if config.get("diagnosis", {}).get("method_identifier") != METHOD:
        raise ConfigError("Observed commands require their separate method identifier")
    if config["diagnosis"]["nominal_real_trajectory"].get("exogenous_inputs"):
        raise ConfigError("Recorded feedback commands must not be declared future exogenous")
    channels = cfg.get("channels")
    if not isinstance(channels, list) or not channels:
        raise ConfigError("Observed command channels must be an explicit nonempty list")
    names, off, on = [], [], []
    for item in channels:
        if not isinstance(item, dict):
            raise ConfigError("Observed command provenance must be a mapping")
        name = item.get("name")
        if name not in features or ".command." not in name:
            raise ConfigError("Only recorded controller-command features are admissible")
        if name in masked:
            raise ConfigError("An observed command cannot be masked")
        if (item.get("availability") != "recorded_controller_output"
                or item.get("before_fault_effects") is not True):
            raise ConfigError("Recorded command provenance before fault effects is required")
        unit = "rev/min" if name.endswith(".speed") else "1"
        if item.get("unit") != unit or not name.endswith((".speed", ".opening")):
            raise ConfigError("Unsupported observed command unit or quantity")
        support = item.get("support")
        if (not isinstance(support, list) or len(support) != 2
                or any(type(v) not in (int, float) or not math.isfinite(v) for v in support)
                or not support[0] < support[1]):
            raise ConfigError("Command support requires two finite ordered values")
        names.append(name)
        off.append(float(support[0]))
        on.append(float(support[1]))
    if len(set(names)) != len(names) or set(names) != {n for n in features if ".command." in n}:
        raise ConfigError("Every recorded command must be declared exactly once")
    age_cap, transient = cfg.get("age_cap_steps", 64), cfg.get("transient_steps", 5)
    if type(age_cap) is not int or type(transient) is not int or not 1 <= transient <= age_cap:
        raise ConfigError("Command age and transient limits must be positive integer steps")
    return CommandContract(tuple(features.index(n) for n in names), tuple(names),
                           tuple(off), tuple(on), age_cap, transient)


def causal_command_features(commands, age_cap_steps=64):
    """Current command, backward difference and capped age. No look-ahead.

    Age at the left window edge is censored. A history at least as long as the
    cap resolves that censoring before the nominal boundary.
    """
    if commands.shape[1] == 0:
        return commands.new_empty((*commands.shape[:2], commands.shape[-1] * 3)), commands.long()
    previous = torch.cat([commands[:, :1], commands[:, :-1]], 1)
    changes = commands.ne(previous)
    tick = torch.arange(commands.shape[1], device=commands.device).view(1, -1, 1)
    last_change = torch.where(changes, tick, 0).cummax(dim=1).values
    age = tick - last_change
    capped = age.clamp(max=age_cap_steps).to(commands.dtype) / float(age_cap_steps)
    return torch.cat([commands, commands - previous, capped], -1), age


def selection_key(metrics, config):
    """Joint normal criterion for the new revision, legacy criterion otherwise."""
    real, nominal = metrics["real_trajectory_loss"], metrics["nominal_trajectory_loss"]
    if config.get("diagnosis", {}).get("method_identifier") == METHOD:
        training = config.get("training", {})
        return (float(training.get("lambda_real", 1.)) * real
                + float(training.get("lambda_nominal", 1.)) * nominal, real, nominal)
    return real, nominal


def select_common_normal_horizon(scores):
    """Pair-only horizon selection, never individual test-driven selection."""
    if set(scores) != {"one_step", "recursive"}:
        raise ConfigError("Common horizon selection requires the two complete training arms")
    by_arm = {arm: {r["delta_t_steps"]: r for r in rows} for arm, rows in scores.items()}
    candidates = set(by_arm["one_step"])
    if not candidates or candidates != set(by_arm["recursive"]):
        raise ConfigError("Both arms require identical horizon candidates")
    endpoints = set()
    for rows in scores.values():
        if len({r["delta_t_steps"] for r in rows}) != len(rows):
            raise ConfigError("Repeated horizon score")
        for row in rows:
            if (row.get("selection_scope") != "normal_validation_only" or row.get("test_used") is not False
                    or row.get("initial_history_steps") != 240 or not row.get("endpoint_identity")
                    or not math.isfinite(row["normal_validation_mae"])):
                raise ConfigError("Only paired normal scores with the same declared history are admissible")
            endpoints.add(row["endpoint_identity"])
    if len(endpoints) != 1:
        raise ConfigError("Normal selection endpoints differ between arms or horizons")
    return min(candidates, key=lambda h: (sum(by_arm[a][h]["normal_validation_mae"] for a in by_arm), h))
