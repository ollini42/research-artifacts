"""Normal-only fitting with explicit recursive or one-step training.

Recursive training is the standard. One-step training is a runtime
approximation. Historical campaign profiles remain explicitly selectable.
"""
from __future__ import annotations

import copy
import resource
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import torch

from . import training as tr
from .config import ConfigError, ONE_STEP_ALGORITHM, RECURSIVE_ALGORITHM
from .model import build_model
from .reconstructed_variables import fit_reconstructed_variable_scaling
from .training_resume import (
    ResumeCheckpoint, TrainingInterrupted, atomic_torch_save, capture_rng, cpu_snapshot,
    device_provenance, enable_reproducible_execution, make_identity, replay_loader, restore_rng,
)
from .utils import set_seed, write_json
from .compilation_timing import CompilationWindow
from .training_modes import training_mode, strategy_metadata

ALGORITHM = ONE_STEP_ALGORITHM
PROTOCOL = 'hai_v21_ds1_short_history_one_step_v1'
DS5_PROTOCOL = 'hai_v21_ds5_short_history_one_step_v1'
DS5_RECURSIVE_PROTOCOL = 'hai_v21_ds5_recursive_fixed_horizon_v1'
HISTORY_STEPS = 48


def short_history_view(bundle, history_steps=HISTORY_STEPS):
    """Keep identical endpoints and groups, changing only model input history."""
    if type(history_steps) is not int or not 1 <= history_steps < bundle.windows.shape[1]:
        raise ConfigError('History must be positive and shorter than the original window')
    result = copy.copy(bundle)
    result.windows = bundle.windows[:, -(history_steps + 1):, :]
    if bundle.oracle_windows is not None:
        result.oracle_windows = bundle.oracle_windows[:, -(history_steps + 1):, :]
    return result


def learning_config(diagnosis_config, history_steps=HISTORY_STEPS):
    """Create a separate fitting configuration, never shorten diagnosis."""
    cfg = copy.deepcopy(diagnosis_config)
    from .observed_commands import METHOD as COMMAND_METHOD
    from .observed_commands import ONE_STEP_ALGORITHM as COMMAND_ONE_STEP, RECURSIVE_ALGORITHM as COMMAND_RECURSIVE
    conditioned = cfg.get('diagnosis', {}).get('method_identifier') == COMMAND_METHOD
    explicit_mode = 'mode' in cfg.get('training', {})
    if conditioned or explicit_mode:
        history_steps = cfg['training'].get('history_steps', 240)
    cfg['experiment']['algorithm_version'] = ALGORITHM
    arm = training_mode(cfg)
    cfg['experiment']['training_comparison_arm'] = arm
    if arm not in {'one_step', 'recursive'}:
        raise ConfigError('Unknown training comparison arm')
    if arm == 'recursive':
        steps = cfg['training'].get('recursive_training_steps')
        if steps is None and 'recursive_training_steps' not in cfg['training']:
            candidates = cfg['diagnosis']['nominal_real_trajectory']['delta_t']['candidates']
            if len(candidates) == 1:
                steps = candidates[0]
        window = cfg['datasets'][cfg['active_dataset']]['windows']['window_size']
        if type(steps) is not int or not 1 <= steps < window:
            raise ConfigError('Recursive training requires a fixed admissible horizon')
        cfg['experiment']['algorithm_version'] = RECURSIVE_ALGORITHM
        cfg['experiment']['evaluation_protocol'] = (
            'random_hybrid_ode_recursive_v1'
            if cfg['experiment'].get('data_version') == 'random_hybrid_ode_v1'
            else DS5_RECURSIVE_PROTOCOL)
        cfg['experiment']['paper_evidence_status'] = 'experimental_training_revision'
        cfg['training'].update(mode=arm, recursive_training_steps=steps,
                              history_steps=window-steps, prediction_steps=steps,
                              trajectory_training_protocol='recursive_legacy_v18')
        if conditioned:
            cfg['experiment']['algorithm_version'] = COMMAND_RECURSIVE
            cfg['experiment']['evaluation_protocol'] = cfg['experiment'].get('command_topology', 'ds5') + '_recorded_commands_recursive_v1'
            cfg['training']['history_steps'] = history_steps
            cfg['datasets'][cfg['active_dataset']]['windows']['window_size'] = history_steps + steps
        elif explicit_mode:
            if type(history_steps) is not int or not 1 <= history_steps <= window - steps:
                raise ConfigError('Recursive training history exceeds the available window')
            cfg['training']['history_steps'] = history_steps
            cfg['datasets'][cfg['active_dataset']]['windows']['window_size'] = history_steps + steps
        cfg['diagnosis']['nominal_real_trajectory']['delta_t']['candidates'] = [steps]
        cfg.pop('_delta_t_selection', None)
        cfg['experiment']['training_strategy'] = strategy_metadata(cfg)
        return cfg
    protocol = cfg['experiment'].get('one_step_training_protocol', PROTOCOL)
    if protocol not in {PROTOCOL, DS5_PROTOCOL, 'recorded_command_one_step_v1'}:
        raise ConfigError('Unknown one-step study protocol')
    cfg['experiment']['evaluation_protocol'] = protocol
    cfg['experiment']['paper_evidence_status'] = 'experimental_training_revision'
    cfg['training']['history_steps'] = history_steps
    cfg['training']['prediction_steps'] = 1
    cfg['training']['trajectory_training_protocol'] = 'one_step_short_history_v1'
    cfg['training']['mode'] = arm
    cfg['diagnosis']['nominal_real_trajectory']['delta_t']['candidates'] = [1]
    cfg.pop('_delta_t_selection', None)
    cfg['datasets'][cfg['active_dataset']]['windows']['window_size'] = history_steps + 1
    if conditioned:
        cfg['experiment']['algorithm_version'] = COMMAND_ONE_STEP
        cfg['experiment']['evaluation_protocol'] = cfg['experiment'].get('command_topology', 'ds5') + '_recorded_commands_one_step_v1'
    cfg['experiment']['training_strategy'] = strategy_metadata(cfg)
    return cfg


def require_normal(bundle):
    if not len(bundle.times) or set(bundle.labels or []) != {'normal'}:
        raise ConfigError('Fitting and selection require nonempty normal reference runs')


class PhaseTimer:
    """Synchronized durations, phase CUDA peaks and process-lifetime RSS peaks."""
    def __init__(self, device, path):
        self.device = torch.device(device)
        self.path = Path(path)
        self.phases = []

    def clock(self):
        if self.device.type == 'cuda':
            torch.cuda.synchronize(self.device)
        return time.perf_counter()

    @contextmanager
    def phase(self, name, **counts):
        # Drain preceding CUDA work before attributing peaks to this phase.
        start = self.clock()
        compilation = CompilationWindow()
        start = time.perf_counter()
        if self.device.type == 'cuda':
            torch.cuda.reset_peak_memory_stats(self.device)
        write_json(self.path, {'active_phase': name, 'phases': self.phases})
        try:
            details = {}
            yield details
            elapsed = self.clock() - start
            details.update(compilation.finish(elapsed))
        except BaseException as error:
            # CUDA failures may make further synchronization unsafe. Preserve
            # the original exception even if writing diagnostics also fails.
            try:
                self._finish(name, time.perf_counter() - start, counts,
                             status='failed', error_type=type(error).__name__)
            except Exception:
                pass
            raise
        else:
            self._finish(name, elapsed, dict(counts, **details), status='completed')

    def _finish(self, name, elapsed, counts, *, status, error_type=None):
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        row = dict(name=name, seconds=elapsed, status=status,
                   cuda_synchronized=self.device.type == 'cuda' and status == 'completed',
                   process_lifetime_peak_rss_bytes=int(rss if sys.platform == 'darwin' else rss * 1024),
                   **counts)
        if error_type is not None:
            row['error_type'] = error_type
        if self.device.type == 'cuda' and status == 'completed':
            row['cuda_peak_allocated_bytes'] = torch.cuda.max_memory_allocated(self.device)
            row['cuda_peak_reserved_bytes'] = torch.cuda.max_memory_reserved(self.device)
        self.phases.append(row)
        write_json(self.path, {'active_phase': None, 'phases': self.phases})


def fit_one_step(prepared, diagnosis_config, knowledge, directory, timer, *,
                 resume_identity=None, checkpoint_every_batches=64,
                 interruption_callback=None, stop_requested=None):
    """Fit or resume one shared model, committing only completed minibatches.

    The optional caller identity must remain stable across executions.
    ``interruption_callback(event)`` runs after a durable checkpoint. It may
    raise to test interruption, but cannot change the training RNG streams.
    ``stop_requested()`` reads a caller-managed signal flag after each batch.
    A true flag commits immediately and raises ``TrainingInterrupted``.
    Abrupt termination may replay up to 63 uncommitted batches by default.
    """
    if len(prepared.test.times):
        raise ConfigError('Do not pass any fault/test windows to fitting')
    require_normal(prepared.train)
    require_normal(prepared.val)
    if type(checkpoint_every_batches) is not int or checkpoint_every_batches < 1:
        raise ConfigError('checkpoint_every_batches must be a positive integer')
    if int(diagnosis_config['training']['epochs']) < 1:
        raise ConfigError('One-step training requires at least one epoch')
    enable_reproducible_execution(timer.device)
    identity = make_identity(prepared, diagnosis_config, knowledge, timer.device, resume_identity)
    checkpoint = ResumeCheckpoint(directory, identity)
    with checkpoint.lock():
        return _fit_one_step_locked(
            prepared, diagnosis_config, knowledge, directory, timer, checkpoint,
            checkpoint_every_batches, interruption_callback, stop_requested,
        )


def _fit_one_step_locked(prepared, diagnosis_config, knowledge, directory, timer,
                         checkpoint, checkpoint_every_batches, interruption_callback, stop_requested):
    saved = checkpoint.load()
    if saved is not None:
        required = {'stage', 'epoch', 'model', 'optimizer', 'rng', 'audit_cursor',
                    'scaling', 'ridge', 'initial', 'best_key', 'best_state', 'bad_epochs',
                    'history', 'progress', 'order', 'trained', 'timer_phases'}
        if (not required.issubset(saved)
                or saved['stage'] not in {'train', 'validation', 'selection', 'finalize', 'complete'}
                or type(saved['epoch']) is not int or saved['epoch'] < 1):
            raise ConfigError('Incomplete or invalid training resume state')
        if ((saved['stage'] == 'selection' and not isinstance(saved.get('validated'), dict))
                or (saved['stage'] == 'complete' and not isinstance(saved.get('final'), dict))):
            raise ConfigError('Incomplete resume selection or final audit state')
    cfg = learning_config(diagnosis_config)
    protocol = cfg['experiment']['evaluation_protocol']
    algorithm = cfg['experiment']['algorithm_version']
    short_train = tr._fitting_bundle(prepared.train, cfg)
    short_val = tr._fitting_bundle(prepared.val, cfg)
    prediction_steps = tr._training_delta_t_steps(cfg, short_train.windows.shape[1])
    history_steps = short_train.windows.shape[1] - prediction_steps
    device = timer.device
    set_seed(int(cfg['training']['seed']))
    mask = tr.build_observation_mask(prepared.feature_columns, cfg)
    with timer.phase('training_setup' if saved is None else 'training_resume_setup',
                     train_windows=len(short_train.times), history_steps=history_steps, prediction_steps=prediction_steps):
        # Preserve the original normal target scaling and ridge reference.
        # Only the learned temporal objective and its history change.
        cfg['_reconstructed_variable_scaling'] = saved['scaling'] if saved is not None else fit_reconstructed_variable_scaling(
            prepared.train.windows, knowledge, prepared.feature_columns,
            prepared.scaler.mean, prepared.scaler.std,
            oracle_windows=prepared.train.oracle_windows,
            oracle_columns=prepared.train.oracle_columns)
        model = build_model(cfg, knowledge, len(prepared.feature_columns),
            feature_columns=prepared.feature_columns,
            masked_feature_columns=mask.masked_feature_columns).to(device)
        tr._validate_rule_partition(knowledge, cfg)
        # Response-horizon admissibility belongs to diagnosis, not to the
        # explicitly one-step training objective of this experimental protocol.
        tr._validate_fixed_observer_configuration(diagnosis_config, mask, knowledge)
        ridge = saved['ridge'] if saved is not None else tr.fit_dependency_matched_ridge(
            prepared.train.windows.reshape(-1, len(prepared.feature_columns)), model, alpha=1e-3)
        model.initialize_affine_from_ridge(ridge)
        optimizer = torch.optim.AdamW(model.parameters(),
            lr=float(cfg['training']['learning_rate']),
            weight_decay=float(cfg['training'].get('weight_decay', 0.)))
    batch_size = cfg['training'].get('batch_size', 16)
    if type(batch_size) is not int or batch_size < 1:
        raise ConfigError('Training batch size must be a positive integer')
    loaders = [tr._make_loader(b, batch_size, shuffle, 0, pin_memory=device.type == 'cuda')
               for b, shuffle in [(short_train, True), (short_val, False)]]
    if saved is None:
        with timer.phase('initial_rule_audit', windows=len(short_val.times)):
            initial = tr._structured_training_rule_diagnostics(model, loaders[1], cfg,
                knowledge, prepared.feature_columns, device, mask)
        state = dict(stage='train', epoch=1, initial=initial, best_key=(float('inf'), float('inf')),
                     best_state=None, history=[], bad_epochs=0, progress=None, order=None,
                     trained=None, scaling=cfg['_reconstructed_variable_scaling'], ridge=ridge)
    else:
        state = saved
        model.load_state_dict(state['model'])
        optimizer.load_state_dict(state['optimizer'])
        model._logic_audit_cursor = int(state['audit_cursor'])
        # Preserve the new setup cost as well as previously committed phases.
        timer.phases = copy.deepcopy(state['timer_phases']) + [timer.phases[-1]]
        restore_rng(state['rng'], device)
    state.setdefault('execution_provenance', []).append(device_provenance(device))

    def commit(event):
        if device.type == 'cuda':
            torch.cuda.synchronize(device)
        state.update(model=cpu_snapshot(model.state_dict()), optimizer=cpu_snapshot(optimizer.state_dict()),
                     rng=capture_rng(device), audit_cursor=int(getattr(model, '_logic_audit_cursor', 0)),
                     timer_phases=copy.deepcopy(timer.phases))
        checkpoint.save(state)
        if interruption_callback is not None:
            try:
                interruption_callback(dict(event))
            finally:
                restore_rng(state['rng'], device)

    if saved is None:
        commit(dict(event='initialized', stage=state['stage'], epoch=state['epoch'], completed_batches=0))
    while state['stage'] in {'train', 'validation', 'selection'}:
        epoch = state['epoch']
        if state['stage'] in {'train', 'validation'}:
            stage = state['stage']
            training = stage == 'train'
            progress = state['progress']
            cursor = 0 if progress is None else progress['completed_batches']
            loader, state['order'] = replay_loader(loaders[0 if training else 1], state['order'], cursor)
            phase_started = time.perf_counter()
            elapsed_before = state.get('phase_elapsed_seconds', 0.)

            def after_batch(progress):
                state['progress'] = progress
                count = progress['completed_batches']
                requested = stop_requested is not None and stop_requested()
                if requested or count % checkpoint_every_batches == 0 or count == len(state['order']):
                    state['phase_elapsed_seconds'] = elapsed_before + time.perf_counter() - phase_started
                    commit(dict(event='batch', stage=stage, epoch=epoch, completed_batches=count))
                    if requested:
                        raise TrainingInterrupted('Stop requested after durable completed-batch checkpoint')

            audit_timings = []
            with timer.phase('training_epoch' if training else 'validation_epoch', epoch=epoch,
                             windows=len(short_train.times) if training else len(short_val.times), batch_size=batch_size) as timing:
                metrics = tr._epoch(model, loader, cfg, knowledge, prepared.feature_columns,
                                    device, optimizer if training else None, mask,
                                    progress_state=progress, batch_callback=after_batch,
                                    audit_timings=audit_timings)
                timing['gradient_audit_compute_seconds'] = sum(x['compute_seconds'] for x in audit_timings)
                timing['gradient_audit_compilation_seconds'] = sum(x['compilation_seconds'] for x in audit_timings)
                timing['gradient_audit_count'] = len(audit_timings)
            timer.phases[-1]['seconds'] += elapsed_before
            timer.phases[-1]['compute_seconds'] += elapsed_before
            timer.phases[-1]['resumed_elapsed_unclassified_seconds'] = elapsed_before
            write_json(timer.path, {'active_phase': None, 'phases': timer.phases})
            state.update(progress=None, order=None, phase_elapsed_seconds=0.)
            if training:
                state.update(stage='validation', trained=metrics)
            else:
                state.update(stage='selection', validated=metrics)
            commit(dict(event='phase', stage=state['stage'], epoch=epoch, completed_batches=0))

        if state['stage'] == 'selection':
            validated = state['validated']
            from .observed_commands import selection_key
            key = selection_key(validated, cfg)
            if not np.isfinite(key).all():
                raise ConfigError('Nonfinite normal model-selection objective')
            state['history'].append(dict(epoch=epoch, train=state['trained'], val=validated))
            if key < tuple(state['best_key']):
                state.update(best_key=key, bad_epochs=0, best_state=cpu_snapshot(model.state_dict()))
            else:
                state['bad_epochs'] += 1
            write_json(Path(directory)/'training_progress.json', dict(
                algorithm_version=algorithm, training_protocol=protocol,
                history=state['history'], best_key=list(state['best_key']), completed=False))
            stop = (state['bad_epochs'] >= int(cfg['training']['early_stopping_patience'])
                    or epoch >= int(cfg['training']['epochs']))
            state.update(stage='finalize' if stop else 'train', epoch=epoch + 1,
                         trained=None, validated=None)
            commit(dict(event='epoch', stage=state['stage'], epoch=epoch, completed_batches=0))
    best_state = state['best_state']
    if best_state is None:
        raise ConfigError('No trained checkpoint')
    model.load_state_dict(best_state)
    if state['stage'] != 'complete':
        with timer.phase('final_rule_audit', windows=len(short_val.times)):
            state['final'] = tr._structured_training_rule_diagnostics(model, loaders[1], cfg,
                knowledge, prepared.feature_columns, device, mask)
    model.eval()
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    history = state['history']
    gradient = max(h['train']['weighted_logic_gradient_norm'] for h in history)
    if not np.isfinite(gradient) or (cfg['training']['beta'] == 0 and gradient != 0):
        raise ConfigError('Invalid beta/gradient contract')
    if cfg['training']['beta'] > 0 and gradient <= 0:
        raise ConfigError('No observed gradient for the enabled rule arm')
    result = dict(algorithm_version=algorithm, training_protocol=protocol,
        training_strategy=strategy_metadata(cfg),
        history_steps=history_steps, training_prediction_steps=prediction_steps,
        model_selection_identifier=('recorded_commands_normal_joint_real_nominal_phase_balanced_v1'
            if model.observed_command_indices else 'recursive_normal_lexicographic_real_then_nominal_fixed_horizon'
            if cfg['experiment'].get('training_comparison_arm') == 'recursive' else
            'os1_normal_lexicographic_real_then_nominal_one_step'),
        best_key=list(state['best_key']), history=history, initial_rule_audit=state['initial'],
        final_rule_audit=state['final'], weighted_logic_gradient_norm=gradient,
        normal_only=True, online_labels=False, online_oracle=False, completed=True)
    diagnosis_config['_reconstructed_variable_scaling'] = cfg['_reconstructed_variable_scaling']
    write_json(Path(directory)/'training_metrics.json', result)
    atomic_torch_save(dict(algorithm_version=algorithm, training_protocol=protocol,
        model_state=best_state, training_config=cfg, diagnosis_config=diagnosis_config,
        scaler=prepared.scaler.to_dict(), feature_columns=prepared.feature_columns),
        Path(directory)/'one_step_model.pt')
    if state['stage'] != 'complete':
        state['stage'] = 'complete'
        commit(dict(event='complete', stage='complete', epoch=state['epoch'] - 1, completed_batches=0))
    return model, mask, ridge, result


def normal_horizon_score(model, bundle, config, mask, delta, device, batch_size=16, pump_references=None):
    """Same endpoint MAE criterion, streamed without storing full trajectories.

    This is selection only. Exact full-horizon normal error bands are still
    calibrated separately on the untouched dedicated calibration recordings.
    """
    require_normal(bundle)
    cfg = tr._with_selected_delta_t(config, delta)
    _, exogenous, _ = tr._nominal_real_trajectory_configuration(
        cfg, list(model.feature_names[:model.num_features]), mask, bundle.windows.shape[1])
    count, error = 0, 0.
    pump_totals = {}
    model.eval()
    for start in range(0, len(bundle.times), batch_size):
        windows = torch.as_tensor(bundle.windows[start:start+batch_size],
                                  dtype=torch.float32, device=device)
        values, available = tr._apply_random_mask(windows, 0., mask)
        with torch.no_grad():
            real = model.predict_update_sequence(values, available)
            trajectory = model.nominal_real_trajectories(values, available,
                delta_t_steps=delta, exogenous_measured_indices=exogenous, p_real_output=real)
            if pump_references is not None:
                from .command_quality import update_pump_quality
                update_pump_quality(pump_totals, model, trajectory, bundle, start,
                                    len(windows), values, available, pump_references)
            residual = (trajectory.p_real - trajectory.p_nominal).abs()
            if model.observed_command_indices:
                predicted = [i for i in range(model.diagnostic_dim) if i not in model.observed_command_indices]
                residual = residual[:, predicted]
            error += float(residual.double().sum().cpu())
            count += residual.numel()
    result = error/count if count else float('inf')
    if not np.isfinite(result):
        raise ConfigError('Invalid normal horizon selection')
    result = dict(delta_t_steps=delta, normal_validation_mae=result,
                  selection_scope='normal_validation_only', test_used=False)
    if model.observed_command_indices:
        from .training_resume import content_identity
        result.update(initial_history_steps=model.nominal_history_steps,
                      endpoint_identity=content_identity((bundle.row_ids, bundle.groups, bundle.times)))
    if pump_references is not None:
        from .command_quality import summarize_pump_quality
        result['pump_quality'] = summarize_pump_quality(pump_totals)
    return result
