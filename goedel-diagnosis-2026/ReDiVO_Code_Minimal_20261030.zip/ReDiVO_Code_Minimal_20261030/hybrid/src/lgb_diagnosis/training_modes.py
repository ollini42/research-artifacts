"""Explicit training strategy with recursive training as the standard."""
from __future__ import annotations

import copy

from .config import ConfigError, ONE_STEP_ALGORITHM, RECURSIVE_ALGORITHM


PROTOCOLS = {"recursive": "recursive_legacy_v18", "one_step": "one_step_short_history_v1"}


def training_mode(config):
    """Resolve an explicit strategy, retaining declared historical profiles."""
    training = config.get("training", {})
    experiment = config.get("experiment", {})
    mode = training.get("mode")
    arm = experiment.get("training_comparison_arm")
    protocol = training.get("trajectory_training_protocol")
    if protocol is not None and protocol not in PROTOCOLS.values():
        raise ConfigError("Unknown trajectory_training_protocol")
    if mode is not None and mode not in PROTOCOLS:
        raise ConfigError("training.mode must be recursive or one_step")
    if arm is not None and arm not in PROTOCOLS:
        raise ConfigError("Unknown training comparison arm")
    declarations = [value for value in (mode, arm) if value is not None]
    if protocol is not None:
        declarations.append(next(name for name, value in PROTOCOLS.items() if value == protocol))
    if len(set(declarations)) > 1:
        raise ConfigError("Training mode declarations conflict: mode, arm or trajectory_training_protocol")
    if declarations:
        return declarations[0]
    # This historical study marker is a fallback, not permission to replace
    # an explicitly declared recursive fitting protocol.
    return "one_step" if experiment.get("one_step_training_protocol") is not None else "recursive"


def strategy_metadata(config):
    """Report the chosen approximation without inventing a runtime decision."""
    mode = training_mode(config)
    return dict(mode=mode, standard_mode="recursive", approximation=mode == "one_step",
                approximation_reason=config.get("training", {}).get("approximation_reason"),
                automatic_runtime_fallback=False)


def configure_training_mode(config, mode=None, *, history_steps=None,
                            recursive_training_steps=None, approximation_reason=None):
    """Return a fitting profile without changing diagnosis or the input config."""
    cfg = copy.deepcopy(config)
    mode = training_mode(cfg) if mode is None else {
        "one-step": "one_step", "recursive-legacy": "recursive"
    }.get(mode, mode)
    if mode not in PROTOCOLS:
        raise ConfigError("Training mode must be recursive or one_step")
    training = cfg.setdefault("training", {})
    experiment = cfg.setdefault("experiment", {})
    dataset = cfg["datasets"][cfg["active_dataset"]]
    window = dataset["windows"]["window_size"]
    candidates = cfg["diagnosis"]["nominal_real_trajectory"]["delta_t"]["candidates"]
    steps = recursive_training_steps if recursive_training_steps is not None else training.get("recursive_training_steps")
    if steps is None and "recursive_training_steps" not in training and len(candidates) == 1:
        steps = candidates[0]
    if mode == "recursive" and (type(steps) is not int or not 1 <= steps < window):
        raise ConfigError("Recursive training requires one explicit admissible recursive_training_steps horizon")
    history = history_steps if history_steps is not None else training.get("history_steps")
    if history is None:
        if not candidates or any(type(h) is not int for h in candidates):
            raise ConfigError("Training history cannot be resolved from the diagnosis window")
        history = window - max(candidates)
    prediction = steps if mode == "recursive" else 1
    if type(history) is not int or history < 1 or history + prediction > window:
        raise ConfigError("Training history and prediction exceed the available window")
    reason = approximation_reason if approximation_reason is not None else training.get("approximation_reason")
    if reason is not None and (not isinstance(reason, str) or not reason.strip()):
        raise ConfigError("approximation_reason must be nonempty text")
    if mode == "recursive" and approximation_reason is not None:
        raise ConfigError("An approximation reason applies only to one_step training")
    training.update(mode=mode, history_steps=history, prediction_steps=prediction,
                    trajectory_training_protocol=PROTOCOLS[mode])
    if mode == "recursive":
        training["recursive_training_steps"] = steps
        training.pop("approximation_reason", None)
    elif reason is not None:
        training["approximation_reason"] = reason
    experiment["training_comparison_arm"] = mode
    conditioned = cfg["diagnosis"].get("method_identifier") == "v18_observed_command_conditioned_direct_residual_v1"
    if conditioned:
        from .observed_commands import ONE_STEP_ALGORITHM as command_one_step
        from .observed_commands import RECURSIVE_ALGORITHM as command_recursive
        experiment["algorithm_version"] = command_recursive if mode == "recursive" else command_one_step
    else:
        experiment["algorithm_version"] = RECURSIVE_ALGORITHM if mode == "recursive" else ONE_STEP_ALGORITHM
    experiment["paper_evidence_status"] = (
        "recursive_standard_training_revision" if mode == "recursive" else "one_step_runtime_approximation_revision")
    experiment["training_strategy"] = strategy_metadata(cfg)
    return cfg
