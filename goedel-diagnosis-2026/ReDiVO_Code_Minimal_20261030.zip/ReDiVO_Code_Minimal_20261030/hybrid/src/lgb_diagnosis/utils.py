"""Small shared utilities."""

from __future__ import annotations

import json
import logging
import os
import platform
import random
import resource
import sys
import tempfile
from pathlib import Path
from typing import Any

import numpy as np
import torch


def setup_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


def ensure_dir(path: str | Path) -> Path:
    result = Path(path)
    result.mkdir(parents=True, exist_ok=True)
    return result


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def select_device(requested: str = "auto") -> torch.device:
    if requested == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested, but CUDA is not available")
    return torch.device(requested)


def write_json(path: str | Path, payload: dict[str, Any]) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=target.parent,
                                         prefix=f".{target.name}.", suffix=".tmp", delete=False) as handle:
            temporary = Path(handle.name)
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, target)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def read_json(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def system_info() -> dict[str, Any]:
    usage = resource.getrusage(resource.RUSAGE_SELF)
    result = {
        "python": sys.version,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "torch": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_device_count": torch.cuda.device_count() if torch.cuda.is_available() else 0,
        "torch_num_threads": torch.get_num_threads(),
        "torch_num_interop_threads": torch.get_num_interop_threads(),
        "slurm_cpus_per_task": os.environ.get("SLURM_CPUS_PER_TASK"),
        "torch_cuda_tf32": bool(torch.backends.cuda.matmul.allow_tf32),
        "torch_cudnn_tf32": bool(torch.backends.cudnn.allow_tf32),
        "implementation_revision": "source_audit_one_step_r2_20261010",
        "process_cpu_user_seconds": usage.ru_utime,
        "process_cpu_system_seconds": usage.ru_stime,
        "process_peak_rss_bytes": int(usage.ru_maxrss * (1 if sys.platform == "darwin" else 1024)),
    }
    if torch.cuda.is_available():
        result.update({"cuda_device_name": torch.cuda.get_device_name(),
                       "cuda_peak_allocated_bytes": torch.cuda.max_memory_allocated(),
                       "cuda_peak_reserved_bytes": torch.cuda.max_memory_reserved(),
                       "cuda_total_device_memory_bytes": torch.cuda.get_device_properties(torch.cuda.current_device()).total_memory})
    return result
