"""V18 model construction and differentiable Gödel training loss."""

from __future__ import annotations

from typing import Any

import numpy as np
import torch
from torch import nn

from .knowledge import RuleSpec, SystemKnowledge


def build_model(
    config: dict[str, Any],
    knowledge: SystemKnowledge,
    num_features: int,
    *,
    feature_columns: list[str] | None = None,
    masked_feature_columns: list[str] | tuple[str, ...] = (),
) -> nn.Module:
    model_cfg = config["model"]
    architecture = str(
        model_cfg.get("architecture", "structured_predict_update_v18")
    ).lower()
    if architecture not in {
        "structured_predict_update_v18",
        "v18_structured_predict_update",
    }:
        raise ValueError(f"Unsupported model architecture: {architecture}")
    if feature_columns is None or len(feature_columns) != num_features:
        raise ValueError(
            "V18 structured observer requires the ordered feature_columns manifest"
        )
    from .structured_observer import build_structured_observer

    observer = build_structured_observer(
        config,
        knowledge,
        feature_columns,
        masked_feature_columns,
    )
    from .observed_commands import METHOD
    observer.method_version = (METHOD if observer.observed_command_indices else
                               "v18_audited_range_open_loop_component_fault_observer")
    observer.architecture = "structured_predict_update_v18"
    return observer


def compute_logic_loss(
    tau: torch.Tensor,
    knowledge: SystemKnowledge,
    margin: float,
) -> torch.Tensor:
    loss, _group_losses = compute_logic_loss_by_group(tau, knowledge, margin)
    return loss


def compute_logic_loss_by_group(
    tau: torch.Tensor,
    knowledge: SystemKnowledge,
    margin: float,
    group_weights: dict[str, float] | None = None,
    rules: list[RuleSpec] | None = None,
) -> tuple[torch.Tensor, dict[str, torch.Tensor]]:
    active_rules = knowledge.rules if rules is None else rules
    if tau.shape[1] == 0 or not active_rules:
        return tau.sum() * 0.0, {}
    predicate_index = {predicate.name: idx for idx, predicate in enumerate(knowledge.predicates)}
    losses_by_group: dict[str, list[torch.Tensor]] = {}
    group_weights = group_weights or {}
    for rule in active_rules:
        score = evaluate_rule_torch(tau, rule, predicate_index)
        group = str(getattr(rule, "group", "module_nominality") or "module_nominality")
        rule_loss = float(rule.weight) * torch.relu(float(margin) - score).mean()
        losses_by_group.setdefault(group, []).append(rule_loss)
    if not losses_by_group:
        return tau.sum() * 0.0, {}
    unweighted_group_losses = {
        group: torch.stack(group_losses).mean()
        for group, group_losses in losses_by_group.items()
        if group_losses
    }
    raw_weights = {
        group: max(float(group_weights.get(group, 1.0)), 0.0)
        for group in unweighted_group_losses
    }
    weight_sum = sum(raw_weights.values())
    if weight_sum <= 0.0:
        return tau.sum() * 0.0, {
            group: loss * 0.0 for group, loss in unweighted_group_losses.items()
        }
    normalized = {
        group: raw_weights[group] / weight_sum for group in raw_weights
    }
    group_losses = {
        group: normalized[group] * loss
        for group, loss in unweighted_group_losses.items()
    }
    # Rules are averaged within each group. Active group weights are then
    # normalized to sum to one. Adding a rule or a group therefore cannot
    # increase the regularization merely by changing the rule count.
    return torch.stack(list(group_losses.values())).sum(), group_losses


def evaluate_rule_torch(tau: torch.Tensor, rule: RuleSpec, predicate_index: dict[str, int]) -> torch.Tensor:
    if rule.type == "require":
        return tau[:, predicate_index[_required(rule.predicate, rule.name)]]
    if rule.type == "all":
        values = [tau[:, predicate_index[name]] for name in rule.predicates]
        return torch.stack(values, dim=1).min(dim=1).values
    if rule.type == "any":
        values = [tau[:, predicate_index[name]] for name in rule.predicates]
        return torch.stack(values, dim=1).max(dim=1).values
    if rule.type == "implication":
        antecedent = tau[:, predicate_index[_required(rule.antecedent, rule.name)]]
        consequent = tau[:, predicate_index[_required(rule.consequent, rule.name)]]
        return torch.where(antecedent <= consequent, torch.ones_like(consequent), consequent)
    if rule.type == "implication_all":
        antecedents = [tau[:, predicate_index[name]] for name in rule.predicates]
        if not antecedents:
            raise ValueError(f"Rule '{rule.name}' has no antecedent predicates")
        antecedent = torch.stack(antecedents, dim=1).min(dim=1).values
        consequent = tau[:, predicate_index[_required(rule.consequent, rule.name)]]
        return torch.where(antecedent <= consequent, torch.ones_like(consequent), consequent)
    raise ValueError(f"Unsupported rule type: {rule.type}")


def evaluate_rule_numpy(tau: np.ndarray, rule: RuleSpec, predicate_index: dict[str, int]) -> np.ndarray:
    if rule.type == "require":
        return tau[:, predicate_index[_required(rule.predicate, rule.name)]]
    if rule.type == "all":
        values = [tau[:, predicate_index[name]] for name in rule.predicates]
        return np.stack(values, axis=1).min(axis=1)
    if rule.type == "any":
        values = [tau[:, predicate_index[name]] for name in rule.predicates]
        return np.stack(values, axis=1).max(axis=1)
    if rule.type == "implication":
        antecedent = tau[:, predicate_index[_required(rule.antecedent, rule.name)]]
        consequent = tau[:, predicate_index[_required(rule.consequent, rule.name)]]
        return np.where(antecedent <= consequent, 1.0, consequent)
    if rule.type == "implication_all":
        if not rule.predicates:
            raise ValueError(f"Rule '{rule.name}' has no antecedent predicates")
        antecedents = [tau[:, predicate_index[name]] for name in rule.predicates]
        antecedent = np.stack(antecedents, axis=1).min(axis=1)
        consequent = tau[:, predicate_index[_required(rule.consequent, rule.name)]]
        return np.where(antecedent <= consequent, 1.0, consequent)
    raise ValueError(f"Unsupported rule type: {rule.type}")


def _required(value: str | None, rule_name: str) -> str:
    if not value:
        raise ValueError(f"Rule '{rule_name}' is missing a predicate name")
    return value
