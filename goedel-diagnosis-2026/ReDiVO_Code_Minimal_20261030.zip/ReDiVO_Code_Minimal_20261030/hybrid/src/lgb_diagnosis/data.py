"""CSV catalog ingestion, schema checks, split logic, and time windows."""

from __future__ import annotations

import csv
import logging
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from .config import ConfigError, active_dataset_config, expand_path

LOGGER = logging.getLogger(__name__)


@dataclass(frozen=True)
class TableReport:
    name: str
    path: str
    rows: int
    columns: list[str]
    missing_values: dict[str, int]


@dataclass
class Standardizer:
    mean: np.ndarray
    std: np.ndarray

    @classmethod
    def fit(cls, values: np.ndarray) -> "Standardizer":
        mean = np.nanmean(values, axis=0)
        std = np.nanstd(values, axis=0)
        std[std < 1e-8] = 1.0
        return cls(mean=mean.astype(np.float32), std=std.astype(np.float32))

    def transform(self, values: np.ndarray) -> np.ndarray:
        return ((values - self.mean) / self.std).astype(np.float32)

    def to_dict(self) -> dict[str, Any]:
        return {"mean": self.mean.tolist(), "std": self.std.tolist()}

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "Standardizer":
        return cls(np.asarray(payload["mean"], dtype=np.float32), np.asarray(payload["std"], dtype=np.float32))


@dataclass
class WindowBundle:
    windows: np.ndarray
    targets: np.ndarray
    row_ids: list[Any]
    groups: list[Any]
    times: list[Any]
    labels: list[Any] | None
    root_causes: list[Any] | None
    metadata: dict[str, list[Any]] = field(default_factory=dict)
    oracle_windows: np.ndarray | None = None
    oracle_columns: list[str] = field(default_factory=list)


@dataclass
class PreparedData:
    train: WindowBundle
    val: WindowBundle
    test: WindowBundle
    scaler: Standardizer
    feature_columns: list[str]
    oracle_columns: list[str]
    dataset_config: dict[str, Any]
    reports: list[TableReport]


class TimeSeriesWindowDataset(Dataset):
    def __init__(self, bundle: WindowBundle):
        self.bundle_oracle_columns = list(bundle.oracle_columns)
        self.windows = torch.as_tensor(bundle.windows, dtype=torch.float32)
        self.targets = torch.as_tensor(bundle.targets, dtype=torch.float32)
        if bundle.oracle_windows is None:
            shape = (*bundle.windows.shape[:2], 0)
            self.oracle_windows = torch.empty(shape, dtype=torch.float32)
        else:
            self.oracle_windows = torch.as_tensor(bundle.oracle_windows, dtype=torch.float32)

    def __len__(self) -> int:
        return int(self.windows.shape[0])

    def __getitem__(self, index: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        return self.windows[index], self.targets[index], self.oracle_windows[index]


def _window_storage(
    shape: tuple[int, ...],
    dataset: dict[str, Any],
    *,
    purpose: str,
) -> np.ndarray:
    """Allocate large window tensors without duplicating them in RAM.

    TEP evaluation can contain hundreds of thousands of overlapping windows.
    Materializing these windows with ``np.stack`` first builds a Python list
    and then allocates another dense array.  The peak can exceed the memory of
    an otherwise suitable GPU node.  ``memmap`` keeps the same NumPy indexing
    contract while paging the dense window tensor through job-local storage.

    The backing file is unlinked immediately after mapping on the supported
    POSIX platforms.  It therefore disappears automatically when the process
    exits, including after a normal Slurm task.  Scientific sampling and all
    window values remain unchanged.
    """

    window_cfg = dataset.get("windows") or {}
    mode = str(window_cfg.get("storage", "auto")).strip().lower()
    if mode not in {"auto", "memory", "memmap"}:
        raise ConfigError("dataset.windows.storage must be auto, memory, or memmap")
    threshold_gib = float(window_cfg.get("max_in_memory_gib", 2.0))
    if threshold_gib <= 0.0:
        raise ConfigError("dataset.windows.max_in_memory_gib must be positive")
    byte_count = int(np.prod(shape, dtype=np.int64)) * np.dtype(np.float32).itemsize
    if mode == "memory" or (
        mode == "auto" and byte_count <= threshold_gib * (1024**3)
    ):
        return np.empty(shape, dtype=np.float32)

    scratch = os.environ.get("SLURM_TMPDIR") or tempfile.gettempdir()
    Path(scratch).mkdir(parents=True, exist_ok=True)
    descriptor, path = tempfile.mkstemp(
        prefix=f"lgb_{purpose}_", suffix=".f32", dir=scratch
    )
    os.close(descriptor)
    try:
        array = np.memmap(path, dtype=np.float32, mode="w+", shape=shape)
        os.unlink(path)
    except Exception:
        try:
            os.unlink(path)
        except FileNotFoundError:
            pass
        raise
    LOGGER.info(
        "Using anonymous memmap for %s: shape=%s size=%.2f GiB scratch=%s",
        purpose,
        shape,
        byte_count / float(1024**3),
        scratch,
    )
    return array


def load_table(entry: dict[str, Any], project_root: str | Path) -> tuple[pd.DataFrame, TableReport]:
    path = expand_path(entry["path"], project_root)
    if not path.exists():
        raise FileNotFoundError(
            f"CSV table '{entry['name']}' not found at {path}. "
            "Download the dataset locally first or adjust the catalog path."
        )
    configured_dtypes = entry.get("dtypes") or None
    if configured_dtypes is not None and not isinstance(configured_dtypes, dict):
        raise ConfigError(f"Table '{entry['name']}' field 'dtypes' must be a mapping")
    use_columns = entry.get("use_columns") or None
    if use_columns is not None:
        use_columns = list(dict.fromkeys([entry["key_column"], *use_columns]))
    frame = pd.read_csv(path, dtype=configured_dtypes, usecols=use_columns)
    required = list(entry.get("required_columns", []))
    missing = [column for column in required if column not in frame.columns]
    if missing:
        raise ConfigError(f"Table '{entry['name']}' misses required columns: {missing}")
    key = entry["key_column"]
    if bool(entry.get("unique_key", True)) and frame[key].duplicated().any():
        raise ConfigError(f"Table '{entry['name']}' has duplicate key values in '{key}'")
    report = TableReport(
        name=entry["name"],
        path=str(path),
        rows=int(len(frame)),
        columns=[str(c) for c in frame.columns],
        missing_values={str(c): int(v) for c, v in frame.isna().sum().items() if int(v) > 0},
    )
    return frame, report


def load_catalog(config: dict[str, Any]) -> tuple[pd.DataFrame, list[TableReport]]:
    dataset = active_dataset_config(config)
    project_root = config["_project_root"]
    merged: pd.DataFrame | None = None
    reports: list[TableReport] = []
    base_key: str | None = None
    for entry in dataset["catalog"]:
        frame, report = load_table(entry, project_root)
        reports.append(report)
        key = entry["key_column"]
        if merged is None:
            merged = frame.copy()
            base_key = key
            continue
        if base_key is None:
            raise ConfigError("Internal catalog merge error: missing base key")
        before = len(merged)
        merged = merged.merge(
            frame,
            left_on=base_key,
            right_on=key,
            how="left",
            validate="one_to_one" if bool(entry.get("unique_key", True)) else "one_to_many",
            suffixes=("", f"_{entry['name']}"),
        )
        if len(merged) != before:
            raise ConfigError(f"Merging '{entry['name']}' changed row count from {before} to {len(merged)}")
        if key != base_key and key in merged.columns:
            merged = merged.drop(columns=[key])
    if merged is None:
        raise ConfigError("No CSV tables loaded")
    return merged, reports


def infer_feature_columns(frame: pd.DataFrame, dataset: dict[str, Any]) -> list[str]:
    configured = list(dataset.get("feature_columns") or [])
    excluded: set[str] = set()
    for key in ("target_column", "root_cause_column", "group_column", "time_column", "split_column"):
        value = dataset.get(key)
        if value:
            excluded.add(str(value))
    excluded.update(str(entry["key_column"]) for entry in dataset["catalog"])
    excluded.update(str(column) for column in dataset.get("oracle_columns") or [])
    split_column = (dataset.get("split") or {}).get("column")
    if split_column:
        excluded.add(str(split_column))
    for entry in dataset["catalog"]:
        if entry.get("role") == "features":
            continue
        excluded.update(str(column) for column in entry.get("required_columns", []))
        excluded.update(str(column) for column in entry.get("optional_columns", []))
        excluded.update(str(column) for column in entry.get("use_columns", []) or [])
    if configured:
        missing = [column for column in configured if column not in frame.columns]
        if missing:
            raise ConfigError(f"Configured feature columns are missing: {missing}")
        forbidden = sorted(set(configured).intersection(excluded))
        if forbidden:
            raise ConfigError(f"Identifiers and offline columns cannot be feature columns: {forbidden}")
        return configured
    numeric = [column for column in frame.select_dtypes(include=[np.number]).columns if column not in excluded]
    if not numeric:
        raise ConfigError("No numeric feature columns could be inferred; set feature_columns explicitly")
    return list(numeric)


def infer_oracle_columns(frame: pd.DataFrame, dataset: dict[str, Any]) -> list[str]:
    """Return offline-only simulator state columns used as latent targets.

    Oracle columns are merged by ``row_id`` for training/evaluation only. They
    are never part of the online feature matrix and therefore cannot leak into
    reconstruction or diagnosis inputs.
    """

    configured = [str(column) for column in dataset.get("oracle_columns") or []]
    if configured:
        missing = [column for column in configured if column not in frame.columns]
        if missing:
            raise ConfigError(f"Configured oracle columns are missing: {missing}")
        return configured
    columns: list[str] = []
    for entry in dataset["catalog"]:
        if entry.get("role") != "oracle":
            continue
        for column in entry.get("use_columns") or entry.get("required_columns") or []:
            column = str(column)
            if column != entry["key_column"] and column in frame.columns:
                columns.append(column)
    return list(dict.fromkeys(columns))


def filter_dataset_rows(frame: pd.DataFrame, dataset: dict[str, Any]) -> pd.DataFrame:
    """Apply explicit experiment-scope filters before fitting any statistics."""

    filtered = frame
    column_values = (dataset.get("filters") or {}).get("column_values") or {}
    if not isinstance(column_values, dict):
        raise ConfigError("datasets.<name>.filters.column_values must be a mapping")
    for column, allowed in column_values.items():
        if str(column) not in filtered.columns:
            raise ConfigError(
                f"datasets.<name>.filters.column_values references missing column {column!r}"
            )
        values = allowed if isinstance(allowed, list) else [allowed]
        filtered = filtered[
            filtered[str(column)].astype(str).isin(str(value) for value in values)
        ].copy()
        if filtered.empty:
            raise ConfigError(
                f"No rows remain after filtering {column!r} to {values}"
            )
    return filtered


def _add_reproducible_measurement_noise(
    frame: pd.DataFrame,
    feature_columns: list[str],
    dataset: dict[str, Any],
    *,
    reference_frame: pd.DataFrame | None = None,
    random_stream: int = 0,
) -> pd.DataFrame:
    """Apply noise using a fixed normal-training spread and split-specific stream."""

    preprocessing = dataset.get("preprocessing") or {}
    standard_deviation = float(preprocessing.get("measurement_noise_std", 0.0))
    if not np.isfinite(standard_deviation) or standard_deviation < 0.0:
        raise ConfigError("preprocessing.measurement_noise_std must be finite and non-negative")
    if standard_deviation == 0.0:
        return frame
    seed = int(preprocessing.get("measurement_noise_seed", 20260820))
    if reference_frame is None:
        raise ConfigError("Measurement-noise scaling requires a normal training reference")
    rng = np.random.default_rng(np.random.SeedSequence([seed, random_stream]))
    result = frame.copy()
    # Test values cannot determine the perturbation of training observations.
    spread = reference_frame[feature_columns].std(axis=0, ddof=0).replace(0.0, 1.0)
    if not np.isfinite(spread.to_numpy(dtype=np.float64)).all():
        raise ConfigError("Cannot fit finite measurement-noise scales on normal training data")
    noise = rng.normal(
        loc=0.0,
        scale=standard_deviation,
        size=(len(result), len(feature_columns)),
    ) * spread.to_numpy(dtype=np.float64).reshape(1, -1)
    result.loc[:, feature_columns] = (
        result[feature_columns].to_numpy(dtype=np.float64) + noise
    )
    return result


def _normal_training_fraction(
    frame: pd.DataFrame,
    dataset: dict[str, Any],
) -> pd.DataFrame:
    """Deterministically reduce only the normal training information."""

    fraction = float(
        (dataset.get("preprocessing") or {}).get("normal_training_fraction", 1.0)
    )
    if not 0.0 < fraction <= 1.0:
        raise ConfigError("preprocessing.normal_training_fraction must lie in (0, 1]")
    if fraction >= 1.0:
        return frame
    group_column = dataset.get("group_column")
    seed = int((dataset.get("preprocessing") or {}).get("training_fraction_seed", 42))
    if group_column and group_column in frame.columns:
        groups = np.asarray(sorted(frame[group_column].dropna().unique().tolist()))
        rng = np.random.default_rng(seed)
        rng.shuffle(groups)
        keep_count = max(1, int(np.ceil(len(groups) * fraction)))
        return frame[frame[group_column].isin(set(groups[:keep_count]))].copy()
    keep_count = max(1, int(np.ceil(len(frame) * fraction)))
    return frame.iloc[:keep_count].copy()


def handle_missing_values(
    frame: pd.DataFrame,
    feature_columns: list[str],
    strategy: str,
    *,
    reference_frame: pd.DataFrame | None = None,
) -> pd.DataFrame:
    result = frame.copy()
    missing = result[feature_columns].isna().sum()
    if missing.any():
        LOGGER.warning("Missing feature values: %s", missing[missing > 0].to_dict())
    if strategy == "drop":
        return result.dropna(subset=feature_columns)
    if strategy == "zero":
        result[feature_columns] = result[feature_columns].fillna(0.0)
        return result
    if strategy == "interpolate":
        if missing.any():
            raise ConfigError(
                "Bidirectional interpolation is not causal. Use normal-training median "
                "replacement or an explicitly supplied causal preprocessing method."
            )
    if strategy in {"median", "interpolate"}:
        reference = result if reference_frame is None else reference_frame
        medians = reference[feature_columns].median(numeric_only=True)
        result[feature_columns] = result[feature_columns].fillna(medians)
        if result[feature_columns].isna().any().any():
            raise ConfigError("Normal training data do not supply every required feature median")
        return result
    raise ConfigError(f"Unsupported missing strategy: {strategy}")


def _validate_target_labels(frame: pd.DataFrame, dataset: dict[str, Any]) -> None:
    """A declared label must distinguish normal, faulty, and unavailable data."""

    target = dataset.get("target_column")
    if not target:
        return
    if target not in frame.columns:
        raise ConfigError(f"Configured target column '{target}' is missing")
    if frame[target].isna().any():
        raise ConfigError(f"Configured target column '{target}' contains missing labels")


def filter_normal(frame: pd.DataFrame, dataset: dict[str, Any]) -> pd.DataFrame:
    _validate_target_labels(frame, dataset)
    target = dataset.get("target_column")
    normal_labels = dataset.get("normal_labels") or []
    if target and not normal_labels:
        raise ConfigError("A declared target requires nonempty normal_labels for normal-only filtering")
    if not target:
        return frame
    normal = frame[frame[target].isin(normal_labels)].copy()
    if normal.empty:
        raise ConfigError(f"No rows match normal_labels={normal_labels} in '{target}'")
    return normal


def split_frame(frame: pd.DataFrame, dataset: dict[str, Any]) -> dict[str, pd.DataFrame]:
    split = dataset["split"]
    train_ratio = float(split["train_ratio"])
    val_ratio = float(split["val_ratio"])
    seed = int(split.get("seed", 42))
    group_col = dataset.get("group_column")
    time_col = dataset.get("time_column")
    method = split.get("method", "group")
    rng = np.random.default_rng(seed)
    if group_col:
        if group_col not in frame.columns:
            raise ConfigError(f"Configured group column '{group_col}' is missing")
        if frame[group_col].isna().any():
            raise ConfigError(f"Configured group column '{group_col}' contains missing identifiers")
    if method == "column":
        split_col = split.get("column") or dataset.get("split_column")
        if not split_col:
            raise ConfigError("split.method='column' requires split.column or dataset split_column")
        if split_col not in frame.columns:
            raise ConfigError(f"Configured split column '{split_col}' is missing")
        if frame[split_col].isna().any():
            raise ConfigError(f"Split column '{split_col}' contains missing assignments")
        allowed = {"train", "val", "test"}
        values = set(str(value) for value in frame[split_col].dropna().unique().tolist())
        unknown = values.difference(allowed)
        if unknown:
            raise ConfigError(f"Split column '{split_col}' contains unsupported values: {sorted(unknown)}")
        splits = {
            name: frame[frame[split_col].astype(str) == name].copy()
            for name in ("train", "val", "test")
        }
        empty = [name for name, part in splits.items() if part.empty]
        if empty:
            raise ConfigError(f"Split column '{split_col}' produced empty splits: {empty}")
        assert_no_group_leakage(splits, group_col)
        return splits
    if method == "group" and group_col and group_col in frame.columns:
        groups = np.asarray(sorted(frame[group_col].dropna().unique().tolist()))
        rng.shuffle(groups)
        n_train = max(1, int(round(len(groups) * train_ratio)))
        n_val = max(1, int(round(len(groups) * val_ratio))) if len(groups) >= 3 else 0
        train_groups = set(groups[:n_train])
        val_groups = set(groups[n_train:n_train + n_val])
        test_groups = set(groups[n_train + n_val:])
        if not test_groups:
            test_groups = val_groups
            val_groups = set()
        splits = {
            "train": frame[frame[group_col].isin(train_groups)].copy(),
            "val": frame[frame[group_col].isin(val_groups)].copy(),
            "test": frame[frame[group_col].isin(test_groups)].copy(),
        }
        assert_no_group_leakage(splits, group_col)
        return splits
    if method in {"group", "time"}:
        ordered = frame.sort_values(time_col) if time_col and time_col in frame.columns else frame.copy()
        n = len(ordered)
        n_train = int(n * train_ratio)
        n_val = int(n * val_ratio)
        return {
            "train": ordered.iloc[:n_train].copy(),
            "val": ordered.iloc[n_train:n_train + n_val].copy(),
            "test": ordered.iloc[n_train + n_val:].copy(),
        }
    raise ConfigError(f"Unsupported split method: {method}")


def assert_no_group_leakage(splits: dict[str, pd.DataFrame], group_col: str | None) -> None:
    if not group_col:
        return
    group_sets = {
        name: set(part[group_col].dropna().unique().tolist())
        for name, part in splits.items()
        if group_col in part.columns
    }
    names = list(group_sets)
    for i, left_name in enumerate(names):
        for right_name in names[i + 1:]:
            overlap = group_sets[left_name].intersection(group_sets[right_name])
            if overlap:
                raise ConfigError(f"Group leakage between {left_name} and {right_name}: {sorted(overlap)[:5]}")


def make_windows(
    frame: pd.DataFrame,
    feature_columns: list[str],
    dataset: dict[str, Any],
    scaler: Standardizer,
    oracle_columns: list[str] | None = None,
    stride_override: int | None = None,
    allowed_row_ids: set[Any] | None = None,
) -> WindowBundle:
    group_col = dataset.get("group_column")
    time_col = dataset.get("time_column")
    target_col = dataset.get("target_column")
    root_col = dataset.get("root_cause_column")
    key_col = dataset["catalog"][0]["key_column"]
    window_size = int(dataset["windows"]["window_size"])
    stride = int(
        stride_override
        if stride_override is not None
        else dataset["windows"].get("stride", 1)
    )
    if stride < 1:
        raise ConfigError("Window stride must be positive")
    row_ids: list[Any] = []
    groups: list[Any] = []
    times: list[Any] = []
    labels: list[Any] = []
    root_causes: list[Any] = []
    metadata_columns = [
        column
        for column in (
            "root_cause_fault",
            "root_cause_feature",
            "scenario_id",
            "scenario_category",
            "ds_id",
            "signal_mode",
            "fault_onset_step",
            "is_post_fault",
            "hydraulic_demand_model",
        )
        if column in frame.columns
    ]
    metadata: dict[str, list[Any]] = {column: [] for column in metadata_columns}
    oracle_columns = list(oracle_columns or [])
    normal_labels = dataset.get("normal_labels") or []
    if target_col and normal_labels and target_col in frame.columns:
        metadata["window_all_normal"] = []
    iterable = (
        frame.groupby(group_col, sort=False)
        if group_col and group_col in frame.columns
        else [(None, frame)]
    )
    parts: list[tuple[Any, pd.DataFrame, np.ndarray]] = []
    total_windows = 0
    for group, part in iterable:
        if time_col and time_col in part.columns:
            part = part.sort_values(time_col)
            raw_times = part[time_col]
            if pd.api.types.is_numeric_dtype(raw_times):
                valid_times = np.isfinite(raw_times.to_numpy(dtype=float)).all()
            else:
                valid_times = pd.to_datetime(raw_times, errors="coerce", utc=True).notna().all()
            if not valid_times or raw_times.duplicated().any():
                raise ConfigError(f"Recording timestamps in '{time_col}' must be finite and distinct")
        if len(part) < window_size:
            continue
        starts = np.arange(
            0, len(part) - window_size + 1, stride, dtype=np.int64
        )
        if allowed_row_ids is not None:
            # Select whole scheduled windows before removing faulty rows.
            # Filtering the rows first would join history across fault gaps.
            excluded_rows = ~part[key_col].isin(allowed_row_ids).to_numpy()
            excluded_prefix = np.r_[0, np.cumsum(excluded_rows)]
            starts = starts[(excluded_prefix[starts + window_size] - excluded_prefix[starts]) == 0]
        if starts.size:
            parts.append((group, part, starts))
            total_windows += int(starts.size)
    if total_windows == 0:
        raise ConfigError(
            f"No windows created. Check window_size={window_size}, stride={stride}, and split sizes."
        )
    windows = _window_storage(
        (total_windows, window_size, len(feature_columns)),
        dataset,
        purpose="measurement_windows",
    )
    targets = np.empty((total_windows, len(feature_columns)), dtype=np.float32)
    oracle_windows = (
        _window_storage(
            (total_windows, window_size, len(oracle_columns)),
            dataset,
            purpose="oracle_windows",
        )
        if oracle_columns
        else None
    )
    cursor = 0
    copy_chunk_size = max(
        1, int((dataset.get("windows") or {}).get("storage_copy_chunk_size", 4096))
    )
    for group, part, starts in parts:
        count = int(starts.size)
        stop = cursor + count
        values = scaler.transform(
            part[feature_columns].to_numpy(dtype=np.float32)
        )
        sliding = np.lib.stride_tricks.sliding_window_view(
            values, window_size, axis=0
        )
        # NumPy places the new window axis last for axis=0.  Move it between
        # the sample and feature axes to retain [sample, time, feature].
        sliding = np.moveaxis(sliding, -1, 1)
        for chunk_start in range(0, count, copy_chunk_size):
            chunk_stop = min(count, chunk_start + copy_chunk_size)
            windows[cursor + chunk_start : cursor + chunk_stop] = sliding[
                starts[chunk_start:chunk_stop]
            ]
        target_indices = starts + window_size - 1
        targets[cursor:stop] = values[target_indices]
        if oracle_windows is not None:
            oracle_values = part[oracle_columns].to_numpy(dtype=np.float32)
            oracle_sliding = np.lib.stride_tricks.sliding_window_view(
                oracle_values, window_size, axis=0
            )
            oracle_sliding = np.moveaxis(oracle_sliding, -1, 1)
            for chunk_start in range(0, count, copy_chunk_size):
                chunk_stop = min(count, chunk_start + copy_chunk_size)
                oracle_windows[cursor + chunk_start : cursor + chunk_stop] = (
                    oracle_sliding[starts[chunk_start:chunk_stop]]
                )
        last_rows = part.iloc[target_indices]
        if key_col in part.columns:
            row_ids.extend(last_rows[key_col].tolist())
        else:
            row_ids.extend(range(cursor, stop))
        groups.extend([group] * count)
        if time_col and time_col in part.columns:
            times.extend(last_rows[time_col].tolist())
        else:
            times.extend(target_indices.tolist())
        if target_col and target_col in part.columns:
            labels.extend(last_rows[target_col].tolist())
        if root_col and root_col in part.columns:
            root_causes.extend(
                "" if pd.isna(value) else value
                for value in last_rows[root_col].tolist()
            )
        if "window_all_normal" in metadata:
            faulty = ~part[target_col].isin(normal_labels).to_numpy()
            faulty_prefix = np.r_[0, np.cumsum(faulty)]
            metadata["window_all_normal"].extend(
                ((faulty_prefix[starts + window_size] - faulty_prefix[starts]) == 0).tolist()
            )
        for column in metadata_columns:
            metadata[column].extend(
                "" if pd.isna(value) else value
                for value in last_rows[column].tolist()
            )
        cursor = stop
    return WindowBundle(
        windows=windows,
        targets=targets,
        row_ids=row_ids,
        groups=groups,
        times=times,
        labels=labels if labels else None,
        root_causes=root_causes if root_causes else None,
        metadata=metadata,
        oracle_windows=oracle_windows,
        oracle_columns=oracle_columns,
    )


def prepare_data(config: dict[str, Any], train_on_normal_only: bool = True) -> PreparedData:
    dataset = active_dataset_config(config)
    frame, reports = load_catalog(config)
    frame = filter_dataset_rows(frame, dataset)
    _validate_target_labels(frame, dataset)
    feature_columns = infer_feature_columns(frame, dataset)
    oracle_columns = infer_oracle_columns(frame, dataset)
    overlap = sorted(set(feature_columns).intersection(oracle_columns))
    if overlap:
        raise ConfigError(
            "Oracle columns must remain offline-only and cannot be feature columns: "
            f"{overlap}"
        )
    target = dataset.get("target_column")
    if target and target in feature_columns:
        raise ConfigError(f"Target column '{target}' must not be in feature_columns")
    root = dataset.get("root_cause_column")
    if root and root in feature_columns:
        raise ConfigError(f"Root-cause column '{root}' must not be in feature_columns")
    strategy = dataset.get("preprocessing", {}).get("missing_strategy", "median")
    splits = split_frame(frame, dataset)
    reference = filter_normal(splits["train"], dataset) if train_on_normal_only else splits["train"]
    reference = _normal_training_fraction(reference, dataset)
    reference = handle_missing_values(reference, feature_columns, strategy, reference_frame=reference)
    for stream, name in enumerate(("train", "val", "test")):
        part = handle_missing_values(splits[name], feature_columns, strategy, reference_frame=reference)
        splits[name] = _add_reproducible_measurement_noise(
            part, feature_columns, dataset, reference_frame=reference, random_stream=stream,
        )
    train_for_scaler = filter_normal(splits["train"], dataset) if train_on_normal_only else splits["train"]
    train_for_scaler = _normal_training_fraction(train_for_scaler, dataset)
    scaler = Standardizer.fit(train_for_scaler[feature_columns].to_numpy(dtype=np.float32))
    train_source = splits["train"]
    return PreparedData(
        train=make_windows(
            train_source,
            feature_columns,
            dataset,
            scaler,
            oracle_columns,
            stride_override=int(
                dataset["windows"].get(
                    "train_stride", dataset["windows"].get("stride", 1)
                )
            ),
            allowed_row_ids=(
                set(train_for_scaler[dataset["catalog"][0]["key_column"]])
                if train_on_normal_only else None
            ),
        ),
        val=make_windows(
            splits["val"],
            feature_columns,
            dataset,
            scaler,
            oracle_columns,
            stride_override=int(
                dataset["windows"].get(
                    "evaluation_stride", dataset["windows"].get("stride", 1)
                )
            ),
        ),
        test=make_windows(
            splits["test"],
            feature_columns,
            dataset,
            scaler,
            oracle_columns,
            stride_override=int(
                dataset["windows"].get(
                    "evaluation_stride", dataset["windows"].get("stride", 1)
                )
            ),
        ),
        scaler=scaler,
        feature_columns=feature_columns,
        oracle_columns=oracle_columns,
        dataset_config=dataset,
        reports=reports,
    )


def catalog_summary(config: dict[str, Any]) -> dict[str, Any]:
    dataset = active_dataset_config(config)
    frame, reports = load_catalog(config)
    frame = filter_dataset_rows(frame, dataset)
    features = infer_feature_columns(frame, dataset)
    return {
        "dataset": dataset["name"],
        "rows": int(len(frame)),
        "columns": [str(c) for c in frame.columns],
        "feature_columns": features,
        "oracle_columns": infer_oracle_columns(frame, dataset),
        "tables": [report.__dict__ for report in reports],
    }


def feature_columns_from_metadata(config: dict[str, Any]) -> list[str] | None:
    """Load declared/prepared feature names without reading the full dataset."""

    dataset = active_dataset_config(config)
    configured = [str(column) for column in dataset.get("feature_columns") or []]
    if configured:
        return configured
    prepared_dir = (dataset.get("source") or {}).get("prepared_dir")
    if not prepared_dir:
        return None
    feature_path = expand_path(prepared_dir, config["_project_root"]) / "feature_columns.txt"
    if not feature_path.exists():
        return None
    features = [
        line.strip()
        for line in feature_path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]
    if not features:
        raise ConfigError(f"Prepared feature list is empty: {feature_path}")
    feature_entries = [entry for entry in dataset["catalog"] if entry.get("role") == "features"]
    available: set[str] = set()
    for entry in feature_entries:
        path = expand_path(entry["path"], config["_project_root"])
        available.update(str(column) for column in pd.read_csv(path, nrows=0).columns)
    missing = [column for column in features if column not in available]
    if missing:
        raise ConfigError(
            f"Prepared feature list contains columns missing from feature tables: {missing[:10]}"
        )
    return features


def evaluation_readiness_summary(
    config: dict[str, Any],
    *,
    required_fault_splits: tuple[str, ...] = ("val", "test"),
    chunksize: int = 250_000,
) -> dict[str, Any]:
    """Check diagnosis split composition from the label table in chunks."""

    dataset = active_dataset_config(config)
    label_entries = [entry for entry in dataset["catalog"] if entry.get("role") == "labels"]
    if len(label_entries) != 1:
        raise ConfigError("Evaluation readiness requires exactly one labels table")
    entry = label_entries[0]
    path = expand_path(entry["path"], config["_project_root"])
    header = [str(column) for column in pd.read_csv(path, nrows=0).columns]
    target = dataset.get("target_column")
    root_cause = dataset.get("root_cause_column")
    split_column = dataset.get("split", {}).get("column") or dataset.get("split_column")
    for name, column in (
        ("target_column", target),
        ("root_cause_column", root_cause),
        ("split column", split_column),
    ):
        if not column or column not in header:
            raise ConfigError(f"Evaluation readiness requires {name} in the labels table")
    case_column = next(
        (
            column for column in ("scenario_id", dataset.get("group_column"), entry.get("key_column"))
            if column and column in header
        ),
        None,
    )
    usecols = [str(target), str(root_cause), str(split_column)]
    if case_column:
        usecols.append(str(case_column))
    if "scenario_category" in header:
        usecols.append("scenario_category")
    configured_dtypes = entry.get("dtypes") or {}
    dtypes = {key: value for key, value in configured_dtypes.items() if key in usecols}
    normal_labels = set(dataset.get("normal_labels") or [])
    if not normal_labels:
        raise ConfigError("Evaluation readiness requires non-empty normal_labels")
    rows: dict[str, dict[str, Any]] = {
        split: {
            "rows": 0,
            "normal_rows": 0,
            "fault_rows": 0,
            "fault_rows_with_root_cause": 0,
            "fault_case_count": 0,
        }
        for split in ("train", "val", "test")
    }
    fault_cases: dict[str, set[str]] = {split: set() for split in rows}
    for chunk in pd.read_csv(
        path,
        usecols=usecols,
        dtype=dtypes or None,
        chunksize=chunksize,
    ):
        split_values = chunk[str(split_column)].astype(str)
        normal_mask = chunk[str(target)].isin(normal_labels)
        root_present = (
            chunk[str(root_cause)].notna()
            & chunk[str(root_cause)].astype(str).str.strip().ne("")
        )
        for split in rows:
            in_split = split_values.eq(split)
            fault_mask = in_split & ~normal_mask
            rows[split]["rows"] += int(in_split.sum())
            rows[split]["normal_rows"] += int((in_split & normal_mask).sum())
            rows[split]["fault_rows"] += int(fault_mask.sum())
            rows[split]["fault_rows_with_root_cause"] += int((fault_mask & root_present).sum())
            if case_column:
                fault_cases[split].update(
                    str(value)
                    for value in chunk.loc[fault_mask & root_present, str(case_column)].dropna().unique()
                )
    for split in rows:
        rows[split]["fault_case_count"] = len(fault_cases[split])
    errors: list[str] = []
    configured_evaluation_splits = set(
        str(split) for split in config.get("diagnosis", {}).get("evaluation_splits", ["test"])
    )
    missing_evaluation_splits = set(required_fault_splits).difference(configured_evaluation_splits)
    if missing_evaluation_splits:
        errors.append(
            "diagnosis.evaluation_splits is missing "
            + ", ".join(sorted(missing_evaluation_splits))
        )
    if rows["train"]["normal_rows"] == 0:
        errors.append("train has no normal rows")
    if rows["val"]["normal_rows"] == 0:
        errors.append("val has no normal rows for early stopping/threshold calibration")
    for split in required_fault_splits:
        if split not in rows:
            errors.append(f"unknown required fault split '{split}'")
            continue
        if rows[split]["fault_rows"] == 0:
            errors.append(f"{split} has no fault rows")
        elif rows[split]["fault_rows_with_root_cause"] == 0:
            errors.append(f"{split} fault rows have no root-cause labels")
        if case_column and rows[split]["fault_case_count"] == 0:
            errors.append(f"{split} has no labeled fault cases")
    summary = {
        "dataset": dataset["name"],
        "labels_path": str(path),
        "case_column": case_column,
        "required_fault_splits": list(required_fault_splits),
        "configured_evaluation_splits": sorted(configured_evaluation_splits),
        "splits": rows,
        "ready": not errors,
        "errors": errors,
    }
    if errors:
        raise ConfigError(
            "Dataset is not ready for diagnosis model selection: "
            + "; ".join(errors)
            + ". Re-run HAI-CPPS preparation with the current software so fault scenarios "
            "are split between validation and test."
        )
    return summary


def create_sample_dataset(output_dir: str | Path, rows_per_run: int = 90, runs: int = 6, seed: int = 11) -> None:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    measurements_path = output / "measurements.csv"
    labels_path = output / "labels.csv"
    with measurements_path.open("w", newline="", encoding="utf-8") as m_handle, labels_path.open(
        "w", newline="", encoding="utf-8"
    ) as l_handle:
        m_writer = csv.DictWriter(
            m_handle,
            fieldnames=[
                "row_id",
                "timestamp",
                "run_id",
                "feed_flow",
                "tank_level",
                "reactor_temp",
                "motor_current",
                "conveyor_speed",
                "quality_score",
            ],
        )
        l_writer = csv.DictWriter(
            l_handle,
            fieldnames=["row_id", "fault_label", "root_cause_module", "root_cause_feature"],
        )
        m_writer.writeheader()
        l_writer.writeheader()
        row_id = 0
        for run in range(runs):
            fault_module = "drive_transport" if run == runs - 1 else ""
            fault_start = rows_per_run // 2 if fault_module else None
            for t in range(rows_per_run):
                phase = (t / rows_per_run) * 2.0 * np.pi
                feed_flow = 10.0 + 0.4 * np.sin(phase) + rng.normal(0, 0.05)
                tank_level = 50.0 + 0.3 * feed_flow + 0.8 * np.sin(phase / 2.0) + rng.normal(0, 0.08)
                reactor_temp = 65.0 + 0.06 * tank_level + rng.normal(0, 0.06)
                motor_current = 4.0 + 0.03 * tank_level + rng.normal(0, 0.04)
                conveyor_speed = 1.2 + 0.08 * motor_current + rng.normal(0, 0.02)
                quality_score = 90.0 - 0.2 * abs(reactor_temp - 68.0) + 1.5 * conveyor_speed + rng.normal(0, 0.1)
                label = "normal"
                root_feature = ""
                if fault_start is not None and t >= fault_start:
                    motor_current += 1.2 + 0.025 * (t - fault_start)
                    conveyor_speed -= 0.25
                    quality_score -= 2.5 + 0.03 * (t - fault_start)
                    label = "fault"
                    root_feature = "motor_current"
                m_writer.writerow(
                    {
                        "row_id": row_id,
                        "timestamp": t,
                        "run_id": f"run_{run}",
                        "feed_flow": f"{feed_flow:.6f}",
                        "tank_level": f"{tank_level:.6f}",
                        "reactor_temp": f"{reactor_temp:.6f}",
                        "motor_current": f"{motor_current:.6f}",
                        "conveyor_speed": f"{conveyor_speed:.6f}",
                        "quality_score": f"{quality_score:.6f}",
                    }
                )
                l_writer.writerow(
                    {
                        "row_id": row_id,
                        "fault_label": label,
                        "root_cause_module": fault_module,
                        "root_cause_feature": root_feature,
                    }
                )
                row_id += 1
