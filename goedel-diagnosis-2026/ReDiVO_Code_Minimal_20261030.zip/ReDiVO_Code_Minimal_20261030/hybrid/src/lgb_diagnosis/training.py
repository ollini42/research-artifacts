"""V18 training, range calibration, root-cause diagnosis, and evaluation."""

from __future__ import annotations

import copy
import fnmatch
import json
import logging
import time
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader

from .config import ConfigError, ONE_STEP_ALGORITHM, RECURSIVE_ALGORITHM, expand_path
from .data import PreparedData, TimeSeriesWindowDataset, WindowBundle, _window_storage, prepare_data
from .knowledge import (
    RuleSpec,
    SystemKnowledge,
    VirtualFaultSensorSpec,
    load_system_knowledge,
    module_signal_indices,
    render_knowledge_text,
)
from .metrics import (
    anomaly_metrics,
    root_cause_case_outcomes,
    root_cause_ranking_metrics,
    unconditional_root_cause_metrics,
)
from .model import build_model
from .godel_trajectory import predicate_trajectories, trajectory_rule_loss
from .reconstructed_variables import (
    augmented_final_targets_numpy,
    diagnostic_state_columns,
    fit_reconstructed_variable_scaling,
    reconstructed_variable_targets_numpy,
    reconstructed_variable_targets_torch,
)
from .structured_training import (
    dependency_matched_ridge_metrics,
    fit_dependency_matched_ridge,
    is_structured_observer,
    structured_target_balanced_losses,
)
from .structured_observer import build_diagnostic_target_specs
from .utils import ensure_dir, select_device, set_seed, system_info, write_json

LOGGER = logging.getLogger(__name__)

# A single threshold crossing is an explicit negative control, not the
# operational diagnosis default. Three consecutive exceedances suppress
# isolated normal-noise spikes without consulting fault-onset labels.
DEFAULT_ONSET_PERSISTENCE = 3


def _gradient_l2_norm(
    objective: torch.Tensor,
    parameters: list[nn.Parameter],
    *,
    retain_graph: bool,
) -> float:
    """Measure an objective's gradient norm without changing optimizer state."""

    if not objective.requires_grad:
        return 0.0
    gradients = torch.autograd.grad(
        objective,
        parameters,
        retain_graph=retain_graph,
        allow_unused=True,
    )
    squared = objective.new_zeros(())
    for gradient in gradients:
        if gradient is not None:
            squared = squared + torch.sum(gradient.detach() ** 2)
    return float(torch.sqrt(squared).cpu())


def detector_threshold_protocol(method_version: str) -> dict[str, Any]:
    """Return the machine-readable V18 detector protocol."""

    corrected = str(method_version).lower().startswith("v18_")
    if not corrected:
        raise ConfigError("Only V18 detector records are accepted")
    from .observed_commands import METHOD as COMMAND_METHOD
    if str(method_version) == COMMAND_METHOD:
        return {
            "name": "recorded_commands_direct_normal_residual_persistent_threshold_v1",
            "positive_fault_sensor_floor_enforced": True,
            "radii_subtracted": False,
            "paper_evidence_status": "isolated_revision_not_C055",
        }
    return {
        "name": "v18_range_gap_persistent_component_fault_threshold",
        "positive_fault_sensor_floor_enforced": True,
        "paper_evidence_status": "current_v18_method",
    }


@dataclass(frozen=True)
class ObservationMaskSpec:
    masked_indices: tuple[int, ...]
    masked_feature_columns: tuple[str, ...]
    loss_on_masked_features: bool
    apply_to_validation: bool

    @property
    def enabled(self) -> bool:
        return bool(self.masked_indices)

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "masked_feature_count": len(self.masked_indices),
            "masked_feature_columns": list(self.masked_feature_columns),
            "loss_on_masked_features": self.loss_on_masked_features,
            "apply_to_validation": self.apply_to_validation,
        }


@dataclass(frozen=True)
class ObserverResidualResult:
    """Outputs of a fixed-observation diagnostic trajectory protocol.

    V18 names the evidence-conditioned trajectory ``p_real`` and the
    measurement-free open-loop normal trajectory ``p_nominal``.
    """

    residuals: np.ndarray
    p_real: np.ndarray
    p_nominal: np.ndarray
    raw_residuals: np.ndarray | None = None
    state_columns: tuple[str, ...] = ()
    filter_affine: np.ndarray | None = None
    filter_nonlinear_residual: np.ndarray | None = None
    filter_target_names: tuple[str, ...] = ()
    horizon_raw_residuals: np.ndarray | None = None
    p_real_horizons: np.ndarray | None = None
    p_nominal_horizons: np.ndarray | None = None
    delta_t_steps: int = 1
    boundary_index: int = -1


@dataclass(frozen=True)
class DiagnosisTimeAxis:
    """Validated physical time base for one diagnosis episode."""

    seconds: np.ndarray
    source: str
    input_unit: str
    raw_sample_period_seconds: float
    evaluation_stride_samples: int
    expected_evaluation_period_seconds: float
    time_axis_validated: bool
    sensor_synchronization_supplied: bool
    timestamp_synchronized: bool
    gap_policy: str

def _make_loader(bundle: WindowBundle, batch_size: int, shuffle: bool, num_workers: int,
                 *, pin_memory: bool = False) -> DataLoader:
    return DataLoader(
        TimeSeriesWindowDataset(bundle),
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=pin_memory,
        drop_last=False,
    )


def build_observation_mask(feature_columns: list[str], config: dict[str, Any]) -> ObservationMaskSpec:
    """Select fixed feature columns to hide as physically unavailable.

    This implements the paper's observation-mask idea at column level. The
    selected columns are never passed as Dataset inputs during training. For
    fixed-observer experiments they remain supervised targets because the
    complete benchmark data emulate removing sensors from an otherwise
    recorded system; they are never exposed to the inference input.
    """

    training_cfg = config.get("training", {})
    mask_cfg = training_cfg.get("partial_observation") or {}
    explicit_columns = [str(column) for column in mask_cfg.get("masked_feature_columns", [])]
    count = int(mask_cfg.get("masked_feature_count", 0) or 0)
    if count < 0:
        raise ConfigError("training.partial_observation.masked_feature_count must be non-negative")
    missing = [column for column in explicit_columns if column not in feature_columns]
    if missing:
        raise ConfigError(f"Configured masked_feature_columns are not feature columns: {missing}")
    selected: list[str] = list(dict.fromkeys(explicit_columns))
    remaining = [column for column in feature_columns if column not in selected]
    if count > len(remaining):
        raise ConfigError(
            "training.partial_observation.masked_feature_count is larger than the number of "
            f"available unmasked feature columns ({len(remaining)})"
        )
    if count:
        seed = int(mask_cfg.get("seed", training_cfg.get("seed", 42)))
        rng = np.random.default_rng(seed)
        sampled = rng.choice(np.asarray(remaining, dtype=object), size=count, replace=False).tolist()
        selected.extend(str(column) for column in sampled)
    if len(selected) >= len(feature_columns) and feature_columns:
        raise ConfigError("Partial observation cannot mask all feature columns")
    index_by_feature = {feature: idx for idx, feature in enumerate(feature_columns)}
    selected = sorted(selected, key=lambda column: index_by_feature[column])
    indices = tuple(index_by_feature[column] for column in selected)
    return ObservationMaskSpec(
        masked_indices=indices,
        masked_feature_columns=tuple(selected),
        loss_on_masked_features=bool(mask_cfg.get("loss_on_masked_features", False)),
        apply_to_validation=bool(mask_cfg.get("apply_to_validation", True)),
    )


def _bundle_group_indices(bundle: WindowBundle) -> dict[Any, list[int]]:
    """Index episodes in one pass, preserving first occurrence and row order."""

    groups: dict[Any, list[int]] = {}
    for index, group in enumerate(bundle.groups):
        groups.setdefault(group, []).append(index)
    return groups


def _limit_bundle_contiguous_tail(
    bundle: WindowBundle, max_windows: int | None
) -> WindowBundle:
    """Limit normal calibration data without inventing temporal adjacency."""

    if max_windows is None or int(max_windows) >= len(bundle.row_ids):
        return bundle
    limit = int(max_windows)
    if limit < 1:
        raise ConfigError("A calibration window limit must be positive")
    groups = list(dict.fromkeys(bundle.groups))
    if limit < len(groups):
        raise ConfigError(
            f"A limit of {limit} cannot retain every one of {len(groups)} cases"
        )
    indices_by_group = _bundle_group_indices(bundle)
    base, remainder = divmod(limit, len(groups))
    selected: list[int] = []
    for group_index, group in enumerate(groups):
        candidates = indices_by_group[group]
        quota = min(len(candidates), base + int(group_index < remainder))
        selected.extend(candidates[-quota:])
    return _select_bundle(bundle, sorted(selected))


def _diagnosis_bundle(
    bundle: WindowBundle,
    config: dict[str, Any],
    normal_labels: list[Any],
) -> WindowBundle:
    """Keep complete, predeclared episodes without consulting fault labels."""

    selection = config.get("diagnosis", {}).get("window_selection") or {}
    mode = str(selection.get("mode", "full_case")).lower()
    max_windows = int(config.get("diagnosis", {}).get("max_diagnosis_windows", 0)) or None
    if mode != "full_case":
        raise ConfigError(
            "Diagnosis requires full_case. Fault labels may only be used for evaluation"
        )
    if max_windows is not None:
        raise ConfigError("V18 full-case diagnosis forbids max_diagnosis_windows")
    return bundle


def _select_bundle(bundle: WindowBundle, indices: list[int]) -> WindowBundle:
    return WindowBundle(
        windows=bundle.windows[indices],
        targets=bundle.targets[indices],
        row_ids=[bundle.row_ids[idx] for idx in indices],
        groups=[bundle.groups[idx] for idx in indices],
        times=[bundle.times[idx] for idx in indices],
        labels=[bundle.labels[idx] for idx in indices] if bundle.labels is not None else None,
        root_causes=[bundle.root_causes[idx] for idx in indices] if bundle.root_causes is not None else None,
        metadata={
            key: [values[idx] for idx in indices]
            for key, values in (bundle.metadata or {}).items()
        },
        oracle_windows=(
            bundle.oracle_windows[indices] if bundle.oracle_windows is not None else None
        ),
        oracle_columns=list(bundle.oracle_columns),
    )


def _normal_only_bundle(bundle: WindowBundle, normal_labels: list[Any]) -> WindowBundle:
    """Return windows with normal endpoints and entirely normal raw history.

    HAI-CPPS validation splits may contain held-out fault scenarios for
    hyperparameter selection. Early stopping and residual-threshold
    calibration must still use normal validation behavior only.
    """

    if bundle.labels is None or not normal_labels:
        return bundle
    all_normal = (bundle.metadata or {}).get("window_all_normal")
    if all_normal is not None and (
        len(all_normal) != len(bundle.labels)
        or any(not isinstance(value, (bool, np.bool_)) for value in all_normal)
    ):
        raise ConfigError("window_all_normal must contain one boolean per window")
    indices = [idx for idx, label in enumerate(bundle.labels)
               if label in normal_labels and (all_normal is None or all_normal[idx])]
    if not indices:
        raise ConfigError("Validation split contains no normal windows for early stopping and threshold calibration")
    return _select_bundle(bundle, indices)


def _apply_random_mask(
    windows: torch.Tensor,
    probability: float,
    observation_mask: ObservationMaskSpec | None = None,
) -> tuple[torch.Tensor, torch.Tensor]:
    mask = torch.ones_like(windows)
    values = windows.clone()
    if observation_mask and observation_mask.masked_indices:
        indices = torch.as_tensor(observation_mask.masked_indices, dtype=torch.long, device=windows.device)
        mask.index_fill_(-1, indices, 0.0)
        values.index_fill_(-1, indices, 0.0)
    if probability > 0.0:
        dropped = torch.rand_like(windows) < probability
        mask[dropped] = 0.0
        values[dropped] = 0.0
    return values, mask


def _reconstruction_loss(
    reconstruction: torch.Tensor,
    targets: torch.Tensor,
    observation_mask: ObservationMaskSpec | None,
) -> torch.Tensor:
    if not observation_mask or not observation_mask.masked_indices or observation_mask.loss_on_masked_features:
        return nn.functional.mse_loss(reconstruction, targets)
    feature_weights = torch.ones(targets.shape[-1], dtype=targets.dtype, device=targets.device)
    indices = torch.as_tensor(observation_mask.masked_indices, dtype=torch.long, device=targets.device)
    feature_weights.index_fill_(0, indices, 0.0)
    squared = (reconstruction - targets) ** 2
    return (squared * feature_weights.view(1, -1)).sum() / torch.clamp(
        feature_weights.sum() * targets.shape[0],
        min=1.0,
    )


def _predicate_tau_from_reconstruction_error(
    reconstruction: torch.Tensor,
    targets: torch.Tensor,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    scale: float,
    windows: torch.Tensor | None = None,
    reconstructed_estimate: torch.Tensor | None = None,
    reconstructed_targets: torch.Tensor | None = None,
    reconstructed_windows: torch.Tensor | None = None,
    feature_scaling: dict[str, list[float]] | None = None,
) -> torch.Tensor:
    """Snapshot adapter for explicit completed-history predicate checks.

    Active training uses full real/nominal trajectories instead. This helper
    requires the complete historical window for every temporal predicate.
    """
    estimate, expected = reconstruction, targets
    history = windows
    if reconstructed_estimate is not None:
        if reconstructed_targets is None:
            raise ConfigError("Reconstructed predicate values need normal references")
        estimate = torch.cat([estimate, reconstructed_estimate], -1)
        expected = torch.cat([expected, reconstructed_targets], -1)
        if windows is not None:
            if reconstructed_windows is None:
                raise ConfigError("Reconstructed predicate history is required")
            history = torch.cat([windows, reconstructed_windows], -1)
    sequence = estimate[:, None, :] if history is None else torch.cat(
        [history[:, :-1, :], estimate[:, None, :]], 1
    )
    references = expected[:, None, :].expand_as(sequence)
    mean = std = None
    if feature_scaling:
        mean = estimate.new_tensor(feature_scaling["feature_mean"] + feature_scaling.get("reconstructed_mean", []))
        std = estimate.new_tensor(feature_scaling["feature_std"] + feature_scaling.get("reconstructed_std", []))
    result = predicate_trajectories(
        sequence, references, knowledge,
        list(feature_columns) + knowledge.reconstructed_variable_names,
        scale, mean=mean, std=std,
    )
    # Insufficient history must not be reported as satisfied evidence.
    for i, p in enumerate(knowledge.predicates):
        lag = max(p.lag_steps, p.min_lag_steps, p.max_lag_steps)
        temporal = p.kind in {"co_increase", "inverse_change", "delayed_follow", "pressure_level_compatible", "state_level_direction"}
        if temporal and sequence.shape[1] < lag + 2:
            raise ConfigError(f"Insufficient history for predicate {p.name}")
    return result.truth[:, -1, :]


def _rule_diagnostics_for_residuals(
    residuals: np.ndarray,
    thresholds: np.ndarray,
    bundle: WindowBundle,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    config: dict[str, Any],
    *,
    include_rules: bool = False,
    rules: list[RuleSpec] | None = None,
    windows: np.ndarray | None = None,
    targets: np.ndarray | None = None,
    observation_mask: ObservationMaskSpec | None = None,
) -> dict[str, Any]:
    # A scalar diagnosis residual does not contain the completed trajectories
    # needed for a signed or delayed relation. Do not manufacture truth from
    # absolute residuals. The training audit evaluates actual trajectories.
    return {
        "status": "not_evaluated_from_diagnostic_residuals",
        "reason": "K_train truth requires completed real/nominal trajectories and normal applicability",
        "rule_count": len(knowledge.rules if rules is None else rules),
        "group_count": 0,
        "groups": {},
        "rules": {},
    }


def _logic_history_summary(history: list[dict[str, Any]]) -> dict[str, Any]:
    if not history:
        return {}

    def _logic_values(metrics: dict[str, Any]) -> dict[str, float]:
        return {
            key: float(value)
            for key, value in metrics.items()
            if key == "logic_loss"
            or key.startswith("logic_loss_group_")
            or key.startswith("logic_parameter_gradient_norm::")
            or key.startswith("logic_rule_parameter_gradient_norm::")
            or key
            in {
                "base_gradient_norm",
                "logic_gradient_norm",
                "weighted_logic_gradient_norm",
                "effective_logic_gradient_fraction",
                "logic_weighted_loss_fraction",
                "logic_gradient_audited_batches",
            }
        }

    first = history[0]
    last = history[-1]
    return {
        "max_audited_training": {
            key: max(float(row["train"].get(key, 0.0)) for row in history)
            for key in {key for row in history for key in _logic_values(row["train"])}
        },
        "first_epoch": {
            "epoch": float(first["epoch"]),
            "train": _logic_values(first["train"]),
            "val": _logic_values(first["val"]),
        },
        "last_epoch": {
            "epoch": float(last["epoch"]),
            "train": _logic_values(last["train"]),
            "val": _logic_values(last["val"]),
        },
    }


def _knowledge_prior_summary(knowledge: SystemKnowledge, config: dict[str, Any]) -> dict[str, Any]:
    predicate_counts: dict[str, int] = {}
    rule_counts: dict[str, int] = {}
    rule_weight_sums: dict[str, float] = {}
    for predicate in knowledge.predicates:
        group = str(getattr(predicate, "group", "module_nominality") or "module_nominality")
        predicate_counts[group] = predicate_counts.get(group, 0) + 1
    for rule in knowledge.rules:
        group = str(getattr(rule, "group", "module_nominality") or "module_nominality")
        rule_counts[group] = rule_counts.get(group, 0) + 1
        rule_weight_sums[group] = rule_weight_sums.get(group, 0.0) + float(rule.weight)
    prior_cfg = (config.get("knowledge") or {}).get("prior_knowledge") or {}
    effective_selection = None
    if (config.get("knowledge") or {}).get("builder") == "tep_reinartz":
        from .dataset_knowledge import _prior_knowledge_config
        effective_selection = _prior_knowledge_config(config)["_selection"]
    return {
        "effective_prior_selection": effective_selection,
        "supplied_prior_is_not_a_detectability_or_fault_preservation_certificate": True,
        "variant": str(prior_cfg.get("variant", "module_nominality")),
        "control": str(prior_cfg.get("control", "correct")),
        "supplied_connection_count": float(len(knowledge.connections)),
        "reconstructed_variable_variable_count": float(len(knowledge.reconstructed_variables)),
        "reconstructed_variable_variables": [
            {
                "name": variable.name,
                "module": variable.module,
                "kind": variable.kind,
                "inputs": list(variable.inputs),
                "function": variable.function,
                "lag_steps": float(variable.lag_steps),
                "source": variable.source,
            }
            for variable in knowledge.reconstructed_variables
        ],
        "predicate_counts_by_group": {key: float(value) for key, value in sorted(predicate_counts.items())},
        "rule_counts_by_group": {key: float(value) for key, value in sorted(rule_counts.items())},
        "rule_weight_sums_by_group": {key: float(value) for key, value in sorted(rule_weight_sums.items())},
        "logic_group_weights": {
            str(group): float(weight)
            for group, weight in (config.get("training", {}).get("logic_group_weights") or {}).items()
        },
        "example_connections": [
            {
                "source_module": connection.source_module,
                "source_signal": connection.source_signal,
                "target_module": connection.target_module,
                "target_signal": connection.target_signal,
                "relation": connection.relation,
                "min_latency_steps": float(connection.min_latency_steps),
                "max_latency_steps": float(connection.max_latency_steps),
                "influence_sign": float(connection.influence_sign),
                "operating_condition": connection.operating_condition,
                "operating_condition_signals": list(
                    connection.operating_condition_signals
                ),
                "provenance": connection.provenance,
            }
            for connection in knowledge.connections[:25]
        ],
    }



_TRAINING_RULE_GROUPS = (
    "latent_structure",
    "topology_compatibility",
    "qualitative_relation",
    "latency_relation",
    "physical_flow",
    "mode_exclusivity",
    "state_dynamics",
    "sensor_physics",
)
_DEFAULT_TRAINING_RULE_GROUPS = (
    "supervised_target_fit",
    "topology_compatibility",
    "qualitative_relation",
    "latency_relation",
)


def _diagnosis_scoring_protocol(config: dict[str, Any]) -> str:
    return str(
        config.get("diagnosis", {}).get("scoring_protocol", "fixed_observer")
        or "fixed_observer"
    ).lower()


def _fixed_observer_enabled(config: dict[str, Any]) -> bool:
    return _diagnosis_scoring_protocol(config) == "fixed_observer"


def _validate_fixed_observer_configuration(
    config: dict[str, Any],
    observation_mask: ObservationMaskSpec,
    knowledge: SystemKnowledge | None = None,
) -> None:
    if not _fixed_observer_enabled(config):
        return
    random_probability = float(config.get("training", {}).get("random_feature_mask_probability", 0.0))
    if random_probability != 0.0:
        raise ConfigError(
            "fixed_observer requires training.random_feature_mask_probability = 0.0; "
            "one model represents exactly one observation configuration X"
        )
    if not observation_mask.apply_to_validation:
        raise ConfigError(
            "fixed_observer requires training.partial_observation.apply_to_validation = true "
            "so training, validation, and diagnosis use the same X"
        )
    if observation_mask.enabled and not observation_mask.loss_on_masked_features:
        raise ConfigError(
            "fixed_observer requires training.partial_observation.loss_on_masked_features = true "
            "when X is non-empty, because virtual targets require supervised normal targets"
        )
    if int(config.get("datasets", {}).get(config.get("active_dataset", ""), {}).get("windows", {}).get("window_size", 0)) < 2:
        raise ConfigError("fixed_observer requires a window_size of at least 2 for open-loop prediction")
    range_cfg = config.get("diagnosis", {}).get("value_ranges") or {}
    if bool(range_cfg.get("enabled", False)):
        quantile = float(range_cfg.get("quantile", 0.99))
        if not 0.0 < quantile < 1.0:
            raise ConfigError(
                "diagnosis.value_ranges.quantile must lie in (0, 1)"
            )
        if float(range_cfg.get("min_radius", 0.0)) < 0.0:
            raise ConfigError(
                "diagnosis.value_ranges.min_radius must be non-negative"
            )
    representation = str(
        config.get("diagnosis", {}).get("symptom_representation", "godel_truth")
    ).lower()
    if representation in {"godel_truth", "godel", "truth"}:
        threshold = float(config.get("diagnosis", {}).get("symptom_threshold", 0.5))
        if not 0.0 <= threshold < 1.0:
            raise ConfigError("fixed_observer Gödel symptom_threshold must lie in [0, 1)")
    if knowledge is not None:
        window_size = int(
            config["datasets"][config["active_dataset"]]["windows"]["window_size"]
        )
        # Response admissibility constrains diagnosis, not the one-step
        # fitting target. Every proposed diagnostic horizon must pass.
        candidates = config.get("diagnosis", {}).get("nominal_real_trajectory", {}).get("delta_t", {}).get("candidates", [])
        if (not candidates or any(type(value) is not int or not 1 <= value < window_size
                                  for value in candidates)):
            raise ConfigError("Invalid diagnostic horizon candidates")
        delta_t_steps = min(candidates)
        required_horizon = max(
            (
                int(sensor.response_horizon_steps)
                for sensor in active_virtual_fault_sensors(knowledge, config)
            ),
            default=0,
        )
        if delta_t_steps <= required_horizon:
            raise ConfigError(
                "delta_t must exceed the largest supplied fault-sensor response "
                f"horizon ({required_horizon} samples)"
            )


def _rule_group(rule: RuleSpec) -> str:
    return str(getattr(rule, "group", "module_nominality") or "module_nominality")


def _explicit_rule_roles_enabled(config: dict[str, Any]) -> bool:
    architecture = str((config.get("model") or {}).get("architecture", "")).lower()
    method = str((config.get("diagnosis") or {}).get("method_identifier", "")).lower()
    return architecture == "structured_predict_update_v18" or method.startswith("v18_")


def _configured_rule_groups(config: dict[str, Any], key: str, default: tuple[str, ...]) -> list[str]:
    partition = config.get("diagnosis", {}).get("rule_partition") or {}
    value = partition.get(key, None)
    if value is None:
        return list(default)
    if not isinstance(value, list):
        raise ConfigError(f"diagnosis.rule_partition.{key} must be a list of rule-group names")
    return [str(item) for item in value]


def _select_rules_by_groups(knowledge: SystemKnowledge, groups: list[str]) -> list[RuleSpec]:
    allowed = set(groups)
    return [rule for rule in knowledge.rules if _rule_group(rule) in allowed]


def _rule_predicate_names(rule: RuleSpec) -> list[str]:
    names: list[str] = []
    if rule.predicate:
        names.append(rule.predicate)
    names.extend(rule.predicates)
    if rule.antecedent:
        names.append(rule.antecedent)
    if rule.consequent:
        names.append(rule.consequent)
    return names


def _rule_signal_names(rule: RuleSpec, knowledge: SystemKnowledge) -> set[str]:
    predicate_by_name = {predicate.name: predicate for predicate in knowledge.predicates}
    signals: set[str] = set()
    for name in _rule_predicate_names(rule):
        predicate = predicate_by_name.get(name)
        if predicate is None:
            continue
        for value in (predicate.signal, predicate.source, predicate.target):
            if value:
                signals.add(str(value))
        signals.update(str(value) for value in predicate.signals if value)
    return signals


def _scope_training_rules(
    rules: list[RuleSpec], knowledge: SystemKnowledge, config: dict[str, Any]
) -> list[RuleSpec]:
    scope = str(config.get("training", {}).get("logic_rule_scope", "all")).lower()
    if scope == "all":
        return rules
    if scope != "masked_predicates":
        raise ConfigError("training.logic_rule_scope must be 'all' or 'masked_predicates'")
    partial = config.get("training", {}).get("partial_observation") or {}
    masked = {str(name) for name in (partial.get("masked_feature_columns") or [])}
    if not masked:
        return []
    return [rule for rule in rules if _rule_signal_names(rule, knowledge).intersection(masked)]


def _training_regularization_rules(
    knowledge: SystemKnowledge,
    config: dict[str, Any],
) -> list[RuleSpec]:
    """Return the complete fault-preserving training rule base K_train."""

    if not bool(((config.get("knowledge") or {}).get("godel") or {}).get("enabled", True)):
        return []
    groups = _configured_rule_groups(
        config, "training_groups", _DEFAULT_TRAINING_RULE_GROUPS
    )
    rules = [
        rule
        for rule in _select_rules_by_groups(knowledge, groups)
        if rule.role == "training" and rule.fault_preserving
    ]
    return _scope_training_rules(rules, knowledge, config)


def _validate_rule_partition(knowledge: SystemKnowledge, config: dict[str, Any]) -> None:
    """Fail unless every active rule belongs exclusively to K_train."""

    invalid = sorted(
        rule.name
        for rule in knowledge.rules
        if rule.role != "training" or not rule.fault_preserving
    )
    if invalid:
        raise ConfigError(
            "V18 permits only fault-preserving K_train rules. Invalid rules: "
            f"{invalid[:10]}"
        )


def active_virtual_fault_sensors(
    knowledge: SystemKnowledge,
    config: dict[str, Any],
) -> list[VirtualFaultSensorSpec]:
    """Return the complete active component-fault candidate universe.

    Candidate exclusions affect calibration, ranking, exports, and random
    baselines. They are therefore applied to sensors rather than only to true
    evaluation labels.
    """

    exclusions = (config.get("diagnosis") or {}).get(
        "exclude_root_cause_faults", []
    ) or []
    active: list[VirtualFaultSensorSpec] = []
    for sensor in knowledge.virtual_fault_sensors:
        excluded = False
        for item in exclusions:
            if isinstance(item, str):
                excluded = item in {
                    sensor.fault_type,
                    sensor.physical_component,
                    *sensor.covered_fault_modes,
                }
                if excluded:
                    break
                continue
            if not isinstance(item, dict):
                raise ConfigError(
                    "diagnosis.exclude_root_cause_faults entries must be strings or mappings"
                )
            module = str(item.get("module", ""))
            fault = str(item.get("fault", item.get("fault_type", "")))
            component = str(item.get("component", ""))
            module_match = not module or module == sensor.module
            component_match = not component or component == sensor.physical_component
            fault_match = (
                not fault
                or fault == sensor.fault_type
                or fault in sensor.covered_fault_modes
                or f"anom_{fault}" in sensor.covered_fault_modes
            )
            if module_match and component_match and fault_match:
                excluded = True
                break
        if not excluded:
            active.append(sensor)
    return active


def active_root_cause_candidates(
    knowledge: SystemKnowledge,
    config: dict[str, Any],
) -> list[str]:
    return [
        sensor.candidate_id
        for sensor in active_virtual_fault_sensors(knowledge, config)
    ]


def _diagnostic_residuals(
    residuals: np.ndarray,
    observation_mask: ObservationMaskSpec | None,
    config: dict[str, Any],
) -> np.ndarray:
    del observation_mask, config
    # V18 residuals are the gap between current and nominal value ranges.
    return residuals


def _measured_feature_indices(
    feature_columns: list[str],
    observation_mask: ObservationMaskSpec | None,
    config: dict[str, Any],
    knowledge: SystemKnowledge | None = None,
) -> set[int]:
    del config
    masked = set(observation_mask.masked_indices if observation_mask else ())
    reconstructed = set(knowledge.reconstructed_variable_names if knowledge is not None else ())
    return {
        idx
        for idx, name in enumerate(feature_columns)
        if idx not in masked and name not in reconstructed
    }


def _rule_partition_summary(knowledge: SystemKnowledge, config: dict[str, Any]) -> dict[str, Any]:
    training = _training_regularization_rules(knowledge, config)

    def _counts(rules: list[RuleSpec]) -> dict[str, float]:
        counts: dict[str, int] = {}
        for rule in rules:
            group = _rule_group(rule)
            counts[group] = counts.get(group, 0) + 1
        return {key: float(value) for key, value in sorted(counts.items())}

    return {
        "rule_base": "K_train",
        "rule_evaluation_protocol": "completed_real_and_open_loop_nominal_trajectories",
        "logic_branches": list(config.get("training", {}).get("logic_branches", ["real", "nominal"])),
        "reference_targets": "normal_training_only_for_signal_and_residual_geometry_predicates",
        "temporal_history": "completed_trajectory_never_hidden_oracle_history",
        "eligibility": "valid_history_and_condition_and_structural_gradient_path",
        "satisfied_eligible_rules_remain_in_normalizer": True,
        "topology_gradient_reference": "detached_lower_endpoint_error",
        "rule_gradient_audit": "bounded_rotating_rule_subset_with_explicit_counts",
        "online_godel_scoring": False,
        "training_regularization_rule_count": float(len(training)),
        "training_groups": _configured_rule_groups(
            config, "training_groups", _DEFAULT_TRAINING_RULE_GROUPS
        ),
        "logic_rule_scope": str(config.get("training", {}).get("logic_rule_scope", "all")),
        "masked_feature_columns": list(
            (config.get("training", {}).get("partial_observation") or {}).get(
                "masked_feature_columns", []
            )
        ),
        "training_regularization_rule_counts_by_group": _counts(training),
    }


def _training_delta_t_steps(config: dict[str, Any], window_steps: int) -> int:
    """Return the single comparison window used to train this model.

    Every candidate requires its own trained model. Campaign-level selection
    compares their normal-validation objectives and fixes one candidate before
    test reporting. This prevents a model trained for one rollout horizon from
    being evaluated as if it had been trained for another.
    """

    if "mode" in config.get("training", {}):
        from .training_modes import training_mode
        mode = training_mode(config)
        steps = config["training"].get("prediction_steps")
        if type(steps) is not int or not 1 <= steps < window_steps:
            raise ConfigError("Training prediction steps exceed the fitting window")
        if mode == "one_step" and steps != 1:
            raise ConfigError("One-step training requires prediction_steps=1")
        if mode == "recursive" and steps != config["training"].get("recursive_training_steps"):
            raise ConfigError("Recursive training horizon disagrees with prediction_steps")
        return steps
    if config.get("training", {}).get("trajectory_training_protocol") == "one_step_short_history_v1":
        if config["training"].get("prediction_steps", 1) != 1 or window_steps < 2:
            raise ConfigError("One-step training requires prediction_steps=1 and history")
        return 1
    delta = (
        (config.get("diagnosis") or {})
        .get("nominal_real_trajectory", {})
        .get("delta_t", {})
    )
    candidates = [int(value) for value in delta.get("candidates") or []]
    if len(candidates) != 1:
        raise ConfigError(
            "V18 training requires exactly one delta_t candidate per model. "
            "Sweep candidates as separate runs and select by normal validation."
        )
    steps = candidates[0]
    if steps < 1 or steps >= int(window_steps):
        raise ConfigError("delta_t must be positive and smaller than the training window")
    return steps


def _fitting_bundle(bundle: WindowBundle, config: dict[str, Any]) -> WindowBundle:
    """Use short fitting history without changing any diagnostic endpoints."""
    from .observed_commands import METHOD as COMMAND_METHOD
    if ("mode" in config.get("training", {})
            or config.get("diagnosis", {}).get("method_identifier") == COMMAND_METHOD):
        training = config["training"]
        length = int(training["history_steps"]) + int(training["prediction_steps"])
        if not 1 < length <= bundle.windows.shape[1]:
            raise ConfigError("Fitting history and target exceed the available window")
        return replace(bundle, windows=bundle.windows[:, -length:, :],
                       oracle_windows=(None if bundle.oracle_windows is None
                                       else bundle.oracle_windows[:, -length:, :]))
    if config.get("training", {}).get("trajectory_training_protocol") != "one_step_short_history_v1":
        return bundle
    history = config["training"].get("history_steps", 48)
    if type(history) is not int or not 1 <= history < bundle.windows.shape[1]:
        raise ConfigError("One-step history must be positive and shorter than the diagnostic window")
    return replace(bundle, windows=bundle.windows[:, -(history + 1):, :],
                   oracle_windows=(None if bundle.oracle_windows is None
                                   else bundle.oracle_windows[:, -(history + 1):, :]))


def _training_exogenous_indices(
    config: dict[str, Any],
    feature_columns: list[str],
    observation_mask: ObservationMaskSpec | None,
) -> tuple[int, ...]:
    """Validate and resolve fault-safe exogenous inputs for training rollouts."""

    declarations = (
        (config.get("diagnosis") or {})
        .get("nominal_real_trajectory", {})
        .get("exogenous_inputs", [])
        or []
    )
    index = {name: position for position, name in enumerate(feature_columns)}
    masked = set(
        observation_mask.masked_feature_columns if observation_mask else ()
    )
    result: list[int] = []
    for item in declarations:
        if not isinstance(item, dict):
            raise ConfigError("Every exogenous input requires a declaration mapping")
        name = str(item.get("name", ""))
        if name not in index:
            raise ConfigError(f"Unknown exogenous input {name!r}")
        if name in masked:
            raise ConfigError(f"Masked target {name!r} cannot be exogenous")
        if str(item.get("role", "")).lower() not in {"command", "setpoint"}:
            raise ConfigError(f"Exogenous input {name!r} must be a command or setpoint")
        if bool(item.get("fault_revealing", True)):
            raise ConfigError(f"Exogenous input {name!r} may not reveal the fault")
        result.append(index[name])
    return tuple(dict.fromkeys(result))

def _trajectory_training_logic(model, output, trajectory, windows, reconstructed_targets,
                               values, mask, knowledge, feature_columns, config):
    """Use exactly the real completion and open-loop nominal training rollout."""
    cfg = config["training"]
    branch_names = cfg.get("logic_branches", ["real", "nominal"])
    if not branch_names or len(set(branch_names)) != len(branch_names) or set(branch_names) - {"real", "nominal"}:
        raise ConfigError("training.logic_branches must select real and/or nominal exactly once")
    rules = _training_regularization_rules(knowledge, config)
    if not rules:
        return output.posterior_measured.sum() * 0., {}, {}, {}
    used = {n for r in rules for n in [r.predicate, r.antecedent, r.consequent, *r.predicates] if n}
    knowledge = replace(knowledge, predicates=[p for p in knowledge.predicates if p.name in used])
    real = torch.cat([output.posterior_measured, output.posterior_reconstructed], -1)
    start = int(trajectory.boundary_index) + 1
    nominal = torch.cat([real[:, :start, :], trajectory.p_nominal_horizons], 1)
    expected = torch.cat([windows, reconstructed_targets], -1)
    available = torch.cat([mask.bool(), torch.zeros_like(output.posterior_reconstructed, dtype=torch.bool)], -1)
    condition_values = torch.cat([values, torch.zeros_like(output.posterior_reconstructed)], -1)
    real_learned = ~available
    nominal_learned = real_learned.clone()
    nominal_learned[:, start:, :] = True
    for i in _training_exogenous_indices(config, feature_columns, None):
        nominal_learned[:, start:, i] = False
    branches = {}
    for name in branch_names:
        branches[name] = predicate_trajectories(
            real if name == "real" else nominal, expected, knowledge,
            list(feature_columns) + knowledge.reconstructed_variable_names,
            float(cfg.get("logic_residual_scale", 1.0)), start=start,
            learned=real_learned if name == "real" else nominal_learned,
            mean=model.diagnostic_mean, std=model.diagnostic_std,
            condition_values=condition_values, condition_available=available,
        )
    loss, groups, audit, terms = trajectory_rule_loss(
        branches, knowledge, rules,
        float(cfg.get("logic_margin", 0.8)), cfg.get("logic_group_weights"),
        fixed_group_normalizer=cfg.get("logic_fixed_group_normalizer"),
    )
    return loss, groups, audit, terms


def _epoch(
    model: nn.Module,
    loader: DataLoader,
    config: dict[str, Any],
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    device: torch.device,
    optimizer: torch.optim.Optimizer | None,
    observation_mask: ObservationMaskSpec | None = None,
    *,
    progress_state: dict[str, Any] | None = None,
    batch_callback=None,
    audit_timings=None,
) -> dict[str, Any]:
    """Run one V18 epoch with exactly two target-balanced data losses."""

    if not is_structured_observer(model):
        raise ConfigError("V18 supports only the structured observer")
    is_train = optimizer is not None
    model.train(is_train)
    total: dict[str, float] = {
        "loss": 0.0,
        "real_trajectory_loss": 0.0,
        "nominal_trajectory_loss": 0.0,
        "logic_loss": 0.0,
        "base_gradient_norm": 0.0,
        "logic_gradient_norm": 0.0,
        "weighted_logic_gradient_norm": 0.0,
        "effective_logic_gradient_fraction": 0.0,
        "logic_weighted_loss_fraction": 0.0,
    }
    batches = 0
    sample_count = 0
    scalar_keys: set[str] = set()
    scalar_totals: dict[tuple[str, ...], torch.Tensor] = {}
    phase_totals: dict[tuple[str, str], torch.Tensor] = {}
    rule_stat_weights: dict[str, float] = {}
    audited_batches = 0
    gradient_audit_seconds = 0.0
    beta = float(config["training"].get("beta", 0.0))
    lambda_real = float(config["training"].get("lambda_real", 1.0))
    lambda_nominal = float(config["training"].get("lambda_nominal", 1.0))
    if min(beta, lambda_real, lambda_nominal) < 0.0:
        raise ConfigError(
            "training.beta, training.lambda_real, and training.lambda_nominal "
            "must be non-negative"
        )
    margin = float(config["training"].get("logic_margin", 0.8))
    logic_scale = float(config["training"].get("logic_residual_scale", 1.0))
    logic_group_weights = {
        str(group): float(weight)
        for group, weight in (
            config["training"].get("logic_group_weights") or {}
        ).items()
    }
    gradient_cfg = config["training"].get("logic_gradient_audit") or {}
    gradient_enabled = bool(gradient_cfg.get("enabled", False))
    gradient_batches = max(1, int(gradient_cfg.get("batches_per_epoch", 1)))
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]

    if progress_state is not None:
        total = dict(progress_state["total"])
        batches = int(progress_state["completed_batches"])
        sample_count = int(progress_state["sample_count"])
        scalar_keys = set(progress_state["scalar_keys"])
        scalar_totals = {names: value.to(device).clone()
                         for names, value in progress_state["scalar_totals"].items()}
        phase_totals = {names: value.to(device).clone()
                        for names, value in progress_state.get("phase_totals", {}).items()}
        rule_stat_weights = dict(progress_state["rule_stat_weights"])
        audited_batches = int(progress_state["audited_batches"])
        gradient_audit_seconds = float(progress_state["gradient_audit_seconds"])
        model._logic_audit_cursor = int(progress_state["audit_cursor"])

    for windows, _targets, oracle_windows in loader:
        windows = windows.to(device, non_blocking=bool(loader.pin_memory))
        oracle_windows = oracle_windows.to(device, non_blocking=bool(loader.pin_memory))
        values, mask = _apply_random_mask(
            windows,
            0.0,
            observation_mask,
        )
        values = values.to(device)
        mask = mask.to(device)
        with torch.set_grad_enabled(is_train):
            output = model.predict_update_sequence(values, mask)
            reconstructed_targets = reconstructed_variable_targets_torch(
                windows,
                knowledge,
                feature_columns,
                scaling=config.get("_reconstructed_variable_scaling"),
                oracle_values=oracle_windows,
                oracle_columns=list(
                    getattr(loader.dataset, "bundle_oracle_columns", [])
                ),
                prefer_oracle=bool(oracle_windows.shape[-1]),
            )
            losses = structured_target_balanced_losses(
                model,
                output,
                windows,
                reconstructed_targets,
                values,
                mask,
                delta_t_steps=_training_delta_t_steps(config, windows.shape[1]),
                exogenous_measured_indices=_training_exogenous_indices(
                    config, feature_columns, observation_mask
                ),
            )
            real_loss = losses["real_trajectory_loss"]
            nominal_loss = losses["nominal_trajectory_loss"]
            logic_loss, group_logic_losses, rule_audit, rule_terms = _trajectory_training_logic(
                model, output, losses["trajectory"], windows, reconstructed_targets,
                values, mask, knowledge, feature_columns, config,
            )
            base_objective = lambda_real * real_loss + lambda_nominal * nominal_loss
            loss = base_objective + beta * logic_loss
            if is_train:
                assert optimizer is not None
                optimizer.zero_grad(set_to_none=True)
                if gradient_enabled and audited_batches < gradient_batches:
                    if device.type == "cuda":
                        torch.cuda.synchronize(device)
                    gradient_audit_started = time.perf_counter()
                    if audit_timings is not None:
                        from .compilation_timing import CompilationWindow
                        audit_compilation = CompilationWindow()
                        gradient_audit_started = time.perf_counter()
                    base_gradient = _gradient_l2_norm(
                        base_objective,
                        trainable,
                        retain_graph=True,
                    )
                    logic_gradient = (
                        _gradient_l2_norm(
                            logic_loss,
                            trainable,
                            retain_graph=True,
                        )
                        if beta > 0.0 and logic_loss.requires_grad
                        else 0.0
                    )
                    weighted_logic_gradient = beta * logic_gradient
                    denominator = base_gradient + weighted_logic_gradient
                    total["base_gradient_norm"] += base_gradient
                    total["logic_gradient_norm"] += logic_gradient
                    total["weighted_logic_gradient_norm"] += weighted_logic_gradient
                    total["effective_logic_gradient_fraction"] += (
                        weighted_logic_gradient / denominator
                        if denominator > 0.0
                        else 0.0
                    )
                    base_magnitude = abs(float(base_objective.detach().cpu()))
                    logic_magnitude = abs(float((beta * logic_loss).detach().cpu()))
                    total["logic_weighted_loss_fraction"] += (
                        logic_magnitude / (base_magnitude + logic_magnitude)
                        if base_magnitude + logic_magnitude > 0.0
                        else 0.0
                    )
                    for group, term in group_logic_losses.items():
                        key = f"logic_parameter_gradient_norm::{group}"
                        total.setdefault(key, 0.0)
                        total[key] += _gradient_l2_norm(term, trainable, retain_graph=True)
                    # Audited batches only. Per-rule norms are gradients of
                    # the actual model parameters, not truth-head proxies.
                    rule_limit = max(0, int(gradient_cfg.get("max_rule_gradients_per_batch", 16)))
                    items = list(rule_terms.items())
                    cursor = int(getattr(model, "_logic_audit_cursor", 0))
                    selected = [items[(cursor + i) % len(items)] for i in range(min(rule_limit, len(items)))]
                    model._logic_audit_cursor = cursor + len(selected)
                    for name, term in selected:
                        key = f"logic_rule_parameter_gradient_norm::{name}"
                        total.setdefault(key, 0.0)
                        total[key] += _gradient_l2_norm(term, trainable, retain_graph=True)
                        count_key = f"logic_rule_gradient_audit_count::{name}"
                        total[count_key] = total.get(count_key, 0.0) + 1
                    audited_batches += 1
                    if device.type == "cuda":
                        torch.cuda.synchronize(device)
                    audit_elapsed = time.perf_counter() - gradient_audit_started
                    gradient_audit_seconds += audit_elapsed
                    if audit_timings is not None:
                        audit_timings.append(audit_compilation.finish(audit_elapsed))
                loss.backward()
                optimizer.step()

        batch_scalars = {"loss": loss, "real_trajectory_loss": real_loss,
                         "nominal_trajectory_loss": nominal_loss, "logic_loss": logic_loss}
        for names, (sums, counts) in losses.get("phase_statistics", {}).items():
            statistics = torch.cat([sums.detach(), counts.detach()]).to(torch.float64)
            if names in phase_totals:
                phase_totals[names].add_(statistics)
            else:
                phase_totals[names] = statistics.clone()
        for name, audit in rule_audit.items():
            for branch, stats in audit["branches"].items():
                for stat, value in stats.items():
                    if value is not None:
                        key = f"logic_rule::{name}::{branch}::{stat}"
                        total.setdefault(key, 0.0)
                        weight = 1.0 if stat.endswith("groundings") else float(stats["eligible_groundings"])
                        total[key] += float(value) * weight
                        rule_stat_weights[key] = rule_stat_weights.get(key, 0.0) + weight
        for group, group_loss in group_logic_losses.items():
            key = f"logic_loss_group_{group}"
            batch_scalars[key] = group_loss
        for branch, values_by_target in (
            ("real", losses["per_real_target"]),
            ("nominal", losses["per_nominal_target"]),
        ):
            for target_name, target_loss in values_by_target.items():
                key = f"{branch}_target_loss::{target_name}"
                batch_scalars[key] = target_loss
        # Retain only detached scalars, not autograd graphs. Accumulation in
        # float64 matches the previous Python-float reduction while avoiding
        # a CUDA-to-host synchronization for every training minibatch.
        names = tuple(batch_scalars)
        weighted = torch.stack([value.detach() for value in batch_scalars.values()])
        weighted = weighted.to(dtype=torch.float64) * windows.shape[0]
        if names in scalar_totals:
            scalar_totals[names].add_(weighted)
        else:
            scalar_totals[names] = weighted
        scalar_keys.update(names)
        sample_count += windows.shape[0]
        batches += 1
        if batch_callback is not None:
            # The optimizer update and all metric additions are committed for
            # this batch. No autograd graph is exposed to the checkpoint path.
            batch_callback({
                "total": dict(total), "completed_batches": batches, "sample_count": sample_count,
                "scalar_keys": tuple(sorted(scalar_keys)),
                "scalar_totals": {names: value.detach().clone() for names, value in scalar_totals.items()},
                "phase_totals": {names: value.detach().clone() for names, value in phase_totals.items()},
                "rule_stat_weights": dict(rule_stat_weights),
                "audited_batches": audited_batches, "gradient_audit_seconds": gradient_audit_seconds,
                "audit_cursor": int(getattr(model, "_logic_audit_cursor", 0)),
            })

    if scalar_totals:
        scalar_values = iter(torch.cat(list(scalar_totals.values())).cpu().tolist())
        for names in scalar_totals:
            for key in names:
                total[key] = total.get(key, 0.0) + next(scalar_values)
    result = {key: value / max(batches, 1) for key, value in total.items()}
    for key in scalar_keys:
        result[key] = total[key] / max(sample_count, 1)
    for key, weight in rule_stat_weights.items():
        result[key] = total[key] if key.endswith("groundings") else total[key] / max(weight, 1)
    if phase_totals:
        for (branch, target), statistics in phase_totals.items():
            sums, counts = statistics[:4].cpu().tolist(), statistics[4:].cpu().tolist()
            present = [p for p in range(4) if counts[p] > 0]
            result[f"{branch}_target_loss::{target}"] = sum(sums[p] / counts[p] for p in present) / max(len(present), 1)
            for p in range(4):
                result[f"{branch}_phase_count::{target}::{p}"] = counts[p]
                if counts[p]:
                    result[f"{branch}_phase_loss::{target}::{p}"] = sums[p] / counts[p]
        for branch in ("real", "nominal"):
            targets = [v for k, v in result.items() if k.startswith(f"{branch}_target_loss::")]
            result[f"{branch}_trajectory_loss"] = sum(targets) / max(len(targets), 1)
        result["loss"] = (lambda_real * result["real_trajectory_loss"]
                          + lambda_nominal * result["nominal_trajectory_loss"]
                          + beta * result["logic_loss"])
    if is_train and gradient_enabled:
        for key in (
            "base_gradient_norm",
            "logic_gradient_norm",
            "weighted_logic_gradient_norm",
            "effective_logic_gradient_fraction",
            "logic_weighted_loss_fraction",
        ):
            result[key] = total[key] / max(audited_batches, 1)
        result["logic_gradient_audited_batches"] = float(audited_batches)
        for key in total:
            if key.startswith(("logic_parameter_gradient_norm::", "logic_rule_parameter_gradient_norm::")):
                count = audited_batches
                if key.startswith("logic_rule_parameter_gradient_norm::"):
                    name = key.split("::", 1)[1]
                    count = total[f"logic_rule_gradient_audit_count::{name}"]
                result[key] = total[key] / max(count, 1)
            elif key.startswith("logic_rule_gradient_audit_count::"):
                result[key] = total[key]
    result["execution_gradient_audit_seconds"] = gradient_audit_seconds
    return result

@torch.no_grad()
def _structured_training_rule_diagnostics(
    model: nn.Module, loader: DataLoader, config: dict[str, Any],
    knowledge: SystemKnowledge, feature_columns: list[str],
    device: torch.device, observation_mask: ObservationMaskSpec,
) -> dict[str, Any]:
    """Audit exactly the two-trajectory K_train objective on normal windows."""
    model.eval()
    records: dict[str, Any] = {}
    group_values: dict[str, list[float]] = {}
    batches = 0
    for windows, _targets, oracle_windows in loader:
        windows, oracle_windows = windows.to(device), oracle_windows.to(device)
        values, mask = _apply_random_mask(windows, 0.0, observation_mask)
        output = model.predict_update_sequence(values, mask)
        reconstructed_targets = reconstructed_variable_targets_torch(
            windows, knowledge, feature_columns,
            scaling=config.get("_reconstructed_variable_scaling"),
            oracle_values=oracle_windows,
            oracle_columns=list(getattr(loader.dataset, "bundle_oracle_columns", [])),
            prefer_oracle=bool(oracle_windows.shape[-1]),
        )
        trajectory = model.nominal_real_trajectories(
            values, mask, delta_t_steps=_training_delta_t_steps(config, windows.shape[1]),
            exogenous_measured_indices=_training_exogenous_indices(config, feature_columns, observation_mask),
            p_real_output=output,
        )
        _, groups, audit, _ = _trajectory_training_logic(
            model, output, trajectory, windows, reconstructed_targets,
            values, mask, knowledge, feature_columns, config,
        )
        for g, v in groups.items():
            group_values.setdefault(g, []).append(float(v.cpu()))
        for name, info in audit.items():
            row = records.setdefault(name, {"group": info["group"], "role": info["role"], "branches": {}})
            for branch, stats in info["branches"].items():
                out = row["branches"].setdefault(branch, {})
                n = stats["eligible_groundings"]
                for key, value in stats.items():
                    if key.endswith("groundings"):
                        out[key] = out.get(key, 0) + value
                    elif value is not None:
                        out[key + "_sum"] = out.get(key + "_sum", 0.) + value * n
        batches += 1
    for row in records.values():
        for out in row["branches"].values():
            count = out.get("eligible_groundings", 0)
            for key in list(out):
                if key.endswith("_sum"):
                    out[key[:-4]] = out.pop(key) / count if count else None
    return {
        "protocol": "v18_completed_trajectory_rule_audit",
        "rule_count": len(records), "group_count": len(group_values), "batches": batches,
        "rules": records,
        "groups": {g: {"mean_weighted_loss": float(np.mean(v))} for g, v in group_values.items()},
        "normal_reference_used_only_for_training_residual_predicates": True,
    }


def compute_fixed_observer_outputs(
    model: nn.Module,
    bundle: WindowBundle,
    config: dict[str, Any],
    batch_size: int,
    device: torch.device,
    max_windows: int | None = None,
    observation_mask: ObservationMaskSpec | None = None,
    knowledge: SystemKnowledge | None = None,
    feature_columns: list[str] | None = None,
    value_range_radii: dict[str, np.ndarray] | None = None,
    horizon_storage: str = "all",
) -> ObserverResidualResult:
    """Evaluate fixed-mask trajectories with explicit retained-output scope.

    Calibration requires ``all`` horizon values. Evaluation only needs
    endpoints, plus optional residual traces. Omitting unused arrays changes
    neither the per-batch observer computation nor any diagnosis value.
    """

    if horizon_storage not in {"all", "residuals", "none"}:
        raise ConfigError("horizon_storage must be all, residuals, or none")

    model.eval()
    if not bool(getattr(model, "enable_virtual_prior", False)):
        raise ConfigError("fixed_observer diagnosis requires a model trained with the causal virtual-prior head")
    windows = bundle.windows if max_windows is None else bundle.windows[:max_windows]
    targets = bundle.targets if max_windows is None else bundle.targets[:max_windows]
    if windows.shape[1] < 2:
        raise ConfigError("fixed_observer requires windows with at least two time steps")
    if not is_structured_observer(model):
        raise ConfigError("Only the V18 nominal-real observer is supported")
    return _compute_nominal_real_open_loop_outputs(
        model,
        bundle,
        config,
        batch_size,
        device,
        max_windows=max_windows,
        observation_mask=observation_mask,
        knowledge=knowledge,
        feature_columns=feature_columns,
        value_range_radii=value_range_radii,
        horizon_storage=horizon_storage,
    )



def _nominal_real_trajectory_configuration(
    config: dict[str, Any],
    feature_columns: list[str],
    observation_mask: ObservationMaskSpec | None,
    available_steps: int,
) -> tuple[int, tuple[int, ...], list[dict[str, Any]]]:
    cfg = config.get("diagnosis", {}).get("nominal_real_trajectory") or {}
    method = str(config.get("diagnosis", {}).get("method_identifier", ""))
    if not method.startswith("v18_"):
        raise ConfigError("Only the V18 nominal-real trajectory protocol is active")
    if str(cfg.get("protocol", "")).lower() != "open_loop_v18":
        raise ConfigError(
            "V18 requires diagnosis.nominal_real_trajectory.protocol=open_loop_v18"
        )
    delta_cfg = cfg.get("delta_t") or {}
    selection = config.get("_delta_t_selection") or {}
    delta_t_steps = int(selection.get("selected_steps", 0))
    if delta_t_steps <= 0:
        candidates = [int(value) for value in delta_cfg.get("candidates") or []]
        if len(candidates) != 1:
            raise ConfigError(
                "V18 requires a normal-validation-selected delta_t before diagnosis"
            )
        delta_t_steps = candidates[0]
    if delta_t_steps < 1 or delta_t_steps >= available_steps:
        raise ConfigError(
            "delta_t must be positive and smaller than the data window"
        )
    declarations = cfg.get("exogenous_inputs") or []
    if not isinstance(declarations, list):
        raise ConfigError("V18 exogenous_inputs must be a list of declarations")
    feature_index = {name: index for index, name in enumerate(feature_columns)}
    masked = set(observation_mask.masked_feature_columns if observation_mask else ())
    indices: list[int] = []
    normalized: list[dict[str, Any]] = []
    for item in declarations:
        if not isinstance(item, dict):
            raise ConfigError(
                "Each V18 exogenous input requires name, role, and fault_revealing fields"
            )
        name = str(item.get("name", ""))
        role = str(item.get("role", "")).lower()
        if name not in feature_index:
            raise ConfigError(f"Unknown V18 exogenous input '{name}'")
        if name in masked:
            raise ConfigError(f"Masked target '{name}' cannot be a V18 exogenous input")
        if role not in {"command", "setpoint"}:
            raise ConfigError(
                f"V18 exogenous input '{name}' must be a command or setpoint"
            )
        if bool(item.get("fault_revealing", True)):
            raise ConfigError(
                f"V18 exogenous input '{name}' is not admissible when fault_revealing"
            )
        indices.append(feature_index[name])
        normalized.append(
            {"name": name, "role": role, "fault_revealing": False}
        )
    return delta_t_steps, tuple(dict.fromkeys(indices)), normalized


def _compute_nominal_real_open_loop_outputs(
    model: nn.Module,
    bundle: WindowBundle,
    config: dict[str, Any],
    batch_size: int,
    device: torch.device,
    *,
    max_windows: int | None,
    observation_mask: ObservationMaskSpec | None,
    knowledge: SystemKnowledge | None,
    feature_columns: list[str] | None,
    value_range_radii: dict[str, np.ndarray] | None,
    horizon_storage: str = "all",
) -> ObserverResidualResult:
    """Evaluate p_real against the delta_t-step open-loop p_nominal protocol."""

    if not is_structured_observer(model):
        raise ConfigError("V18 nominal-real diagnosis requires the structured observer")
    columns = list(feature_columns or [])
    if not columns:
        raise ConfigError("V18 nominal-real diagnosis requires feature_columns")
    windows = bundle.windows if max_windows is None else bundle.windows[:max_windows]
    delta_t_steps, exogenous_indices, _declarations = _nominal_real_trajectory_configuration(
        config, columns, observation_mask, windows.shape[1]
    )
    # Allocate each output once. Lists followed by concatenate otherwise hold
    # two full copies of every rollout, which is prohibitive for long TEP
    # splits. Reuse the configured job-local storage policy for large arrays.
    outputs: dict[str, np.ndarray] = {}
    dataset = (config.get("datasets") or {}).get(config.get("active_dataset"), {})

    def store_batch(name: str, tensor: torch.Tensor, start: int, end: int) -> None:
        block = tensor.cpu().numpy()
        if not np.isfinite(block).all():
            raise ConfigError(f"Nonfinite observer output: {name}")
        if name not in outputs:
            shape = (len(windows), *block.shape[1:])
            outputs[name] = (
                _window_storage(shape, dataset, purpose=f"observer_{name}")
                if block.size else np.empty(shape, dtype=np.float32)
            )
        outputs[name][start:end] = block
    fixed_indices: torch.Tensor | None = None
    if observation_mask and observation_mask.masked_indices:
        fixed_indices = torch.as_tensor(
            observation_mask.masked_indices, dtype=torch.long, device=device
        )
    from .observed_commands import METHOD as COMMAND_METHOD
    range_tensors = None
    if value_range_radii and str(model.method_version) != COMMAND_METHOD:
        current_radius, nominal_radius = _validated_value_range_radii(
            value_range_radii, model.diagnostic_dim, steps=delta_t_steps)
        range_tensors = tuple(torch.as_tensor(radius, dtype=torch.float32, device=device)
                              for radius in (current_radius, nominal_radius))
    for start in range(0, len(windows), batch_size):
        end = min(start + batch_size, len(windows))
        values = torch.as_tensor(
            windows[start:end], dtype=torch.float32, device=device
        ).clone()
        mask = torch.ones_like(values)
        if fixed_indices is not None:
            mask.index_fill_(-1, fixed_indices, 0.0)
            values.index_fill_(-1, fixed_indices, 0.0)
        with torch.no_grad():
            structured = model.predict_update_sequence(values, mask)
            trajectory = model.nominal_real_trajectories(
                values,
                mask,
                delta_t_steps=delta_t_steps,
                exogenous_measured_indices=exogenous_indices,
                p_real_output=structured,
            )
            horizon_raw = torch.abs(
                trajectory.p_real_horizons - trajectory.p_nominal_horizons
            )
            raw = horizon_raw[:, -1, :]
            adjusted = raw
            if range_tensors is not None:
                current_radius, nominal_radius = range_tensors
                adjusted = torch.relu(raw - current_radius - nominal_radius)
            store_batch("residuals", adjusted, start, end)
            store_batch("raw_residuals", raw, start, end)
            store_batch("p_real", trajectory.p_real, start, end)
            store_batch("p_nominal", trajectory.p_nominal, start, end)
            if horizon_storage != "none":
                store_batch("horizon_raw_residuals", horizon_raw, start, end)
            if horizon_storage == "all":
                store_batch("p_real_horizons", trajectory.p_real_horizons, start, end)
                store_batch("p_nominal_horizons", trajectory.p_nominal_horizons, start, end)
            store_batch("filter_affine", structured.filter_affine[:, -1, :], start, end)
            store_batch(
                "filter_nonlinear_residual",
                structured.filter_nonlinear_residual[:, -1, :], start, end,
            )
    state_columns = diagnostic_state_columns(columns, knowledge) if knowledge else columns
    state_count = len(state_columns)
    if not outputs:
        empty = np.zeros((0, state_count), dtype=np.float32)
        return ObserverResidualResult(
            residuals=empty,
            p_real=empty.copy(),
            p_nominal=empty.copy(),
            raw_residuals=empty.copy(),
            state_columns=tuple(state_columns),
            horizon_raw_residuals=np.zeros(
                (0, delta_t_steps, state_count), dtype=np.float32
            ) if horizon_storage != "none" else None,
            p_real_horizons=np.zeros(
                (0, delta_t_steps, state_count), dtype=np.float32
            ) if horizon_storage == "all" else None,
            p_nominal_horizons=np.zeros(
                (0, delta_t_steps, state_count), dtype=np.float32
            ) if horizon_storage == "all" else None,
            delta_t_steps=delta_t_steps,
            boundary_index=int(windows.shape[1] - delta_t_steps - 1),
        )
    return ObserverResidualResult(
        **outputs,
        state_columns=tuple(state_columns),
        filter_target_names=tuple(getattr(model, "target_names", ())),
        delta_t_steps=delta_t_steps,
        boundary_index=int(windows.shape[1] - delta_t_steps - 1),
    )


def compute_masked_residuals(
    model: nn.Module,
    bundle: WindowBundle,
    config: dict[str, Any],
    batch_size: int,
    device: torch.device,
    max_windows: int | None = None,
    observation_mask: ObservationMaskSpec | None = None,
    knowledge: SystemKnowledge | None = None,
    feature_columns: list[str] | None = None,
) -> np.ndarray:
    """Compute V18 range-gap residuals for the fixed observation mask."""

    return compute_fixed_observer_outputs(
        model,
        bundle,
        config,
        batch_size,
        device,
        max_windows=max_windows,
        observation_mask=observation_mask,
        knowledge=knowledge,
        feature_columns=feature_columns,
    ).residuals




def complete_bundle_values(
    model: nn.Module,
    bundle: WindowBundle,
    config: dict[str, Any],
    batch_size: int,
    device: torch.device,
    observation_mask: ObservationMaskSpec | None,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
) -> tuple[np.ndarray, np.ndarray]:
    """Return oracle-free completed windows and final-step vectors.

    Measured variables remain real measurements. Physically masked variables are
    filled by the fixed neural model. Training knowledge is not reused as an
    online score or completion objective.
    """

    model.eval()
    completed_window_blocks: list[np.ndarray] = []
    completed_target_blocks: list[np.ndarray] = []
    for start in range(0, len(bundle.windows), batch_size):
        windows = torch.as_tensor(bundle.windows[start:start + batch_size], dtype=torch.float32, device=device)
        values = windows.clone()
        mask = torch.ones_like(windows)
        if observation_mask and observation_mask.masked_indices:
            fixed_indices = torch.as_tensor(
                observation_mask.masked_indices, dtype=torch.long, device=device
            )
            mask.index_fill_(-1, fixed_indices, 0.0)
            values.index_fill_(-1, fixed_indices, 0.0)
        with torch.no_grad():
            output = model.predict_update_sequence(values, mask)
            completed = output.posterior_measured
        completed_window_blocks.append(completed.detach().cpu().numpy())
        completed_target_blocks.append(completed[:, -1, :].detach().cpu().numpy())
    if not completed_window_blocks:
        return bundle.windows[:0].copy(), bundle.targets[:0].copy()
    return np.concatenate(completed_window_blocks, axis=0), np.concatenate(completed_target_blocks, axis=0)


def calibrate_thresholds(residuals: np.ndarray, config: dict[str, Any]) -> np.ndarray:
    threshold_cfg = config["diagnosis"].get("threshold", {})
    method = threshold_cfg.get("method", "quantile")
    min_threshold = float(threshold_cfg.get("min_threshold", 0.0))
    if method == "quantile":
        thresholds = np.quantile(residuals, float(threshold_cfg.get("quantile", 0.995)), axis=0)
    elif method == "median_mad":
        median = np.median(residuals, axis=0)
        mad = np.median(np.abs(residuals - median), axis=0)
        thresholds = median + float(threshold_cfg.get("mad_factor", 6.0)) * 1.4826 * mad
    else:
        raise ValueError(f"Unsupported threshold method: {method}")
    return np.maximum(thresholds, min_threshold).astype(np.float32)


def _uncertainty_scale_floor(config: dict[str, Any]) -> float:
    """Return the fixed normal-validation scale floor used by V18 diagnosis."""

    cfg = config.get("diagnosis", {}).get("uncertainty_normalization") or {}
    floor = float(cfg.get("min_scale", 1.0e-6))
    if not np.isfinite(floor) or floor <= 0:
        raise ConfigError("Uncertainty scale floor must be finite and positive")
    return floor


def _normalized_diagnostic_residuals(residuals, thresholds, config):
    """Validate frozen evidence and scales before any symptom decision."""
    residuals, thresholds = np.asarray(residuals), np.asarray(thresholds)
    if (residuals.ndim != 2 or thresholds.shape != (residuals.shape[1],)
            or residuals.dtype.kind not in "fiu" or thresholds.dtype.kind not in "fiu"):
        raise ConfigError("Diagnostic residuals and scales must be aligned numeric arrays")
    if not np.isfinite(residuals).all():
        raise ConfigError("Diagnostic residuals must be finite")
    if not np.isfinite(thresholds).all() or (thresholds <= 0).any():
        raise ConfigError("Diagnostic scales must be finite and positive")
    return residuals / np.maximum(thresholds.reshape(1, -1), _uncertainty_scale_floor(config))


def calibrate_sensor_timing_bounds(
    knowledge: SystemKnowledge,
    config: dict[str, Any],
) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Resolve fixed onset uncertainty without changing detected timestamps."""

    cfg = config.get("diagnosis", {}).get("timing_uncertainty") or {}
    source = str(cfg.get("source", "supplied"))
    unit = str(cfg.get("unit", "raw_samples"))
    if unit not in {"raw_samples", "seconds"}:
        raise ConfigError("Timing uncertainty must use raw_samples or seconds")
    time_cfg = config.get("diagnosis", {}).get("time_axis") or {}
    raw_period_seconds = float(time_cfg.get("raw_sample_period_seconds", 1.0))
    if raw_period_seconds <= 0.0:
        raise ConfigError("The raw sample period must be positive")
    if unit == "raw_samples":
        default_radius = float(cfg.get("default_radius_raw_samples", 0.0))
        overrides = {
            str(name): float(value)
            for name, value in (
                cfg.get("per_sensor_radius_raw_samples") or {}
            ).items()
        }
        variable_overrides = {
            str(name): float(value)
            for name, value in (
                cfg.get("per_variable_radius_raw_samples") or {}
            ).items()
        }
        to_seconds = raw_period_seconds
    else:
        default_radius = float(cfg.get("default_radius_seconds", 0.0))
        overrides = {
            str(name): float(value)
            for name, value in (cfg.get("per_sensor_radius_seconds") or {}).items()
        }
        variable_overrides = {
            str(name): float(value)
            for name, value in (
                cfg.get("per_variable_radius_seconds") or {}
            ).items()
        }
        to_seconds = 1.0
    sensors = active_virtual_fault_sensors(knowledge, config)
    known_names = {sensor.name for sensor in sensors}
    unknown = sorted(set(overrides).difference(known_names))
    if unknown:
        raise ConfigError(f"Timing bounds reference unknown sensors: {unknown}")
    known_variables = {
        variable for sensor in sensors for variable in sensor.component_variables
    }
    unknown_variables = sorted(set(variable_overrides).difference(known_variables))
    if unknown_variables:
        raise ConfigError(
            f"Timing bounds reference unknown diagnostic variables: {unknown_variables}"
        )
    bounds: dict[str, dict[str, Any]] = {}
    for sensor in sensors:
        if sensor.name in overrides:
            radius = overrides[sensor.name]
            radius_source = "supplied_sensor_override"
        elif source == "response_horizon":
            radius_seconds = float(sensor.response_horizon_steps) * raw_period_seconds
            radius = (
                radius_seconds / raw_period_seconds
                if unit == "raw_samples"
                else radius_seconds
            )
            radius_source = "supplied_sensor_response_horizon"
        else:
            radius = default_radius
            radius_source = "supplied_default"
        radius_seconds = float(radius) * to_seconds
        bounds[sensor.name] = {
            "root_cause": sensor.candidate_id,
            "radius_seconds": radius_seconds,
            "configured_radius": float(radius),
            "configured_unit": unit,
            "source": radius_source,
            "constituent_radius_seconds": {
                variable: float(variable_overrides.get(variable, radius))
                * to_seconds
                for variable in sensor.component_variables
            },
            "fault_labels_used": False,
            "fault_onsets_used": False,
            "test_data_used": False,
        }
    return bounds, {
        "unit": "seconds",
        "configured_input_unit": unit,
        "raw_sample_period_seconds": raw_period_seconds,
        "configured_source": source,
        "fault_labels_used": False,
        "fault_onsets_used": False,
        "test_data_used": False,
        "sensor_count": len(bounds),
        "nonzero_radius_sensor_count": sum(
            int(row["radius_seconds"] > 0) for row in bounds.values()
        ),
        "sensors": bounds,
    }


def calibrate_observer_value_range_radii(
    observer: ObserverResidualResult,
    bundle: WindowBundle,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    config: dict[str, Any],
) -> dict[str, np.ndarray]:
    """Calibrate current and nominal value-range radii on normal validation."""

    cfg = config.get("diagnosis", {}).get("value_ranges") or {}
    state_count = observer.p_nominal.shape[1]
    if not bool(cfg.get("enabled", False)):
        zeros = np.zeros(state_count, dtype=np.float32)
        if observer.horizon_raw_residuals is not None:
            horizon = np.zeros(
                observer.horizon_raw_residuals.shape[1:], dtype=np.float32
            )
            return {
                "nominal_horizon": horizon,
                "nominal_selected": horizon[-1].copy(),
                "current": zeros.copy(),
            }
        return {"nominal_selected": zeros.copy(), "current": zeros.copy()}
    quantile = float(cfg.get("quantile", 0.99))
    if not 0.0 < quantile < 1.0:
        raise ConfigError("diagnosis.value_ranges.quantile must lie in (0, 1)")
    minimum = float(cfg.get("min_radius", 0.0))
    targets = augmented_final_targets_numpy(
        bundle.windows, bundle.targets, knowledge, feature_columns,
        scaling=config.get("_reconstructed_variable_scaling"),
        oracle_windows=bundle.oracle_windows, oracle_columns=bundle.oracle_columns,
    )
    if targets.shape != observer.p_nominal.shape:
        raise ConfigError(
            "Observer range calibration target/state shape mismatch: "
            f"{targets.shape} versus {observer.p_nominal.shape}"
        )
    current = np.maximum(
        np.quantile(np.abs(observer.p_real - targets), quantile, axis=0), minimum
    ).astype(np.float32)

    result: dict[str, np.ndarray]
    if (
        observer.p_real_horizons is not None
        and observer.p_nominal_horizons is not None
    ):
        steps = int(observer.p_nominal_horizons.shape[1])
        boundary = int(observer.boundary_index)
        measured_targets = np.asarray(
            bundle.windows[:, boundary + 1 : boundary + 1 + steps, :],
            dtype=np.float32,
        )
        reconstructed_targets = reconstructed_variable_targets_numpy(
            bundle.windows,
            knowledge,
            feature_columns,
            scaling=config.get("_reconstructed_variable_scaling"),
            oracle_values=bundle.oracle_windows,
            oracle_columns=bundle.oracle_columns,
            prefer_oracle=bundle.oracle_windows is not None,
        )[:, boundary + 1 : boundary + 1 + steps, :]
        target_shape = (*measured_targets.shape[:2], measured_targets.shape[2] + reconstructed_targets.shape[2])
        if target_shape != observer.p_nominal_horizons.shape:
            raise ConfigError(
                "Observer horizon target/state shape mismatch: "
                f"{target_shape} versus {observer.p_nominal_horizons.shape}"
            )
        # Quantiles are independent across diagnostic variables. Computing
        # one column at a time gives the same exact sample quantiles without
        # multiple full [window,horizon,variable] error arrays in host RAM.
        current = np.empty(state_count, dtype=np.float32)
        nominal_horizon = np.empty((steps, state_count), dtype=np.float32)
        for index in range(state_count):
            target = (measured_targets[:, :, index] if index < len(feature_columns)
                      else reconstructed_targets[:, :, index - len(feature_columns)])
            current[index] = np.maximum(np.quantile(
                np.abs(observer.p_real_horizons[:, :, index] - target), quantile), minimum)
            nominal_horizon[:, index] = np.maximum(np.quantile(
                np.abs(observer.p_nominal_horizons[:, :, index] - target), quantile, axis=0), minimum)
        result = {
            "current": current,
            "nominal_horizon": nominal_horizon,
            "nominal_selected": nominal_horizon[-1].copy(),
        }
    else:
        nominal = np.maximum(
            np.quantile(
                np.abs(observer.p_nominal - targets), quantile, axis=0
            ),
            minimum,
        ).astype(np.float32)
        result = {"current": current, "nominal_selected": nominal}

    state_columns = list(observer.state_columns) or diagnostic_state_columns(
        feature_columns, knowledge
    )
    if len(state_columns) != state_count:
        raise ConfigError("Observer range calibration state manifest is inconsistent")
    for key, config_key in (
        ("current", "current_radius_overrides"),
        ("nominal_selected", "nominal_radius_overrides"),
    ):
        for name, value in (cfg.get(config_key) or {}).items():
            if name not in state_columns:
                raise ConfigError(f"Unknown range-radius variable {name!r}")
            result[key][state_columns.index(name)] = float(value)
    if "nominal_horizon" in result:
        for name, value in (cfg.get("nominal_radius_overrides") or {}).items():
            result["nominal_horizon"][:, state_columns.index(name)] = float(value)
    return result


def observer_value_range_calibration_summary(
    observer: ObserverResidualResult,
    bundle: WindowBundle,
    widths: dict[str, np.ndarray],
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    config: dict[str, Any],
    *,
    model_selection_bundle: WindowBundle | None = None,
) -> dict[str, Any]:
    """Describe empirical range estimation without claiming formal coverage."""

    cfg = config.get("diagnosis", {}).get("value_ranges") or {}
    targets = augmented_final_targets_numpy(
        bundle.windows,
        bundle.targets,
        knowledge,
        feature_columns,
        scaling=config.get("_reconstructed_variable_scaling"),
        oracle_windows=bundle.oracle_windows,
        oracle_columns=bundle.oracle_columns,
    )
    state_columns = list(observer.state_columns) or diagnostic_state_columns(
        feature_columns, knowledge
    )
    current_errors = np.abs(observer.p_real - targets)
    nominal_errors = np.abs(observer.p_nominal - targets)
    current_width = np.asarray(widths["current"], dtype=np.float32)
    nominal_width = np.asarray(widths["nominal_selected"], dtype=np.float32)
    current_overrides = set((cfg.get("current_radius_overrides") or {}).keys())
    nominal_overrides = set((cfg.get("nominal_radius_overrides") or {}).keys())
    return {
        "estimator": "empirical_quantile",
        "configured_quantile": float(cfg.get("quantile", 0.99)),
        "value_unit": "training_standardized",
        "range_origin": "empirical_normal_validation_quantile",
        "calibration_window_count": int(len(bundle.row_ids)),
        "independent_calibration_case_count": int(len(set(bundle.groups))),
        "model_selection_validation_reuse": (
            bool(set(bundle.row_ids).intersection(model_selection_bundle.row_ids))
            if model_selection_bundle is not None else None
        ),
        "model_selection_reuse_audit": (
            "target_row_id_overlap" if model_selection_bundle is not None else "not_supplied"
        ),
        "formal_fwer_guarantee": False,
        "hard_override_count": int(
            len(current_overrides) + len(nominal_overrides)
        ),
        "per_variable_origin": {
            name: {
                "current": (
                    "hard_engineering_override"
                    if name in current_overrides
                    else "empirical_normal_validation_quantile"
                ),
                "nominal": (
                    "hard_engineering_override"
                    if name in nominal_overrides
                    else "empirical_normal_validation_quantile"
                ),
            }
            for name in state_columns
        },
        "empirical_current_range_coverage": float(
            np.mean(current_errors <= current_width.reshape(1, -1))
        ),
        "empirical_nominal_range_coverage": float(
            np.mean(nominal_errors <= nominal_width.reshape(1, -1))
        ),
        "per_variable_current_range_coverage": {
            name: float(np.mean(current_errors[:, index] <= current_width[index]))
            for index, name in enumerate(state_columns)
        },
        "per_variable_nominal_range_coverage": {
            name: float(np.mean(nominal_errors[:, index] <= nominal_width[index]))
            for index, name in enumerate(state_columns)
        },
    }


def _validated_value_range_radii(widths, state_count, *, steps=None):
    """Share the same frozen-radius contract in calibration and inference."""
    if "current" not in widths:
        raise ConfigError("A fixed current radius is required")
    current = np.asarray(widths["current"], dtype=np.float32)
    selected = widths.get("nominal_selected")
    horizon = widths.get("nominal_horizon")
    if current.shape != (state_count,):
        raise ConfigError("Current radii must match the diagnostic state")
    checked = [current]
    if selected is not None:
        selected = np.asarray(selected, dtype=np.float32)
        if selected.shape != (state_count,):
            raise ConfigError("Selected nominal radii must match the diagnostic state")
        checked.append(selected)
    if horizon is not None:
        horizon = np.asarray(horizon, dtype=np.float32)
        if (horizon.ndim != 2 or not len(horizon) or horizon.shape[1] != state_count
                or (steps is not None and len(horizon) != steps)):
            raise ConfigError("Nominal horizon radii must match the horizon and diagnostic state")
        checked.append(horizon)
        if selected is not None and not np.array_equal(selected, horizon[-1]):
            raise ConfigError("Selected nominal radius disagrees with its final horizon")
    if selected is None and horizon is None:
        raise ConfigError("A selected nominal radius or nominal horizon is required")
    if any(not np.isfinite(radius).all() or (radius < 0).any() for radius in checked):
        raise ConfigError("Current and nominal radii must be finite and non-negative")
    return current, selected if selected is not None else horizon[-1]


def apply_observer_value_ranges(
    observer: ObserverResidualResult,
    widths: dict[str, np.ndarray],
) -> np.ndarray:
    raw = np.asarray(
        observer.raw_residuals if observer.raw_residuals is not None else observer.residuals,
        dtype=np.float32,
    )
    if raw.ndim != 2 or not np.isfinite(raw).all():
        raise ConfigError("Observer residuals must be a finite diagnostic matrix")
    current, nominal = _validated_value_range_radii(widths, raw.shape[1])
    return np.maximum(
        raw - current.reshape(1, -1) - nominal.reshape(1, -1), 0.0
    ).astype(np.float32)


def _diagnosis_module_signal_indices(
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    config: dict[str, Any],
) -> dict[str, list[int]]:
    """Return the supplied and validated variable ownership relation."""

    if str(
        config.get("diagnosis", {}).get("evidence_assignment_mode", "owner")
    ).lower() != "owner":
        raise ConfigError("V18 permits only the supplied variable owner assignment")
    return {
        name: list(indices)
        for name, indices in module_signal_indices(
            knowledge, feature_columns
        ).items()
    }


def _persistent_constituent_strength(
    values: np.ndarray, persistence: int
) -> float:
    """Return the strongest threshold-independent persistent episode.

    The rolling minimum is computed for one evidence constituent. Aggregation
    across constituents is intentionally performed only after this operation.
    """

    series = np.asarray(values, dtype=np.float32).reshape(-1)
    if persistence < 1:
        raise ConfigError("Persistence must be positive")
    if len(series) < persistence:
        return 0.0
    intervals = np.lib.stride_tricks.sliding_window_view(series, persistence)
    return float(np.max(np.min(intervals, axis=-1)))




def calibrate_persistent_case_fault_sensor_thresholds(
    bundle: WindowBundle,
    residuals: np.ndarray,
    feature_thresholds: np.ndarray,
    knowledge: SystemKnowledge,
    state_columns: list[str],
    config: dict[str, Any],
) -> tuple[dict[str, float], dict[str, Any]]:
    """Calibrate one persistent normal-case threshold per root-cause pair."""

    cfg = config.get("diagnosis", {}).get("fault_sensor_threshold") or {}
    case_quantile = float(cfg.get("quantile", 0.995))
    if not 0.0 < case_quantile < 1.0:
        raise ConfigError("diagnosis.fault_sensor_threshold.quantile must lie in (0, 1)")
    correction = str(cfg.get("multiple_testing_control", "bonferroni")).lower()
    if correction not in {"none", "bonferroni"}:
        raise ConfigError(
            "diagnosis.fault_sensor_threshold.multiple_testing_control must be "
            "'none' or 'bonferroni'"
        )
    sensors = active_virtual_fault_sensors(knowledge, config)
    if not sensors:
        raise ConfigError("Component-fault threshold calibration requires sensors")
    candidate_count = len(sensors)
    effective_quantile = (
        1.0 - (1.0 - case_quantile) / candidate_count
        if correction == "bonferroni"
        else case_quantile
    )
    symptom_threshold = _symptom_threshold(config)
    configured_floor = float(cfg.get("min_threshold", symptom_threshold))
    if configured_floor <= 0.0 or configured_floor < symptom_threshold:
        raise ConfigError(
            "Fault-sensor threshold floor must be positive and at least "
            "diagnosis.symptom_threshold"
        )
    persistence = int(
        config.get("diagnosis", {}).get(
            "onset_persistence", DEFAULT_ONSET_PERSISTENCE
        )
    )
    if persistence < 2:
        raise ConfigError(
            "Fault-sensor calibration requires diagnosis.onset_persistence >= 2"
        )
    normalized = _normalized_diagnostic_residuals(residuals, feature_thresholds, config)
    symptoms = _variable_symptom_matrix(normalized, config)
    state_index = {name: idx for idx, name in enumerate(state_columns)}
    groups = np.asarray(bundle.groups, dtype=object)
    case_scores: dict[str, list[float]] = {sensor.name: [] for sensor in sensors}
    for group in list(dict.fromkeys(bundle.groups)):
        positions = np.flatnonzero(groups == group)
        for sensor in sensors:
            coordinates = [
                state_index[name]
                for name in sensor.component_variables
                if name in state_index
            ]
            if len(coordinates) != len(sensor.component_variables):
                missing = sorted(
                    set(sensor.component_variables).difference(state_index)
                )
                raise ConfigError(
                    "Fault-sensor coordinates are missing during threshold "
                    f"calibration: {missing}"
                )
            constituent_scores = [
                _persistent_constituent_strength(
                    symptoms[positions, coordinate], persistence
                )
                for coordinate in coordinates
            ]
            # Persistence is established independently for every constituent.
            # Taking the maximum afterwards prevents alternating excursions in
            # different channels from forming one synthetic persistent event.
            score = max(constituent_scores, default=0.0)
            case_scores[sensor.name].append(score)
    thresholds: dict[str, float] = {}
    sensor_summary: dict[str, dict[str, float | str]] = {}
    for sensor in sensors:
        scores = case_scores[sensor.name]
        try:
            value = float(np.quantile(scores, effective_quantile, method="higher"))
        except TypeError:
            value = float(
                np.quantile(scores, effective_quantile, interpolation="higher")
            )
        threshold = max(configured_floor, value)
        thresholds[sensor.name] = threshold
        sensor_summary[sensor.name] = {
            "root_cause": sensor.candidate_id,
            "threshold": threshold,
            "normal_case_count": float(len(scores)),
            "normal_case_activation_rate": float(
                np.mean(np.asarray(scores) > threshold)
            ),
        }
    normal_case_count = max((len(values) for values in case_scores.values()), default=0)
    any_candidate_activations = []
    for case_index in range(normal_case_count):
        any_candidate_activations.append(
            any(
                case_index < len(case_scores[sensor.name])
                and case_scores[sensor.name][case_index] > thresholds[sensor.name]
                for sensor in sensors
            )
        )
    return thresholds, {
        "calibration_unit": "persistent_event_per_fault_sensor_per_normal_case",
        "normal_window_selection": "contiguous_tail_per_case",
        "onset_persistence": float(persistence),
        "configured_case_quantile": case_quantile,
        "effective_candidate_quantile": effective_quantile,
        "multiple_testing_control": correction,
        "multiple_testing_semantics": (
            "target_quantile_adjustment_not_finite_sample_fwer_guarantee"
        ),
        "independent_normal_calibration_case_count": float(normal_case_count),
        "normal_case_any_candidate_activation_rate": (
            float(np.mean(any_candidate_activations))
            if any_candidate_activations
            else 0.0
        ),
        "candidate_root_cause_count": float(candidate_count),
        "variable_symptom_threshold": float(symptom_threshold),
        "configured_fault_sensor_threshold_floor": configured_floor,
        "fault_labels_used": False,
        "online_godel_rules_calibrated": False,
        "fault_sensors": sensor_summary,
    }




def _first_persistent_event(
    mask: np.ndarray, persistence: int
) -> tuple[int, int] | None:
    """Return symptom onset and the later persistence-confirmation index."""

    if persistence < 1:
        raise ConfigError("Persistence must be positive")
    if len(mask) < persistence:
        return None
    intervals = np.lib.stride_tricks.sliding_window_view(
        np.asarray(mask, dtype=bool).reshape(-1), persistence
    )
    events = np.flatnonzero(np.all(intervals, axis=-1))
    if not len(events):
        return None
    onset = int(events[0])
    return onset, onset + persistence - 1


def _first_persistent(mask: np.ndarray, persistence: int) -> int | None:
    """Compatibility helper returning only the retrospective onset index."""

    event = _first_persistent_event(mask, persistence)
    return event[0] if event is not None else None


def virtual_fault_sensor_traces(
    residuals: np.ndarray,
    thresholds: np.ndarray,
    knowledge: SystemKnowledge,
    state_columns: list[str],
    config: dict[str, Any],
    observation_mask: ObservationMaskSpec | None = None,
    *,
    groups: list[Any] | None = None,
) -> tuple[np.ndarray, list[str], list[str]]:
    """Return causal persistence-filtered traces for supplied virtual sensors.

    Persistence is evaluated for each constituent before constituents are
    aggregated. Alternating one-sample excursions in different variables can
    therefore not create a virtual-sensor event. The trace value at time ``t``
    is available online at ``t`` and summarizes the interval ending at ``t``.
    Contiguous episodes are evaluated independently when groups are supplied.
    """

    sensors = active_virtual_fault_sensors(knowledge, config)
    if not sensors:
        return (
            np.zeros((len(residuals), 0), dtype=np.float32),
            [],
            [],
        )
    normalized = _normalized_diagnostic_residuals(
        _diagnostic_residuals(residuals, observation_mask, config), thresholds, config)
    symptoms = _variable_symptom_matrix(normalized, config)
    persistence = int(
        config.get("diagnosis", {}).get(
            "onset_persistence", DEFAULT_ONSET_PERSISTENCE
        )
    )
    if persistence < 1:
        raise ConfigError("Persistence must be positive")
    if groups is not None and len(groups) != len(residuals):
        raise ConfigError("Sensor trace groups must align with residual rows")
    boundaries = [0]
    if groups is not None:
        boundaries.extend(
            idx for idx in range(1, len(groups)) if groups[idx] != groups[idx - 1]
        )
    boundaries.append(len(residuals))
    index = {name: idx for idx, name in enumerate(state_columns)}
    traces = np.zeros((len(residuals), len(sensors)), dtype=np.float32)
    for sensor_idx, sensor in enumerate(sensors):
        constituent_names = sensor.component_variables
        constituent_indices = [
            index[name] for name in constituent_names if name in index
        ]
        for feature_idx in constituent_indices:
            values = symptoms[:, feature_idx]
            persistent_values = np.zeros(len(values), dtype=np.float32)
            for start, end in zip(boundaries[:-1], boundaries[1:]):
                if end - start < persistence:
                    continue
                intervals = np.lib.stride_tricks.sliding_window_view(
                    values[start:end], persistence
                )
                persistent_values[start + persistence - 1:end] = np.min(
                    intervals, axis=-1
                )
            traces[:, sensor_idx] = np.maximum(
                traces[:, sensor_idx], persistent_values
            )
    return (
        traces,
        [sensor.name for sensor in sensors],
        [sensor.module for sensor in sensors],
    )


def _symptom_representation(config: dict[str, Any]) -> str:
    default = "godel_truth" if _fixed_observer_enabled(config) else "normalized_residual"
    value = str(config.get("diagnosis", {}).get("symptom_representation", default)).lower()
    if value not in {"godel_truth", "normalized_residual"}:
        raise ConfigError(
            "diagnosis.symptom_representation must be 'godel_truth' or "
            "'normalized_residual'"
        )
    return value


def _symptom_threshold(config: dict[str, Any]) -> float:
    default = 0.5 if _symptom_representation(config) == "godel_truth" else 1.0
    return float(config.get("diagnosis", {}).get("symptom_threshold", default))


def _variable_symptom_matrix(normalized_residuals: np.ndarray, config: dict[str, Any]) -> np.ndarray:
    ratios = np.asarray(normalized_residuals, dtype=np.float32)
    if not np.isfinite(ratios).all():
        raise ConfigError("Normalized diagnostic evidence must be finite")
    ratios = np.maximum(ratios, 0.0)
    if _symptom_representation(config) == "godel_truth":
        # tau_sym = 1 / (1 + r), hence s = 1 - tau_sym = r / (1 + r).
        return ratios / (1.0 + ratios)
    return ratios


def evidence_channel_onset_audit(
    bundle: WindowBundle,
    observer: ObserverResidualResult,
    feature_thresholds: np.ndarray,
    knowledge: SystemKnowledge,
    state_columns: list[str],
    config: dict[str, Any],
    normal_labels: list[Any],
    fault_sensor_thresholds: dict[str, float],
    observation_mask: ObservationMaskSpec | None = None,
    *,
    value_range_radii: dict[str, np.ndarray] | None = None,
) -> tuple[pd.DataFrame, dict[str, np.ndarray]]:
    """Export an offline audit of the V18 trajectory evidence channels.

    Fault labels annotate the artifact only after inference. They never enter
    reconstruction, calibration, activation, or ranking.
    """

    if not str(
        config.get("diagnosis", {}).get("method_identifier", "")
    ).startswith("v18_"):
        raise ConfigError("The evidence audit supports only V18 trajectories")
    normalized = _normalized_diagnostic_residuals(
        observer.residuals, np.asarray(feature_thresholds, dtype=np.float32), config)
    symptoms = _variable_symptom_matrix(normalized, config)
    owner_by_signal = knowledge.signal_to_module()
    measured_indices = _measured_feature_indices(
        state_columns, observation_mask, config, knowledge
    )
    current_radius = np.asarray(
        (value_range_radii or {}).get(
            "current", np.zeros(len(state_columns), dtype=np.float32)
        ),
        dtype=np.float32,
    )
    nominal_radius = np.asarray(
        (value_range_radii or {}).get(
            "nominal_selected", np.zeros(len(state_columns), dtype=np.float32)
        ),
        dtype=np.float32,
    )
    sensors_by_variable: dict[str, list[VirtualFaultSensorSpec]] = {}
    for sensor in active_virtual_fault_sensors(knowledge, config):
        for variable in sensor.component_variables:
            sensors_by_variable.setdefault(variable, []).append(sensor)
    reconstructed_inputs = {
        specification.name: list(specification.inputs)
        for specification in knowledge.reconstructed_variables
    }
    offline_targets = augmented_final_targets_numpy(
        bundle.windows,
        bundle.targets,
        knowledge,
        state_columns[: bundle.targets.shape[1]],
        scaling=config.get("_reconstructed_variable_scaling"),
        oracle_windows=bundle.oracle_windows,
        oracle_columns=bundle.oracle_columns,
    )
    persistence = int(
        config.get("diagnosis", {}).get(
            "onset_persistence", DEFAULT_ONSET_PERSISTENCE
        )
    )
    normal_set = {str(value) for value in normal_labels}
    rows: list[dict[str, Any]] = []
    for group in dict.fromkeys(bundle.groups):
        group_indices = [
            index for index, value in enumerate(bundle.groups) if value == group
        ]
        if not group_indices:
            continue
        labels = (
            [str(bundle.labels[index]) for index in group_indices]
            if bundle.labels is not None
            else []
        )
        true_root_causes = extract_true_component_fault_pairs(
            _select_bundle(bundle, group_indices), knowledge, normal_labels
        )
        case_kind = (
            "fault"
            if labels and any(value not in normal_set for value in labels)
            else "normal"
        )
        group_time = _diagnosis_time_axis(
            [bundle.times[index] for index in group_indices],
            len(group_indices),
            config,
        )
        true_fault_relative_index = next(
            (
                index
                for index, value in enumerate(labels)
                if value not in normal_set
            ),
            None,
        )
        true_fault_onset_time = (
            float(group_time.seconds[true_fault_relative_index])
            if true_fault_relative_index is not None
            else float("nan")
        )
        for channel_index, channel_name in enumerate(state_columns):
            channel_sensors = sensors_by_variable.get(channel_name, [])
            candidate_ids = [sensor.candidate_id for sensor in channel_sensors]
            candidate_thresholds = [
                float(
                    fault_sensor_thresholds.get(
                        sensor.name, _symptom_threshold(config)
                    )
                )
                for sensor in channel_sensors
            ]
            threshold = (
                min(candidate_thresholds)
                if candidate_thresholds
                else _symptom_threshold(config)
            )
            symptom = symptoms[group_indices, channel_index]
            persistent_event = _first_persistent_event(
                symptom > threshold, persistence
            )
            relative_onset = (
                persistent_event[0] if persistent_event is not None else None
            )
            relative_confirmation = (
                persistent_event[1] if persistent_event is not None else None
            )
            representative = (
                relative_onset
                if relative_onset is not None
                else int(np.argmax(symptom))
            )
            absolute_index = group_indices[representative]
            reference_value = float(
                offline_targets[absolute_index, channel_index]
            )
            available_inputs = reconstructed_inputs.get(
                channel_name,
                [channel_name] if channel_index in measured_indices else [],
            )
            sensor_causal_inputs = sorted(
                {
                    value
                    for sensor in channel_sensors
                    for value in sensor.causal_inputs
                }
            )
            rows.append(
                {
                    "case_id": str(group),
                    "case_kind": case_kind,
                    "true_root_causes": json.dumps(true_root_causes),
                    "evidence_channel": channel_name,
                    "evidence_type": (
                        "measured_variable"
                        if channel_index in measured_indices
                        else "reconstructed_variable"
                    ),
                    "owner_module": owner_by_signal.get(channel_name, ""),
                    "candidate_root_causes": json.dumps(candidate_ids),
                    "p_real": float(observer.p_real[absolute_index, channel_index]),
                    "p_nominal_open_loop": float(
                        observer.p_nominal[absolute_index, channel_index]
                    ),
                    "offline_reference_target": reference_value,
                    "offline_reference_available": bool(
                        np.isfinite(reference_value)
                    ),
                    "p_real_reconstruction_absolute_error": float(
                        abs(
                            observer.p_real[absolute_index, channel_index]
                            - reference_value
                        )
                    ),
                    "available_input_names": json.dumps(available_inputs),
                    "sensor_causal_inputs": json.dumps(sensor_causal_inputs),
                    "current_value_radius": float(current_radius[channel_index]),
                    "nominal_value_radius": float(nominal_radius[channel_index]),
                    "adjusted_residual": float(
                        observer.residuals[absolute_index, channel_index]
                    ),
                    "variable_symptom_strength": float(symptom[representative]),
                    "audit_threshold": float(threshold),
                    "audit_threshold_semantics": (
                        "minimum_relevant_fault_sensor_threshold"
                        if candidate_thresholds
                        else "global_variable_symptom_threshold"
                    ),
                    "onset_persistence": persistence,
                    "persistent_onset_index": (
                        int(relative_onset) if relative_onset is not None else -1
                    ),
                    "persistent_onset_time": (
                        float(group_time.seconds[int(relative_onset)])
                        if relative_onset is not None
                        else float("nan")
                    ),
                    "persistence_confirmation_index": (
                        int(relative_confirmation)
                        if relative_confirmation is not None
                        else -1
                    ),
                    "persistence_confirmation_time": (
                        float(group_time.seconds[int(relative_confirmation)])
                        if relative_confirmation is not None
                        else float("nan")
                    ),
                    "true_fault_onset_time": true_fault_onset_time,
                    "symptom_onset_error_seconds": (
                        float(
                            group_time.seconds[int(relative_onset)]
                            - true_fault_onset_time
                        )
                        if relative_onset is not None
                        and np.isfinite(true_fault_onset_time)
                        else float("nan")
                    ),
                    "activated": relative_onset is not None,
                    "representative_row_id": str(bundle.row_ids[absolute_index]),
                    "max_symptom_strength": float(np.max(symptom)),
                    "root_local_channel": bool(
                        set(candidate_ids).intersection(true_root_causes)
                    ),
                    "fault_labels_used_online": False,
                    "offline_reference_annotation_only": True,
                    "named_sensor_is_not_detectability_proof": True,
                    "p_nominal_semantics": (
                        "normal_model_open_loop_rollout_not_guaranteed_fault_free_"
                        "counterfactual"
                    ),
                }
            )
    arrays = {
        "p_real": np.asarray(observer.p_real, dtype=np.float32),
        "p_nominal_open_loop": np.asarray(observer.p_nominal, dtype=np.float32),
        "offline_reference_target": np.asarray(offline_targets, dtype=np.float32),
        "current_value_radius": current_radius,
        "nominal_value_radius": nominal_radius,
        "adjusted_residual": np.asarray(observer.residuals, dtype=np.float32),
        "variable_symptom_strength": symptoms.astype(np.float32),
        "feature_residual_threshold": np.asarray(
            feature_thresholds, dtype=np.float32
        ),
        "owner_module": np.asarray(
            [owner_by_signal.get(name, "") for name in state_columns], dtype=str
        ),
        "state_columns": np.asarray(state_columns, dtype=str),
    }
    return pd.DataFrame(rows), arrays


def matched_root_local_no_fault_audit(
    bundle: WindowBundle,
    measured_values: np.ndarray,
    knowledge: SystemKnowledge,
    state_columns: list[str],
    config: dict[str, Any],
    normal_labels: list[Any],
    observation_mask: ObservationMaskSpec | None = None,
) -> pd.DataFrame:
    """Compare each root-local measured trace with a context-matched normal trace."""

    if bundle.labels is None:
        return pd.DataFrame()
    normal_set = {str(value) for value in normal_labels}
    owner_by_signal = knowledge.signal_to_module()
    measured_indices = set(
        _measured_feature_indices(
            state_columns, observation_mask, config, knowledge
        )
    )
    groups = list(dict.fromkeys(bundle.groups))
    group_indices = {
        group: [index for index, value in enumerate(bundle.groups) if value == group]
        for group in groups
    }
    normal_groups = [
        group
        for group, indices in group_indices.items()
        if indices
        and all(str(bundle.labels[index]) in normal_set for index in indices)
    ]
    metadata = bundle.metadata or {}
    match_fields = [
        field
        for field in ("ds_id", "hydraulic_demand_model", "signal_mode")
        if field in metadata
    ]

    def context(group: Any) -> dict[str, str]:
        indices = group_indices[group]
        result: dict[str, str] = {}
        for field in match_fields:
            values = {
                str(metadata[field][index])
                for index in indices
                if index < len(metadata[field]) and str(metadata[field][index]).strip()
            }
            if len(values) == 1:
                result[field] = next(iter(values))
        return result

    rows: list[dict[str, Any]] = []
    for group in groups:
        indices = group_indices[group]
        fault_indices = [
            index
            for index in indices
            if str(bundle.labels[index]) not in normal_set
        ]
        if not fault_indices:
            continue
        case_bundle = _select_bundle(bundle, indices)
        true_modules = extract_true_root_modules(
            case_bundle, knowledge, normal_labels
        )
        if not true_modules:
            continue
        case_context = context(group)
        references = [
            candidate
            for candidate in normal_groups
            if all(
                context(candidate).get(field) == value
                for field, value in case_context.items()
            )
        ]
        if references:
            reference_indices = [
                index for candidate in references for index in group_indices[candidate]
            ]
            reference_source = "matched_normal_case"
        else:
            first_fault = indices.index(fault_indices[0])
            reference_indices = indices[:first_fault]
            reference_source = "same_case_pre_fault_fallback"
        if not reference_indices:
            reference_source = "unavailable"
        for root_module in true_modules:
            for channel_index, channel_name in enumerate(state_columns):
                if channel_index not in measured_indices:
                    continue
                if owner_by_signal.get(channel_name) != root_module:
                    continue
                fault_values = measured_values[fault_indices, channel_index]
                reference_values = measured_values[
                    reference_indices, channel_index
                ] if reference_indices else np.asarray([], dtype=np.float32)
                fault_values = fault_values[np.isfinite(fault_values)]
                reference_values = reference_values[np.isfinite(reference_values)]
                fault_mean = (
                    float(np.mean(fault_values)) if fault_values.size else np.nan
                )
                reference_mean = (
                    float(np.mean(reference_values))
                    if reference_values.size else np.nan
                )
                reference_std = (
                    float(np.std(reference_values, ddof=1))
                    if reference_values.size > 1 else np.nan
                )
                rows.append(
                    {
                        "case_id": str(group),
                        "root_cause_module": root_module,
                        "root_local_measured_variable": channel_name,
                        "fault_window_count": int(fault_values.size),
                        "reference_window_count": int(reference_values.size),
                        "reference_source": reference_source,
                        "reference_groups": ",".join(str(value) for value in references),
                        "reference_match_fields": ",".join(case_context),
                        "fault_mean": fault_mean,
                        "fault_median": (
                            float(np.median(fault_values))
                            if fault_values.size else np.nan
                        ),
                        "reference_mean": reference_mean,
                        "reference_median": (
                            float(np.median(reference_values))
                            if reference_values.size else np.nan
                        ),
                        "mean_shift": fault_mean - reference_mean,
                        "absolute_mean_shift": abs(fault_mean - reference_mean),
                        "reference_standard_deviation": reference_std,
                        "standardized_mean_shift": (
                            (fault_mean - reference_mean) / reference_std
                            if np.isfinite(reference_std) and reference_std > 1.0e-12
                            else np.nan
                        ),
                        "evaluation_labels_used_offline_only": True,
                    }
                )
    return pd.DataFrame(rows)





def _diagnosis_time_axis(
    times: list[Any] | np.ndarray | None,
    length: int,
    config: dict[str, Any],
) -> DiagnosisTimeAxis:
    """Validate one episode time axis and convert it to physical seconds.

    Invalid supplied timestamps never fall back to sample indices. A missing
    axis is represented explicitly as an unsynchronized sample-index aid and
    cannot be mistaken for a validated physical time contract.
    """

    cfg = config.get("diagnosis", {}).get("time_axis") or {}
    input_unit = str(cfg.get("input_unit", "seconds"))
    raw_period = float(
        cfg.get(
            "raw_sample_period_seconds",
            (
                config.get("diagnosis", {})
                .get("nominal_real_trajectory", {})
                .get("delta_t", {})
                .get("sample_period_seconds", 1.0)
            ),
        )
    )
    stride = int(cfg.get("evaluation_stride_samples", 1))
    expected_period = raw_period * stride
    gap_policy = str(cfg.get("gap_policy", "reject"))
    synchronization_supplied = bool(
        cfg.get("sensor_synchronization_supplied", False)
    )
    if raw_period <= 0.0 or stride < 1:
        raise ConfigError("Invalid diagnosis raw period or evaluation stride")
    if gap_policy != "reject":
        raise ConfigError("Only the fail-closed time-axis gap policy is supported")
    if times is None:
        return DiagnosisTimeAxis(
            seconds=np.arange(length, dtype=np.float64) * expected_period,
            source="explicitly_missing_sample_index_aid",
            input_unit="sample_index_aid",
            raw_sample_period_seconds=raw_period,
            evaluation_stride_samples=stride,
            expected_evaluation_period_seconds=expected_period,
            time_axis_validated=False,
            sensor_synchronization_supplied=False,
            timestamp_synchronized=False,
            gap_policy=gap_policy,
        )
    if len(times) != length:
        raise ConfigError(
            "Supplied diagnosis timestamps do not match the episode length"
        )
    series = pd.Series(list(times))
    numeric = pd.to_numeric(series, errors="coerce")
    if bool(numeric.notna().all()):
        values = numeric.to_numpy(dtype=np.float64)
        source = "source_timestamp_numeric"
    elif input_unit == "seconds":
        datetimes = pd.to_datetime(series, errors="coerce", utc=True)
        if not bool(datetimes.notna().all()):
            raise ConfigError("Supplied diagnosis timestamps are not parseable")
        nanoseconds = datetimes.astype("int64").to_numpy(dtype=np.float64)
        values = (nanoseconds - nanoseconds[0]) / 1.0e9
        source = "source_timestamp_elapsed_seconds"
    else:
        raise ConfigError("Hour or raw-sample timestamps must be finite numeric values")
    if not bool(np.isfinite(values).all()):
        raise ConfigError("Diagnosis timestamps must be finite")
    differences = np.diff(values)
    if len(differences) and bool(np.any(differences <= 0.0)):
        raise ConfigError("Diagnosis timestamps must be unique and strictly increasing")
    if input_unit == "raw_sample_index":
        seconds = (values - values[0]) * raw_period
    elif input_unit == "seconds":
        seconds = values
    elif input_unit == "hours":
        # Extended TEP stores simulation time in hours, not sample indices.
        # Convert units without resetting the episode origin or inferring a
        # sampling rate that could hide missing observations.
        seconds = values * 3600.0
    else:
        raise ConfigError(
            "diagnosis.time_axis.input_unit must be seconds, hours or raw_sample_index"
        )
    physical_differences = np.diff(seconds)
    tolerance = max(
        float(cfg.get("gap_tolerance_seconds", 1.0e-6)),
        expected_period * float(cfg.get("gap_tolerance_fraction", 1.0e-6)),
    )
    if len(physical_differences) and not bool(
        np.all(np.abs(physical_differences - expected_period) <= tolerance)
    ):
        raise ConfigError(
            "Diagnosis timestamps contain a gap or contradict the configured "
            "raw sampling period and evaluation stride"
        )
    return DiagnosisTimeAxis(
        seconds=seconds.astype(np.float64),
        source=source,
        input_unit=input_unit,
        raw_sample_period_seconds=raw_period,
        evaluation_stride_samples=stride,
        expected_evaluation_period_seconds=expected_period,
        time_axis_validated=True,
        sensor_synchronization_supplied=synchronization_supplied,
        timestamp_synchronized=synchronization_supplied,
        gap_policy=gap_policy,
    )


def diagnose_component_fault_pairs(
    residuals: np.ndarray,
    thresholds: np.ndarray,
    knowledge: SystemKnowledge,
    state_columns: list[str],
    config: dict[str, Any],
    *,
    times: list[Any] | np.ndarray | None = None,
    fault_sensor_thresholds: dict[str, float] | None = None,
    sensor_timing_bounds: dict[str, dict[str, Any]] | None = None,
    observation_mask: ObservationMaskSpec | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Rank root causes as component and fault-type pairs."""

    if str(
        config.get("diagnosis", {}).get("virtual_evidence_mode", "")
    ).lower() != "nominal_real_open_loop":
        raise ConfigError(
            "V18 component-fault diagnosis requires nominal-real open-loop evidence"
        )
    sensors = active_virtual_fault_sensors(knowledge, config)
    if not sensors:
        raise ConfigError("Component-fault diagnosis requires virtual fault sensors")
    index = {name: idx for idx, name in enumerate(state_columns)}
    missing = sorted(
        {
            variable
            for sensor in sensors
            for variable in sensor.component_variables
            if variable not in index
        }
    )
    if missing:
        raise ConfigError(
            f"Primary virtual-sensor coordinates are missing: {sorted(missing)}"
        )
    residuals = np.asarray(residuals)
    if residuals.ndim != 2 or residuals.shape[1] != len(state_columns):
        raise ConfigError("Diagnostic residuals must match the declared state columns")
    normalized = _normalized_diagnostic_residuals(residuals, thresholds, config)
    symptoms = _variable_symptom_matrix(normalized, config)
    persistence = int(
        config.get("diagnosis", {}).get(
            "onset_persistence", DEFAULT_ONSET_PERSISTENCE
        )
    )
    symptom_threshold = _symptom_threshold(config)
    time_contract = _diagnosis_time_axis(times, len(residuals), config)
    time_axis = time_contract.seconds
    rows: list[dict[str, Any]] = []
    for sensor in sensors:
        threshold = float(
            (fault_sensor_thresholds or {}).get(
                sensor.name,
                (fault_sensor_thresholds or {}).get(sensor.module, symptom_threshold),
            )
        )
        masked_names = set(
            observation_mask.masked_feature_columns if observation_mask else []
        )
        constituents: list[tuple[str, str, np.ndarray]] = []
        measured_component_variables: list[str] = []
        virtual_component_variables: list[str] = []
        for variable in sensor.component_variables:
            variable_is_measured = (
                variable not in knowledge.reconstructed_variable_names
                and variable not in masked_names
            )
            if variable_is_measured:
                measured_component_variables.append(variable)
                evidence_kind = "measured_component_variable_p_real_vs_p_nominal"
            else:
                virtual_component_variables.append(variable)
                evidence_kind = "virtual_component_variable_p_real_vs_p_nominal"
            constituents.append(
                (f"feature:{variable}", evidence_kind, symptoms[:, index[variable]])
            )
        timing_record = dict((sensor_timing_bounds or {}).get(sensor.name) or {})
        default_timing_radius_seconds = float(
            timing_record.get("radius_seconds", 0.0)
        )
        variable_timing_radii = {
            str(name): float(value)
            for name, value in (
                timing_record.get("constituent_radius_seconds") or {}
            ).items()
        }
        if any(not np.isfinite(v) or v < 0 for v in [default_timing_radius_seconds, *variable_timing_radii.values()]):
            raise ConfigError("Sensor timing radii must be finite and non-negative")
        if not np.isfinite(threshold) or threshold <= 0:
            raise ConfigError("Fault-sensor thresholds must be finite and positive")
        active_constituents: list[dict[str, Any]] = []
        persistent_strengths: list[float] = []
        for order, (evidence_name, evidence_kind, constituent_trace) in enumerate(
            constituents
        ):
            persistent_event = _first_persistent_event(
                constituent_trace > threshold, persistence
            )
            persistent_strengths.append(
                _persistent_constituent_strength(
                    constituent_trace, persistence
                )
            )
            if persistent_event is not None:
                constituent_onset, confirmation_index = persistent_event
                variable = evidence_name.removeprefix("feature:")
                radius_seconds = float(
                    variable_timing_radii.get(
                        variable, default_timing_radius_seconds
                    )
                )
                onset_time = float(time_axis[int(constituent_onset)])
                confirmation_time = float(time_axis[int(confirmation_index)])
                active_constituents.append(
                    {
                        "name": evidence_name,
                        "kind": evidence_kind,
                        "onset": int(constituent_onset),
                        "onset_time": onset_time,
                        "confirmation": int(confirmation_index),
                        "confirmation_time": confirmation_time,
                        "timing_radius_seconds": radius_seconds,
                        "onset_interval_lower_time": onset_time - radius_seconds,
                        "onset_interval_upper_time": onset_time + radius_seconds,
                        "order": order,
                    }
                )
        earliest = (
            min(
                active_constituents,
                key=lambda item: (int(item["onset"]), int(item["order"])),
            )
            if active_constituents
            else None
        )
        onset_index = int(earliest["onset"]) if earliest is not None else None
        confirmation_index = (
            int(earliest["confirmation"]) if earliest is not None else None
        )
        max_raw_symptom = max(
            (
                float(np.max(constituent_trace))
                for _, _, constituent_trace in constituents
                if len(constituent_trace)
            ),
            default=0.0,
        )
        max_persistent_symptom = max(persistent_strengths, default=0.0)
        evidence_confidence = max(
            (max_persistent_symptom - threshold)
            / max(threshold, _uncertainty_scale_floor(config)),
            0.0,
        )
        if onset_index is None:
            detected_time = float("inf")
            confirmation_time = float("inf")
            onset_interval_lower_time = float("inf")
            onset_interval_upper_time = float("inf")
            active = False
        else:
            detected_time = float(time_axis[onset_index])
            confirmation_time = float(time_axis[int(confirmation_index)])
            onset_interval_lower_time = float(
                min(item["onset_interval_lower_time"] for item in active_constituents)
            )
            onset_interval_upper_time = float(
                min(item["onset_interval_upper_time"] for item in active_constituents)
            )
            active = True
        active_constituent_kinds = {
            str(item["kind"]) for item in active_constituents
        }
        rows.append(
            {
                "root_cause": sensor.candidate_id,
                "module": sensor.module,
                "component": sensor.physical_component,
                "fault_type": sensor.fault_type,
                "physical_quantity": sensor.physical_quantity,
                "component_variables": ",".join(sensor.component_variables),
                "fault_modes": ",".join(sensor.covered_fault_modes),
                "virtual_fault_sensor_name": sensor.name,
                "primary_component_variable": sensor.primary_cause_sensitive_variable,
                "primary_virtual_variable": (
                    sensor.primary_cause_sensitive_variable
                    if sensor.primary_cause_sensitive_variable in virtual_component_variables
                    else ""
                ),
                "measured_component_variables": ",".join(
                    measured_component_variables
                ),
                "virtual_component_variables": ",".join(
                    virtual_component_variables
                ),
                "virtual_evidence_required": bool(virtual_component_variables),
                "diagnostic_evidence_active": active,
                "measured_evidence_active": bool(
                    "measured_component_variable_p_real_vs_p_nominal"
                    in active_constituent_kinds
                ),
                "virtual_evidence_active": bool(
                    "virtual_component_variable_p_real_vs_p_nominal"
                    in active_constituent_kinds
                ),
                "online_godel_evidence_active": False,
                "symptom_onset_index": int(onset_index) if onset_index is not None else -1,
                "symptom_onset_time": detected_time,
                "persistence_confirmation_index": (
                    int(confirmation_index) if confirmation_index is not None else -1
                ),
                "persistence_confirmation_time": confirmation_time,
                "detected_onset": int(onset_index) if onset_index is not None else -1,
                "detected_onset_time": detected_time,
                "episode_end_time": (
                    float(time_axis[-1]) if len(time_axis) else float("nan")
                ),
                "finite_episode_decision_time": (
                    float(time_axis[-1]) if len(time_axis) else float("nan")
                ),
                "decision_scope": "finite_episode_retrospective",
                "decision_is_irreversible_online": False,
                "online_wait_condition_present": False,
                "onset_interval_lower_time": onset_interval_lower_time,
                "onset_interval_upper_time": onset_interval_upper_time,
                "time_axis_source": time_contract.source,
                "time_axis_validated": time_contract.time_axis_validated,
                "timestamp_synchronized": time_contract.timestamp_synchronized,
                "sensor_synchronization_supplied": (
                    time_contract.sensor_synchronization_supplied
                ),
                "raw_sample_period_seconds": (
                    time_contract.raw_sample_period_seconds
                ),
                "evaluation_stride_samples": (
                    time_contract.evaluation_stride_samples
                ),
                "expected_evaluation_period_seconds": (
                    time_contract.expected_evaluation_period_seconds
                ),
                "persistence_unit": "consecutive_evaluation_points",
                "timing_uncertainty_radius_seconds": (
                    default_timing_radius_seconds
                ),
                "timing_uncertainty_source": str(
                    timing_record.get("source", "point_onset_default")
                ),
                "response_horizon_steps": sensor.response_horizon_steps,
                "response_horizon_source": sensor.response_horizon_source,
                "causal_inputs": ",".join(sensor.causal_inputs),
                "observable_effects": ",".join(sensor.observable_effects),
                "max_symptom": max_raw_symptom,
                "max_persistent_symptom": max_persistent_symptom,
                "sensor_threshold": threshold,
                "evidence_confidence": evidence_confidence,
                "evidence_confidence_source": "descriptive_not_used_for_ranking",
                "earliest_evidence": str(earliest["name"]) if earliest else "",
                "earliest_evidence_kind": (
                    str(earliest["kind"]) if earliest else ""
                ),
                "active_constituent_count": len(active_constituents),
                "sensor_constituent_count": len(constituents),
                "online_godel_rule_count": 0,
                "detectability_claim": sensor.detectability_claim,
                "detectability_certified": sensor.detectability_claim.startswith(
                    "certified"
                ),
            }
        )
    frame = pd.DataFrame(rows)
    frame = frame.sort_values(
        ["detected_onset_time", "root_cause"], kind="mergesort"
    ).reset_index(drop=True)
    frame.insert(0, "rank", np.arange(1, len(frame) + 1))
    finite = np.isfinite(frame["detected_onset_time"].to_numpy(dtype=float))
    likelihood = np.zeros(len(frame), dtype=float)
    if bool(np.any(finite)):
        values = frame.loc[finite, "detected_onset_time"].to_numpy(dtype=float)
        values = values - float(np.min(values))
        weights = np.exp(-values / max(float(config["diagnosis"].get("likelihood_temperature", 1.0)), 1.0e-6))
        likelihood[finite] = weights / max(float(np.sum(weights)), 1.0e-12)
    frame["likelihood"] = likelihood
    active_frame = frame[frame["diagnostic_evidence_active"]].copy()
    ranked_candidates = active_frame["root_cause"].astype(str).tolist()
    unique_root: str | None = None
    decision = "no_diagnosis"
    candidates: list[str] = []
    if len(active_frame) == 1:
        unique_root = str(active_frame.iloc[0]["root_cause"])
        candidates = [unique_root]
        decision = "unique_component_fault_pair"
    elif len(active_frame) > 1:
        unique_rows: list[pd.Series] = []
        for row_index, row in active_frame.iterrows():
            competitor_lower = active_frame.loc[
                active_frame.index != row_index, "onset_interval_lower_time"
            ]
            if float(row["onset_interval_upper_time"]) < float(
                competitor_lower.min()
            ):
                unique_rows.append(row)
        if len(unique_rows) == 1:
            unique_root = str(unique_rows[0]["root_cause"])
            candidates = [unique_root]
            decision = "unique_component_fault_pair"
        else:
            earliest_upper = float(
                active_frame["onset_interval_upper_time"].min()
            )
            possible = active_frame[
                active_frame["onset_interval_lower_time"] <= earliest_upper
            ]
            candidates = possible["root_cause"].astype(str).tolist()
            decision = "ambiguous_candidate_set"
    frame["diagnosis_decision"] = decision
    frame["candidate_root_causes"] = json.dumps(candidates)
    frame["is_candidate"] = frame["root_cause"].isin(candidates)
    active_scores = {
        str(row["root_cause"]): float(row["likelihood"])
        for _, row in active_frame.iterrows()
    }
    case = {
        "ranked_root_causes": ranked_candidates,
        "earliest_root_causes": (
            active_frame.loc[
                active_frame["detected_onset_time"] == active_frame["detected_onset_time"].min(),
                "root_cause",
            ].astype(str).tolist() if len(active_frame) else []
        ),
        "scores_by_root_cause": active_scores,
        "diagnosis_decision": decision,
        "candidate_root_causes": candidates,
        "unique_root_cause": unique_root,
        "timestamp_synchronized": time_contract.timestamp_synchronized,
        "time_axis_validated": time_contract.time_axis_validated,
        "decision_scope": "finite_episode_retrospective",
        "decision_is_irreversible_online": False,
        "online_wait_condition_present": False,
        "tie_ordering_semantics": "reporting_only_not_diagnostic_evidence",
        "timing_uncertainty_representation": "symmetric_onset_intervals",
    }
    return frame, {
        "ranking_case": case,
        "diagnosis_decision": decision,
        "candidate_root_causes": candidates,
        "unique_root_cause": unique_root,
        "ranked_root_cause_count": float(len(frame)),
        "timestamp_synchronized": time_contract.timestamp_synchronized,
        "time_axis_validated": time_contract.time_axis_validated,
        "sensor_synchronization_supplied": (
            time_contract.sensor_synchronization_supplied
        ),
        "decision_scope": "finite_episode_retrospective",
        "decision_is_irreversible_online": False,
        "online_wait_condition_present": False,
        "tie_ordering_semantics": "reporting_only_not_diagnostic_evidence",
        "timing_uncertainty_representation": "symmetric_onset_intervals",
        "uncertainty_normalization": "component_variable_and_fault_sensor_specific",
        "online_godel_scoring": False,
    }


def _top_features_for_module(normalized: np.ndarray, indices: list[int], feature_columns: list[str], limit: int = 3) -> list[str]:
    if not indices:
        return []
    maxima = [(feature_columns[idx], float(np.max(normalized[:, idx]))) for idx in indices]
    maxima.sort(key=lambda item: item[1], reverse=True)
    return [name for name, _ in maxima[:limit]]


def partial_observation_reconstruction_metrics(
    model: nn.Module,
    bundle: WindowBundle,
    batch_size: int,
    device: torch.device,
    observation_mask: ObservationMaskSpec,
    feature_columns: list[str],
    config: dict[str, Any] | None = None,
    knowledge: SystemKnowledge | None = None,
    virtual_sensor_baselines: dict[str, Any] | None = None,
) -> dict[str, float]:
    """Measure how well physically hidden variables are reconstructed.

    These metrics are separate from the diagnosis ranking. They quantify the
    virtual-sensor claim: if columns are removed from the observation mask, the
    latent model should still reconstruct them from the remaining signals.
    """

    if not observation_mask.masked_indices:
        return {
            "masked_feature_count": 0.0,
            "masked_mae": 0.0,
            "masked_rmse": 0.0,
            "nominal_open_loop_mae": 0.0,
            "nominal_open_loop_rmse": 0.0,
            "real_nominal_gap_mae": 0.0,
            "real_nominal_gap_rmse": 0.0,
            "nominal_open_loop_available": True,
            "observed_mae": 0.0,
            "observed_rmse": 0.0,
            "baselines": {},
            "masked_features": {},
        }
    model.eval()
    masked_indices = torch.as_tensor(observation_mask.masked_indices, dtype=torch.long, device=device)
    observed_indices = [
        idx for idx in range(bundle.windows.shape[-1])
        if idx not in set(observation_mask.masked_indices)
    ]
    observed_index_tensor = torch.as_tensor(observed_indices, dtype=torch.long, device=device)
    masked_abs_sum = 0.0
    masked_sq_sum = 0.0
    masked_count = 0
    masked_abs_by_feature = np.zeros(len(observation_mask.masked_indices), dtype=np.float64)
    masked_sq_by_feature = np.zeros(len(observation_mask.masked_indices), dtype=np.float64)
    masked_count_by_feature = np.zeros(len(observation_mask.masked_indices), dtype=np.float64)
    prior_abs_sum = 0.0
    prior_sq_sum = 0.0
    innovation_abs_sum = 0.0
    innovation_sq_sum = 0.0
    prior_abs_by_feature = np.zeros(len(observation_mask.masked_indices), dtype=np.float64)
    prior_sq_by_feature = np.zeros(len(observation_mask.masked_indices), dtype=np.float64)
    innovation_abs_by_feature = np.zeros(len(observation_mask.masked_indices), dtype=np.float64)
    innovation_sq_by_feature = np.zeros(len(observation_mask.masked_indices), dtype=np.float64)
    binary_target_indices = {
        int(spec.measured_index)
        for spec in getattr(model, "target_specs", ())
        if spec.measured_index is not None and spec.output_type == "binary"
    }
    binary_confusion = {
        int(index): {"tp": 0, "tn": 0, "fp": 0, "fn": 0, "brier_sum": 0.0, "count": 0}
        for index in observation_mask.masked_indices
        if int(index) in binary_target_indices
    }
    observed_abs_sum = 0.0
    observed_sq_sum = 0.0
    observed_count = 0
    for start in range(0, len(bundle.windows), batch_size):
        windows = torch.as_tensor(bundle.windows[start:start + batch_size], dtype=torch.float32, device=device)
        targets = torch.as_tensor(bundle.targets[start:start + batch_size], dtype=torch.float32, device=device)
        values = windows.clone()
        mask = torch.ones_like(windows)
        mask.index_fill_(-1, masked_indices, 0.0)
        values.index_fill_(-1, masked_indices, 0.0)
        with torch.no_grad():
            output = model.predict_update_sequence(values, mask)
            reconstruction = output.posterior_measured[:, -1, :]
            delta_t_steps, exogenous_indices, _ = (
                _nominal_real_trajectory_configuration(
                    config or {}, feature_columns, observation_mask, windows.shape[1]
                )
            )
            trajectory = model.nominal_real_trajectories(
                values,
                mask,
                delta_t_steps=delta_t_steps,
                exogenous_measured_indices=exogenous_indices,
                p_real_output=output,
            )
            prior_a = trajectory.p_nominal[:, : len(feature_columns)]
        masked_error = reconstruction.index_select(1, masked_indices) - targets.index_select(1, masked_indices)
        observed_error = reconstruction.index_select(1, observed_index_tensor) - targets.index_select(1, observed_index_tensor)
        masked_abs_sum += float(torch.abs(masked_error).sum().cpu())
        masked_sq_sum += float((masked_error ** 2).sum().cpu())
        masked_count += int(masked_error.numel())
        masked_abs_by_feature += torch.abs(masked_error).sum(dim=0).detach().cpu().numpy()
        masked_sq_by_feature += (masked_error ** 2).sum(dim=0).detach().cpu().numpy()
        masked_count_by_feature += float(masked_error.shape[0])
        scaling = (config or {}).get("_reconstructed_variable_scaling") or {}
        feature_mean = scaling.get("feature_mean") or [0.0] * len(feature_columns)
        feature_std = scaling.get("feature_std") or [1.0] * len(feature_columns)
        for feature_idx, counts in binary_confusion.items():
            prediction_raw = torch.clamp(
                reconstruction[:, feature_idx] * float(feature_std[feature_idx])
                + float(feature_mean[feature_idx]),
                min=0.0,
                max=1.0,
            )
            truth_raw = torch.clamp(
                targets[:, feature_idx] * float(feature_std[feature_idx])
                + float(feature_mean[feature_idx]),
                min=0.0,
                max=1.0,
            )
            prediction_class = prediction_raw >= 0.5
            truth_class = truth_raw >= 0.5
            counts["tp"] += int(torch.sum(prediction_class & truth_class).cpu())
            counts["tn"] += int(torch.sum(~prediction_class & ~truth_class).cpu())
            counts["fp"] += int(torch.sum(prediction_class & ~truth_class).cpu())
            counts["fn"] += int(torch.sum(~prediction_class & truth_class).cpu())
            counts["brier_sum"] += float(
                torch.sum((prediction_raw - truth_raw) ** 2).cpu()
            )
            counts["count"] += int(prediction_raw.numel())
        prior_error = prior_a.index_select(1, masked_indices) - targets.index_select(1, masked_indices)
        innovation = prior_a.index_select(1, masked_indices) - reconstruction.index_select(1, masked_indices)
        prior_abs_sum += float(torch.abs(prior_error).sum().cpu())
        prior_sq_sum += float((prior_error ** 2).sum().cpu())
        innovation_abs_sum += float(torch.abs(innovation).sum().cpu())
        innovation_sq_sum += float((innovation ** 2).sum().cpu())
        prior_abs_by_feature += torch.abs(prior_error).sum(dim=0).detach().cpu().numpy()
        prior_sq_by_feature += (prior_error ** 2).sum(dim=0).detach().cpu().numpy()
        innovation_abs_by_feature += torch.abs(innovation).sum(dim=0).detach().cpu().numpy()
        innovation_sq_by_feature += (innovation ** 2).sum(dim=0).detach().cpu().numpy()
        observed_abs_sum += float(torch.abs(observed_error).sum().cpu())
        observed_sq_sum += float((observed_error ** 2).sum().cpu())
        observed_count += int(observed_error.numel())
    masked_feature_metrics: dict[str, dict[str, float]] = {}
    for position, feature_idx in enumerate(observation_mask.masked_indices):
        count = max(float(masked_count_by_feature[position]), 1.0)
        feature_name = feature_columns[feature_idx] if feature_idx < len(feature_columns) else str(feature_idx)
        masked_feature_metrics[feature_name] = {
            "mae": float(masked_abs_by_feature[position] / count),
            "rmse": float(np.sqrt(masked_sq_by_feature[position] / count)),
            "nominal_open_loop_mae": float(prior_abs_by_feature[position] / count),
            "nominal_open_loop_rmse": float(np.sqrt(prior_sq_by_feature[position] / count)),
            "real_nominal_gap_mae": float(innovation_abs_by_feature[position] / count),
            "real_nominal_gap_rmse": float(np.sqrt(innovation_sq_by_feature[position] / count)),
        }
        if int(feature_idx) in binary_confusion:
            counts = binary_confusion[int(feature_idx)]
            sensitivity = counts["tp"] / max(counts["tp"] + counts["fn"], 1)
            specificity = counts["tn"] / max(counts["tn"] + counts["fp"], 1)
            masked_feature_metrics[feature_name].update(
                {
                    "output_type": "binary",
                    "f1": float(
                        2 * counts["tp"]
                        / max(2 * counts["tp"] + counts["fp"] + counts["fn"], 1)
                    ),
                    "balanced_accuracy": float((sensitivity + specificity) / 2.0),
                    "brier_score": float(
                        counts["brier_sum"] / max(counts["count"], 1)
                    ),
                }
            )
        else:
            masked_feature_metrics[feature_name]["output_type"] = "continuous"
    baseline_metrics = _virtual_sensor_baseline_metrics(
        bundle,
        observation_mask,
        feature_columns,
        virtual_sensor_baselines,
    )
    return {
        "masked_feature_count": float(len(observation_mask.masked_indices)),
        "masked_mae": float(masked_abs_sum / max(masked_count, 1)),
        "masked_rmse": float(np.sqrt(masked_sq_sum / max(masked_count, 1))),
        "nominal_open_loop_mae": float(prior_abs_sum / max(masked_count, 1)),
        "nominal_open_loop_rmse": float(np.sqrt(prior_sq_sum / max(masked_count, 1))),
        "real_nominal_gap_mae": float(innovation_abs_sum / max(masked_count, 1)),
        "real_nominal_gap_rmse": float(np.sqrt(innovation_sq_sum / max(masked_count, 1))),
        "nominal_open_loop_available": True,
        "observed_mae": float(observed_abs_sum / max(observed_count, 1)),
        "observed_rmse": float(np.sqrt(observed_sq_sum / max(observed_count, 1))),
        "baselines": baseline_metrics,
        "masked_features": masked_feature_metrics,
    }


def _virtual_sensor_baseline_metrics(
    bundle: WindowBundle,
    observation_mask: ObservationMaskSpec,
    feature_columns: list[str],
    baselines: dict[str, Any] | None,
) -> dict[str, Any]:
    """Evaluate the dependency-matched affine comparator on identical targets."""

    del feature_columns
    if not baselines or not observation_mask.masked_indices:
        return {}
    if "target_models" not in baselines:
        raise ConfigError("V18 requires dependency-matched ridge baselines")
    ridge = dependency_matched_ridge_metrics(bundle.targets, baselines)
    values = np.asarray(bundle.targets, dtype=np.float64)
    per_target: dict[str, dict[str, float]] = {}
    all_errors: list[np.ndarray] = []
    for target_index, target_model in baselines["target_models"].items():
        index = int(target_index)
        error = float(target_model["normal_mean"]) - values[:, index]
        all_errors.append(error)
        per_target[str(target_model["name"])] = {
            "mae": float(np.mean(np.abs(error))),
            "rmse": float(np.sqrt(np.mean(np.square(error)))),
        }
    concatenated = (
        np.concatenate(all_errors)
        if all_errors
        else np.zeros(0, dtype=np.float64)
    )
    normal_mean = {
        "mae": (
            float(np.mean(np.abs(concatenated))) if len(concatenated) else 0.0
        ),
        "rmse": (
            float(np.sqrt(np.mean(np.square(concatenated))))
            if len(concatenated)
            else 0.0
        ),
        "masked_features": per_target,
    }
    return {
        "comparison_protocol": (
            "identical targets, topology-restricted current inputs, splits, "
            "scaling, and validation data"
        ),
        "normal_mean": normal_mean,
        "linear_ridge": ridge,
    }


def extract_true_root_modules(bundle: WindowBundle, knowledge: SystemKnowledge, normal_labels: list[Any]) -> list[str]:
    if not bundle.root_causes:
        return []
    signal_to_module = knowledge.signal_to_module()
    result: list[str] = []
    for idx, value in enumerate(bundle.root_causes):
        if value is None or str(value).strip() == "":
            continue
        if bundle.labels and idx < len(bundle.labels) and bundle.labels[idx] in normal_labels:
            continue
        text = str(value).strip()
        if text in knowledge.module_names:
            result.append(text)
        elif text in signal_to_module:
            result.append(signal_to_module[text])
        else:
            result.append(text)
    return sorted(set(result))


def extract_true_component_fault_pairs(
    bundle: WindowBundle,
    knowledge: SystemKnowledge,
    normal_labels: list[Any],
) -> list[str]:
    """Map evaluation-only labels to component and fault-type pairs."""

    if not bundle.root_causes:
        return []
    faults = (bundle.metadata or {}).get("root_cause_fault", [])
    result: list[str] = []
    for idx, module_value in enumerate(bundle.root_causes):
        if bundle.labels and idx < len(bundle.labels) and bundle.labels[idx] in normal_labels:
            continue
        module = str(module_value or "").strip()
        fault_mode = str(faults[idx] if idx < len(faults) else "").strip()
        if not module or not fault_mode:
            continue
        sensor = knowledge.virtual_fault_sensor_for_fault(module, fault_mode)
        if sensor is None:
            raise ConfigError(
                "No supplied physical root-cause sensor for evaluation label "
                f"module={module!r}, fault={fault_mode!r}"
            )
        result.append(sensor.candidate_id)
    return sorted(set(result))


def diagnosis_excluded_cases(bundle: WindowBundle, config: dict[str, Any]) -> list[dict[str, str]]:
    """Return diagnosis cases excluded by explicit evaluation policy."""

    result: list[dict[str, str]] = []
    for group in dict.fromkeys(bundle.groups):
        indices = [idx for idx, value in enumerate(bundle.groups) if value == group]
        reason = _case_exclusion_reason(bundle, indices, config)
        if reason:
            result.append({"case_id": str(group), "reason": reason})
    return result


def _case_evaluation_contract(
    bundle: WindowBundle,
    indices: list[int],
    knowledge: SystemKnowledge,
) -> dict[str, Any]:
    """Return conservative publication metadata for one labeled fault case."""

    modules = {
        str(bundle.root_causes[idx]).strip()
        for idx in indices
        if bundle.root_causes is not None
        and idx < len(bundle.root_causes)
        and str(bundle.root_causes[idx]).strip()
    }
    faults = (bundle.metadata or {}).get("root_cause_fault", [])
    fault_modes = {
        str(faults[idx]).strip()
        for idx in indices
        if idx < len(faults) and str(faults[idx]).strip()
    }
    sensors = [
        knowledge.virtual_fault_sensor_for_fault(module, fault)
        for module in modules
        for fault in fault_modes
    ]
    claims = sorted(
        {
            sensor.detectability_claim
            for sensor in sensors
            if sensor is not None and sensor.detectability_claim
        }
    )
    subgroup = "main_evaluation"
    general_claim_allowed = True
    limitation = ""
    metadata = bundle.metadata or {}

    def _unique_metadata(name: str) -> str:
        values = {
            str(metadata[name][idx]).strip()
            for idx in indices
            if name in metadata
            and idx < len(metadata[name])
            and str(metadata[name][idx]).strip()
        }
        return ",".join(sorted(values))

    return {
        "evaluation_subgroup": subgroup,
        "general_detectability_claim_allowed": general_claim_allowed,
        "detectability_claims": ",".join(claims),
        "evaluation_limitation": limitation,
        "offline_fault_id": _unique_metadata("fault_id"),
        "offline_operating_mode": _unique_metadata("operating_mode"),
        "offline_fault_magnitude": _unique_metadata("fault_magnitude"),
        "offline_simulation_seed": _unique_metadata("simulation_seed"),
        "offline_fault_onset_step": _unique_metadata("fault_onset_step"),
        "offline_case_metadata_used_for_ranking": False,
    }


def _non_excluded_case_indices(bundle: WindowBundle, config: dict[str, Any]) -> list[int]:
    selected: list[int] = []
    for group in dict.fromkeys(bundle.groups):
        indices = [idx for idx, value in enumerate(bundle.groups) if value == group]
        if _case_exclusion_reason(bundle, indices, config):
            continue
        selected.extend(indices)
    return selected


def _case_exclusion_reason(bundle: WindowBundle, indices: list[int], config: dict[str, Any]) -> str | None:
    if not indices:
        return None
    diagnosis_cfg = config.get("diagnosis", {})
    case_id = str(bundle.groups[indices[0]])
    for pattern in diagnosis_cfg.get("exclude_case_patterns", []) or []:
        pattern_text = str(pattern)
        if fnmatch.fnmatchcase(case_id, pattern_text) or pattern_text in case_id:
            return f"case_id matches '{pattern_text}'"
    exclusions = diagnosis_cfg.get("exclude_root_cause_faults", []) or []
    if not exclusions:
        return None
    metadata = bundle.metadata or {}
    faults = metadata.get("root_cause_fault", [])
    fault_modes = metadata.get("fault_mode", [])
    fault_ids = metadata.get("fault_id", [])
    for exclusion in exclusions:
        if isinstance(exclusion, str):
            pattern = exclusion.strip().lower()
            if not pattern:
                raise ConfigError(
                    "diagnosis.exclude_root_cause_faults string entries must not be empty"
                )
            for idx in indices:
                candidates: list[str] = []
                if bundle.root_causes is not None and idx < len(bundle.root_causes):
                    candidates.append(str(bundle.root_causes[idx]).strip().lower())
                if idx < len(faults):
                    candidates.append(str(faults[idx]).strip().lower())
                if idx < len(fault_modes):
                    candidates.append(str(fault_modes[idx]).strip().lower())
                if idx < len(fault_ids):
                    fault_id = str(fault_ids[idx]).strip().lower()
                    candidates.extend((fault_id, f"idv{fault_id}"))
                if idx < len(bundle.labels):
                    candidates.append(str(bundle.labels[idx]).strip().lower())
                if any(
                    candidate
                    and (
                        candidate == pattern
                        or fnmatch.fnmatchcase(candidate, pattern)
                        or candidate.endswith(f"_{pattern}")
                    )
                    for candidate in candidates
                ):
                    return f"root-cause identifier matches {pattern!r}"
            continue
        if not isinstance(exclusion, dict):
            raise ConfigError(
                "diagnosis.exclude_root_cause_faults entries must be strings or mappings"
            )
        module_pattern = str(exclusion.get("module", "")).strip().lower()
        fault_pattern = str(exclusion.get("fault", "")).strip().lower()
        if not module_pattern or not fault_pattern:
            raise ConfigError("diagnosis.exclude_root_cause_faults entries require module and fault")
        for idx in indices:
            module = ""
            if bundle.root_causes is not None and idx < len(bundle.root_causes):
                module = str(bundle.root_causes[idx]).strip().lower()
            fault = str(faults[idx]).strip().lower() if idx < len(faults) else ""
            if not module or not fault:
                continue
            module_matches = fnmatch.fnmatchcase(module, module_pattern) or module == module_pattern
            fault_matches = fnmatch.fnmatchcase(fault, fault_pattern) or fault_pattern in fault
            if module_matches and fault_matches:
                return f"root_cause_module={module!r}, root_cause_fault={fault!r}"
    return None


def diagnose_cases_by_group(
    bundle: WindowBundle,
    residuals: np.ndarray,
    thresholds: np.ndarray,
    knowledge: SystemKnowledge,
    state_columns: list[str],
    config: dict[str, Any],
    normal_labels: list[Any],
    observation_mask: ObservationMaskSpec | None = None,
    fault_sensor_thresholds: dict[str, float] | None = None,
    sensor_timing_bounds: dict[str, dict[str, Any]] | None = None,
) -> tuple[pd.DataFrame, list[dict[str, Any]]]:
    frames: list[pd.DataFrame] = []
    cases: list[dict[str, Any]] = []
    case_policy = _label_free_case_window_policy(config)
    for group, indices in _bundle_group_indices(bundle).items():
        if not indices:
            continue
        diagnosis_indices = indices
        case_residuals = residuals[diagnosis_indices]
        diagnosis, meta = diagnose_component_fault_pairs(
            case_residuals,
            thresholds,
            knowledge,
            state_columns,
            config,
            times=[bundle.times[idx] for idx in diagnosis_indices],
            fault_sensor_thresholds=fault_sensor_thresholds,
            sensor_timing_bounds=sensor_timing_bounds,
            observation_mask=observation_mask,
        )
        # Predictions see every episode first. Labels only determine the
        # subsequent ground-truth evaluation cohort, never times or inputs.
        if _case_exclusion_reason(bundle, indices, config):
            continue
        case_bundle = _select_bundle(bundle, indices)
        true_candidates = extract_true_component_fault_pairs(
            case_bundle, knowledge, normal_labels
        )
        if not true_candidates:
            continue
        if not diagnosis.empty:
            evaluation_contract = _case_evaluation_contract(
                bundle, indices, knowledge
            )
            diagnosis = diagnosis.copy()
            diagnosis.insert(0, "case_id", str(group))
            diagnosis.insert(1, "true_root_causes", json.dumps(true_candidates))
            diagnosis.insert(2, "case_window_policy", case_policy)
            diagnosis.insert(3, "case_window_count", len(diagnosis_indices))
            for key, value in evaluation_contract.items():
                diagnosis[key] = value
            frames.append(diagnosis)
        else:
            evaluation_contract = _case_evaluation_contract(
                bundle, indices, knowledge
            )
        case = dict(meta.get("ranking_case") or {})
        case.setdefault("ranked_root_causes", [])
        case.setdefault("scores_by_root_cause", {})
        case["case_id"] = str(group)
        case["true_root_causes"] = true_candidates
        case["case_window_policy"] = case_policy
        case["case_window_count"] = len(diagnosis_indices)
        case["diagnosed"] = bool(case["ranked_root_causes"])
        case.update(evaluation_contract)
        cases.append(case)
    if frames:
        return pd.concat(frames, ignore_index=True), cases
    columns = [
        "case_id",
        "true_root_causes",
        "case_window_policy",
        "case_window_count",
        "rank",
        "root_cause",
        "component",
        "fault_type",
        "symptom_onset_index",
        "symptom_onset_time",
        "persistence_confirmation_index",
        "persistence_confirmation_time",
        "detected_onset",
        "detected_onset_time",
        "episode_end_time",
        "finite_episode_decision_time",
        "decision_scope",
        "decision_is_irreversible_online",
        "online_wait_condition_present",
        "time_axis_source",
        "time_axis_validated",
        "onset_interval_lower_time",
        "onset_interval_upper_time",
        "timestamp_synchronized",
        "sensor_synchronization_supplied",
        "raw_sample_period_seconds",
        "evaluation_stride_samples",
        "expected_evaluation_period_seconds",
        "persistence_unit",
        "timing_uncertainty_radius_seconds",
        "timing_uncertainty_source",
        "evidence_confidence",
        "evidence_confidence_source",
        "earliest_evidence",
        "earliest_evidence_kind",
        "active_constituent_count",
        "sensor_constituent_count",
        "sensor_threshold",
        "max_symptom",
        "likelihood",
        "measured_evidence_active",
        "virtual_evidence_active",
        "online_godel_evidence_active",
        "diagnosis_decision",
        "candidate_root_causes",
        "is_candidate",
    ]
    return pd.DataFrame(columns=columns), cases


def _label_free_case_window_policy(config: dict[str, Any]) -> str:
    policy = str(config.get("diagnosis", {}).get("case_window_policy", "all_case_windows"))
    if policy != "all_case_windows":
        raise ConfigError("Diagnosis requires all_case_windows. Fault labels may only be used for evaluation")
    return policy


def count_eligible_diagnosis_cases(
    bundle: WindowBundle,
    knowledge: SystemKnowledge,
    normal_labels: list[Any],
    config: dict[str, Any],
) -> int:
    """Count labeled fault cases that should receive a diagnosis ranking."""

    _label_free_case_window_policy(config)
    count = 0
    for group in dict.fromkeys(bundle.groups):
        indices = [idx for idx, value in enumerate(bundle.groups) if value == group]
        if not indices:
            continue
        if _case_exclusion_reason(bundle, indices, config):
            continue
        case_bundle = _select_bundle(bundle, indices)
        true_roots = extract_true_component_fault_pairs(
            case_bundle, knowledge, normal_labels
        )
        if not true_roots:
            continue
        count += 1
    return count


def _checkpoint_path(config: dict[str, Any]) -> Path:
    return expand_path(config["output"]["run_dir"], config["_project_root"]) / config["output"].get("checkpoint_name", "best_model.pt")


def _split_artifact_name(config: dict[str, Any], split: str, key: str, default: str) -> str:
    configured = config["output"].get(key, default)
    if split == "test":
        return str(configured)
    return f"{split}_{configured}"


def reconstructed_variable_reconstruction_metrics(
    observer: ObserverResidualResult | None,
    bundle: WindowBundle,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    config: dict[str, Any],
) -> dict[str, Any]:
    """Report reconstruction quality for every non-CSV technical state."""

    if observer is None or not knowledge.reconstructed_variables:
        return {
            "reconstructed_variable_count": float(len(knowledge.reconstructed_variables)),
            "available": False,
            "posterior_mae": 0.0,
            "posterior_rmse": 0.0,
            "prior_mae": 0.0,
            "prior_rmse": 0.0,
            "innovation_mae": 0.0,
            "innovation_rmse": 0.0,
            "variables": {},
        }
    targets = augmented_final_targets_numpy(
        bundle.windows,
        bundle.targets,
        knowledge,
        feature_columns,
        scaling=config.get("_reconstructed_variable_scaling"),
        oracle_windows=bundle.oracle_windows,
        oracle_columns=bundle.oracle_columns,
    )
    start = len(feature_columns)
    posterior = observer.p_real[:, start:]
    prior = observer.p_nominal[:, start:]
    reconstructed_targets = targets[:, start:]
    posterior_error = posterior - reconstructed_targets
    prior_error = prior - reconstructed_targets
    innovation = prior - posterior

    def summarize(values: np.ndarray) -> tuple[float, float]:
        return float(np.mean(np.abs(values))), float(np.sqrt(np.mean(values**2)))

    posterior_mae, posterior_rmse = summarize(posterior_error)
    prior_mae, prior_rmse = summarize(prior_error)
    innovation_mae, innovation_rmse = summarize(innovation)
    variables: dict[str, dict[str, Any]] = {}
    output_types = {
        spec.name: spec.output_type
        for spec in build_diagnostic_target_specs(feature_columns, knowledge, [], config)
    }
    for idx, specification in enumerate(knowledge.reconstructed_variables):
        post_mae, post_rmse = summarize(posterior_error[:, idx])
        pre_mae, pre_rmse = summarize(prior_error[:, idx])
        inn_mae, inn_rmse = summarize(innovation[:, idx])
        variables[specification.name] = {
            "module": specification.module,
            "kind": specification.kind,
            "source": specification.source,
            "function": specification.function,
            "inputs": list(specification.inputs),
            "posterior_mae": post_mae,
            "posterior_rmse": post_rmse,
            "prior_mae": pre_mae,
            "prior_rmse": pre_rmse,
            "innovation_mae": inn_mae,
            "innovation_rmse": inn_rmse,
        }
        is_binary = output_types[specification.name] == "binary"
        variables[specification.name]["output_type"] = (
            "binary" if is_binary else "continuous"
        )
        if is_binary:
            scaling = config.get("_reconstructed_variable_scaling") or {}
            mean = float((scaling.get("reconstructed_mean") or [0.0] * len(knowledge.reconstructed_variables))[idx])
            std = max(
                float((scaling.get("reconstructed_std") or [1.0] * len(knowledge.reconstructed_variables))[idx]),
                1.0e-8,
            )
            prediction_raw = np.clip(posterior[:, idx] * std + mean, 0.0, 1.0)
            target_raw = np.clip(reconstructed_targets[:, idx] * std + mean, 0.0, 1.0)
            predicted = prediction_raw >= 0.5
            expected = target_raw >= 0.5
            tp = int(np.sum(predicted & expected))
            tn = int(np.sum(~predicted & ~expected))
            fp = int(np.sum(predicted & ~expected))
            fn = int(np.sum(~predicted & expected))
            variables[specification.name].update(
                {
                    "f1": float(2 * tp / max(2 * tp + fp + fn, 1)),
                    "balanced_accuracy": float(
                        (
                            tp / max(tp + fn, 1)
                            + tn / max(tn + fp, 1)
                        )
                        / 2.0
                    ),
                    "brier_score": float(np.mean((prediction_raw - target_raw) ** 2)),
                }
            )
    return {
        "reconstructed_variable_count": float(len(knowledge.reconstructed_variables)),
        "available": True,
        "posterior_mae": posterior_mae,
        "posterior_rmse": posterior_rmse,
        "prior_mae": prior_mae,
        "prior_rmse": prior_rmse,
        "innovation_mae": innovation_mae,
        "innovation_rmse": innovation_rmse,
        "variables": variables,
    }


def observer_value_range_coverage(
    observer: ObserverResidualResult | None,
    bundle: WindowBundle,
    widths: dict[str, np.ndarray],
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    config: dict[str, Any],
    normal_labels: list[Any],
) -> dict[str, Any]:
    """Report offline empirical coverage separately for normal and fault rows."""

    if observer is None:
        return {"available": False}
    targets = augmented_final_targets_numpy(
        bundle.windows,
        bundle.targets,
        knowledge,
        feature_columns,
        scaling=config.get("_reconstructed_variable_scaling"),
        oracle_windows=bundle.oracle_windows,
        oracle_columns=bundle.oracle_columns,
    )
    current_inside = np.abs(observer.p_real - targets) <= np.asarray(
        widths["current"], dtype=np.float32
    ).reshape(1, -1)
    nominal_inside = np.abs(observer.p_nominal - targets) <= np.asarray(
        widths["nominal_selected"], dtype=np.float32
    ).reshape(1, -1)
    labels = np.asarray(
        list(bundle.labels) if bundle.labels is not None else [""] * len(targets),
        dtype=object,
    )
    normal_set = set(normal_labels)
    masks = {
        "all": np.ones(len(targets), dtype=bool),
        "normal": np.asarray([value in normal_set for value in labels], dtype=bool),
        "fault": np.asarray([value not in normal_set for value in labels], dtype=bool),
    }
    result: dict[str, Any] = {
        "available": True,
        "offline_labels_used_for_stratification_only": True,
        "value_unit": "training_standardized",
        "reference": "actual_recorded_or_supplied_offline_targets",
        "nominal_reference_available": False,
        "nominal_counterfactual_coverage_claimed": False,
        "legacy_aliases": {"nominal_range_coverage": "nominal_interval_contains_actual_value_fraction"},
    }
    for name, mask in masks.items():
        result[name] = {
            "window_count": int(mask.sum()),
            "current_range_coverage": (
                float(np.mean(current_inside[mask])) if bool(mask.any()) else None
            ),
            "nominal_range_coverage": (
                float(np.mean(nominal_inside[mask])) if bool(mask.any()) else None
            ),
            "nominal_interval_contains_actual_value_fraction": (
                float(np.mean(nominal_inside[mask])) if bool(mask.any()) else None
            ),
            "nominal_reference_coverage": None,
        }
    return result


def normal_case_false_alarm_metrics(
    bundle: WindowBundle,
    residuals: np.ndarray,
    thresholds: np.ndarray,
    knowledge: SystemKnowledge,
    state_columns: list[str],
    config: dict[str, Any],
    normal_labels: list[Any],
    observation_mask: ObservationMaskSpec,
    fault_sensor_thresholds: dict[str, float],
    sensor_timing_bounds: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    """Measure activation in held-out full-normal episodes or normal prefixes.

    Fault-bearing TEP runs have an initial normal interval but no separate
    entirely normal run. Its prefix is an offline normal evaluation segment,
    not a complete fault experiment. Never include a post-fault recovery
    interval, and never recalibrate thresholds on these held-out values.
    """

    if bundle.labels is None:
        return {"normal_case_count": 0, "available": False}
    normal_set = set(normal_labels)
    outcomes: list[bool] = []
    segments: list[dict[str, Any]] = []
    persistence = int(config.get("diagnosis", {}).get("onset_persistence", DEFAULT_ONSET_PERSISTENCE))
    for group, episode_indices in _bundle_group_indices(bundle).items():
        prefix_length = next(
            (position for position, index in enumerate(episode_indices)
             if bundle.labels[index] not in normal_set), len(episode_indices),
        )
        indices = episode_indices[:prefix_length]
        if len(indices) < persistence:
            continue
        frame, _metadata = diagnose_component_fault_pairs(
            residuals[indices],
            thresholds,
            knowledge,
            state_columns,
            config,
            times=[bundle.times[index] for index in indices],
            fault_sensor_thresholds=fault_sensor_thresholds,
            sensor_timing_bounds=sensor_timing_bounds,
            observation_mask=observation_mask,
        )
        outcomes.append(bool(frame["diagnostic_evidence_active"].any()))
        segments.append({
            "case_id": str(group),
            "kind": "full_normal_episode" if prefix_length == len(episode_indices) else "prefault_normal_prefix",
            "window_count": len(indices),
            "any_candidate_false_alarm": outcomes[-1],
        })
    return {
        "available": bool(outcomes),
        "evaluation_unit": "held_out_normal_episode_or_prefault_prefix",
        "normal_full_episode_count": sum(row["kind"] == "full_normal_episode" for row in segments),
        "normal_prefault_prefix_count": sum(row["kind"] == "prefault_normal_prefix" for row in segments),
        "normal_evaluated_window_count": sum(row["window_count"] for row in segments),
        "normal_segment_window_counts": [row["window_count"] for row in segments],
        "normal_segment_outcomes": segments,
        "normal_case_count": len(outcomes),
        "normal_case_any_candidate_false_alarm_count": int(sum(outcomes)),
        "normal_case_any_candidate_false_alarm_rate": (
            float(np.mean(outcomes)) if outcomes else None
        ),
        "labels_used_for_offline_normal_stratification_only": True,
    }


def _onset_sensitivity_summary(true_onset_rows, diagnosis_meta):
    """Keep comparison sentinels internal and report undefined times as null."""
    finite_detected = [
        float(row["detected_onset_time"])
        for row in true_onset_rows
        if np.isfinite(float(row.get("detected_onset_time", np.inf)))
    ]
    return {
        "eligible_true_sensor_cases": float(len(true_onset_rows)),
        "detected_true_sensor_cases": float(len(finite_detected)),
        "true_sensor_onset_coverage": (
            float(len(finite_detected) / len(true_onset_rows)) if true_onset_rows else 0.0
        ),
        "median_detected_onset_time": float(np.median(finite_detected)) if finite_detected else None,
        "median_detected_onset_time_status": (
            "observed" if finite_detected else "not_detected" if true_onset_rows else "not_applicable"
        ),
        "timing_uncertainty_representation": str(
            diagnosis_meta.get("timing_uncertainty_representation", "symmetric_onset_intervals")
        ),
    }


def _evaluate_model_split(
    model: nn.Module,
    bundle: WindowBundle,
    *,
    split: str,
    thresholds: np.ndarray,
    config: dict[str, Any],
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    batch_size: int,
    device: torch.device,
    observation_mask: ObservationMaskSpec,
    normal_labels: list[Any],
    run_dir: Path,
    virtual_sensor_baselines: dict[str, Any],
    fault_sensor_thresholds: dict[str, float],
    observer_value_range_radii: dict[str, np.ndarray],
    sensor_timing_bounds: dict[str, dict[str, Any]],
) -> dict[str, Any]:
    selected_bundle = _diagnosis_bundle(bundle, config, normal_labels)
    state_columns = diagnostic_state_columns(feature_columns, knowledge)
    observer_outputs: ObserverResidualResult | None = None
    if _fixed_observer_enabled(config):
        observer_outputs = compute_fixed_observer_outputs(
            model,
            selected_bundle,
            config,
            batch_size,
            device,
            observation_mask=observation_mask,
            knowledge=knowledge,
            feature_columns=feature_columns,
            value_range_radii=observer_value_range_radii,
            horizon_storage=(
                "residuals" if config["diagnosis"].get("export_observer_traces", False)
                else "none"
            ),
        )
        residuals = observer_outputs.residuals
        if bool(config["diagnosis"].get("export_observer_traces", False)):
            virtual_sensor_values, virtual_sensor_names, virtual_sensor_modules = (
                virtual_fault_sensor_traces(
                    residuals,
                    thresholds,
                    knowledge,
                    state_columns,
                    config,
                    observation_mask,
                    groups=selected_bundle.groups,
                )
            )
            trace_name = str(config["output"].get("observer_trace_name", "observer_outputs.npz"))
            trace_path = run_dir / (trace_name if split == "test" else f"{split}_{trace_name}")
            trajectory_trace = (
                {
                    "p_real": observer_outputs.p_real,
                    "p_nominal_open_loop": observer_outputs.p_nominal,
                    "horizon_raw_residuals": (
                        observer_outputs.horizon_raw_residuals
                        if observer_outputs.horizon_raw_residuals is not None
                        else np.zeros((len(observer_outputs.residuals), 0, 0), dtype=np.float32)
                    ),
                }
                if str(
                    config.get("diagnosis", {}).get("method_identifier", "")
                ).startswith("v18_")
                else {}
            )
            np.savez_compressed(
                trace_path,
                **trajectory_trace,
                residuals=observer_outputs.residuals,
                raw_residuals=observer_outputs.raw_residuals,
                filter_affine=(
                    observer_outputs.filter_affine
                    if observer_outputs.filter_affine is not None
                    else np.zeros((len(observer_outputs.residuals), 0), dtype=np.float32)
                ),
                filter_nonlinear_residual=(
                    observer_outputs.filter_nonlinear_residual
                    if observer_outputs.filter_nonlinear_residual is not None
                    else np.zeros((len(observer_outputs.residuals), 0), dtype=np.float32)
                ),
                filter_target_names=np.asarray(
                    observer_outputs.filter_target_names, dtype=str
                ),
                targets=augmented_final_targets_numpy(
                    selected_bundle.windows,
                    selected_bundle.targets,
                    knowledge,
                    feature_columns,
                    scaling=config.get("_reconstructed_variable_scaling"),
                    oracle_windows=selected_bundle.oracle_windows,
                    oracle_columns=selected_bundle.oracle_columns,
                ),
                state_columns=np.asarray(state_columns, dtype=str),
                feature_columns=np.asarray(feature_columns, dtype=str),
                reconstructed_variable_columns=np.asarray(
                    knowledge.reconstructed_variable_names, dtype=str
                ),
                virtual_fault_sensor_traces=virtual_sensor_values,
                virtual_fault_sensor_names=np.asarray(
                    virtual_sensor_names, dtype=str
                ),
                virtual_fault_sensor_modules=np.asarray(
                    virtual_sensor_modules, dtype=str
                ),
                virtual_fault_sensor_root_causes=np.asarray(
                    [
                        sensor.candidate_id
                        for sensor in active_virtual_fault_sensors(knowledge, config)
                    ],
                    dtype=str,
                ),
                virtual_fault_sensor_persistence=np.asarray(
                    [
                        int(
                            config.get("diagnosis", {}).get(
                                "onset_persistence",
                                DEFAULT_ONSET_PERSISTENCE,
                            )
                        )
                    ],
                    dtype=np.int64,
                ),
                virtual_fault_sensor_trace_alignment=np.asarray(
                    ["causal_trailing_persistent_interval_end"], dtype=str
                ),
                masked_feature_columns=np.asarray(observation_mask.masked_feature_columns, dtype=str),
                row_ids=np.asarray([str(value) for value in selected_bundle.row_ids], dtype=str),
                groups=np.asarray([str(value) for value in selected_bundle.groups], dtype=str),
                times=np.asarray([str(value) for value in selected_bundle.times], dtype=str),
            )
    else:
        residuals = compute_masked_residuals(
            model,
            selected_bundle,
            config,
            batch_size,
            device,
            observation_mask=observation_mask,
            knowledge=knowledge,
            feature_columns=feature_columns,
        )
    # Diagnostic residuals cannot evaluate signed trajectory rules. The
    # diagnostics below explicitly report this boundary and need no second
    # observer pass or materialized copies of the completed input windows.
    training_rules = _training_regularization_rules(knowledge, config)
    rule_diagnostics = _rule_diagnostics_for_residuals(
        residuals,
        thresholds,
        selected_bundle,
        knowledge,
        state_columns,
        config,
        include_rules=False,
        rules=training_rules,
        observation_mask=observation_mask,
    )
    full_rule_diagnostics = {
        "rule_partition": _rule_partition_summary(knowledge, config),
        "training_rules": _rule_diagnostics_for_residuals(
            residuals,
            thresholds,
            selected_bundle,
            knowledge,
            state_columns,
            config,
            include_rules=True,
            rules=training_rules,
            observation_mask=observation_mask,
        ),
        "all_rules": _rule_diagnostics_for_residuals(
            residuals,
            thresholds,
            selected_bundle,
            knowledge,
            state_columns,
            config,
            include_rules=True,
            observation_mask=observation_mask,
        ),
    }
    write_json(run_dir / f"{split}_rule_diagnostics.json", full_rule_diagnostics)
    audit_cfg = config.get("diagnosis", {}).get("evidence_channel_audit") or {}
    if bool(audit_cfg.get("enabled", False)):
        if observer_outputs is None:
            raise ConfigError(
                "The evidence-channel audit requires fixed-observer outputs"
            )
        onset_audit, audit_arrays = evidence_channel_onset_audit(
            selected_bundle,
            observer_outputs,
            thresholds,
            knowledge,
            state_columns,
            config,
            normal_labels,
            fault_sensor_thresholds,
            observation_mask,
            value_range_radii=observer_value_range_radii,
        )
        audit_stem = str(
            config["output"].get(
                "evidence_channel_audit_name", "evidence_channel_audit"
            )
        )
        audit_prefix = audit_stem if split == "test" else f"{split}_{audit_stem}"
        onset_audit.to_csv(
            run_dir / f"{audit_prefix}_onsets.csv", index=False
        )
        np.savez_compressed(
            run_dir / f"{audit_prefix}_traces.npz",
            **audit_arrays,
            row_ids=np.asarray(
                [str(value) for value in selected_bundle.row_ids], dtype=str
            ),
            groups=np.asarray(
                [str(value) for value in selected_bundle.groups], dtype=str
            ),
            times=np.asarray(
                [str(value) for value in selected_bundle.times], dtype=str
            ),
        )
        matched_reference = matched_root_local_no_fault_audit(
            selected_bundle,
            audit_arrays.get("p_real", audit_arrays.get("measured_value")),
            knowledge,
            state_columns,
            config,
            normal_labels,
            observation_mask,
        )
        matched_reference.to_csv(
            run_dir / f"{audit_prefix}_matched_no_fault.csv", index=False
        )
        write_json(
            run_dir / f"{audit_prefix}_manifest.json",
            {
                "audit_protocol": (
                    "nominal_real_open_loop_evidence_channel_audit"
                    if str(getattr(model, "method_version", "")).startswith("v18_")
                    else "unsupported_method"
                ),
                "method_version": str(
                    getattr(model, "method_version", "unknown_method")
                ),
                "detector_threshold_protocol": detector_threshold_protocol(
                    str(getattr(model, "method_version", "unknown_method"))
                ),
                "value_scale": "training_standardized",
                "variable_symptom_threshold": _symptom_threshold(config),
                "fault_sensor_thresholds": fault_sensor_thresholds,
                "onset_persistence": int(
                    config.get("diagnosis", {}).get(
                        "onset_persistence", DEFAULT_ONSET_PERSISTENCE
                    )
                ),
                "case_channel_row_count": int(len(onset_audit)),
                "matched_root_local_row_count": int(len(matched_reference)),
                "fault_labels_used_for_observer_or_ranking": False,
                "fault_labels_used_for_offline_audit_annotation": True,
                "offline_reference_targets_exported": True,
                "offline_oracle_values_used_for_diagnosis": False,
                "named_sensor_is_not_detectability_proof": True,
                "nominal_trajectory_semantics": (
                    "normal_model_open_loop_rollout_not_guaranteed_fault_free_"
                    "counterfactual"
                ),
                "matched_no_fault_reference_required": bool(
                    audit_cfg.get("matched_no_fault_reference", False)
                ),
            },
        )
    diagnosis, diagnosis_meta = diagnose_component_fault_pairs(
        residuals,
        thresholds,
        knowledge,
        state_columns,
        config,
        # This aggregate artifact can contain several independent cases whose
        # local clocks restart. It is not used for the primary case-level
        # diagnosis metrics. Passing those concatenated timestamps would
        # violate the strict V18 time-axis contract and could create artificial
        # temporal order across case boundaries.
        times=None,
        fault_sensor_thresholds=fault_sensor_thresholds,
        sensor_timing_bounds=sensor_timing_bounds,
        observation_mask=observation_mask,
    )
    diagnosis_meta["aggregate_trace_time_axis_is_non_primary"] = True
    diagnosis_meta["aggregate_trace_time_axis_reason"] = (
        "independent_case_clocks_are_not_concatenated"
    )
    diagnosis.to_csv(
        run_dir / _split_artifact_name(config, split, "diagnosis_name", "root_causes.csv"),
        index=False,
    )
    excluded_cases = diagnosis_excluded_cases(selected_bundle, config)
    non_excluded_indices = _non_excluded_case_indices(selected_bundle, config)
    true_root_cause_bundle = (
        _select_bundle(selected_bundle, non_excluded_indices)
        if non_excluded_indices
        else selected_bundle
    )
    true_root_causes = (
        extract_true_component_fault_pairs(
            true_root_cause_bundle, knowledge, normal_labels
        )
        if non_excluded_indices
        else []
    )
    case_diagnosis, cases = diagnose_cases_by_group(
        selected_bundle,
        residuals,
        thresholds,
        knowledge,
        state_columns,
        config,
        normal_labels,
        observation_mask=observation_mask,
        fault_sensor_thresholds=fault_sensor_thresholds,
        sensor_timing_bounds=sensor_timing_bounds,
    )
    case_diagnosis.to_csv(
        run_dir / _split_artifact_name(config, split, "case_diagnosis_name", "root_causes_by_case.csv"),
        index=False,
    )
    if not cases and true_root_causes and diagnosis_meta.get("ranking_case"):
        case = dict(diagnosis_meta["ranking_case"])
        case["true_root_causes"] = true_root_causes
        cases.append(case)
    candidate_universe = active_root_cause_candidates(knowledge, config)
    evaluation = root_cause_ranking_metrics(
        cases,
        candidate_universe,
        k_values=(1, int(config["diagnosis"].get("top_k", 3))),
    )
    evaluation.update(unconditional_root_cause_metrics(
        cases,
        candidate_universe,
        k_values=(1, int(config["diagnosis"].get("top_k", 3))),
    ))
    evaluation_cases = cases
    evaluation_universe = candidate_universe
    evaluation["root_cause_evaluation_resolution"] = "exact_component_fault_pair"
    evaluation["timing_uncertainty_representation"] = str(
        diagnosis_meta.get(
            "timing_uncertainty_representation", "symmetric_onset_intervals"
        )
    )
    eligible_case_count = count_eligible_diagnosis_cases(
        selected_bundle,
        knowledge,
        normal_labels,
        config,
    )
    diagnosed_case_count = int(evaluation.get("diagnosis_case_count", 0.0))
    evaluation["eligible_case_count"] = float(eligible_case_count)
    evaluation["diagnosis_case_coverage"] = (
        float(diagnosed_case_count / eligible_case_count)
        if eligible_case_count
        else 0.0
    )
    pd.DataFrame(root_cause_case_outcomes(
        evaluation_cases,
        evaluation_universe,
        k_values=(1, int(config["diagnosis"].get("top_k", 3))),
    )).to_csv(
        run_dir / _split_artifact_name(config, split, "case_outcomes_name", "case_outcomes.csv"),
        index=False,
    )
    write_json(
        run_dir / _split_artifact_name(config, split, "evaluation_name", "diagnosis_metrics.json"),
        evaluation,
    )
    anomaly_scores = (
        _variable_symptom_matrix(
            _normalized_diagnostic_residuals(
                _diagnostic_residuals(residuals, observation_mask, config), thresholds, config),
            config,
        ).max(axis=1)
        if len(residuals)
        else np.asarray([])
    )
    true_onset_rows: list[pd.Series] = []
    for _case_id, frame in case_diagnosis.groupby("case_id", sort=False):
        encoded = str(frame.iloc[0].get("true_root_causes", "[]"))
        try:
            declared = {str(value) for value in json.loads(encoded)}
        except (TypeError, ValueError, json.JSONDecodeError):
            declared = set()
        matches = frame[frame["root_cause"].astype(str).isin(declared)]
        if not matches.empty:
            true_onset_rows.append(matches.iloc[0])
    onset_sensitivity = _onset_sensitivity_summary(true_onset_rows, diagnosis_meta)
    range_coverage = observer_value_range_coverage(
        observer_outputs,
        selected_bundle,
        observer_value_range_radii,
        knowledge,
        feature_columns,
        config,
        normal_labels,
    )
    false_alarm_metrics = normal_case_false_alarm_metrics(
        selected_bundle,
        residuals,
        thresholds,
        knowledge,
        state_columns,
        config,
        normal_labels,
        observation_mask,
        fault_sensor_thresholds,
        sensor_timing_bounds,
    )
    return {
        "anomaly_metrics": anomaly_metrics(
            selected_bundle.labels,
            anomaly_scores,
            normal_labels,
            threshold=_symptom_threshold(config),
        ),
        "root_cause_evaluation": evaluation,
        "onset_sensitivity": onset_sensitivity,
        "observer_value_range_coverage": range_coverage,
        "normal_case_false_alarm_metrics": false_alarm_metrics,
        "partial_observation_reconstruction": partial_observation_reconstruction_metrics(
            model,
            selected_bundle,
            batch_size,
            device,
            observation_mask,
            feature_columns,
            config=config,
            knowledge=knowledge,
            virtual_sensor_baselines=virtual_sensor_baselines,
        ),
        "reconstructed_variable_reconstruction": reconstructed_variable_reconstruction_metrics(
            observer_outputs,
            selected_bundle,
            knowledge,
            feature_columns,
            config,
        ),
        "observer_outputs": {
            "protocol": _diagnosis_scoring_protocol(config),
            "p_real_available": bool(observer_outputs is not None),
            "p_nominal_open_loop_available": bool(observer_outputs is not None),
            "state_columns": state_columns,
            "delta_t_steps": int(
                observer_outputs.delta_t_steps
                if observer_outputs is not None
                else 0
            ),
            "delta_t_boundary_index": int(
                observer_outputs.boundary_index
                if observer_outputs is not None
                else -1
            ),
            "reconstructed_variable_count": float(len(knowledge.reconstructed_variables)),
            "value_ranges_enabled": bool(
                (config.get("diagnosis", {}).get("value_ranges") or {}).get(
                    "enabled", False
                )
            ),
            "trace_exported": bool(
                observer_outputs is not None and config["diagnosis"].get("export_observer_traces", False)
            ),
            "target_path_contributions": (
                {
                    name: {
                        "mean_absolute_affine": float(
                            np.mean(np.abs(observer_outputs.filter_affine[:, index]))
                        ),
                        "mean_absolute_nonlinear_residual": float(
                            np.mean(
                                np.abs(
                                    observer_outputs.filter_nonlinear_residual[:, index]
                                )
                            )
                        ),
                        "nonlinear_to_affine_ratio": float(
                            np.mean(
                                np.abs(
                                    observer_outputs.filter_nonlinear_residual[:, index]
                                )
                            )
                            / max(
                                float(
                                    np.mean(
                                        np.abs(observer_outputs.filter_affine[:, index])
                                    )
                                ),
                                1.0e-12,
                            )
                        ),
                    }
                    for index, name in enumerate(
                        observer_outputs.filter_target_names
                    )
                }
                if observer_outputs is not None
                and observer_outputs.filter_affine is not None
                and observer_outputs.filter_nonlinear_residual is not None
                else {}
            ),
        },
        "rule_diagnostics": rule_diagnostics,
        "diagnosis_window_selection": {
            "mode": str(
                (config.get("diagnosis", {}).get("window_selection") or {}).get(
                    "mode", "full_case"
                )
            ),
            "windows_before_limit": len(bundle.row_ids),
            "windows_after_limit": len(selected_bundle.row_ids),
            "groups_before_limit": len(set(bundle.groups)),
            "groups_after_limit": len(set(selected_bundle.groups)),
            "excluded_case_count": len(excluded_cases),
            "case_window_policy": _label_free_case_window_policy(config),
            "fault_phase_labels_used_for_offline_context_slicing": False,
            "fault_phase_labels_used_by_observer_or_ranking": False,
            "fault_labels_used_for_ground_truth_metrics_only": True,
        },
        "excluded_diagnosis_cases": excluded_cases,
        "true_root_causes": true_root_causes,
    }


def _with_selected_delta_t(
    config: dict[str, Any], delta_t_steps: int
) -> dict[str, Any]:
    selected = copy.deepcopy(config)
    delta_cfg = (
        selected.get("diagnosis", {})
        .get("nominal_real_trajectory", {})
        .get("delta_t", {})
    )
    sample_period = float(delta_cfg.get("sample_period_seconds", 1.0))
    selected["_delta_t_selection"] = {
        "selected_steps": int(delta_t_steps),
        "selected_seconds": float(delta_t_steps) * sample_period,
        "unit": "samples",
        "sample_period_seconds": sample_period,
        "selection_scope": "validation_only",
        "test_metrics_used_for_selection": False,
    }
    return selected


def _calibrate_diagnosis_candidate(
    model: nn.Module,
    normal_bundle: WindowBundle,
    config: dict[str, Any],
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    batch_size: int,
    device: torch.device,
    observation_mask: ObservationMaskSpec,
    *,
    model_selection_bundle: WindowBundle | None = None,
) -> dict[str, Any]:
    from .observed_commands import METHOD as COMMAND_METHOD
    if str(model.method_version) == COMMAND_METHOD:
        allowed = set(config.get("experiment", {}).get("dedicated_normal_calibration_groups", []))
        if (not allowed or not normal_bundle.groups
                or not set(normal_bundle.groups).issubset(allowed)
                or any(label != "normal" for label in normal_bundle.labels)
                or any(label is not None for label in normal_bundle.root_causes)):
            raise ConfigError("Command residual calibration requires dedicated normal calibration recordings")
        if model_selection_bundle is not None and (
                set(normal_bundle.groups).intersection(model_selection_bundle.groups)
                or set(normal_bundle.row_ids).intersection(model_selection_bundle.row_ids)):
            raise ConfigError("Command calibration must not reuse model-selection evidence")
    state_columns = diagnostic_state_columns(feature_columns, knowledge)
    observer = compute_fixed_observer_outputs(
        model,
        normal_bundle,
        config,
        batch_size,
        device,
        observation_mask=observation_mask,
        knowledge=knowledge,
        feature_columns=feature_columns,
    )
    from .observed_commands import METHOD as COMMAND_METHOD
    if str(model.method_version) == COMMAND_METHOD:
        widths = {"current": np.zeros(len(state_columns), dtype=np.float32),
                  "nominal_selected": np.zeros(len(state_columns), dtype=np.float32)}
    else:
        widths = calibrate_observer_value_range_radii(
            observer, normal_bundle, knowledge, feature_columns, config
        )
    value_range_summary = ({"mode": "direct_difference", "radii_subtracted": False,
                            "uncertainty_calibration": "direct_normal_residual_thresholds"}
                           if str(model.method_version) == COMMAND_METHOD else
                           observer_value_range_calibration_summary(
                               observer, normal_bundle, widths, knowledge, feature_columns,
                               config, model_selection_bundle=model_selection_bundle))
    residuals = (np.asarray(observer.raw_residuals).copy() if str(model.method_version) == COMMAND_METHOD
                 else apply_observer_value_ranges(observer, widths))
    thresholds = calibrate_thresholds(residuals, config)
    fault_sensor_thresholds, fault_sensor_summary = (
        calibrate_persistent_case_fault_sensor_thresholds(
            normal_bundle,
            residuals,
            thresholds,
            knowledge,
            state_columns,
            config,
        )
    )
    sensor_timing_bounds, sensor_timing_summary = calibrate_sensor_timing_bounds(
        knowledge, config
    )
    raw = np.asarray(observer.raw_residuals, dtype=np.float64)
    prediction_indices = [i for i in range(raw.shape[-1])
                          if i not in getattr(model, "observed_command_indices", ())]
    normal_mae = float(np.mean(np.abs(raw[:, prediction_indices]))) if raw.size else float("inf")
    return {
        "config": config,
        "observer": observer,
        "value_range_radii": widths,
        "value_range_calibration_summary": value_range_summary,
        "residuals": residuals,
        "thresholds": thresholds,
        "fault_sensor_thresholds": fault_sensor_thresholds,
        "fault_sensor_threshold_summary": fault_sensor_summary,
        "sensor_timing_bounds": sensor_timing_bounds,
        "sensor_timing_summary": sensor_timing_summary,
        "normal_validation_mae": normal_mae,
    }


def _v18_delta_t_selection_key(row: dict[str, Any]) -> tuple[float, float]:
    """Rank comparison windows using normal validation evidence only."""

    return (
        float(row["normal_validation_mae"]),
        float(row["delta_t_steps"]),
    )


def _select_v18_delta_t(
    model: nn.Module,
    normal_bundle: WindowBundle,
    validation_bundle: WindowBundle,
    config: dict[str, Any],
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    batch_size: int,
    device: torch.device,
    observation_mask: ObservationMaskSpec,
    normal_labels: list[Any],
    run_dir: Path,
    virtual_sensor_baselines: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], list[dict[str, Any]]]:
    delta_cfg = (
        config["diagnosis"]["nominal_real_trajectory"].get("delta_t") or {}
    )
    candidates = [int(value) for value in delta_cfg.get("candidates") or []]
    sensitivity: list[dict[str, Any]] = []
    calibrated: dict[int, dict[str, Any]] = {}
    validation_results: dict[int, dict[str, Any]] = {}
    for candidate in candidates:
        candidate_config = _with_selected_delta_t(config, candidate)
        candidate_calibration = _calibrate_diagnosis_candidate(
            model,
            normal_bundle,
            candidate_config,
            knowledge,
            feature_columns,
            batch_size,
            device,
            observation_mask,
        )
        candidate_dir = run_dir / "delta_t_validation" / f"samples_{candidate}"
        candidate_dir.mkdir(parents=True, exist_ok=True)
        validation_result = _evaluate_model_split(
            model,
            validation_bundle,
            split="val",
            thresholds=candidate_calibration["thresholds"],
            config=candidate_config,
            knowledge=knowledge,
            feature_columns=feature_columns,
            batch_size=batch_size,
            device=device,
            observation_mask=observation_mask,
            normal_labels=normal_labels,
            run_dir=candidate_dir,
            virtual_sensor_baselines=virtual_sensor_baselines,
            fault_sensor_thresholds=candidate_calibration["fault_sensor_thresholds"],
            observer_value_range_radii=candidate_calibration["value_range_radii"],
            sensor_timing_bounds=candidate_calibration[
                "sensor_timing_bounds"
            ],
        )
        evaluation = validation_result["root_cause_evaluation"]
        row = {
            "delta_t_steps": candidate,
            "delta_t_seconds": float(candidate)
            * float(delta_cfg.get("sample_period_seconds", 1.0)),
            "normal_validation_mae": candidate_calibration[
                "normal_validation_mae"
            ],
            "validation_reconstruction": validation_result[
                "partial_observation_reconstruction"
            ],
            "validation_onset": validation_result["onset_sensitivity"],
            "validation_diagnosis": evaluation,
            "selection_input": {
                "normal_validation_mae": True,
                "fault_validation_metrics": False,
                "test_metrics": False,
            },
        }
        sensitivity.append(row)
        calibrated[candidate] = candidate_calibration
        validation_results[candidate] = validation_result

    selected_row = min(sensitivity, key=_v18_delta_t_selection_key)
    selected_steps = int(selected_row["delta_t_steps"])
    selection = {
        "candidate_steps": candidates,
        "candidate_seconds": [
            float(value) * float(delta_cfg.get("sample_period_seconds", 1.0))
            for value in candidates
        ],
        "selected_steps": selected_steps,
        "selected_seconds": float(selected_row["delta_t_seconds"]),
        "unit": "samples",
        "sample_period_seconds": float(
            delta_cfg.get("sample_period_seconds", 1.0)
        ),
        "selection_scope": "validation_only",
        "selection_rule": (
            "min_normal_validation_open_loop_mae_then_shorter_delta_t"
        ),
        "fault_validation_metrics_used_for_selection": False,
        "test_metrics_used_for_selection": False,
    }
    selected_config = _with_selected_delta_t(config, selected_steps)
    selected_config["_delta_t_selection"].update(selection)
    selected_calibration = calibrated[selected_steps]
    selected_calibration["config"] = selected_config
    return (
        selection,
        selected_calibration,
        validation_results[selected_steps],
        sensitivity,
    )


def _record_split_result_metrics(
    metrics: dict[str, Any], split: str, result: dict[str, Any]
) -> None:
    """Attach one V18 evaluation split without reintroducing module-level roots."""

    metrics[f"{split}_anomaly_metrics"] = result["anomaly_metrics"]
    metrics[f"{split}_root_cause_evaluation"] = result["root_cause_evaluation"]
    metrics[f"{split}_onset_sensitivity"] = result["onset_sensitivity"]
    metrics[f"{split}_observer_value_range_coverage"] = result[
        "observer_value_range_coverage"
    ]
    metrics[f"{split}_normal_case_false_alarm_metrics"] = result[
        "normal_case_false_alarm_metrics"
    ]
    metrics[f"{split}_partial_observation_reconstruction"] = result[
        "partial_observation_reconstruction"
    ]
    metrics[f"{split}_reconstructed_variable_reconstruction"] = result[
        "reconstructed_variable_reconstruction"
    ]
    metrics[f"{split}_observer_outputs"] = result["observer_outputs"]
    metrics[f"{split}_rule_diagnostics"] = result["rule_diagnostics"]
    metrics[f"{split}_diagnosis_window_selection"] = result[
        "diagnosis_window_selection"
    ]
    metrics[f"{split}_excluded_diagnosis_cases"] = result[
        "excluded_diagnosis_cases"
    ]
    metrics[f"true_root_causes_in_{split}"] = result["true_root_causes"]


def train_lgb(config: dict[str, Any], prepared_data: PreparedData | None = None) -> dict[str, Any]:
    if config.get("active_dataset") in {"hai_cpps_v2", "hai_cpps_v21"}:
        raise ConfigError(
            "HAI requires the dedicated campaign runner with disjoint normal "
            "selection and calibration runs. Use run_hai_one_step_pilot.py for "
            "the approved HAI-2.1 one-step plans, not generic train_lgb.")
    run_started = time.perf_counter()
    one_step_training = config.get("training", {}).get("trajectory_training_protocol") == "one_step_short_history_v1"
    from .training_modes import strategy_metadata
    if one_step_training:
        config.setdefault("experiment", {}).update(
            algorithm_version=ONE_STEP_ALGORITHM, paper_evidence_status="one_step_training_revision")
    else:
        config.setdefault("experiment", {}).update(
            algorithm_version=RECURSIVE_ALGORITHM,
            paper_evidence_status="corrected_recursive_objective_not_archival_replay")
    set_seed(int(config["training"].get("seed", 42)))
    prepare_started = time.perf_counter()
    prepared = prepared_data if prepared_data is not None else prepare_data(config, train_on_normal_only=True)
    data_preparation_seconds = time.perf_counter() - prepare_started
    knowledge = load_system_knowledge(config, prepared.feature_columns)
    _validate_rule_partition(knowledge, config)
    if knowledge.reconstructed_variables:
        config["_reconstructed_variable_scaling"] = fit_reconstructed_variable_scaling(
            prepared.train.windows,
            knowledge,
            prepared.feature_columns,
            prepared.scaler.mean,
            prepared.scaler.std,
            oracle_windows=prepared.train.oracle_windows,
            oracle_columns=prepared.train.oracle_columns,
        )
    observation_mask = build_observation_mask(prepared.feature_columns, config)
    _validate_fixed_observer_configuration(config, observation_mask, knowledge)
    run_dir = ensure_dir(expand_path(config["output"]["run_dir"], config["_project_root"]))
    knowledge_text = render_knowledge_text(knowledge)
    (run_dir / config["output"].get("knowledge_text_name", "system_knowledge.txt")).write_text(knowledge_text, encoding="utf-8")
    batch_size = int(config["training"]["batch_size"])
    diagnosis_batch_size = int(config["diagnosis"].get("batch_size", batch_size))
    if diagnosis_batch_size < 1:
        raise ConfigError("diagnosis.batch_size must be positive")
    num_workers = int(config["training"].get("num_workers", 0))
    device = select_device(str(config["training"].get("device", "auto")))
    def execution_clock():
        # Wall time must include outstanding CUDA work, not only dispatch.
        if device.type == "cuda":
            torch.cuda.synchronize(device)
        return time.perf_counter()

    execution_timing = {"version": "separated_training_phases_v1", "cuda_synchronized": device.type == "cuda"}
    LOGGER.info("Training on %s with %d features, %d modules, %d predicates", device, len(prepared.feature_columns), len(knowledge.modules), len(knowledge.predicates))
    if observation_mask.enabled:
        LOGGER.info(
            "Partial observation masks %d feature columns: %s",
            len(observation_mask.masked_feature_columns),
            ", ".join(observation_mask.masked_feature_columns),
        )
    model = build_model(
        config,
        knowledge,
        len(prepared.feature_columns),
        feature_columns=prepared.feature_columns,
        masked_feature_columns=observation_mask.masked_feature_columns,
    ).to(device)
    if not is_structured_observer(model):
        raise ConfigError("Only the V18 component-fault observer is active")
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config["training"].get("learning_rate", 1e-3)),
        weight_decay=float(config["training"].get("weight_decay", 0.0)),
    )
    normal_labels = prepared.dataset_config.get("normal_labels") or []
    ridge_alpha = float(
        config.get("diagnosis", {}).get(
            "virtual_sensor_baseline_ridge_alpha", 1.0e-3
        )
    )
    # The comparator sees the same normal-training target examples and the
    # observed subset of supplied dependencies. It must not read hidden input
    # oracles when the observer additionally uses predicted dependencies.
    ridge_training_values = prepared.train.windows.reshape(
        -1, len(prepared.feature_columns)
    )
    virtual_sensor_baselines = fit_dependency_matched_ridge(
        ridge_training_values,
        model,
        alpha=ridge_alpha,
    )
    if bool(
        (config.get("model", {}).get("structured_observer") or {}).get(
            "initialize_affine_from_ridge", True
        )
    ):
        model.initialize_affine_from_ridge(virtual_sensor_baselines)
    write_json(
        run_dir / "structured_target_manifest.json",
        {
            "method_version": str(model.method_version),
            "targets": model.target_manifest(),
            "ridge_alpha": ridge_alpha,
            "ridge_training_examples": int(len(ridge_training_values)),
        },
    )
    normal_val_bundle = _normal_only_bundle(prepared.val, normal_labels)
    pin_memory = device.type == "cuda" and bool(config["training"].get("pin_memory", True))
    train_loader = _make_loader(_fitting_bundle(prepared.train, config), batch_size, True, num_workers, pin_memory=pin_memory)
    val_loader = _make_loader(_fitting_bundle(normal_val_bundle, config), batch_size, False, num_workers, pin_memory=pin_memory)
    audit_started = execution_clock()
    execution_timing["setup_seconds"] = audit_started - run_started
    initial_training_rule_diagnostics = _structured_training_rule_diagnostics(
        model,
        val_loader,
        config,
        knowledge,
        prepared.feature_columns,
        device,
        observation_mask,
    )
    execution_timing["initial_audit_seconds"] = execution_clock() - audit_started
    execution_timing["train_epoch_seconds"] = []
    execution_timing["gradient_audit_epoch_seconds"] = []
    execution_timing["validation_epoch_seconds"] = []
    epochs = int(config["training"]["epochs"])
    patience = int(config["training"].get("early_stopping_patience", epochs))
    best_val = float("inf")
    best_selection_key = (float("inf"), float("inf"))
    best_state = copy.deepcopy(model.state_dict())
    bad_epochs = 0
    history: list[dict[str, Any]] = []
    val_observation_mask = observation_mask if observation_mask.apply_to_validation else None
    for epoch in range(1, epochs + 1):
        epoch_started = execution_clock()
        train_metrics = _epoch(
            model,
            train_loader,
            config,
            knowledge,
            prepared.feature_columns,
            device,
            optimizer,
            observation_mask,
        )
        validation_started = execution_clock()
        execution_timing["train_epoch_seconds"].append(validation_started - epoch_started)
        execution_timing["gradient_audit_epoch_seconds"].append(train_metrics["execution_gradient_audit_seconds"])
        val_metrics = _epoch(
            model,
            val_loader,
            config,
            knowledge,
            prepared.feature_columns,
            device,
            optimizer=None,
            observation_mask=val_observation_mask,
        )
        execution_timing["validation_epoch_seconds"].append(execution_clock() - validation_started)
        val_metrics["real_trajectory_error"] = float(
            val_metrics["real_trajectory_loss"]
        )
        val_metrics["nominal_trajectory_error"] = float(
            val_metrics["nominal_trajectory_loss"]
        )
        from .observed_commands import selection_key as normal_selection_key
        selection_key = normal_selection_key(val_metrics, config)
        if not np.isfinite(selection_key).all():
            raise ConfigError("Nonfinite normal model-selection objective")
        history.append({"epoch": epoch, "train": train_metrics, "val": val_metrics})
        LOGGER.info(
            "epoch=%d train=%.6f val=%.6f selection=%s",
            epoch,
            train_metrics["loss"],
            val_metrics["loss"],
            selection_key,
        )
        if selection_key < best_selection_key:
            best_selection_key = selection_key
            best_val = float(val_metrics["loss"])
            best_state = copy.deepcopy(model.state_dict())
            bad_epochs = 0
        else:
            bad_epochs += 1
            if bad_epochs >= patience:
                break
    model.load_state_dict(best_state)
    audit_started = execution_clock()
    final_training_rule_diagnostics = _structured_training_rule_diagnostics(
        model,
        val_loader,
        config,
        knowledge,
        prepared.feature_columns,
        device,
        observation_mask,
    )
    execution_timing["final_audit_seconds"] = execution_clock() - audit_started
    postfit_started = execution_clock()
    max_threshold_windows = int(config["diagnosis"].get("max_threshold_windows", 0)) or None
    fault_sensor_threshold_cfg = config["diagnosis"].get("fault_sensor_threshold") or {}
    fault_sensor_calibration_unit = str(
        fault_sensor_threshold_cfg.get("calibration_unit", "persistent_case")
    ).lower()
    if fault_sensor_calibration_unit != "persistent_case":
        raise ConfigError(
            "V18 requires persistent-case fault-sensor threshold calibration"
        )
    normal_threshold_bundle = _limit_bundle_contiguous_tail(
        normal_val_bundle, max_threshold_windows
    )
    state_columns = diagnostic_state_columns(prepared.feature_columns, knowledge)
    observer_value_range_radii: dict[str, np.ndarray] = {
        "current": np.zeros(len(state_columns), dtype=np.float32),
        "nominal_selected": np.zeros(len(state_columns), dtype=np.float32),
    }
    delta_t_selection: dict[str, Any] | None = None
    delta_t_sensitivity: list[dict[str, Any]] = []
    cached_validation_result: dict[str, Any] | None = None
    (
        delta_t_selection,
        selected_calibration,
        cached_validation_result,
        delta_t_sensitivity,
    ) = _select_v18_delta_t(
        model,
        normal_threshold_bundle,
        prepared.val,
        config,
        knowledge,
        prepared.feature_columns,
        diagnosis_batch_size,
        device,
        val_observation_mask,
        normal_labels,
        run_dir,
        virtual_sensor_baselines,
    )
    config["_delta_t_selection"] = copy.deepcopy(delta_t_selection)
    observer_value_range_radii = selected_calibration["value_range_radii"]
    observer_value_range_calibration = selected_calibration[
        "value_range_calibration_summary"
    ]
    val_residuals = selected_calibration["residuals"]
    thresholds = selected_calibration["thresholds"]
    fault_sensor_thresholds = selected_calibration["fault_sensor_thresholds"]
    fault_sensor_threshold_summary = selected_calibration[
        "fault_sensor_threshold_summary"
    ]
    sensor_timing_bounds = selected_calibration[
        "sensor_timing_bounds"
    ]
    sensor_timing_summary = selected_calibration["sensor_timing_summary"]
    normal_validation_rule_diagnostics = copy.deepcopy(final_training_rule_diagnostics)
    normal_validation_rule_diagnostics["split"] = "normal_validation_only"
    write_json(run_dir / "normal_validation_rule_diagnostics.json", {
        "rule_partition": _rule_partition_summary(knowledge, config),
        "training_rules": normal_validation_rule_diagnostics,
        "inactive_rules": "not evaluated as independent evidence",
    })
    evaluation_splits = config["diagnosis"].get("evaluation_splits", ["test"])
    if not isinstance(evaluation_splits, list) or not evaluation_splits:
        raise ConfigError("diagnosis.evaluation_splits must be a non-empty list containing val and/or test")
    unknown_splits = set(evaluation_splits).difference({"val", "test"})
    if unknown_splits:
        raise ConfigError(f"Unsupported diagnosis.evaluation_splits values: {sorted(unknown_splits)}")
    split_results: dict[str, dict[str, Any]] = {}
    for split in evaluation_splits:
        if split == "val" and cached_validation_result is not None:
            split_results[split] = cached_validation_result
        else:
            split_results[split] = _evaluate_model_split(
                model,
                getattr(prepared, split),
                split=split,
                thresholds=thresholds,
                config=config,
                knowledge=knowledge,
                feature_columns=prepared.feature_columns,
                batch_size=diagnosis_batch_size,
                device=device,
                observation_mask=observation_mask,
                normal_labels=normal_labels,
                run_dir=run_dir,
                virtual_sensor_baselines=virtual_sensor_baselines,
                fault_sensor_thresholds=fault_sensor_thresholds,
                observer_value_range_radii=observer_value_range_radii,
                sensor_timing_bounds=sensor_timing_bounds,
            )
    metrics = {
        "best_val_loss": best_val,
        "training_protocol": config["training"].get("trajectory_training_protocol", "recursive_legacy_v18"),
        "training_strategy": strategy_metadata(config),
        "training_history_steps": (int(config["training"]["history_steps"])
            if "mode" in config["training"] or getattr(model, "observed_command_indices", ())
            else int(train_loader.dataset.windows.shape[1] - 1)),
        "training_prediction_steps": _training_delta_t_steps(config, train_loader.dataset.windows.shape[1]),
        "algorithm_version": config.get("experiment", {}).get("algorithm_version", "ALG-V18"),
        "method_version": str(
            getattr(model, "method_version", "unknown_method")
        ),
        "detector_threshold_protocol": detector_threshold_protocol(
            str(getattr(model, "method_version", "unknown_method"))
        ),
        "model_selection": {
            "identifier": (
                "recorded_commands_normal_joint_real_nominal_phase_balanced_v1"
                if getattr(model, "observed_command_indices", ()) else
                "os1_normal_validation_lexicographic_real_then_nominal_one_step"
                if one_step_training else "v18_normal_validation_lexicographic_real_then_nominal_trajectory"
            ),
            "protocol": (
                "normal_validation_joint_real_nominal_phase_balanced"
                if getattr(model, "observed_command_indices", ()) else
                "normal_validation_lexicographic_real_then_nominal_trajectory"
            ),
            "best_key": [float(value) for value in best_selection_key],
            "fault_onset_metrics_used_for_selection": False,
            "test_metrics_used_for_selection": False,
        },
        "normal_validation_objectives": {
            "real_trajectory_error": float(best_selection_key[-2]),
            "nominal_trajectory_error": float(best_selection_key[-1]),
            "selection_scope": "normal_validation_only",
            "fault_labels_used": False,
            "test_metrics_used": False,
        },
        "delta_t_selection": delta_t_selection,
        "delta_t_sensitivity": delta_t_sensitivity,
        "runtime": {
            "total_seconds": float(time.perf_counter() - run_started),
            "data_preparation_seconds": float(data_preparation_seconds),
            "prepared_data_reused": bool(prepared_data is not None),
        },
        "history": history,
        "feature_columns": prepared.feature_columns,
        "structured_target_manifest": (
            model.target_manifest() if is_structured_observer(model) else []
        ),
        "training_rule_diagnostics": {
            "before_training": initial_training_rule_diagnostics,
            "after_selected_checkpoint": final_training_rule_diagnostics,
            "scope": "normal_validation_only",
        },
        "partial_observation": observation_mask.to_dict(),
        "canonical_diagnostic_variable_registry": (
            knowledge.diagnostic_variable_registry(
                prepared.feature_columns,
                observation_mask.masked_feature_columns,
            )
        ),
        "variable_sets": {
            **knowledge.diagnostic_variable_registry(
                prepared.feature_columns,
                observation_mask.masked_feature_columns,
            ),
            "reconstructed_variable_metadata": [
                asdict(item) for item in knowledge.reconstructed_variables
            ],
            "terminology": {
                "observed": "available as an online measurement",
                "reconstructed": (
                    "unavailable online and estimated without its current target"
                ),
                "state_role": "technical state used in the diagnostic model",
                "cause_role": "variable used by a supplied root-cause formula",
                "virtual": "an availability property, not a diagnostic role",
                "virtual_full_observability": (
                    "every candidate component has a supplied oracle-free virtual "
                    "fault sensor"
                ),
                "virtual_fault_sensor": (
                    "an engineer-specified component-owned diagnostic instrument "
                    "formed from persistent nominal-real residuals of named "
                    "diagnostic variables"
                ),
                "engineered_fault_mode_coverage": (
                    "a supplied mapping from fault families to sensor constituents, "
                    "not a guaranteed detection result"
                ),
                "local_fault_detectability_certified": (
                    "supplied physical assurance that every considered local fault "
                    "must create persistent local evidence"
                ),
            },
        },
        "diagnosis_observation": {
            "symptom_source": "p_real_minus_p_nominal_delta_t_open_loop",
            "scoring_protocol": "fixed_observer",
            "fixed_observation_configuration": True,
            "observed_symptom": "absolute_p_real_minus_p_nominal_open_loop",
            "virtual_evidence_mode": "nominal_real_open_loop",
            "online_oracle_allowed": False,
            "virtual_symptom": (
                "absolute_p_real_virtual_reconstruction_minus_p_nominal_open_loop"
            ),
            "evidence_assignment_mode": str(
                config.get("diagnosis", {}).get("evidence_assignment_mode", "owner")
            ),
            "variable_component_ownership": "supplied_exactly_once",
            "variable_component_ownership_source": (
                "supplied_system_knowledge_not_learned"
            ),
            "variable_component_mapping": {
                name: knowledge.signal_to_module()[name]
                for name in state_columns
            },
            "assignment_control_is_contract_violation": str(
                config.get("diagnosis", {}).get("evidence_assignment_mode", "owner")
            ).lower() != "owner",
            "virtual_fault_sensor_manifest": [
                asdict(sensor)
                for sensor in active_virtual_fault_sensors(knowledge, config)
            ],
            "active_root_cause_candidates": active_root_cause_candidates(
                knowledge, config
            ),
            "active_root_cause_candidate_count": float(
                len(active_root_cause_candidates(knowledge, config))
            ),
            "excluded_root_cause_candidates": sorted(
                {
                    sensor.candidate_id
                    for sensor in knowledge.virtual_fault_sensors
                }.difference(active_root_cause_candidates(knowledge, config))
            ),
            "virtual_fault_sensor_coverage": (
                knowledge.virtual_fault_sensor_coverage()
            ),
            "virtual_full_observability": bool(
                active_virtual_fault_sensors(knowledge, config)
            ) and all(knowledge.virtual_fault_sensor_coverage().values()),
            "virtual_full_observability_is_engineered_coverage_not_accuracy": True,
            "fault_labels_used_by_virtual_sensors_online": False,
            "nominal_trajectory_input": (
                "state_at_t_minus_delta_t_then_recursive_own_predictions_only"
            ),
            "nominal_real_trajectory": copy.deepcopy(
                config.get("diagnosis", {}).get("nominal_real_trajectory")
                or {"protocol": "not_applicable"}
            ),
            "online_godel_scoring": False,
            "training_godel_rule_base": "K_train_fault_preserving_only",
            "reconstructed_variable_coordinates": list(knowledge.reconstructed_variable_names),
            "reconstructed_variable_coordinates_are_named_bottleneck_dimensions": bool(
                knowledge.reconstructed_variables
            ),
            "causal_history_detached_between_filtering_steps": bool(
                config["training"].get("detach_causal_history", True)
            ),
            "lambda_real": float(config["training"].get("lambda_real", 1.0)),
            "lambda_nominal": float(
                config["training"].get("lambda_nominal", 1.0)
            ),
            "common_branch_error_loss_used": False,
            "trainable_latency_regularization_used": False,
            "value_ranges": copy.deepcopy(
                config["diagnosis"].get("value_ranges")
                or {"enabled": False}
            ),
            "logic_residual_scale": float(config["training"].get("logic_residual_scale", 1.0)),
            "symptom_threshold": _symptom_threshold(config),
            "symptom_representation": _symptom_representation(config),
            "diagnosis_batch_size": float(diagnosis_batch_size),
            "timing_uncertainty": copy.deepcopy(
                config.get("diagnosis", {}).get("timing_uncertainty") or {}
            ),
            "time_axis": copy.deepcopy(
                config.get("diagnosis", {}).get("time_axis") or {}
            ),
            "persistence_is_evaluated_per_constituent": True,
            "symptom_onset_and_confirmation_exported_separately": True,
            "decision_scope": "finite_episode_retrospective",
            "decision_is_irreversible_online": False,
            "online_wait_condition_present": False,
            "ranking_uses_detected_persistent_onset": True,
            "overlapping_onsets_return_ambiguity": True,
            "uncertainty_normalization": copy.deepcopy(
                config.get("diagnosis", {}).get("uncertainty_normalization") or {}
            ),
        },
        "rule_partition": _rule_partition_summary(knowledge, config),
        "prior_knowledge": _knowledge_prior_summary(knowledge, config),
        "knowledge_role_audit": {
            "architecture_uses_supplied_topology_for_input_selection": bool(
                str(
                    (
                        config.get("model", {}).get("structured_observer")
                        or {}
                    ).get("dependency_scope", "topology")
                )
                == "topology"
            ),
            "training_rule_regularization_enabled": bool(
                float(config.get("training", {}).get("beta", 0.0)) > 0.0
                and _training_regularization_rules(knowledge, config)
            ),
            "training_rule_groups": sorted(
                {
                    _rule_group(rule)
                    for rule in _training_regularization_rules(knowledge, config)
                }
            ),
            "training_rule_count": len(
                _training_regularization_rules(knowledge, config)
            ),
            "rule_loss_is_incremental_over_fixed_architecture": True,
            "online_godel_scoring_enabled": False,
        },
        "logic_history_summary": _logic_history_summary(history),
        "normal_validation_rule_diagnostics": normal_validation_rule_diagnostics,
        "module_names": knowledge.module_names,
        "predicate_names": knowledge.predicate_names,
        "threshold_calibration": {
            "windows_before_limit": float(len(normal_val_bundle.row_ids)),
            "windows_after_limit": float(len(normal_threshold_bundle.row_ids)),
            "max_threshold_windows": float(max_threshold_windows or 0),
        },
        "thresholds": {feature: float(value) for feature, value in zip(state_columns, thresholds)},
        "observer_value_range_radii": {
            "quantile": float(
                (config.get("diagnosis", {}).get("value_ranges") or {}).get(
                    "quantile", 0.99
                )
            ),
            "current": {
                feature: float(value)
                for feature, value in zip(state_columns, observer_value_range_radii["current"])
            },
            "nominal_selected": {
                feature: float(value)
                for feature, value in zip(state_columns, observer_value_range_radii["nominal_selected"])
            },
            "horizon_steps": int(
                observer_value_range_radii.get(
                    "nominal_horizon", np.zeros((0, len(state_columns)), dtype=np.float32)
                ).shape[0]
            ),
            "nominal_horizon": (
                np.asarray(observer_value_range_radii["nominal_horizon"], dtype=np.float32).tolist()
                if "nominal_horizon" in observer_value_range_radii
                else []
            ),
        },
        "observer_value_range_calibration": observer_value_range_calibration,
        "reconstructed_variables": [asdict(item) for item in knowledge.reconstructed_variables],
        "reconstructed_variable_scaling": {
            "fit_scope": str(
                (config.get("_reconstructed_variable_scaling") or {}).get(
                    "fit_scope", "not_applicable"
                )
            ),
            "variables": {
                name: {"mean": float(mean), "std": float(std)}
                for name, mean, std in zip(
                    knowledge.reconstructed_variable_names,
                    (config.get("_reconstructed_variable_scaling") or {}).get(
                        "reconstructed_mean", []
                    ),
                    (config.get("_reconstructed_variable_scaling") or {}).get(
                        "reconstructed_std", []
                    ),
                )
            },
        },
        "fault_sensor_thresholds": fault_sensor_thresholds,
        "fault_sensor_threshold_calibration": fault_sensor_threshold_summary,
        "sensor_timing_bounds": sensor_timing_summary,
        "system_info": system_info(),
        "table_reports": [asdict(report) for report in prepared.reports],
    }
    for split, result in split_results.items():
        _record_split_result_metrics(metrics, split, result)
    if "test" in split_results:
        metrics["root_cause_evaluation"] = split_results["test"]["root_cause_evaluation"]
        metrics["diagnosis_window_selection"] = split_results["test"]["diagnosis_window_selection"]
    write_json(run_dir / config["output"].get("metrics_name", "metrics.json"), metrics)
    checkpoint = {
        "checkpoint_format_version": 8,
        "algorithm_version": metrics["algorithm_version"],
        "training_protocol": metrics["training_protocol"],
        "method_version": str(
            getattr(model, "method_version", "unknown_method")
        ),
        "detector_threshold_protocol": detector_threshold_protocol(
            str(getattr(model, "method_version", "unknown_method"))
        ),
        "model_state": model.state_dict(),
        "config": config,
        "feature_columns": prepared.feature_columns,
        "partial_observation": observation_mask.to_dict(),
        "thresholds": thresholds.tolist(),
        "state_columns": state_columns,
        "observer_value_range_radii": {
            key: value.tolist() for key, value in observer_value_range_radii.items()
        },
        "fault_sensor_thresholds": fault_sensor_thresholds,
        "sensor_timing_bounds": sensor_timing_bounds,
        "best_val_loss": best_val,
        "best_selection_key": [float(value) for value in best_selection_key],
        "structured_target_manifest": (
            model.target_manifest() if is_structured_observer(model) else []
        ),
    }
    torch.save(checkpoint, _checkpoint_path(config))
    execution_timing["postfit_seconds"] = execution_clock() - postfit_started
    execution_timing["total_seconds"] = execution_clock() - run_started
    metrics["runtime"]["execution_timing"] = execution_timing
    write_json(run_dir / config["output"].get("metrics_name", "metrics.json"), metrics)
    return metrics


def diagnose_from_checkpoint(config: dict[str, Any], split: str = "test") -> pd.DataFrame:
    prepared = prepare_data(config, train_on_normal_only=True)
    knowledge = load_system_knowledge(config, prepared.feature_columns)
    checkpoint_path = _checkpoint_path(config)
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint does not exist: {checkpoint_path}")
    device = select_device(str(config["training"].get("device", "auto")))
    try:
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    except TypeError:
        checkpoint = torch.load(checkpoint_path, map_location=device)
    checkpoint_config = checkpoint.get("config", config)
    observation_mask = build_observation_mask(prepared.feature_columns, checkpoint_config)
    _validate_fixed_observer_configuration(
        checkpoint_config, observation_mask, knowledge
    )
    model = build_model(
        checkpoint_config,
        knowledge,
        len(checkpoint["feature_columns"]),
        feature_columns=list(checkpoint["feature_columns"]),
        masked_feature_columns=observation_mask.masked_feature_columns,
    ).to(device)
    model.load_state_dict(checkpoint["model_state"])
    bundle = getattr(prepared, split)
    batch_size = int(config["diagnosis"].get("batch_size", config["training"]["batch_size"]))
    if batch_size < 1:
        raise ConfigError("diagnosis.batch_size must be positive")
    bundle = _diagnosis_bundle(
        bundle,
        checkpoint_config,
        prepared.dataset_config.get("normal_labels") or [],
    )
    feature_columns = list(checkpoint["feature_columns"])
    state_columns = list(
        checkpoint.get(
            "state_columns", diagnostic_state_columns(feature_columns, knowledge)
        )
    )
    value_range_radii = {
        key: np.asarray(value, dtype=np.float32)
        for key, value in (
            checkpoint.get("observer_value_range_radii")
            or {
                "current": np.zeros(len(state_columns), dtype=np.float32),
                "nominal_selected": np.zeros(len(state_columns), dtype=np.float32),
            }
        ).items()
    }
    residuals = compute_fixed_observer_outputs(
        model,
        bundle,
        checkpoint_config,
        batch_size,
        device,
        observation_mask=observation_mask,
        knowledge=knowledge,
        feature_columns=feature_columns,
        value_range_radii=value_range_radii,
    ).residuals
    thresholds = np.asarray(checkpoint["thresholds"], dtype=np.float32)
    fault_sensor_thresholds = {
        str(key): float(value)
        for key, value in (checkpoint.get("fault_sensor_thresholds") or {}).items()
    }
    sensor_timing_bounds = {
        str(key): dict(value)
        for key, value in (checkpoint.get("sensor_timing_bounds") or {}).items()
    }
    diagnosis, _ = diagnose_component_fault_pairs(
        residuals,
        thresholds,
        knowledge,
        state_columns,
        checkpoint_config,
        times=bundle.times,
        fault_sensor_thresholds=fault_sensor_thresholds,
        sensor_timing_bounds=sensor_timing_bounds,
        observation_mask=observation_mask,
    )
    run_dir = ensure_dir(expand_path(config["output"]["run_dir"], config["_project_root"]))
    checkpoint_method_version = str(
        checkpoint.get(
            "method_version", getattr(model, "method_version", "unknown_method")
        )
    )
    write_json(
        run_dir / "diagnosis_replay_manifest.json",
        {
            "checkpoint": str(checkpoint_path),
            "method_version": checkpoint_method_version,
            "detector_threshold_protocol": detector_threshold_protocol(
                checkpoint_method_version
            ),
            "current_v18_checkpoint_required": True,
        },
    )
    diagnosis.to_csv(run_dir / config["output"].get("diagnosis_name", "root_causes.csv"), index=False)
    case_diagnosis, _ = diagnose_cases_by_group(
        bundle,
        residuals,
        thresholds,
        knowledge,
        state_columns,
        checkpoint_config,
        prepared.dataset_config.get("normal_labels") or [],
        observation_mask=observation_mask,
        fault_sensor_thresholds=fault_sensor_thresholds,
        sensor_timing_bounds=sensor_timing_bounds,
    )
    case_diagnosis.to_csv(run_dir / config["output"].get("case_diagnosis_name", "root_causes_by_case.csv"), index=False)
    return diagnosis
