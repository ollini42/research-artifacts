"""Latent Goedel observability diagnostics for modular technical systems."""

__version__ = "0.1.0"
