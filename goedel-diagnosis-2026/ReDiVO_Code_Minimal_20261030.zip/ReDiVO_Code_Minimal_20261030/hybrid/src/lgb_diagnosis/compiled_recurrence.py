"""Regional recurrent execution with the eager observer as the reference.

Only fixed-size filtering regions are compiled. Long diagnosis horizons
therefore do not create an unrolled compiler graph with thousands of steps.
Nominal history and rollout regions use direct PyTorch execution because C061
found residual binary-logit drift beyond the fixed numerical contract there.
No CUDA graphs are used, because successive differentiable regions retain
their outputs until the final backward pass.
"""
from __future__ import annotations

import torch
import itertools
import types
from .nominal_shutdown import shutdown_initial, shutdown_step


_region_ids = itertools.count()

# Preserve eager CUDA arithmetic at rounding-sensitive logic boundaries.
# In particular, do not contract separate multiply/add operations into FMA.
INDUCTOR_OPTIONS = {
    "triton.cudagraphs": False,
    "emulate_precision_casts": True,
    "eager_numerics.division_rounding": True,
    "eager_numerics.disable_ftz": True,
    "eager_numerics.use_pytorch_libdevice": True,
    # Recurrent regions return every intermediate output, not only their final
    # state. C060 showed a no-grad CUDA miscompile that preserved final states
    # but corrupted earlier outputs. Keep storage lifetimes conservative until
    # the affected compiler can prove those outputs remain live.
    "inplace_buffers": False,
    "allow_buffer_reuse": False,
}


class RegionalCallable:
    """Keep finite shape variants separate without changing global cache limits."""

    def __init__(self, function, backend):
        self.function = function
        self.backend = backend
        self.variants = {}

    def __call__(self, *args):
        if self.backend == "inductor" and self.function in (history_chunk, nominal_chunk):
            # Keep the exact reference arithmetic for long nominal trajectories.
            # Filtering remains compiled with conservative storage lifetimes.
            return self.function(*args)
        model, values = args[:2]
        key = (tuple(values.shape), tuple(values.stride()), str(values.device), values.dtype,
               torch.is_grad_enabled(), torch.is_inference_mode_enabled(),
               any(p.requires_grad for p in model.parameters()),
               next((a for a in reversed(args) if isinstance(a, bool)), None))
        if key not in self.variants:
            # Dynamo caches per code object. Independent model/shape variants
            # must not exhaust one global code object's recompilation budget.
            code = self.function.__code__.replace(
                co_name=f"{self.function.__name__}_region_{next(_region_ids)}")
            function = types.FunctionType(code, self.function.__globals__,
                                          code.co_name, self.function.__defaults__)
            options = dict(INDUCTOR_OPTIONS) if self.backend == "inductor" else None
            self.variants[key] = torch.compile(
                function, backend=self.backend, fullgraph=True, dynamic=False, options=options)
        return self.variants[key](*args)


def filter_chunk(model, values, mask, hidden, cell, previous, causal, groups, first, command_context):
    measured = [(p, s) for p, s in enumerate(model.target_specs) if s.measured_index is not None]
    reconstructed = [(p, s) for p, s in enumerate(model.target_specs) if s.reconstructed_index is not None]
    binary = [p for p, s in enumerate(model.target_specs) if s.output_type == "binary"]

    def indices(items):
        return torch.tensor(items, device=values.device, dtype=torch.long)

    measured_indices = indices([s.measured_index for _, s in measured])
    reconstructed_indices = indices([s.reconstructed_index for _, s in reconstructed])
    measured_positions = indices([p for p, _ in measured])
    reconstructed_positions = indices([p for p, _ in reconstructed])
    binary_positions = indices(binary)
    binary_targets = indices([model.target_specs[p].diagnostic_index for p in binary])
    means = model.diagnostic_mean.index_select(0, binary_targets)
    stds = model.diagnostic_std.index_select(0, binary_targets).clamp(min=1.e-8)
    outputs = [[] for _ in range(10)]
    for t in range(values.shape[1]):
        if not (first and t == 0):
            hidden, cell = model.causal_cell(previous, (hidden, cell))
        prior, causal_logits = model._causal_state(hidden, causal, command_context[:, t])
        current = values[:, t, :]
        available = mask[:, t, :] > .5
        measured_b = torch.where(available, current, prior[:, :model.num_features])
        reconstructed_b = prior[:, model.num_features:]
        online = torch.cat([measured_b, reconstructed_b], 1)
        logits, affine, residual = model._batched_updates(online, prior, hidden, groups)
        target_logits = torch.stack(logits, 1) if logits else values.new_zeros((values.shape[0], 0))
        updates = target_logits
        if binary:
            binary_updates = (target_logits.index_select(1, binary_positions).sigmoid() - means) / stds
            updates = updates.index_copy(1, binary_positions, binary_updates)
        if measured:
            measured_b = measured_b.index_copy(1, measured_indices, updates.index_select(1, measured_positions))
        if reconstructed:
            reconstructed_b = reconstructed_b.index_copy(
                1, reconstructed_indices, updates.index_select(1, reconstructed_positions))
        measured_b = torch.where(available, current, measured_b)
        full = torch.cat([measured_b, reconstructed_b], 1)
        entries = (
            measured_b, reconstructed_b, prior[:, :model.num_features],
            prior[:, model.num_features:], torch.cat([reconstructed_b, hidden], 1),
            torch.cat([prior[:, model.num_features:], hidden], 1), target_logits,
            causal_logits, torch.stack(affine, 1) if affine else values.new_zeros((values.shape[0], 0)),
            torch.stack(residual, 1) if residual else values.new_zeros((values.shape[0], 0)),
        )
        for destination, entry in zip(outputs, entries):
            destination.append(entry)
        previous = full.detach() if model.detach_causal_history else full
    return tuple(torch.stack(items, 1) for items in outputs), hidden, cell, previous


def history_chunk(model, values, hidden, cell):
    for t in range(values.shape[1]):
        hidden, cell = model.causal_cell(values[:, t, :], (hidden, cell))
    return hidden, cell


def nominal_chunk(model, commands, hidden, cell, causal, exogenous, command_context, shutdown_state):
    predictions, binary_logits = [], []
    for t in range(commands.shape[1]):
        predicted, logits = model._causal_state(hidden, causal, command_context[:, t])
        if model.binary_diagnostic_indices:
            binary_logits.append(logits.index_select(1, model._binary_indices))
        if exogenous.numel():
            predicted = predicted.index_copy(1, exogenous, commands[:, t, :])
        predicted, shutdown_state = shutdown_step(model, predicted, shutdown_state, command_context[:, t])
        predictions.append(predicted)
        # The final state is unused at the end of the last region. Updating it
        # here keeps a single region independent of its position in a rollout.
        hidden, cell = model.causal_cell(predicted, (hidden, cell))
    binary = (torch.stack(binary_logits, 1) if binary_logits
              else commands.new_empty((commands.shape[0], commands.shape[1], 0)))
    return torch.stack(predictions, 1), binary, hidden, cell, shutdown_state


def configure_recurrence(model, backend="eager", chunk_size=8):
    """Select explicit execution only, retaining parameter names and equations."""
    if backend not in {"eager", "inductor", "eager_compile"}:
        raise ValueError("recurrence_backend must be eager, inductor or eager_compile")
    if type(chunk_size) is not int or not 1 <= chunk_size <= 32:
        raise ValueError("recurrence_chunk_size must be an integer from 1 to 32")
    if backend != "eager":
        # AOTAutograd otherwise may reuse saved forward buffers after a first
        # backward. Rule audits retain this graph for several backward calls.
        # The flag must remain disabled during lazy backward compilation too.
        import torch._functorch.config as aot_config
        aot_config.donated_buffer = False
    model.recurrence_backend = backend
    model.nominal_recurrence_backend = "eager" if backend == "inductor" else backend
    model.recurrence_chunk_size = chunk_size
    functions = None
    if backend != "eager":
        compiler_backend = "eager" if backend == "eager_compile" else "inductor"
        functions = tuple(RegionalCallable(function, compiler_backend)
                          for function in (filter_chunk, history_chunk, nominal_chunk))
    # Do not register wrappers as child modules or change state_dict keys.
    object.__setattr__(model, "_recurrence_functions", functions)
    return model


def predict_update_compiled(model, values, mask):
    from .structured_observer import StructuredObserverOutput
    if values.ndim != 3 or mask.shape != values.shape or values.shape[-1] != model.num_features:
        raise ValueError("values and mask must have identical [batch,time,feature] shape")
    if values.shape[1] == 0:
        return model._predict_update_sequence_eager(values, mask)
    hidden = values.new_zeros((values.shape[0], model.hidden_dim))
    cell = torch.zeros_like(hidden)
    previous = values.new_zeros((values.shape[0], model.diagnostic_dim))
    command_context, _command_age = model.observed_command_features(values, mask)
    causal = model._packed_causal_parameters()
    groups = model._packed_update_parameters()
    outputs = [[] for _ in range(10)]
    step = model.recurrence_chunk_size
    for start in range(0, values.shape[1], step):
        block, hidden, cell, previous = model._recurrence_functions[0](
            model, values[:, start:start+step], mask[:, start:start+step],
            hidden, cell, previous, causal, groups, start == 0,
            command_context[:, start:start+step])
        for destination, entry in zip(outputs, block):
            destination.append(entry)
    return StructuredObserverOutput(*(torch.cat(items, 1) for items in outputs))


def history_state(model, history):
    hidden = history.new_zeros((history.shape[0], model.hidden_dim))
    cell = torch.zeros_like(hidden)
    step = model.recurrence_chunk_size
    for start in range(0, history.shape[1], step):
        hidden, cell = model._recurrence_functions[1](model, history[:, start:start+step], hidden, cell)
    return hidden, cell


def nominal_sequence(model, history, commands, exogenous, causal, command_context=None):
    hidden, cell = history_state(model, history)
    shutdown_state = shutdown_initial(model, history)
    predictions, logits = [], []
    step = model.recurrence_chunk_size
    if command_context is None:
        command_context = commands.new_empty((*commands.shape[:2], 0))
    for start in range(0, commands.shape[1], step):
        predicted, binary, hidden, cell, shutdown_state = model._recurrence_functions[2](
            model, commands[:, start:start+step], hidden, cell, causal, exogenous,
            command_context[:, start:start+step], shutdown_state)
        predictions.append(predicted)
        logits.append(binary)
    return torch.cat(predictions, 1), (
        torch.cat(logits, 1) if model.binary_diagnostic_indices else None)
