"""Healthy shutdown dynamics confined to the nominal rollout."""
from __future__ import annotations

import math
import numpy as np
import torch

from .config import ConfigError

VERSION = 'nominal_command_shutdown_v1'


def fit_shutdown(normal_training, oracle, references):
    """Fit event timing on complete normal training recordings only."""
    if (not len(normal_training) or normal_training.row_id.duplicated().any()
            or not normal_training.run_id.str.fullmatch(r'ds5_\d+_healthy__train').all()):
        raise ConfigError('Shutdown fitting requires ds5 normal training rows only')
    from .command_quality import pump_phases
    alpha = math.exp(-1.)  # Verified ds5 FirstOrder(T=1), one-second sampling.
    channels = []
    for target, reference in references.items():
        numerator, denominator = 0., 0.
        groups = []
        counts = np.zeros(4, np.int64)
        for _, group in normal_training.groupby('run_id', sort=False):
            group = group.sort_values('timestamp')
            if not np.array_equal(group.timestamp.to_numpy(), np.arange(len(group))):
                raise ConfigError('Shutdown fitting requires a contiguous one-second grid')
            u = group[reference['command']].to_numpy(np.float64)
            if not set(np.unique(u)).issubset({0., 150.}):
                raise ConfigError('Unsupported ds5 pump command')
            truth = oracle.loc[group.row_id, reference['oracle_column']].to_numpy(np.float64)
            if not np.isfinite(truth).all():
                raise ConfigError('Nonfinite normal training shutdown references')
            base, derivative = np.empty_like(u), np.zeros_like(u)
            base[0] = u[0]
            for t in range(1, len(u)):
                base[t] = alpha * base[t-1] + (1-alpha) * u[t]
                derivative[t] = alpha * derivative[t-1] - (u[t]-u[t-1])
            phase = pump_phases(u[None, :, None]).reshape(-1)
            valid = np.arange(len(u)) >= 240
            counts += np.bincount(phase[valid], minlength=4)
            groups.append((base[valid], derivative[valid], truth[valid], phase[valid]))
        if min(counts) < 1:
            raise ConfigError('Each normal command phase needs training support')
        for base, derivative, truth, phase in groups:
            weights = 1. / counts[phase]
            numerator += float(np.sum(weights * derivative * (truth-base)))
            denominator += float(np.sum(weights * derivative**2))
        if denominator <= 0:
            raise ConfigError('No normal command transitions available')
        lag_weight = float(np.clip(numerator/denominator, 0., 1-alpha))
        channels.append(dict(target=target, command=reference['command'], alpha=alpha,
                             fitting_phase_counts=counts.tolist(),
                             lag_weight=lag_weight, settle_steps=20))
    return dict(version=VERSION, fitted_split='normal_train_only', training_rows=len(normal_training),
                initial_history_steps=240, numerical_zero_tolerance_rev_min=1.e-6,
                upper_healthy_speed_rev_min=180., channels=channels)


def configure_nominal_shutdown(model, spec):
    """Attach no trainable parameters and no persistent state_dict entries."""
    if spec is None:
        model.nominal_shutdown = None
        return model
    if (spec.get('version') != VERSION or spec.get('fitted_split') != 'normal_train_only'
            or spec.get('initial_history_steps') != model.nominal_history_steps
            or model.observed_command_contract is None):
        raise ConfigError('Invalid nominal-only shutdown contract')
    rows = spec.get('channels', [])
    if not rows or len({r['target'] for r in rows}) != len(rows):
        raise ConfigError('Shutdown targets must be nonempty and unique')
    indices, commands, alpha, lag, settle = [], [], [], [], []
    for row in rows:
        target, command = row['target'], row['command']
        expected = target.rsplit('.', 1)[0].replace('.pump_', '.command.pump_') + '.speed'
        if (not target.endswith('.effective_speed') or command != expected
                or target not in model.feature_names or command not in model.observed_command_contract.names):
            raise ConfigError('Shutdown may constrain only its own declared pump speed')
        a, c, s = row['alpha'], row['lag_weight'], row['settle_steps']
        if (not math.isfinite(a) or not math.isfinite(c) or not 0 < a < 1
                or not 0 <= c <= 1-a or type(s) is not int
                or not 1 <= s <= model.observed_command_contract.age_cap_steps):
            raise ConfigError('Invalid causal shutdown coefficients')
        indices.append(model.feature_names.index(target))
        commands.append(model.observed_command_contract.names.index(command))
        alpha.append(a)
        lag.append(c)
        settle.append(s)
    device = model.diagnostic_mean.device
    for name, values, dtype in (('_shutdown_indices', indices, torch.long),
            ('_shutdown_commands', commands, torch.long), ('_shutdown_alpha', alpha, torch.float32),
            ('_shutdown_lag', lag, torch.float32), ('_shutdown_settle', settle, torch.float32)):
        model.register_buffer(name, torch.tensor(values, dtype=dtype, device=device), persistent=False)
    model.nominal_shutdown = spec
    return model


def shutdown_initial(model, history):
    if model.nominal_shutdown is None:
        return history.new_empty((history.shape[0], 0))
    command_indices = torch.tensor(model.observed_command_indices, device=history.device)
    command_indices = command_indices.index_select(0, model._shutdown_commands)
    u = history.index_select(-1, command_indices)
    u = u * model.diagnostic_std[command_indices] + model.diagnostic_mean[command_indices]
    delta = torch.cat([torch.zeros_like(u[:, :1]), u[:, 1:] - u[:, :-1]], 1)
    length = history.shape[1]
    powers = model._shutdown_alpha.unsqueeze(0).pow(
        torch.arange(length-1, -1, -1, device=history.device, dtype=history.dtype).unsqueeze(1))
    forcing = (1-model._shutdown_alpha) * u - model._shutdown_lag * delta
    return ((forcing * powers).sum(1)
            + u[:, 0] * model._shutdown_alpha.pow(length))


def shutdown_step(model, predicted, state, command_context):
    if model.nominal_shutdown is None:
        return predicted, state
    count = len(model.observed_command_indices)
    positions = model._shutdown_commands
    commands = torch.tensor(model.observed_command_indices, device=predicted.device).index_select(0, positions)
    std, mean = model.diagnostic_std[commands], model.diagnostic_mean[commands]
    u = command_context[:, :count].index_select(1, positions) * std + mean
    difference = command_context[:, count:2*count].index_select(1, positions) * std
    age = command_context[:, 2*count:].index_select(1, positions) * model.observed_command_contract.age_cap_steps
    state = model._shutdown_alpha * state + (1-model._shutdown_alpha) * u - model._shutdown_lag * difference
    command_off = u < 75.
    off = command_off & (age >= model.observed_command_contract.transient_steps)
    state = torch.where(command_off & (age >= model._shutdown_settle), torch.zeros_like(state), state)
    state = state.clamp(min=0.)
    indices = model._shutdown_indices
    standardized = (state-model.diagnostic_mean[indices]) / model.diagnostic_std[indices].clamp(min=1.e-8)
    replacement = torch.where(off, standardized, predicted.index_select(1, indices))
    return predicted.index_copy(1, indices, replacement), state
