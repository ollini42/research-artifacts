"""Gödel training rules on completed trajectories with explicit applicability.

Temporal relations compare adjacent increments at declared source/target times.
The targets argument is a normal-training reference for residual predicates
only. It never supplies temporal history, mode gates, or model inputs.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

import torch

from .config import ConfigError
from .knowledge import SystemKnowledge, RuleSpec, validate_linear_relation
from .model import evaluate_rule_torch


@dataclass
class PredicateTrajectories:
    truth: torch.Tensor
    valid: torch.Tensor
    trainable: torch.Tensor


def predicate_trajectories(
    values: torch.Tensor,
    targets: torch.Tensor,
    knowledge: SystemKnowledge,
    names: list[str],
    scale: float,
    *,
    start: int = 0,
    learned: torch.Tensor | None = None,
    mean: torch.Tensor | None = None,
    std: torch.Tensor | None = None,
    condition_values: torch.Tensor | None = None,
    condition_available: torch.Tensor | None = None,
    normal_operation: bool = True,
) -> PredicateTrajectories:
    """Return truth, evaluability, and a structural path to learned values.

    Boolean conditions are detached and must be available measurements.
    Lag intervals use an existential choice among excited source increments.
    An unexcited source is inapplicable, not evidence for delay satisfaction.
    """
    if values.ndim != 3 or values.shape != targets.shape or len(names) != values.shape[-1]:
        raise ConfigError("Gödel trajectories require matching [batch,time,variable] tensors")
    if not math.isfinite(scale) or scale <= 0:
        raise ConfigError("logic_residual_scale must be finite and positive")
    b, length, width = values.shape
    if not 0 <= start < length:
        raise ConfigError("Gödel start must lie in the trajectory")
    index = {name: i for i, name in enumerate(names)}
    learned = torch.ones_like(values, dtype=torch.bool) if learned is None else learned.bool().expand_as(values)
    mean = values.new_zeros(width) if mean is None else mean.to(values)
    std = values.new_ones(width) if std is None else std.to(values)
    if mean.shape != (width,) or std.shape != (width,):
        raise ConfigError("Gödel scaling requires one mean and standard deviation per variable")
    # Validate all device-resident inputs with one host transfer. Separate
    # Python truth tests forced five CUDA synchronizations for each branch.
    finite_values, finite_targets, finite_mean, finite_std, positive_std = torch.stack([
        torch.isfinite(values).all(), torch.isfinite(targets).all(),
        torch.isfinite(mean).all(), torch.isfinite(std).all(), (std > 0).all(),
    ]).detach().cpu().tolist()
    if not finite_values or not finite_targets:
        raise ConfigError("Gödel trajectory values and normal references must be finite")
    if not finite_mean or not finite_std or not positive_std:
        raise ConfigError("Gödel scaling requires finite positive standard deviations")
    physical = values * std + mean
    errors = (values - targets).abs()
    truths, validities, paths = [], [], []
    temporal = {"co_increase", "inverse_change", "pressure_level_compatible"}
    for p in knowledge.predicates:
        if not math.isfinite(p.tolerance) or p.tolerance <= 0:
            raise ConfigError(f"Invalid tolerance for {p.name}")
        denominator = float(scale) * p.tolerance
        valid = torch.ones((b, length), device=values.device, dtype=torch.bool)
        valid[:, :start] = False
        path = torch.zeros_like(valid)
        violation = values.new_zeros((b, length))
        arguments = [n for n in [p.signal, p.source, p.target, *p.signals, *p.operating_condition_signals] if n]
        if any(n not in index for n in arguments):
            raise ConfigError(f"Unknown Gödel variable in {p.name}")
        if p.kind in {"signal_band", "state_definition"}:
            if not p.signal:
                raise ConfigError(f"{p.name} requires a signal")
            j = index[p.signal]
            violation = errors[..., j]
            path = learned[..., j]
        elif p.kind == "linear_relation":
            validate_linear_relation(p)
            first = max(p.operand_lags)
            valid[:, :first] = False
            if first < length:
                # Reconstruct physical units before combining channels with
                # different means or scales. No target tensor is read here.
                error = values.new_full((b, length-first), -p.bias)
                normalizer = values.new_zeros(())
                for signal, coefficient, lag in zip(p.signals, p.coefficients, p.operand_lags):
                    j = index[signal]
                    left, right = first-lag, length-lag
                    error = error + coefficient * physical[:, left:right, j]
                    path[:, first:] |= learned[:, left:right, j]
                    normalizer = normalizer + abs(coefficient) * std[j]
                violation[:, first:] = torch.relu(error.abs()-p.noise_band) / normalizer
        elif p.kind == "mode_exclusive":
            if len(p.signals) < 2:
                raise ConfigError(f"{p.name} requires at least two mode signals")
            ix = [index[n] for n in p.signals]
            # Binary outputs are already probabilities after inverse scaling.
            # Avoid sigmoid tails producing penalties for legal one-hot modes.
            probability = physical[..., ix].clamp(0, 1)
            violation = torch.relu(probability.sum(-1) - 1)
            path = learned[..., ix].any(-1)
        else:
            if not p.source or not p.target:
                raise ConfigError(f"{p.name} requires source and target")
            i, j = index[p.source], index[p.target]
            path = learned[..., i] | learned[..., j]
            if p.kind == "connection_compatible":
                # Same symmetric truth as residual compatibility, with a
                # fixed lower-error reference in each update. The penalty
                # must never reduce itself by worsening the better endpoint.
                larger = torch.maximum(errors[..., i], errors[..., j])
                reference = torch.minimum(errors[..., i], errors[..., j]).detach()
                violation = (larger - reference).clamp_min(0)
                # The smaller endpoint is detached, so its learned status
                # cannot make this grounding trainable. At a tie, maximum
                # retains a path to both endpoints.
                path = (
                    (learned[..., i] & (errors[..., i] >= errors[..., j]))
                    | (learned[..., j] & (errors[..., j] >= errors[..., i]))
                )
            elif p.kind in {"value_compatible", "flow_balance"}:
                opposite = p.kind == "flow_balance" or "opposite" in p.relation.lower()
                violation = (physical[..., i] + (1 if opposite else -1) * physical[..., j]).abs() / (std[i] + std[j])
            elif p.kind == "delayed_follow":
                low, high = int(p.min_lag_steps), int(p.max_lag_steps)
                if low == high == 0:
                    low = high = int(p.lag_steps)
                if low < 1 or high < low:
                    raise ConfigError(f"{p.name} requires a positive ordered delay interval")
                if min(p.minimum_source_change, p.minimum_response_change) <= 0:
                    raise ConfigError(f"{p.name} requires justified positive source and response changes")
                if p.influence_sign not in {-1, 1}:
                    raise ConfigError(f"{p.name} requires a known influence sign")
                # The score is emitted at the closure of the response window.
                # Every lag compares a response to the SAME source event u.
                first = high + 1
                valid[:, :first] = False
                path = torch.zeros_like(valid)
                if first < length:
                    dx = values[:, 1:length-high, i] - values[:, :length-high-1, i]
                    candidates, linked = [], []
                    for lag in range(low, high + 1):
                        left, right = 1 + lag, length - high + lag
                        dy = values[:, left:right, j] - values[:, left-1:right-1, j]
                        candidates.append(torch.relu(p.minimum_response_change - p.influence_sign * dx.detach().sign() * dy))
                        linked.append(learned[:, left:right, j] | learned[:, left-1:right-1, j])
                    scores = torch.stack(candidates, -1)
                    choice = scores.argmin(-1, keepdim=True)
                    violation[:, first:] = scores.gather(-1, choice).squeeze(-1)
                    valid[:, first:] &= dx.detach().abs() >= p.minimum_source_change
                    # Event identity/direction are fixed for this evaluation.
                    # It cannot train an unknown source from a flat response.
                    path[:, first:] = torch.stack(linked, -1).gather(-1, choice).squeeze(-1)
            elif p.kind in temporal:
                low = int(p.min_lag_steps)
                high = int(p.max_lag_steps)
                if low == high == 0:
                    low = high = int(p.lag_steps)
                if low < 0 or high < low:
                    raise ConfigError(f"Invalid lag interval for {p.name}")
                if p.kind == "delayed_follow" and low < 1:
                    raise ConfigError(f"{p.name} requires a positive delay")
                direction = int(p.influence_sign or (-1 if p.kind == "inverse_change" else 1))
                candidates, candidate_valid, candidate_paths = [], [], []
                # Never truncate an advertised delay to fit the history.
                for lag in range(low, high + 1):
                    v = values.new_zeros((b, length))
                    eligible = torch.zeros_like(valid)
                    linked = torch.zeros_like(valid)
                    first = lag + 1
                    if first < length:
                        dx = values[:, 1:length-lag, i] - values[:, :length-lag-1, i]
                        dy = values[:, first:, j] - values[:, first-1:-1, j]
                        v[:, first:] = torch.relu(-direction * dx * dy)
                        eligible[:, first:] = dx.detach().abs() > 1.0e-8
                        linked[:, first:] = learned[:, 1:length-lag, i] | learned[:, :length-lag-1, i] | learned[:, first:, j] | learned[:, first-1:-1, j]
                    candidates.append(v)
                    candidate_valid.append(eligible)
                    candidate_paths.append(linked)
                cv = torch.stack(candidate_valid, -1)
                vv = torch.stack(candidates, -1).masked_fill(~cv, float("inf"))
                valid = valid & cv.any(-1)
                choice = vv.argmin(-1, keepdim=True)
                violation = torch.where(cv.any(-1), vv.gather(-1, choice).squeeze(-1), torch.zeros_like(violation))
                # Count a grounding as connected only if the selected lag has
                # a learned coordinate. Ties use deterministic first lag.
                path = torch.stack(candidate_paths, -1).gather(-1, choice).squeeze(-1)
            elif p.kind == "state_level_direction":
                gate = physical[..., i].clamp(0, 1)
                delta = values[:, 1:, j] - values[:, :-1, j]
                sign = -1 if "non_increasing" in p.relation else 1
                violation[:, 1:] = gate[:, 1:] * torch.relu(-sign * delta)
                valid[:, 0] = False
                path[:, 1:] |= learned[:, :-1, j]
            else:
                raise ConfigError(f"Unsupported predicate kind {p.kind!r}")
        condition = p.operating_condition
        if condition == "normal_closed_loop_operation":
            valid = valid & normal_operation
        elif condition in {"all_active", "any_active", "none_active"}:
            if not p.operating_condition_signals or condition_values is None or condition_available is None:
                raise ConfigError(f"{p.name} requires independent observed operating conditions")
            ix = [index[n] for n in p.operating_condition_signals]
            available = condition_available[..., ix].bool().all(-1)
            raw = condition_values.detach()[..., ix] * std[ix] + mean[ix]
            # A missing or overflowing condition is unknown, including for
            # none_active. A failed comparison is not evidence of inactivity.
            available = available & torch.isfinite(raw).all(-1)
            active = raw > float(p.condition_threshold)
            gate = active.all(-1) if condition == "all_active" else (active.any(-1) if condition == "any_active" else ~active.any(-1))
            valid = valid & available & gate
        elif condition != "always":
            raise ConfigError(f"Unsupported operating condition {condition!r}")
        truths.append(1 / (1 + violation / denominator))
        validities.append(valid)
        paths.append(path)
    shape = (b, length, 0)
    return PredicateTrajectories(
        torch.stack(truths, -1) if truths else values.new_zeros(shape),
        torch.stack(validities, -1) if truths else torch.zeros(shape, device=values.device, dtype=torch.bool),
        torch.stack(paths, -1) if truths else torch.zeros(shape, device=values.device, dtype=torch.bool),
    )


def trajectory_rule_loss(branches: dict[str, PredicateTrajectories], knowledge: SystemKnowledge,
                         rules: list[RuleSpec], margin: float,
                         group_weights: dict[str, float] | None = None,
                         fixed_group_normalizer: float | None = None):
    """Average eligible groundings, then rules, then weighted rule groups.

    Disconnected and inapplicable instances do not enter rule means.
    Configured groups retain their coefficients even without eligible rules.
    Satisfied but applicable rules DO remain in the denominator. Every branch
    has equal importance for a rule when it supplies eligible groundings.
    """
    if not math.isfinite(margin) or not 0 < margin <= 1:
        raise ConfigError("logic_margin must lie in (0,1]")
    group_weights = group_weights or {}
    if any(not math.isfinite(w) or w < 0 for w in group_weights.values()):
        raise ConfigError("Logic group weights must be finite and non-negative")
    if fixed_group_normalizer is not None and (not math.isfinite(fixed_group_normalizer) or fixed_group_normalizer <= 0):
        raise ConfigError("Fixed logic group normalizer must be finite and positive")
    zero = next(iter(branches.values())).truth.sum() * 0
    pi = {p.name: i for i, p in enumerate(knowledge.predicates)}
    by_group: dict[str, list[torch.Tensor]] = {}
    diagnostics, terms = {}, {}
    # Collect all scalar audit statistics on device. One transfer replaces
    # seven or more synchronizations per rule and branch on CUDA.
    pending = []
    stats_device = []
    for rule in rules:
        names = [n for n in [rule.predicate, rule.antecedent, rule.consequent, *rule.predicates] if n]
        ix = [pi[n] for n in names]
        if not ix:
            raise ConfigError(f"Rule {rule.name} has no predicates")
        entries = []
        for name, data in branches.items():
            flat = data.truth.reshape(-1, len(pi))
            score = evaluate_rule_torch(flat, rule, pi)
            valid = data.valid[..., ix].all(-1).reshape(-1)
            connected = data.trainable[..., ix].any(-1).reshape(-1)
            eligible = valid & connected
            penalty = torch.relu(margin - score) * float(rule.weight)
            count = eligible.sum()
            denominator = count.clamp_min(1)
            term = (penalty * eligible).sum() / denominator
            stats_device.append(torch.stack([
                valid.sum(), count, (~valid).sum(), (valid & ~connected).sum(),
                (score * eligible).sum() / denominator, term.detach(),
                ((penalty > 0) & eligible).sum() / denominator,
            ]).detach())
            entries.append((name, term))
        pending.append((rule, entries))
    host_stats = torch.stack(stats_device).cpu().tolist() if stats_device else []
    cursor = 0
    for rule, entries in pending:
        branch_losses, branch_stats = [], {}
        for name, value in entries:
            row = host_stats[cursor]
            cursor += 1
            count = int(row[1])
            branch_stats[name] = {
                "valid_groundings": int(row[0]),
                "eligible_groundings": count,
                "inapplicable_groundings": int(row[2]),
                "disconnected_groundings": int(row[3]),
                "mean_truth": row[4] if count else None,
                "mean_residual": row[5] if count else None,
                "active_residual_fraction": row[6] if count else None,
            }
            if count:
                branch_losses.append(value)
        term = torch.stack(branch_losses).mean() if branch_losses else zero
        terms[rule.name] = term
        diagnostics[rule.name] = {"group": rule.group, "role": rule.role,
                                  "branches": branch_stats, "eligible": bool(branch_losses),
                                  "mean_residual": sum(s["mean_residual"] for s in branch_stats.values() if s["mean_residual"] is not None) / max(len(branch_losses), 1)}
        if branch_losses and rule.weight > 0 and group_weights.get(rule.group, 1.0) > 0:
            by_group.setdefault(rule.group, []).append(term)
    raw = {g: torch.stack(ts).mean() for g, ts in by_group.items()}
    if fixed_group_normalizer is not None:
        normalizer = fixed_group_normalizer
    elif group_weights:
        # Explicit group coefficients describe the experiment, not the
        # currently eligible minibatch. Retain omitted groups in the fixed
        # denominator and the default weight of undeclared rule groups.
        configured_groups = sorted(set(group_weights) | {rule.group for rule in rules if rule.weight > 0})
        normalizer = sum(group_weights.get(group, 1.0) for group in configured_groups)
    else:
        # Equal default group coefficients are fixed by the configured rules,
        # not by which groups happen to contribute in the current minibatch.
        normalizer = float(len({rule.group for rule in rules if rule.weight > 0}))
    weighted = {g: v * group_weights.get(g, 1.0) / normalizer for g, v in raw.items()}
    loss = torch.stack(list(weighted.values())).sum() if weighted else zero
    return loss, weighted, diagnostics, terms
