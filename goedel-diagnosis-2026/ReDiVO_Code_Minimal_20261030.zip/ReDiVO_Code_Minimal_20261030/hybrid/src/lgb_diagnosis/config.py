"""Fail-closed configuration loading for the active V18 method."""

from __future__ import annotations

import copy
import math
import os
from pathlib import Path
from typing import Any

import yaml


class ConfigError(ValueError):
    """Raised when a configuration is incomplete or scientifically invalid."""


ACTIVE_DATASET_FAMILIES = frozenset({"synthetic_graph_stress", "hybrid_automata", "tep_reinartz", "hai_cpps_v2", "hai_cpps_v21"})
PUBLICATION_DATASETS = frozenset({"tep_reinartz", "hai_cpps_v2", "hai_cpps_v21"})
STRESS_TEST_DATASETS = frozenset({"synthetic_graph_stress", "hybrid_automata"})
V18_METHOD_IDENTIFIER = "v18_audited_range_open_loop_component_fault_observer"
V18_ARCHITECTURE = "structured_predict_update_v18"
V18_PROTOCOL = "open_loop_v18"
ONE_STEP_ALGORITHM = "ALG-V18.3-OS1-R2"
RECURSIVE_ALGORITHM = "ALG-V18.3-RECURSIVE-R2"

# Exported only so archived metadata readers can name the historical boundary.
# New configurations are validated exclusively against V18 below.
V16_METHOD_IDENTIFIER = "v16_range_based_open_loop_component_fault_observer"
V16_ARCHITECTURE = "structured_predict_update_v16"
V16_PROTOCOL = "open_loop_v16"


def deep_update(base: dict[str, Any], updates: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_update(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def load_config(
    path: str | Path, overrides: dict[str, Any] | None = None, *,
    training_mode: str | None = None, history_steps: int | None = None,
    recursive_training_steps: int | None = None, approximation_reason: str | None = None,
    resolve_training: bool = False,
) -> dict[str, Any]:
    config_path = Path(path)
    if not config_path.exists():
        raise ConfigError(f"Configuration file does not exist: {config_path}")
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle) or {}
    if overrides:
        config = deep_update(config, overrides)
    if (resolve_training or training_mode is not None
            or config.get("training", {}).get("mode") is not None):
        from .training_modes import configure_training_mode
        config = configure_training_mode(
            config, training_mode, history_steps=history_steps,
            recursive_training_steps=recursive_training_steps,
            approximation_reason=approximation_reason)
    training = config.get("training", {})
    if (training.get("trajectory_training_protocol") == "one_step_short_history_v1"
            and "history_steps" not in training):
        # Resolve the complete one-step profile before validating it. The
        # original longest-rollout warmup is an initial value, not calibration.
        dataset = config.get("datasets", {}).get(config.get("active_dataset"), {})
        window = dataset.get("windows", {}).get("window_size")
        candidates = config.get("diagnosis", {}).get("nominal_real_trajectory", {}).get("delta_t", {}).get("candidates", [])
        if type(window) is int and candidates and all(type(h) is int for h in candidates):
            training["history_steps"] = window - max(candidates)
    config["_config_path"] = str(config_path.resolve())
    config["_project_root"] = str(config_path.resolve().parent.parent)
    validate_config(config)
    return config


def expand_path(value: str | Path, project_root: str | Path) -> Path:
    text = os.path.expandvars(os.path.expanduser(str(value)))
    path = Path(text)
    return path if path.is_absolute() else Path(project_root) / path


def active_dataset_config(config: dict[str, Any]) -> dict[str, Any]:
    name = str(config.get("active_dataset", ""))
    datasets = config.get("datasets") or {}
    if not name:
        raise ConfigError("Missing active_dataset")
    if name not in datasets:
        raise ConfigError(f"active_dataset {name!r} is not defined in datasets")
    dataset = copy.deepcopy(datasets[name])
    dataset["name"] = name
    return dataset


def _require_mapping(value: Any, name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ConfigError(f"{name} must be a mapping")
    return value


def validate_config(config: dict[str, Any]) -> None:
    """Validate the current method and explicitly admitted dataset families."""

    required = (
        "project",
        "datasets",
        "knowledge",
        "model",
        "training",
        "diagnosis",
        "output",
    )
    for section in required:
        if section not in config:
            raise ConfigError(f"Missing required top-level section: {section}")
    active_name = str(config.get("active_dataset", ""))
    if active_name not in ACTIVE_DATASET_FAMILIES:
        raise ConfigError(
            f"Dataset {active_name!r} is outside the active V18 scope. "
            f"Supported families are {sorted(ACTIVE_DATASET_FAMILIES)}."
        )
    dataset = active_dataset_config(config)
    catalog = dataset.get("catalog")
    if not isinstance(catalog, list) or not catalog:
        raise ConfigError("Active dataset catalog must contain at least one table")
    for index, entry in enumerate(catalog):
        if not isinstance(entry, dict):
            raise ConfigError(f"catalog[{index}] must be a mapping")
        for field in ("name", "role", "path", "key_column", "required_columns"):
            if field not in entry:
                raise ConfigError(f"catalog[{index}] is missing {field}")
        if entry["role"] not in {"features", "labels", "metadata", "groups", "oracle"}:
            raise ConfigError(f"Unsupported table role: {entry['role']}")
        if not isinstance(entry["required_columns"], list):
            raise ConfigError(f"required_columns must be a list for {entry['name']}")

    split = _require_mapping(dataset.get("split") or {}, "dataset.split")
    ratios = [float(split.get(key, 0.0)) for key in ("train_ratio", "val_ratio", "test_ratio")]
    if any(not math.isfinite(value) or value <= 0.0 for value in ratios) or abs(sum(ratios) - 1.0) > 1.0e-6:
        raise ConfigError("Positive train, validation, and test ratios must sum to one")
    windows = _require_mapping(dataset.get("windows") or {}, "dataset.windows")
    window_size = int(windows.get("window_size", 0))
    if window_size < 2:
        raise ConfigError("windows.window_size must be at least two")
    for name in ("stride", "train_stride", "evaluation_stride"):
        if int(windows.get(name, 1)) < 1:
            raise ConfigError(f"windows.{name} must be positive")

    model = _require_mapping(config["model"], "model")
    if str(model.get("architecture", "")) != V18_ARCHITECTURE:
        raise ConfigError(f"V18 requires model.architecture={V18_ARCHITECTURE}")
    structured = _require_mapping(
        model.get("structured_observer") or {}, "model.structured_observer"
    )
    if str(structured.get("dependency_scope", "topology")) not in {
        "topology",
        "all_available",
    }:
        raise ConfigError("structured_observer.dependency_scope is invalid")
    if int(structured.get("causal_hidden_dim", model.get("hidden_dim", 0))) < 1:
        raise ConfigError("structured_observer.causal_hidden_dim must be positive")
    if int(structured.get("residual_hidden_dim", 0)) < 1:
        raise ConfigError("structured_observer.residual_hidden_dim must be positive")
    if structured.get("recurrence_backend", "eager") not in {"eager", "inductor", "eager_compile"}:
        raise ConfigError("Unknown recurrence_backend")
    chunk_size = structured.get("recurrence_chunk_size", 8)
    if type(chunk_size) is not int or not 1 <= chunk_size <= 32:
        raise ConfigError("recurrence_chunk_size must be an integer from 1 to 32")

    training = _require_mapping(config["training"], "training")
    from .training_modes import training_mode
    mode = training_mode(config)
    if "mode" in training:
        prediction = training.get("prediction_steps")
        history = training.get("history_steps")
        if (type(prediction) is not int or type(history) is not int
                or min(prediction, history) < 1 or history + prediction > window_size):
            raise ConfigError("Training mode requires admissible history and prediction steps")
        if mode == "recursive" and prediction != training.get("recursive_training_steps"):
            raise ConfigError("Recursive mode and its fixed training horizon disagree")
    fitting_protocol = str(training.get("trajectory_training_protocol", "recursive_legacy_v18"))
    if fitting_protocol not in {"recursive_legacy_v18", "one_step_short_history_v1"}:
        raise ConfigError("Unknown trajectory_training_protocol")
    if fitting_protocol == "one_step_short_history_v1":
        history = training.get("history_steps")
        if type(history) is not int or not 1 <= history < window_size:
            raise ConfigError("One-step history must be positive and shorter than the diagnostic window")
        if training.get("prediction_steps", 1) != 1:
            raise ConfigError("One-step training requires prediction_steps=1")
    obsolete = {
        "lambda_logic",
        "lambda_ab_common_error",
        "lambda_virtual_prior",
        "lambda_reconstructed_variable",
        "lambda_reconstructed_nominal",
        "lambda_smooth",
        "lambda_latency",
        "detach_prior_history",
    }.intersection(training)
    if obsolete:
        raise ConfigError(f"Obsolete V18 training fields: {sorted(obsolete)}")
    if int(training.get("epochs", 0)) < 1 or int(training.get("batch_size", 0)) < 1:
        raise ConfigError("training.epochs and training.batch_size must be positive")
    if not bool(training.get("target_balanced", False)):
        raise ConfigError("V18 requires target-balanced training")
    coefficients = [float(training.get(key, default)) for key, default in
                    (("lambda_real", 1.), ("lambda_nominal", 1.), ("beta", 0.))]
    if any(not math.isfinite(value) or value < 0 for value in coefficients):
        raise ConfigError("lambda_real, lambda_nominal, and beta must be finite and non-negative")
    branches = training.get("logic_branches", ["real", "nominal"])
    if not isinstance(branches, list) or not branches or len(set(branches)) != len(branches) or set(branches) - {"real", "nominal"}:
        raise ConfigError("logic_branches must select real and/or nominal without duplicates")
    scale = float(training.get("logic_residual_scale", 1.0))
    margin = float(training.get("logic_margin", 0.8))
    if not math.isfinite(scale) or scale <= 0 or not 0 < margin <= 1:
        raise ConfigError("Logic scale must be positive and finite, margin must lie in (0,1]")
    if float(training.get("random_feature_mask_probability", 0.0)) != 0.0:
        raise ConfigError("One model must represent one fixed observation mask")
    group_weights = _require_mapping(
        training.get("logic_group_weights") or {},
        "training.logic_group_weights",
    )
    if any(not math.isfinite(float(value)) or float(value) < 0.0 for value in group_weights.values()):
        raise ConfigError("Gödel logic-group weights must be finite and non-negative")
    fixed_normalizer = training.get("logic_fixed_group_normalizer")
    if fixed_normalizer is not None and (not math.isfinite(float(fixed_normalizer)) or float(fixed_normalizer) <= 0):
        raise ConfigError("logic_fixed_group_normalizer must be finite and positive")
    if float(training.get("beta", 0.0)) > 0.0 and group_weights and not any(
        float(value) > 0.0 for value in group_weights.values()
    ):
        raise ConfigError("At least one Gödel logic-group weight must be positive")
    partial = _require_mapping(
        training.get("partial_observation") or {}, "training.partial_observation"
    )
    if not bool(partial.get("apply_to_validation", True)):
        raise ConfigError("The fixed observation mask must also apply to validation")
    if (partial.get("masked_feature_columns") or []) and not bool(
        partial.get("loss_on_masked_features", False)
    ):
        raise ConfigError("Masked measured targets require normal offline supervision")
    if list((training.get("model_selection") or {}).get("lexicographic_order") or []) != [
        "real_trajectory_error",
        "nominal_trajectory_error",
    ]:
        raise ConfigError("V18 model selection must use the two trajectory errors")

    godel = _require_mapping(
        (config.get("knowledge") or {}).get("godel") or {}, "knowledge.godel"
    )
    if not bool(godel.get("enabled", True)) and float(training.get("beta", 0.0)) != 0.0:
        raise ConfigError("beta must be zero when Gödel training knowledge is disabled")
    partition = _require_mapping(
        (config.get("diagnosis") or {}).get("rule_partition") or {},
        "diagnosis.rule_partition",
    )
    forbidden_partition = {
        "imputation_groups",
        "scoring_groups",
        "exclude_imputation_rules_from_scoring",
    }.intersection(partition)
    if forbidden_partition:
        raise ConfigError(
            f"V18 has only K_train. Removed rule partitions: {sorted(forbidden_partition)}"
        )
    training_groups = partition.get("training_groups") or []
    if not isinstance(training_groups, list):
        raise ConfigError("diagnosis.rule_partition.training_groups must be a list")

    diagnosis = _require_mapping(config["diagnosis"], "diagnosis")
    from .observed_commands import METHOD as COMMAND_METHOD, command_contract
    recorded_commands = str(diagnosis.get("method_identifier", "")) == COMMAND_METHOD
    if str(diagnosis.get("method_identifier", "")) not in {V18_METHOD_IDENTIFIER, COMMAND_METHOD}:
        raise ConfigError(
            f"V18 requires diagnosis.method_identifier={V18_METHOD_IDENTIFIER}"
        )
    if str(diagnosis.get("scoring_protocol", "")) != "fixed_observer":
        raise ConfigError("V18 requires the fixed_observer protocol")
    if str(diagnosis.get("root_cause_level", "")) != "component_fault_pair":
        raise ConfigError("V18 requires component-fault root-cause pairs")
    if str(diagnosis.get("virtual_evidence_mode", "")) != "nominal_real_open_loop":
        raise ConfigError("V18 requires nominal_real_open_loop evidence")
    if str(diagnosis.get("evidence_assignment_mode", "owner")) != "owner":
        raise ConfigError("V18 requires the supplied variable owner assignment")
    removed_diagnosis_fields = {
        "technical_timing",
        "causal_candidate_godel",
        "logic_truth_source",
        "fixed_weight_completion",
        "virtual_sensor_logic_weight",
        "root_cause_equivalence",
        "virtual_sensor_steps",
        "allow_offline_oracle",
        "rank_all_module_hypotheses",
        "non_circular_scoring",
        "module_threshold",
    }.intersection(diagnosis)
    if removed_diagnosis_fields:
        raise ConfigError(
            "V18 uses no online Gödel scoring. Removed fields: "
            f"{sorted(removed_diagnosis_fields)}. Use fault_sensor_threshold "
            "for candidate-specific persistent calibration."
        )
    if int(diagnosis.get("onset_persistence", 0)) < 2:
        raise ConfigError("V18 requires at least two persistent samples")
    threshold = _require_mapping(
        diagnosis.get("fault_sensor_threshold") or {},
        "diagnosis.fault_sensor_threshold",
    )
    if not bool(threshold.get("enabled", False)):
        raise ConfigError("Persistent sensor threshold calibration is required")
    if str(threshold.get("calibration_unit", "")) != "persistent_case":
        raise ConfigError("Sensor thresholds must be calibrated per persistent case")
    if str(threshold.get("multiple_testing_control", "")) != "bonferroni":
        raise ConfigError("V18 requires Bonferroni target-quantile adjustment")
    symptom_threshold = float(diagnosis.get("symptom_threshold", 0.5))
    if not math.isfinite(symptom_threshold) or symptom_threshold <= 0.0:
        raise ConfigError("diagnosis.symptom_threshold must be finite and positive")
    threshold_floor = float(threshold.get("min_threshold", symptom_threshold))
    if not math.isfinite(threshold_floor) or threshold_floor < symptom_threshold:
        raise ConfigError("The sensor threshold floor must cover the variable threshold")
    uncertainty = _require_mapping(
        diagnosis.get("uncertainty_normalization") or {},
        "diagnosis.uncertainty_normalization",
    )
    if not bool(uncertainty.get("enabled", False)):
        raise ConfigError("V18 requires component-variable-specific uncertainty normalization")
    if str(uncertainty.get("scope", "")) != "component_variable_specific":
        raise ConfigError(
            "diagnosis.uncertainty_normalization.scope must be "
            "component_variable_specific"
        )
    if str(uncertainty.get("calibration_split", "")) != "normal_validation_only":
        raise ConfigError("Uncertainty scales must be calibrated on normal validation only")
    if str(uncertainty.get("estimator", "")) not in {"quantile", "mad"}:
        raise ConfigError("Uncertainty estimator must be quantile or mad")
    min_scale = float(uncertainty.get("min_scale", 0.0))
    if not math.isfinite(min_scale) or min_scale <= 0.0:
        raise ConfigError("diagnosis.uncertainty_normalization.min_scale must be finite and positive")

    forbidden_ranking = {"onset_tie_breaker", "delay_correction"}.intersection(
        diagnosis
    )
    if forbidden_ranking:
        raise ConfigError(
            "V18 represents unresolved onset order as an ambiguity group. "
            f"Removed ranking fields: {sorted(forbidden_ranking)}"
        )

    value_ranges = _require_mapping(
        diagnosis.get("value_ranges") or {}, "diagnosis.value_ranges"
    )
    if recorded_commands:
        command_contract(config, dataset.get("feature_columns") or [],
                         (training.get("partial_observation") or {}).get("masked_feature_columns") or [])
        if value_ranges.get("enabled") is not False or diagnosis.get("residual_policy") != "direct_difference":
            raise ConfigError("Recorded commands require direct_difference without radius subtraction")
    elif not bool(value_ranges.get("enabled", False)):
        raise ConfigError("V18 requires current and nominal value ranges")
    if str(value_ranges.get("calibration_split", "")) != "normal_validation_only":
        raise ConfigError("Value ranges must be calibrated on normal validation only")
    if not 0.0 < float(value_ranges.get("quantile", 0.0)) < 1.0:
        raise ConfigError("diagnosis.value_ranges.quantile must lie in (0, 1)")
    min_radius = float(value_ranges.get("min_radius", -1.0))
    if not math.isfinite(min_radius) or min_radius < 0.0:
        raise ConfigError("diagnosis.value_ranges.min_radius must be finite and non-negative")
    for field in ("current_radius_overrides", "nominal_radius_overrides"):
        overrides = _require_mapping(value_ranges.get(field) or {}, f"value_ranges.{field}")
        if any(not math.isfinite(float(value)) or float(value) < 0.0 for value in overrides.values()):
            raise ConfigError(f"value_ranges.{field} must contain finite non-negative radii")

    timing = _require_mapping(
        diagnosis.get("timing_uncertainty") or {},
        "diagnosis.timing_uncertainty",
    )
    if not bool(timing.get("enabled", False)):
        raise ConfigError("V18 requires explicit onset timing bounds")
    timing_unit = str(timing.get("unit", ""))
    if timing_unit not in {"raw_samples", "seconds"}:
        raise ConfigError(
            "diagnosis.timing_uncertainty.unit must be raw_samples or seconds"
        )
    if str(timing.get("source", "")) not in {"supplied", "response_horizon"}:
        raise ConfigError("Timing uncertainty source must be supplied or response_horizon")
    radius_key = (
        "default_radius_raw_samples"
        if timing_unit == "raw_samples"
        else "default_radius_seconds"
    )
    default_radius = float(timing.get(radius_key, -1))
    if not math.isfinite(default_radius) or default_radius < 0:
        raise ConfigError("The default timing radius must be finite and non-negative")
    sensor_key = (
        "per_sensor_radius_raw_samples"
        if timing_unit == "raw_samples"
        else "per_sensor_radius_seconds"
    )
    variable_key = (
        "per_variable_radius_raw_samples"
        if timing_unit == "raw_samples"
        else "per_variable_radius_seconds"
    )
    per_sensor = _require_mapping(timing.get(sensor_key) or {}, f"timing.{sensor_key}")
    if any(not math.isfinite(float(value)) or float(value) < 0 for value in per_sensor.values()):
        raise ConfigError("Per-sensor timing radii must be finite and non-negative")
    per_variable = _require_mapping(
        timing.get(variable_key) or {}, f"timing.{variable_key}"
    )
    if any(not math.isfinite(float(value)) or float(value) < 0 for value in per_variable.values()):
        raise ConfigError("Per-variable timing radii must be finite and non-negative")
    if bool(timing.get("fault_data_used", True)):
        raise ConfigError("Fault data may not calibrate timing uncertainty")
    if bool(timing.get("test_data_used", True)):
        raise ConfigError("Test data may not calibrate timing uncertainty")
    window_selection = _require_mapping(
        diagnosis.get("window_selection") or {},
        "diagnosis.window_selection",
    )
    selection_mode = str(window_selection.get("mode", "full_case"))
    if selection_mode != "full_case":
        raise ConfigError(
            "Diagnosis requires full_case. Fault labels may only be used for evaluation"
        )
    if diagnosis.get("case_window_policy", "all_case_windows") != "all_case_windows":
        raise ConfigError("Diagnosis requires all_case_windows. Fault labels may only be used for evaluation")
    if selection_mode == "full_case" and int(
        diagnosis.get("max_diagnosis_windows", 0)
    ) != 0:
        raise ConfigError(
            "V18 full-case diagnosis forbids max_diagnosis_windows"
        )

    trajectory = _require_mapping(
        diagnosis.get("nominal_real_trajectory") or {},
        "diagnosis.nominal_real_trajectory",
    )
    if str(trajectory.get("protocol", "")) != V18_PROTOCOL:
        raise ConfigError(f"V18 requires trajectory protocol {V18_PROTOCOL}")
    obsolete_trajectory_fields = {
        "rollout_window_steps",
        "window_steps",
        "W",
    }.intersection(trajectory)
    if obsolete_trajectory_fields:
        raise ConfigError(
            "V18 trajectory configuration must use delta_t only. Removed fields: "
            f"{sorted(obsolete_trajectory_fields)}"
        )
    delta_t = _require_mapping(trajectory.get("delta_t") or {}, "trajectory.delta_t")
    if str(delta_t.get("unit", "")) != "samples":
        raise ConfigError("delta_t.unit must be samples")
    candidates = delta_t.get("candidates") or []
    if (not isinstance(candidates, list) or not candidates
            or (fitting_protocol == "recursive_legacy_v18" and not recorded_commands
                and "mode" not in training and len(candidates) != 1)):
        raise ConfigError(
            "Each V18 model requires exactly one delta_t candidate. Sweep separate models."
        )
    if (len(set(candidates)) != len(candidates)
            or any(type(value) is not int for value in candidates)):
        raise ConfigError("delta_t candidates must be unique integers")
    if any(candidate < int(diagnosis.get("onset_persistence", 0)) or candidate >= window_size
           for candidate in candidates):
        raise ConfigError(
            "delta_t must cover persistence and remain smaller than window_size"
        )
    delta_period = float(delta_t.get("sample_period_seconds", 0.0))
    if not math.isfinite(delta_period) or delta_period <= 0.0:
        raise ConfigError("delta_t.sample_period_seconds must be finite and positive")

    time_axis = _require_mapping(
        diagnosis.get("time_axis") or {}, "diagnosis.time_axis"
    )
    if str(time_axis.get("input_unit", "")) not in {
        "seconds",
        "hours",
        "raw_sample_index",
    }:
        raise ConfigError(
            "diagnosis.time_axis.input_unit must be seconds, hours or raw_sample_index"
        )
    raw_period = float(time_axis.get("raw_sample_period_seconds", 0.0))
    if not math.isfinite(raw_period) or raw_period <= 0.0:
        raise ConfigError("diagnosis.time_axis.raw_sample_period_seconds must be finite and positive")
    if int(time_axis.get("evaluation_stride_samples", 0)) < 1:
        raise ConfigError("diagnosis.time_axis.evaluation_stride_samples must be positive")
    if str(time_axis.get("gap_policy", "")) != "reject":
        raise ConfigError("V18 requires diagnosis.time_axis.gap_policy=reject")
    if not bool(time_axis.get("strictly_increasing", False)):
        raise ConfigError("V18 requires a strictly increasing diagnosis time axis")
    if not bool(time_axis.get("unique", False)):
        raise ConfigError("V18 requires unique diagnosis timestamps")
    if not bool(time_axis.get("sensor_synchronization_supplied", False)):
        raise ConfigError(
            "V18 requires an explicit supplied sensor-synchronization assumption"
        )
    if str(delta_t.get("selection_scope", "")) != "validation_only":
        raise ConfigError("delta_t selection must be validation-only")
    if bool(delta_t.get("fault_validation_metrics_used_for_selection", True)):
        raise ConfigError("Fault-validation metrics may not select delta_t")
    if bool(delta_t.get("test_metrics_used_for_selection", True)):
        raise ConfigError("Test metrics may not select delta_t")

    run_dir = str(config["output"].get("run_dir", "")).lower()
    if "v18" not in run_dir:
        raise ConfigError("V18 output.run_dir must be isolated from older methods")
