"""Preparation contract for the Extended Tennessee Eastman Process dataset.

The adapter reads the official HDF5 files published by Reinartz et al. It
materializes only ordinary process measurements as online inputs. Direct IDV
monitoring values, fault profiles, labels, and simulator metadata remain
offline artifacts and can never enter the observer input matrix.
"""

from __future__ import annotations

import hashlib
import json
import re
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

from .config import ConfigError


@dataclass(frozen=True)
class TepFaultSpec:
    fault_id: int
    description: str
    disturbance_type: str
    plant_module: str
    process_indices: tuple[int, ...]
    additional_indices: tuple[int, ...] = ()
    oracle_indices: tuple[int, ...] = ()
    physical_component: str = ""
    fault_type: str = ""
    physical_quantity: str = ""
    component_variables: tuple[str, ...] = ()
    causal_inputs: tuple[str, ...] = ()
    observable_effects: tuple[str, ...] = ()
    state_name: str = ""
    state_function: str = "mean_absolute"
    state_inputs: tuple[str, ...] = ()
    state_coefficients: tuple[float, ...] = ()
    state_oracle_index: int | None = None
    state_oracle_indices: tuple[int, ...] = ()
    state_unit: str = ""
    equation_class: str = ""
    ontology_sources: tuple[str, ...] = ()
    included: bool = True
    exclusion_reason: str = ""

    @property
    def label(self) -> str:
        return f"IDV{self.fault_id}"

    @property
    def root_cause(self) -> str:
        return f"<{self.physical_component}, {self.fault_type}>"

    @property
    def primary_variable(self) -> str:
        if self.state_name:
            suffix = ".coordinate_1" if len(self.state_oracle_indices) > 1 else ""
            return f"state.tep.{self.state_name}{suffix}"
        if not self.component_variables:
            raise ConfigError(f"TEP fault {self.label} has no component variable")
        return tep_feature(self.component_variables[0])


TEP_DATASET_SOURCE = "Reinartz et al. 2021, doi:10.1016/j.compchemeng.2021.107281"
TEP_REVISED_MODEL_SOURCE = "Bathelt et al. 2015, doi:10.1016/j.ifacol.2015.08.199"
TEP_SIMULATOR_SOURCE = "Bathelt revised temexd_mod simulator source"


PROCESS_VARIABLES: dict[int, str] = {
    1: "time_h",
    2: "a_feed_kscmh",
    3: "d_feed_kg_h",
    4: "e_feed_kg_h",
    5: "ac_feed_kscmh",
    6: "recycle_flow_kscmh",
    7: "reactor_feed_rate_kscmh",
    8: "reactor_pressure_kpag",
    9: "reactor_level_pct",
    10: "reactor_temperature_c",
    11: "purge_rate_kscmh",
    12: "separator_temperature_c",
    13: "separator_level_pct",
    14: "separator_pressure_kpag",
    15: "separator_underflow_m3_h",
    16: "stripper_level_pct",
    17: "stripper_pressure_kpag",
    18: "stripper_underflow_m3_h",
    19: "stripper_temperature_c",
    20: "stripper_steam_flow_kg_h",
    21: "compressor_work_kw",
    22: "reactor_coolant_temperature_c",
    23: "separator_coolant_temperature_c",
    24: "component_a_to_reactor_mol_pct",
    25: "component_b_to_reactor_mol_pct",
    26: "component_c_to_reactor_mol_pct",
    27: "component_d_to_reactor_mol_pct",
    28: "component_e_to_reactor_mol_pct",
    29: "component_f_to_reactor_mol_pct",
    30: "component_a_in_purge_mol_pct",
    31: "component_b_in_purge_mol_pct",
    32: "component_c_in_purge_mol_pct",
    33: "component_d_in_purge_mol_pct",
    34: "component_e_in_purge_mol_pct",
    35: "component_f_in_purge_mol_pct",
    36: "component_g_in_purge_mol_pct",
    37: "component_h_in_purge_mol_pct",
    38: "component_d_in_product_mol_pct",
    39: "component_e_in_product_mol_pct",
    40: "component_f_in_product_mol_pct",
    41: "component_g_in_product_mol_pct",
    42: "component_h_in_product_mol_pct",
    43: "d_feed_valve_pct",
    44: "e_feed_valve_pct",
    45: "a_feed_valve_pct",
    46: "ac_feed_valve_pct",
    47: "compressor_recycle_valve_pct",
    48: "purge_valve_pct",
    49: "separator_liquid_valve_pct",
    50: "stripper_liquid_valve_pct",
    51: "stripper_steam_valve_pct",
    52: "reactor_coolant_valve_pct",
    53: "condenser_coolant_valve_pct",
    54: "agitator_speed_pct",
}

ADDITIONAL_VARIABLES: dict[int, str] = {
    1: "feed_a_temperature_c",
    2: "feed_d_temperature_c",
    3: "feed_e_temperature_c",
    4: "feed_ac_temperature_c",
    5: "reactor_cooling_inlet_temperature_c",
    6: "reactor_cooling_flow_m3_h",
    7: "condenser_cooling_inlet_temperature_c",
    8: "condenser_cooling_flow_m3_h",
    **{
        index: f"component_{component}_in_stream_{stream}_mol_pct"
        for stream, start in ((1, 9), (2, 15), (3, 21), (4, 27))
        for index, component in zip(range(start, start + 6), "abcdef")
    },
}

ORACLE_VARIABLES: dict[int, str] = {
    1: "idv8_stream4_component_a",
    2: "idv8_stream4_component_b",
    3: "idv8_stream4_component_c",
    4: "idv9_feed_d_temperature",
    5: "idv10_feed_ac_temperature",
    6: "idv11_reactor_cooling_inlet_temperature",
    7: "idv12_condenser_cooling_inlet_temperature",
    8: "idv14_reaction_kinetics_1",
    9: "idv14_reaction_kinetics_2",
    10: "idv16_stripper_heat_transfer_driver",
    11: "idv18_reactor_heat_transfer_driver",
    12: "idv18_condenser_heat_transfer_driver",
    13: "idv20_unknown_internal_value",
    14: "idv21_feed_a_temperature",
    15: "idv22_feed_e_temperature",
    16: "idv23_feed_a_flow_capacity",
    17: "idv24_feed_d_flow_capacity",
    18: "idv25_feed_e_flow_capacity",
    19: "idv26_feed_ac_flow_capacity",
    20: "idv27_reactor_cooling_flow_capacity",
    21: "idv28_condenser_cooling_flow_capacity",
}

# Nominal values of the 21 disturbance-monitor channels in the revised
# ``temexd_mod`` simulator.  The first nine and channels 14 through 21 are the
# source ``szero`` values after the documented unit conversions.  Channels 10
# through 13 are dimensionless disturbance drivers with zero nominal value.
# Official HDF5 runs that contain ``idv_monitoring`` reproduce this vector at
# the pre-fault operating point.  Some deterministic and sticking-fault runs
# omit the dataset because none of these monitored random processes is active.
ORACLE_NOMINAL_VALUES: dict[int, float] = {
    1: 48.5,
    2: 0.5,
    3: 51.0,
    4: 45.0,
    5: 45.0,
    6: 35.0,
    7: 40.0,
    8: 1.0,
    9: 1.0,
    10: 0.0,
    11: 0.0,
    12: 0.0,
    13: 0.0,
    14: 45.0,
    15: 45.0,
    16: 100.0 * 0.454,
    17: 400.0 * 0.454,
    18: 400.0 * 0.454,
    19: 1500.0 * 0.454,
    20: 1000.0 * 0.003785411784 * 60.0,
    21: 1200.0 * 0.003785411784 * 60.0,
}


def process_feature(index: int) -> str:
    if index == 1:
        raise ValueError("The process time column is metadata, not an online feature")
    return f"tep.pd{index:02d}.{PROCESS_VARIABLES[index]}"


def additional_feature(index: int) -> str:
    return f"tep.add{index:02d}.{ADDITIONAL_VARIABLES[index]}"


def oracle_feature(index: int) -> str:
    return f"tep.oracle.mon{index:02d}.{ORACLE_VARIABLES[index]}"


def tep_feature(reference: str) -> str:
    """Resolve one reviewed ontology reference to an online feature name."""

    match = re.fullmatch(r"(pd|add)(\d+)", str(reference).strip().lower())
    if match is None:
        raise ConfigError(f"Invalid TEP ontology feature reference: {reference!r}")
    index = int(match.group(2))
    return process_feature(index) if match.group(1) == "pd" else additional_feature(index)


ONLINE_FEATURE_COLUMNS = tuple(
    [process_feature(index) for index in range(2, 55)]
    + [additional_feature(index) for index in range(1, 33)]
)
ORACLE_COLUMNS = tuple(oracle_feature(index) for index in range(1, 22))


_SRC = (TEP_DATASET_SOURCE, TEP_REVISED_MODEL_SOURCE, TEP_SIMULATOR_SOURCE)


TEP_FAULT_SPECS: tuple[TepFaultSpec, ...] = (
    TepFaultSpec(1, "A/C feed ratio with constant B composition in stream 4", "step", "feed_system", (5, 24, 25, 26), (27, 28, 29), physical_component="feed.stream4.composition_source", fault_type="ac_ratio_step", physical_quantity="A/C composition ratio in stream 4", component_variables=("add27", "add29"), causal_inputs=("pd46",), observable_effects=("pd5", "pd24", "pd26"), ontology_sources=_SRC),
    TepFaultSpec(2, "B composition with constant A/C ratio in stream 4", "step", "feed_system", (5, 24, 25, 26), (27, 28, 29), physical_component="feed.stream4.composition_source", fault_type="b_fraction_step", physical_quantity="B mole fraction in stream 4", component_variables=("add28",), causal_inputs=("pd46",), observable_effects=("pd5", "pd25"), ontology_sources=_SRC),
    TepFaultSpec(3, "D feed temperature in stream 2", "step", "feed_system", (3, 43), (2,), physical_component="feed.stream2.d_thermal_source", fault_type="temperature_step", physical_quantity="D-feed temperature", component_variables=("add2",), causal_inputs=("pd43",), observable_effects=("pd3", "pd10"), ontology_sources=_SRC),
    TepFaultSpec(4, "Reactor cooling-water inlet temperature", "step", "reactor", (10, 22, 52), (5, 6), physical_component="reactor.cooling_water_thermal_supply", fault_type="inlet_temperature_step", physical_quantity="reactor cooling-water inlet temperature", component_variables=("add5",), causal_inputs=("pd52",), observable_effects=("add6", "pd22", "pd10"), ontology_sources=_SRC),
    TepFaultSpec(5, "Condenser cooling-water inlet temperature", "step", "condenser", (12, 23, 53), (7, 8), physical_component="condenser.cooling_water_thermal_supply", fault_type="inlet_temperature_step", physical_quantity="condenser cooling-water inlet temperature", component_variables=("add7",), causal_inputs=("pd53",), observable_effects=("add8", "pd23", "pd12"), ontology_sources=_SRC),
    TepFaultSpec(6, "Loss of A feed in stream 1", "step", "feed_system", (2, 45), (1, 9), physical_component="feed.stream1.a_supply_path", fault_type="feed_loss", physical_quantity="available A-feed flow", component_variables=("pd2",), causal_inputs=("pd45",), observable_effects=("pd7", "pd24"), ontology_sources=_SRC),
    TepFaultSpec(7, "C header pressure loss affecting stream 4", "step", "feed_system", (5, 46), (4, 27, 29), physical_component="feed.stream4.c_header", fault_type="supply_pressure_loss", physical_quantity="effective stream-4 flow capacity", causal_inputs=("pd46",), observable_effects=("pd5", "pd26", "add29"), state_name="feed.stream4.c_header.effective_capacity", state_function="flow_per_command", state_inputs=("pd5", "pd46"), state_unit="kscmh per valve-percent", equation_class="effective_flow_capacity_proxy", ontology_sources=_SRC),
    TepFaultSpec(8, "A/B/C composition variation in stream 4", "random_variation", "feed_system", (5, 24, 25, 26), (27, 28, 29), (1, 2, 3), physical_component="feed.stream4.composition_source", fault_type="abc_composition_random_variation", physical_quantity="A, B, and C composition vector in stream 4", component_variables=("add27", "add28", "add29"), causal_inputs=("pd46",), observable_effects=("pd24", "pd25", "pd26"), ontology_sources=_SRC),
    TepFaultSpec(9, "D feed-temperature variation in stream 2", "random_variation", "feed_system", (3, 43), (2,), (4,), physical_component="feed.stream2.d_thermal_source", fault_type="temperature_random_variation", physical_quantity="D-feed temperature", component_variables=("add2",), causal_inputs=("pd43",), observable_effects=("pd3", "pd10"), ontology_sources=_SRC),
    TepFaultSpec(10, "C feed-temperature variation in stream 4", "random_variation", "feed_system", (5, 46), (4,), (5,), physical_component="feed.stream4.ac_thermal_source", fault_type="temperature_random_variation", physical_quantity="A/C-feed temperature", component_variables=("add4",), causal_inputs=("pd46",), observable_effects=("pd5", "pd10"), ontology_sources=_SRC),
    TepFaultSpec(11, "Reactor cooling-water inlet-temperature variation", "random_variation", "reactor", (10, 22, 52), (5, 6), (6,), physical_component="reactor.cooling_water_thermal_supply", fault_type="inlet_temperature_random_variation", physical_quantity="reactor cooling-water inlet temperature", component_variables=("add5",), causal_inputs=("pd52",), observable_effects=("add6", "pd22", "pd10"), ontology_sources=_SRC),
    TepFaultSpec(12, "Condenser cooling-water inlet-temperature variation", "random_variation", "condenser", (12, 23, 53), (7, 8), (7,), physical_component="condenser.cooling_water_thermal_supply", fault_type="inlet_temperature_random_variation", physical_quantity="condenser cooling-water inlet temperature", component_variables=("add7",), causal_inputs=("pd53",), observable_effects=("add8", "pd23", "pd12"), ontology_sources=_SRC),
    TepFaultSpec(13, "Variation of reaction kinetics", "random_variation", "reactor", (7, 8, 9, 10, 24, 26, 27, 28), (), (8, 9), physical_component="reactor.reaction_kinetics", fault_type="kinetic_coefficient_random_variation", physical_quantity="two reaction-rate coefficient states", causal_inputs=("pd7", "pd24", "pd26", "pd27", "pd28"), observable_effects=("pd8", "pd9", "pd10"), state_name="reactor.reaction_kinetics.coefficient_state", state_function="mean_absolute", state_inputs=("pd7", "pd24", "pd26", "pd27", "pd28"), state_oracle_indices=(8, 9), state_unit="dimensionless", equation_class="reaction_kinetics_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(14, "Sticking reactor cooling-water outlet valve", "sticking", "reactor", (10, 22, 52), (5, 6), physical_component="reactor.cooling_water_outlet_valve", fault_type="sticking", physical_quantity="effective reactor cooling-water valve response", causal_inputs=("pd52",), observable_effects=("add6", "pd22", "pd10"), state_name="reactor.cooling_water_outlet_valve.effective_response", state_function="flow_per_command", state_inputs=("add6", "pd52"), state_unit="m3/h per valve-percent", equation_class="effective_valve_response_proxy", ontology_sources=_SRC),
    TepFaultSpec(15, "Sticking condenser cooling-water outlet valve", "sticking", "condenser", (12, 23, 53), (7, 8), physical_component="condenser.cooling_water_outlet_valve", fault_type="sticking", physical_quantity="effective condenser cooling-water valve response", causal_inputs=("pd53",), observable_effects=("add8", "pd23", "pd12"), state_name="condenser.cooling_water_outlet_valve.effective_response", state_function="flow_per_command", state_inputs=("add8", "pd53"), state_unit="m3/h per valve-percent", equation_class="effective_valve_response_proxy", ontology_sources=_SRC),
    TepFaultSpec(16, "Variation of stripper heat-exchanger steam supply", "random_variation", "stripper", (16, 17, 19, 20, 51), (), (10,), physical_component="stripper.steam_heat_transfer_path", fault_type="heat_transfer_random_variation", physical_quantity="dimensionless driver of the stripper steam-side heat-transfer multiplier", causal_inputs=("pd51", "pd20"), observable_effects=("pd19", "pd16", "pd17"), state_name="stripper.steam_heat_transfer_path.relative_driver", state_function="mean_absolute", state_inputs=("pd51", "pd20", "pd19"), state_oracle_index=10, state_unit="dimensionless driver", equation_class="stripper_heat_transfer_driver_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(17, "Variation of reactor heat transfer", "random_variation", "reactor", (8, 9, 10, 22, 52), (5, 6), (11,), physical_component="reactor.heat_transfer_interface", fault_type="heat_transfer_random_variation", physical_quantity="dimensionless degradation driver of the reactor heat-transfer multiplier", causal_inputs=("pd52", "add5", "add6"), observable_effects=("pd22", "pd10", "pd8"), state_name="reactor.heat_transfer_interface.degradation_driver", state_function="mean_absolute", state_inputs=("pd52", "add5", "add6", "pd22", "pd10"), state_oracle_index=11, state_unit="dimensionless driver", equation_class="reactor_heat_transfer_driver_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(18, "Variation of condenser heat transfer", "random_variation", "condenser", (12, 13, 14, 23, 53), (7, 8), (12,), physical_component="condenser.heat_transfer_interface", fault_type="heat_transfer_random_variation", physical_quantity="dimensionless degradation driver of the condenser heat-transfer multiplier", causal_inputs=("pd53", "add7", "add8"), observable_effects=("pd23", "pd12", "pd13", "pd14"), state_name="condenser.heat_transfer_interface.degradation_driver", state_function="mean_absolute", state_inputs=("pd53", "add7", "add8", "pd23", "pd12"), state_oracle_index=12, state_unit="dimensionless driver", equation_class="condenser_heat_transfer_driver_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(19, "Unknown benchmark disturbance", "unknown", "plant_wide", (8, 10, 14, 17, 21), physical_component="", fault_type="", physical_quantity="", included=False, exclusion_reason="The benchmark deliberately leaves the physical disturbance and injection component unknown.", ontology_sources=_SRC),
    TepFaultSpec(20, "Unknown random benchmark disturbance", "random_variation_unknown", "plant_wide", (8, 10, 14, 17, 21), (), (13,), physical_component="", fault_type="", physical_quantity="", included=False, exclusion_reason="The benchmark and simulator expose an unknown internal value but no auditable physical injection component.", ontology_sources=_SRC),
    TepFaultSpec(21, "A feed-temperature variation in stream 1", "random_variation", "feed_system", (2, 45), (1,), (14,), physical_component="feed.stream1.a_thermal_source", fault_type="temperature_random_variation", physical_quantity="A-feed temperature", component_variables=("add1",), causal_inputs=("pd45",), observable_effects=("pd2", "pd10"), ontology_sources=_SRC),
    TepFaultSpec(22, "E feed-temperature variation in stream 3", "random_variation", "feed_system", (4, 44), (3,), (15,), physical_component="feed.stream3.e_thermal_source", fault_type="temperature_random_variation", physical_quantity="E-feed temperature", component_variables=("add3",), causal_inputs=("pd44",), observable_effects=("pd4", "pd10"), ontology_sources=_SRC),
    TepFaultSpec(23, "A feed-pressure variation in stream 1", "random_variation", "feed_system", (2, 45), (1,), (16,), physical_component="feed.stream1.a_pressure_source", fault_type="supply_pressure_random_variation", physical_quantity="effective A-feed flow capacity induced by source-pressure variation", causal_inputs=("pd45",), observable_effects=("pd2", "pd7"), state_name="feed.stream1.a_pressure_source.flow_capacity", state_function="flow_per_command", state_inputs=("pd2", "pd45"), state_oracle_index=16, state_unit="kmol/h flow capacity", equation_class="supply_pressure_flow_capacity_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(24, "D feed-pressure variation in stream 2", "random_variation", "feed_system", (3, 43), (2,), (17,), physical_component="feed.stream2.d_pressure_source", fault_type="supply_pressure_random_variation", physical_quantity="effective D-feed flow capacity induced by source-pressure variation", causal_inputs=("pd43",), observable_effects=("pd3", "pd7"), state_name="feed.stream2.d_pressure_source.flow_capacity", state_function="flow_per_command", state_inputs=("pd3", "pd43"), state_oracle_index=17, state_unit="kmol/h flow capacity", equation_class="supply_pressure_flow_capacity_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(25, "E feed-pressure variation in stream 3", "random_variation", "feed_system", (4, 44), (3,), (18,), physical_component="feed.stream3.e_pressure_source", fault_type="supply_pressure_random_variation", physical_quantity="effective E-feed flow capacity induced by source-pressure variation", causal_inputs=("pd44",), observable_effects=("pd4", "pd7"), state_name="feed.stream3.e_pressure_source.flow_capacity", state_function="flow_per_command", state_inputs=("pd4", "pd44"), state_oracle_index=18, state_unit="kmol/h flow capacity", equation_class="supply_pressure_flow_capacity_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(26, "A/C feed-pressure variation in stream 4", "random_variation", "feed_system", (5, 46), (4,), (19,), physical_component="feed.stream4.ac_pressure_source", fault_type="supply_pressure_random_variation", physical_quantity="effective A/C-feed flow capacity induced by source-pressure variation", causal_inputs=("pd46",), observable_effects=("pd5", "pd7"), state_name="feed.stream4.ac_pressure_source.flow_capacity", state_function="flow_per_command", state_inputs=("pd5", "pd46"), state_oracle_index=19, state_unit="kmol/h flow capacity", equation_class="supply_pressure_flow_capacity_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(27, "Reactor cooling-water supply-pressure variation", "random_variation", "reactor", (10, 22, 52), (5, 6), (20,), physical_component="reactor.cooling_water_pressure_source", fault_type="supply_pressure_random_variation", physical_quantity="effective reactor cooling-water flow capacity induced by source-pressure variation", causal_inputs=("pd52",), observable_effects=("add6", "pd22", "pd10"), state_name="reactor.cooling_water_pressure_source.flow_capacity", state_function="flow_per_command", state_inputs=("add6", "pd52"), state_oracle_index=20, state_unit="m3/h flow capacity", equation_class="cooling_pressure_flow_capacity_oracle_target", ontology_sources=_SRC),
    TepFaultSpec(28, "Condenser cooling-water supply-pressure variation", "random_variation", "condenser", (12, 23, 53), (7, 8), (21,), physical_component="condenser.cooling_water_pressure_source", fault_type="supply_pressure_random_variation", physical_quantity="effective condenser cooling-water flow capacity induced by source-pressure variation", causal_inputs=("pd53",), observable_effects=("add8", "pd23", "pd12"), state_name="condenser.cooling_water_pressure_source.flow_capacity", state_function="flow_per_command", state_inputs=("add8", "pd53"), state_oracle_index=21, state_unit="m3/h flow capacity", equation_class="cooling_pressure_flow_capacity_oracle_target", ontology_sources=_SRC),
)
FAULT_BY_ID = {spec.fault_id: spec for spec in TEP_FAULT_SPECS}
RETAINED_TEP_FAULT_SPECS = tuple(spec for spec in TEP_FAULT_SPECS if spec.included)
RETAINED_TEP_FAULT_IDS = tuple(spec.fault_id for spec in RETAINED_TEP_FAULT_SPECS)
EXCLUDED_TEP_FAULT_IDS = tuple(spec.fault_id for spec in TEP_FAULT_SPECS if not spec.included)


MODULE_PROCESS_INDICES: dict[str, tuple[int, ...]] = {
    "feed_system": (2, 3, 4, 5, 43, 44, 45, 46),
    "reactor": (7, 8, 9, 10, 22, 24, 25, 26, 27, 28, 29, 52, 54),
    "condenser": (12, 23, 53),
    "separator": (13, 14, 15, 48, 49),
    "recycle_compressor": (6, 11, 21, 30, 31, 32, 33, 34, 35, 36, 37, 47),
    "stripper": (16, 17, 18, 19, 20, 38, 39, 40, 41, 42, 50, 51),
}
MODULE_ADDITIONAL_INDICES: dict[str, tuple[int, ...]] = {
    "feed_system": tuple(range(1, 5)) + tuple(range(9, 33)),
    "reactor": (5, 6),
    "condenser": (7, 8),
    "separator": (),
    "recycle_compressor": (),
    "stripper": (),
}


OFFICIAL_FILES: dict[int, dict[str, Any]] = {
    1: {"name": "TEP_Mode1.h5", "file_id": 26003087, "size": 23924710848, "md5": "c79ecc6d12a5ccb49caffcd8f531feae"},
    2: {"name": "TEP_Mode2.h5", "file_id": 26003162, "size": 23897125720, "md5": "72ee75fdf6da8e59327f04fd4fd49662"},
    3: {"name": "TEP_Mode3.h5", "file_id": 26003492, "size": 23921551744, "md5": "5f4bf0d87e7f9ff81ee632f84f2d9050"},
    4: {"name": "TEP_Mode4.h5", "file_id": 26024015, "size": 23219369960, "md5": "c1e76a74022230450dc14fe904451236"},
    5: {"name": "TEP_Mode5.h5", "file_id": 26028068, "size": 23890304712, "md5": "8f3c1a1ebeb80ad78089f82a7d521fda"},
    6: {"name": "TEP_Mode6.h5", "file_id": 26034659, "size": 23907566544, "md5": "d01e032a1f3ff9ca3afaa1f74c52e1a6"},
}


@dataclass(frozen=True)
class TepRunDescriptor:
    file_path: str
    hdf5_path: str
    mode: int
    fault_id: int
    magnitude: int
    run_number: int
    completion_status: str

    @property
    def run_id(self) -> str:
        return (
            f"mode{self.mode}_idv{self.fault_id}_mag{self.magnitude}_"
            f"run{self.run_number}_{self.completion_status}"
        )

    @property
    def stratum(self) -> tuple[int, int, int, str]:
        return self.mode, self.fault_id, self.magnitude, self.completion_status


_RUN_PATH = re.compile(
    r"(?:^|/)Mode(?P<mode>\d+)/SingleFault/Simulation(?P<status>Completed|Stopped)/"
    r"IDV\(?(?P<fault>\d+)\)?/[^/]*_(?P<magnitude>\d+)/Run(?P<run>\d+)$",
    re.IGNORECASE,
)


def scan_tep_reinartz(
    raw_dir: str | Path,
    *,
    modes: Iterable[int] | None = None,
    fault_ids: Iterable[int] | None = None,
    magnitudes: Iterable[int] | None = None,
    include_stopped: bool = False,
) -> list[TepRunDescriptor]:
    """Scan reviewed HDF5 run paths without loading simulation matrices.

    The official files also contain simulator-specific HDF5 objects outside
    the single-fault run hierarchy.  Some HDF5 builds cannot determine the
    type of every such object during a file-wide object visit.  Restricting
    traversal to the documented run hierarchy is both more robust and more
    precise because unrelated simulator metadata can never become a run.
    """

    try:
        import h5py
    except ImportError as exc:
        raise ConfigError("Extended TEP preparation requires the h5py package") from exc

    root = Path(raw_dir).expanduser().resolve()
    mode_filter = set(int(value) for value in modes or range(1, 7))
    fault_filter = set(int(value) for value in fault_ids or RETAINED_TEP_FAULT_IDS)
    magnitude_filter = set(int(value) for value in magnitudes or (25, 50, 75, 100))
    descriptors: list[TepRunDescriptor] = []
    for mode in sorted(mode_filter):
        path = root / OFFICIAL_FILES[mode]["name"]
        if not path.exists():
            raise FileNotFoundError(f"Extended TEP mode file is missing: {path}")
        with h5py.File(path, "r") as handle:
            mode_name = f"Mode{mode}"
            if mode_name not in handle or not isinstance(handle[mode_name], h5py.Group):
                raise ConfigError(f"TEP file {path} has no reviewed group {mode_name!r}")
            mode_group = handle[mode_name]
            if "SingleFault" not in mode_group or not isinstance(
                mode_group["SingleFault"], h5py.Group
            ):
                raise ConfigError(
                    f"TEP file {path} has no reviewed single-fault hierarchy"
                )
            single_fault = mode_group["SingleFault"]
            status_names = ["SimulationCompleted"]
            if include_stopped:
                status_names.append("SimulationStopped")
            for status_name in status_names:
                if status_name not in single_fault:
                    if status_name == "SimulationCompleted":
                        raise ConfigError(
                            f"TEP file {path} has no completed single-fault runs"
                        )
                    continue
                status_group = single_fault[status_name]
                if not isinstance(status_group, h5py.Group):
                    raise ConfigError(
                        f"TEP path {status_group.name!r} is not an HDF5 group"
                    )
                for fault_name in status_group.keys():
                    fault_match = re.fullmatch(r"IDV\(?(\d+)\)?", fault_name, re.IGNORECASE)
                    if fault_match is None:
                        continue
                    fault_id = int(fault_match.group(1))
                    if fault_id not in fault_filter:
                        continue
                    fault_group = status_group[fault_name]
                    if not isinstance(fault_group, h5py.Group):
                        raise ConfigError(
                            f"TEP fault path {fault_group.name!r} is not an HDF5 group"
                        )
                    for magnitude_name in fault_group.keys():
                        magnitude_match = re.search(r"_(\d+)$", magnitude_name)
                        if magnitude_match is None:
                            continue
                        magnitude = int(magnitude_match.group(1))
                        if magnitude not in magnitude_filter:
                            continue
                        magnitude_group = fault_group[magnitude_name]
                        if not isinstance(magnitude_group, h5py.Group):
                            raise ConfigError(
                                f"TEP magnitude path {magnitude_group.name!r} is not a group"
                            )
                        for run_name in magnitude_group.keys():
                            run_match = re.fullmatch(r"Run(\d+)", run_name, re.IGNORECASE)
                            if run_match is None:
                                continue
                            run_group = magnitude_group[run_name]
                            if not isinstance(run_group, h5py.Group):
                                raise ConfigError(
                                    f"TEP run path {run_group.name!r} is not an HDF5 group"
                                )
                            dataset_names = {
                                _normalized_key(key) for key in run_group.keys()
                            }
                            if "processdata" not in dataset_names:
                                raise ConfigError(
                                    f"TEP run group {run_group.name!r} has no processdata"
                                )
                            name = run_group.name.lstrip("/")
                            path_match = _RUN_PATH.fullmatch(name)
                            if path_match is None:
                                raise ConfigError(
                                    f"TEP run path does not match the reviewed schema: {name!r}"
                                )
                            descriptors.append(
                                TepRunDescriptor(
                                    file_path=str(path),
                                    hdf5_path=name,
                                    mode=mode,
                                    fault_id=fault_id,
                                    magnitude=magnitude,
                                    run_number=int(run_match.group(1)),
                                    completion_status=(
                                        "completed"
                                        if status_name == "SimulationCompleted"
                                        else "stopped"
                                    ),
                                )
                            )
    return sorted(
        descriptors,
        key=lambda item: (
            item.mode,
            item.fault_id,
            item.magnitude,
            item.completion_status,
            item.run_number,
        ),
    )


def _stable_order(value: str, seed: int) -> str:
    return hashlib.sha256(f"{seed}|{value}".encode("utf-8")).hexdigest()


def assign_tep_splits(
    descriptors: list[TepRunDescriptor],
    *,
    seed: int,
    train_ratio: float,
    val_ratio: float,
) -> dict[str, str]:
    """Assign complete runs within every mode, IDV, and magnitude stratum."""

    if not 0.0 < train_ratio < 1.0 or not 0.0 < val_ratio < 1.0:
        raise ConfigError("TEP train and validation ratios must lie in (0, 1)")
    if train_ratio + val_ratio >= 1.0:
        raise ConfigError("TEP train_ratio + val_ratio must be smaller than one")
    by_stratum: dict[tuple[int, int, int, str], list[TepRunDescriptor]] = defaultdict(list)
    for descriptor in descriptors:
        by_stratum[descriptor.stratum].append(descriptor)
    assignment: dict[str, str] = {}
    for items in by_stratum.values():
        ordered = sorted(items, key=lambda item: _stable_order(item.run_id, seed))
        count = len(ordered)
        if count < 3:
            raise ConfigError(
                "Every retained TEP mode, IDV, magnitude, and status stratum "
                f"requires at least three runs, found {count} for {items[0].stratum}"
            )
        train_count = max(1, int(round(count * train_ratio)))
        val_count = max(1, int(round(count * val_ratio)))
        if train_count + val_count >= count:
            train_count = max(1, count - 2)
            val_count = 1
        for index, descriptor in enumerate(ordered):
            split = "train" if index < train_count else "val" if index < train_count + val_count else "test"
            assignment[descriptor.run_id] = split
    return assignment


def _select_runs_per_stratum(
    descriptors: list[TepRunDescriptor], maximum: int | None, seed: int
) -> list[TepRunDescriptor]:
    if maximum is None:
        return descriptors
    if maximum < 3:
        raise ConfigError("max_runs_per_condition must be at least three")
    grouped: dict[tuple[int, int, int, str], list[TepRunDescriptor]] = defaultdict(list)
    for descriptor in descriptors:
        grouped[descriptor.stratum].append(descriptor)
    selected: list[TepRunDescriptor] = []
    for items in grouped.values():
        selected.extend(
            sorted(items, key=lambda item: _stable_order(item.run_id, seed))[:maximum]
        )
    return sorted(selected, key=lambda item: item.run_id)


def prepare_tep_reinartz_dataset(
    raw_dir: str | Path,
    output_dir: str | Path,
    *,
    modes: Iterable[int] | None = None,
    fault_ids: Iterable[int] | None = None,
    magnitudes: Iterable[int] | None = None,
    include_stopped: bool = False,
    max_runs_per_condition: int | None = None,
    row_stride: int = 1,
    seed: int = 20260829,
    train_ratio: float = 0.6,
    val_ratio: float = 0.2,
) -> dict[str, Any]:
    """Materialize leakage-safe CSV tables from official Extended TEP HDF5 files."""

    try:
        import h5py
    except ImportError as exc:
        raise ConfigError("Extended TEP preparation requires the h5py package") from exc
    if row_stride < 1:
        raise ConfigError("row_stride must be at least one")
    requested_faults = set(int(value) for value in fault_ids or RETAINED_TEP_FAULT_IDS)
    unsupported = sorted(requested_faults.difference(RETAINED_TEP_FAULT_IDS))
    if unsupported:
        reasons = {
            spec.fault_id: spec.exclusion_reason
            for spec in TEP_FAULT_SPECS
            if spec.fault_id in unsupported
        }
        raise ConfigError(
            "Extended TEP preparation is fail-closed for disturbances without "
            f"an auditable component-fault ontology: {reasons}"
        )
    descriptors = scan_tep_reinartz(
        raw_dir,
        modes=modes,
        fault_ids=sorted(requested_faults),
        magnitudes=magnitudes,
        include_stopped=include_stopped,
    )
    descriptors = _select_runs_per_stratum(descriptors, max_runs_per_condition, seed)
    if not descriptors:
        raise ConfigError("No Extended TEP single-fault runs match the selection")
    split_by_run = assign_tep_splits(
        descriptors,
        seed=seed,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
    )
    output = Path(output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    targets = {
        "measurements": output / "measurements.csv.gz",
        "labels": output / "labels.csv.gz",
        "oracle": output / "oracle_states.csv.gz",
    }
    temporary = {name: path.with_name(path.name + ".tmp") for name, path in targets.items()}
    for path in temporary.values():
        path.unlink(missing_ok=True)
    manifest_rows: list[dict[str, Any]] = []
    total_rows = 0
    opened_file: str | None = None
    handle: Any = None
    wrote_header = False
    try:
        for descriptor in descriptors:
            if opened_file != descriptor.file_path:
                if handle is not None:
                    handle.close()
                handle = h5py.File(descriptor.file_path, "r")
                opened_file = descriptor.file_path
            group = handle[descriptor.hdf5_path]
            process = _samples_by_columns(_find_dataset(group, "processdata"), 54, "processdata")
            additional = _samples_by_columns(_find_dataset(group, "additional_meas"), 32, "additional_meas")
            if process.shape[0] != additional.shape[0]:
                raise ConfigError(
                    f"Run {descriptor.run_id} has incompatible process and additional row counts"
                )
            monitoring_dataset = _find_dataset(group, "idv_monitoring", required=False)
            if monitoring_dataset is None:
                nominal_monitoring = np.asarray(
                    [ORACLE_NOMINAL_VALUES[index] for index in range(1, 22)],
                    dtype=np.float64,
                )
                monitoring = np.broadcast_to(
                    nominal_monitoring, (process.shape[0], 21)
                ).copy()
                monitoring_source = "source_nominal_inactive_monitor_processes"
            else:
                monitoring = _samples_by_columns(monitoring_dataset, 21, "idv_monitoring")
                if monitoring.shape[0] != process.shape[0]:
                    raise ConfigError(
                        f"Run {descriptor.run_id} has incompatible IDV-monitoring row count"
                    )
                if not np.isfinite(monitoring).all():
                    raise ConfigError(
                        f"Run {descriptor.run_id} has non-finite IDV-monitoring values"
                    )
                monitoring_source = "hdf5_idv_monitoring"
            selected = np.arange(0, process.shape[0], row_stride, dtype=int)
            process = process[selected]
            additional = additional[selected]
            monitoring = monitoring[selected]
            timestamp = process[:, 0].astype(np.float64)
            onset_h = _fault_onset_hours(group, descriptor.fault_id, fallback=30.0)
            is_post_fault = timestamp >= onset_h
            feature_values = np.concatenate([process[:, 1:54], additional], axis=1)
            run_id = descriptor.run_id
            row_ids = [f"{run_id}:{int(index)}" for index in selected]
            measurements = pd.DataFrame(feature_values, columns=ONLINE_FEATURE_COLUMNS)
            measurements.insert(0, "run_id", run_id)
            measurements.insert(0, "timestamp", timestamp)
            measurements.insert(0, "row_id", row_ids)
            specification = FAULT_BY_ID[descriptor.fault_id]
            label = specification.label
            labels = pd.DataFrame(
                {
                    "row_id": row_ids,
                    "run_id": run_id,
                    "fault_label": np.where(is_post_fault, label, "normal"),
                    "root_cause_component": np.where(
                        is_post_fault, specification.physical_component, ""
                    ),
                    "root_cause_fault": np.where(
                        is_post_fault, specification.fault_type, ""
                    ),
                    "split": split_by_run[run_id],
                    "fault_id": descriptor.fault_id,
                    "fault_onset_step": int(np.searchsorted(timestamp, onset_h, side="left")),
                    "operating_mode": descriptor.mode,
                    "fault_magnitude": descriptor.magnitude,
                    "simulation_seed": descriptor.run_number,
                    "is_post_fault": is_post_fault,
                    "completion_status": descriptor.completion_status,
                }
            )
            oracle = pd.DataFrame(monitoring, columns=ORACLE_COLUMNS)
            oracle.insert(0, "row_id", row_ids)
            for name, frame in (("measurements", measurements), ("labels", labels), ("oracle", oracle)):
                frame.to_csv(
                    temporary[name],
                    mode="a",
                    index=False,
                    header=not wrote_header,
                    compression="gzip",
                )
            wrote_header = True
            total_rows += len(selected)
            manifest_rows.append(
                {
                    **asdict(descriptor),
                    "run_id": run_id,
                    "split": split_by_run[run_id],
                    "sample_count": int(len(selected)),
                    "fault_onset_hours": float(onset_h),
                    "fault_label": label,
                    "root_cause_component": specification.physical_component,
                    "root_cause_fault": specification.fault_type,
                    "root_cause_pair": specification.root_cause,
                    "oracle_state_source": monitoring_source,
                }
            )
    finally:
        if handle is not None:
            handle.close()
    for name, path in targets.items():
        temporary[name].replace(path)
    pd.DataFrame(manifest_rows).to_csv(output / "manifest.csv", index=False)
    _write_variable_dictionary(output / "variable_dictionary.csv")
    _write_fault_ontology(output / "fault_ontology.csv")
    ontology_preflight = tep_ontology_preflight()
    (output / "ontology_preflight.json").write_text(
        json.dumps(ontology_preflight, indent=2, sort_keys=True), encoding="utf-8"
    )
    topology = tep_topology_payload()
    (output / "topology.json").write_text(
        json.dumps(topology, indent=2, sort_keys=True), encoding="utf-8"
    )
    (output / "feature_columns.txt").write_text(
        "\n".join(ONLINE_FEATURE_COLUMNS) + "\n", encoding="utf-8"
    )
    summary = {
        "dataset": "tep_reinartz",
        "source_doi": "10.11583/DTU.13385936.v1",
        "publication_doi": "10.1016/j.compchemeng.2021.107281",
        "run_count": len(descriptors),
        "row_count": total_rows,
        "online_feature_count": len(ONLINE_FEATURE_COLUMNS),
        "offline_oracle_count": len(ORACLE_COLUMNS),
        "offline_oracle_policy": (
            "Use finite HDF5 idv_monitoring values when present. For official "
            "runs that omit this dataset because the monitored random processes "
            "are inactive, use the source-defined nominal simulator values. "
            "Never substitute a structural proxy for a configured oracle target."
        ),
        "modes": sorted({item.mode for item in descriptors}),
        "fault_ids": sorted({item.fault_id for item in descriptors}),
        "magnitudes": sorted({item.magnitude for item in descriptors}),
        "split_run_counts": pd.Series(split_by_run).value_counts().sort_index().to_dict(),
        "root_cause_policy": (
            "Root causes are reviewed <physical component, fault type> pairs. "
            "IDV19 and IDV20 are excluded because no auditable physical injection "
            "component is supplied."
        ),
        "retained_fault_ids": list(RETAINED_TEP_FAULT_IDS),
        "excluded_fault_ids": list(EXCLUDED_TEP_FAULT_IDS),
        "ontology_preflight_ready": bool(ontology_preflight["ready"]),
        "fault_onset_policy": "Read from idv_init when available, otherwise 30 simulation hours from the primary source",
        "leakage_audit": {
            "idv_init_online": False,
            "idv_monitoring_online": False,
            "fault_label_online": False,
            "root_cause_online": False,
            "simulation_seed_online": False,
            "online_columns": list(ONLINE_FEATURE_COLUMNS),
        },
    }
    (output / "preparation_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )
    return summary


def _normalized_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).lower())


def _find_dataset(group: Any, name: str, *, required: bool = True) -> np.ndarray | None:
    wanted = _normalized_key(name)
    for key in group.keys():
        if _normalized_key(key) == wanted:
            return np.asarray(group[key][()])
    if required:
        raise ConfigError(f"TEP run group {group.name!r} has no dataset {name!r}")
    return None


def _samples_by_columns(values: np.ndarray, expected_columns: int, name: str) -> np.ndarray:
    array = np.asarray(values).squeeze()
    if array.ndim != 2:
        raise ConfigError(f"TEP dataset {name!r} must be two-dimensional, got {array.shape}")
    if array.shape[1] == expected_columns:
        return array.astype(np.float64, copy=False)
    if array.shape[0] == expected_columns:
        return array.T.astype(np.float64, copy=False)
    raise ConfigError(
        f"TEP dataset {name!r} has shape {array.shape}, expected one axis of {expected_columns}"
    )


def _fault_onset_hours(group: Any, fault_id: int, fallback: float) -> float:
    values = _find_dataset(group, "idv_init", required=False)
    if values is None:
        return fallback
    array = np.asarray(values).squeeze()
    if array.ndim != 2:
        return fallback
    if array.shape == (3, 28):
        candidate = array[2, fault_id - 1]
    elif array.shape == (28, 3):
        candidate = array[fault_id - 1, 2]
    else:
        return fallback
    return float(candidate) if np.isfinite(candidate) and candidate >= 0.0 else fallback


def _write_variable_dictionary(path: Path) -> None:
    rows = [
        {"column": process_feature(index), "source": f"processdata pd({index})", "role": "online_measurement", "description": PROCESS_VARIABLES[index]}
        for index in range(2, 55)
    ]
    rows.extend(
        {"column": additional_feature(index), "source": f"additional_meas add({index})", "role": "online_measurement", "description": ADDITIONAL_VARIABLES[index]}
        for index in range(1, 33)
    )
    rows.extend(
        {
            "column": oracle_feature(index),
            "source": f"idv_monitoring idv_mon({index})",
            "role": "offline_oracle_only",
            "description": ORACLE_VARIABLES[index],
            "source_nominal_value": ORACLE_NOMINAL_VALUES[index],
        }
        for index in range(1, 22)
    )
    pd.DataFrame(rows).to_csv(path, index=False)


def _write_fault_ontology(path: Path) -> None:
    rows = []
    for spec in TEP_FAULT_SPECS:
        rows.append(
            {
                "fault_id": spec.fault_id,
                "fault_label": spec.label,
                "root_cause_component": spec.physical_component,
                "root_cause_fault": spec.fault_type,
                "root_cause_pair": spec.root_cause if spec.included else "",
                "plant_module": spec.plant_module,
                "disturbance_type": spec.disturbance_type,
                "description": spec.description,
                "physical_quantity": spec.physical_quantity,
                "component_variables": ",".join(spec.component_variables),
                "primary_variable": spec.primary_variable if spec.included else "",
                "causal_inputs": ",".join(spec.causal_inputs),
                "observable_effects": ",".join(spec.observable_effects),
                "state_inputs": ",".join(spec.state_inputs),
                "state_oracle_column": (
                    ",".join(
                        oracle_feature(index)
                        for index in (
                            spec.state_oracle_indices
                            or (
                                (spec.state_oracle_index,)
                                if spec.state_oracle_index is not None
                                else ()
                            )
                        )
                    )
                ),
                "ontology_specificity": "physical_component_fault_pair",
                "physical_cause_known": spec.included,
                "included_in_experiment": spec.included,
                "exclusion_reason": spec.exclusion_reason,
                "sources": " | ".join(spec.ontology_sources),
            }
        )
    pd.DataFrame(rows).to_csv(path, index=False)


def tep_ontology_preflight() -> dict[str, Any]:
    """Validate the reviewed TEP component-fault contract without data loading."""

    errors: list[str] = []
    if {spec.fault_id for spec in TEP_FAULT_SPECS} != set(range(1, 29)):
        errors.append("The ontology must account for IDV1 through IDV28 exactly once")
    if set(EXCLUDED_TEP_FAULT_IDS) != {19, 20}:
        errors.append("Only the physically unknown IDV19 and IDV20 may be excluded")
    if set(ORACLE_NOMINAL_VALUES) != set(range(1, 22)) or not all(
        np.isfinite(value) for value in ORACLE_NOMINAL_VALUES.values()
    ):
        errors.append("All 21 source-defined oracle nominal values must be finite")
    pairs: set[str] = set()
    for spec in RETAINED_TEP_FAULT_SPECS:
        if not all(
            (
                spec.physical_component,
                spec.fault_type,
                spec.physical_quantity,
                spec.causal_inputs,
                spec.observable_effects,
                spec.ontology_sources,
            )
        ):
            errors.append(f"{spec.label} has an incomplete physical ontology")
        if not spec.component_variables and not spec.state_name:
            errors.append(f"{spec.label} has no supplied diagnosis variable")
        if spec.state_name and not spec.state_inputs:
            errors.append(f"{spec.label} has no inputs for its technical state")
        state_oracle_indices = set(
            spec.state_oracle_indices
            or (
                (spec.state_oracle_index,)
                if spec.state_oracle_index is not None
                else ()
            )
        )
        if not state_oracle_indices.issubset(set(spec.oracle_indices)):
            errors.append(
                f"{spec.label} uses a semantic oracle outside its reviewed monitor indices"
            )
        if spec.root_cause in pairs:
            errors.append(f"Duplicate root-cause pair: {spec.root_cause}")
        pairs.add(spec.root_cause)
        for reference in (
            *spec.component_variables,
            *spec.causal_inputs,
            *spec.observable_effects,
            *spec.state_inputs,
        ):
            try:
                tep_feature(reference)
            except (ConfigError, KeyError, ValueError) as exc:
                errors.append(f"{spec.label}: {exc}")
    return {
        "ready": not errors,
        "root_cause_level": "component_fault_pair",
        "retained_fault_ids": list(RETAINED_TEP_FAULT_IDS),
        "excluded_fault_ids": list(EXCLUDED_TEP_FAULT_IDS),
        "retained_pair_count": len(pairs),
        "excluded_fault_reasons": {
            spec.label: spec.exclusion_reason
            for spec in TEP_FAULT_SPECS
            if not spec.included
        },
        "online_fault_label_use": False,
        "online_oracle_use": False,
        "errors": errors,
    }


def tep_topology_payload() -> dict[str, Any]:
    return {
        "source": "Reinartz et al. 2021 and the revised TEP process diagram by Bathelt et al. 2015",
        "modules": [
            "feed_system",
            "reactor",
            "condenser",
            "separator",
            "recycle_compressor",
            "stripper",
            "plant_wide",
        ],
        "edges": [
            {
                "source": "feed_system",
                "target": "reactor",
                "source_signal": process_feature(5),
                "target_signal": process_feature(7),
                "relation": "stream-4 feed contributes to total reactor feed",
                "min_latency_steps": 0,
                "max_latency_steps": 40,
                "influence_sign": 0,
                "operating_condition": "normal_closed_loop_operation",
                "engineering_sources": [TEP_REVISED_MODEL_SOURCE, TEP_SIMULATOR_SOURCE],
                "qualitative_relations": ["compatible"],
            },
            {
                "source": "reactor",
                "target": "condenser",
                "source_signal": process_feature(10),
                "target_signal": process_feature(12),
                "relation": "reactor thermal state propagates through the condenser to the separator temperature",
                "min_latency_steps": 0,
                "max_latency_steps": 40,
                "influence_sign": 0,
                "operating_condition": "normal_closed_loop_operation",
                "engineering_sources": [TEP_REVISED_MODEL_SOURCE, TEP_SIMULATOR_SOURCE],
                "qualitative_relations": ["compatible"],
            },
            {
                "source": "condenser",
                "target": "separator",
                "source_signal": process_feature(12),
                "target_signal": process_feature(13),
                "relation": "integrated condenser-separator temperature and inventory are normally compatible",
                "min_latency_steps": 0,
                "max_latency_steps": 40,
                "influence_sign": 0,
                "operating_condition": "normal_closed_loop_operation",
                "engineering_sources": [TEP_REVISED_MODEL_SOURCE, TEP_SIMULATOR_SOURCE],
                "qualitative_relations": ["compatible"],
            },
            {
                "source": "separator",
                "target": "recycle_compressor",
                "source_signal": process_feature(14),
                "target_signal": process_feature(6),
                "relation": "separator pressure and recycle flow are normally compatible across the compressor path",
                "min_latency_steps": 0,
                "max_latency_steps": 40,
                "influence_sign": 0,
                "operating_condition": "normal_closed_loop_operation",
                "engineering_sources": [TEP_REVISED_MODEL_SOURCE, TEP_SIMULATOR_SOURCE],
                "qualitative_relations": ["compatible"],
            },
            {
                "source": "recycle_compressor",
                "target": "reactor",
                "source_signal": process_feature(6),
                "target_signal": process_feature(7),
                "relation": "compressed recycle contributes positively to total reactor feed",
                "min_latency_steps": 0,
                "max_latency_steps": 40,
                "influence_sign": 1,
                "operating_condition": "normal_closed_loop_operation",
                "engineering_sources": [TEP_REVISED_MODEL_SOURCE, TEP_SIMULATOR_SOURCE],
                "qualitative_relations": ["compatible", "co_increase"],
            },
            {
                "source": "separator",
                "target": "stripper",
                "source_signal": process_feature(15),
                "target_signal": process_feature(18),
                "relation": "separator liquid feed and stripper product flow co-vary after inventory dynamics",
                "min_latency_steps": 0,
                "max_latency_steps": 40,
                "influence_sign": 1,
                "operating_condition": "normal_closed_loop_operation",
                "engineering_sources": [TEP_REVISED_MODEL_SOURCE, TEP_SIMULATOR_SOURCE],
                "qualitative_relations": ["compatible", "co_increase"],
            },
        ],
    }
