"""V18 target-balanced structured predict-update observer."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from typing import Any

import torch
from torch import nn

from .config import ConfigError
from .knowledge import SystemKnowledge


METHOD_VERSION = "v18_audited_range_open_loop_component_fault_observer"


@dataclass(frozen=True)
class DiagnosticTargetSpec:
    """Auditable definition of one filtering-update target."""

    name: str
    owner_module: str
    target_kind: str
    output_type: str
    diagnostic_index: int
    measured_index: int | None
    reconstructed_index: int | None
    dependency_names: tuple[str, ...]
    dependency_indices: tuple[int, ...]
    outgoing_dependency_names: tuple[str, ...]
    provenance: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class StructuredObserverOutput:
    posterior_measured: torch.Tensor
    posterior_reconstructed: torch.Tensor
    prior_measured: torch.Tensor
    prior_reconstructed: torch.Tensor
    posterior_latent: torch.Tensor
    prior_latent: torch.Tensor
    filter_logits: torch.Tensor
    prior_logits: torch.Tensor
    filter_affine: torch.Tensor
    filter_nonlinear_residual: torch.Tensor


@dataclass
class NominalRealTrajectoryOutput:
    """Two trajectories used by the V18 diagnostic protocol.

    ``p_real`` assimilates the measurements that are available under the
    immutable observation configuration. ``p_nominal`` starts at the last
    admissible boundary state and is then rolled forward recursively. Only
    explicitly declared exogenous inputs may be copied into that rollout.
    """

    p_real: torch.Tensor
    p_nominal: torch.Tensor
    p_real_horizons: torch.Tensor
    p_nominal_horizons: torch.Tensor
    boundary_index: int
    delta_t_steps: int
    # Retain binary logits before sigmoid for numerically stable training.
    # Legacy trajectory providers may omit them. Columns follow the model's
    # binary_diagnostic_indices, not the complete diagnostic state.
    nominal_binary_logits: torch.Tensor | None = None

def _module_key(name: str) -> str:
    return "t_" + hashlib.sha1(name.encode("utf-8")).hexdigest()[:16]


def _looks_binary(name: str, kind: str = "") -> bool:
    # Names such as reactive_power contain "active" but are continuous.
    # A probability-valued head requires an explicit datatype declaration.
    return kind.strip().lower() in {"binary", "boolean", "binary_indicator"}


def build_diagnostic_target_specs(
    feature_columns: list[str],
    knowledge: SystemKnowledge,
    masked_feature_columns: list[str] | tuple[str, ...],
    config: dict[str, Any],
) -> list[DiagnosticTargetSpec]:
    """Build fixed target heads and topology-constrained incoming selectors."""

    model_cfg = config.get("model", {})
    structured_cfg = model_cfg.get("structured_observer") or {}
    dependency_scope = str(structured_cfg.get("dependency_scope", "topology")).lower()
    if dependency_scope not in {"topology", "all_available"}:
        raise ConfigError(
            "model.structured_observer.dependency_scope must be 'topology' or "
            "'all_available'"
        )
    for field in ("binary_targets", "continuous_targets"):
        declared = structured_cfg.get(field, [])
        if not isinstance(declared, (list, tuple)) or any(
            not isinstance(name, str) or not name for name in declared
        ):
            raise ConfigError(f"structured_observer.{field} must be a list of variable names")
    explicit_binary = {
        str(name) for name in structured_cfg.get("binary_targets", [])
    }
    explicit_continuous = {
        str(name) for name in structured_cfg.get("continuous_targets", [])
    }
    overlap = explicit_binary.intersection(explicit_continuous)
    if overlap:
        raise ConfigError(f"Targets cannot be both binary and continuous: {sorted(overlap)}")

    feature_index = {name: idx for idx, name in enumerate(feature_columns)}
    reconstructed_index = {
        variable.name: idx for idx, variable in enumerate(knowledge.reconstructed_variables)
    }
    diagnostic_index = {
        **feature_index,
        **{
            name: len(feature_columns) + idx
            for name, idx in reconstructed_index.items()
        },
    }
    unknown_types = sorted((explicit_binary | explicit_continuous).difference(diagnostic_index))
    if unknown_types:
        raise ConfigError(f"Unknown structured-observer typed variables: {unknown_types}")
    masked = tuple(dict.fromkeys(str(name) for name in masked_feature_columns))
    unknown = sorted(set(masked).difference(feature_index))
    if unknown:
        raise ConfigError(f"Unknown structured-observer masked targets: {unknown}")
    masked_set = set(masked)
    available_measured = [name for name in feature_columns if name not in masked_set]
    module_by_name = {module.name: module for module in knowledge.modules}

    def output_type(name: str, kind: str = "") -> str:
        if name in explicit_binary:
            return "binary"
        if name in explicit_continuous:
            return "continuous"
        return "binary" if _looks_binary(name, kind) else "continuous"

    def topology_dependencies(name: str, owner: str) -> list[str]:
        if dependency_scope == "all_available":
            return list(available_measured)
        candidates: list[str] = []
        module = module_by_name.get(owner)
        if module is not None:
            candidates.extend(module.inputs)
            candidates.extend(module.external_inputs)
            candidates.extend(module.states)
            candidates.extend(module.outputs)
        for connection in knowledge.connections:
            if connection.target_module == owner:
                candidates.extend([connection.source_signal, connection.target_signal])
            if connection.source_module == owner and connection.source_signal == name:
                candidates.append(connection.target_signal)
        return candidates

    specs: list[DiagnosticTargetSpec] = []
    for name in masked:
        owner = knowledge.module_for_signal(name)
        if owner is None:
            raise ConfigError(f"Masked target '{name}' has no supplied module owner")
        candidates = topology_dependencies(name, owner)
        dependencies = tuple(
            dict.fromkeys(
                candidate
                for candidate in candidates
                if candidate != name
                and candidate in diagnostic_index
            )
        )
        outgoing = tuple(
            dict.fromkeys(
                [
                    connection.target_signal
                    for connection in knowledge.connections
                    if connection.source_signal == name
                ]
                + [
                    variable.name
                    for variable in knowledge.reconstructed_variables
                    if name in variable.inputs
                ]
            )
        )
        specs.append(
            DiagnosticTargetSpec(
                name=name,
                owner_module=owner,
                target_kind="masked_measured",
                output_type=output_type(name),
                diagnostic_index=feature_index[name],
                measured_index=feature_index[name],
                reconstructed_index=None,
                dependency_names=dependencies,
                dependency_indices=tuple(diagnostic_index[item] for item in dependencies),
                outgoing_dependency_names=outgoing,
                provenance=(
                    "all currently available measured inputs (sanity comparator)"
                    if dependency_scope == "all_available"
                    else "module membership and directed supplied connections"
                ),
            )
        )

    for variable in knowledge.reconstructed_variables:
        candidates = (
            list(available_measured)
            if dependency_scope == "all_available"
            else list(variable.inputs)
        )
        dependencies = tuple(
            dict.fromkeys(
                candidate
                for candidate in candidates
                if candidate != variable.name
                and candidate in diagnostic_index
            )
        )
        specs.append(
            DiagnosticTargetSpec(
                name=variable.name,
                owner_module=variable.module,
                target_kind="reconstructed",
                output_type=output_type(variable.name, variable.kind),
                diagnostic_index=len(feature_columns) + reconstructed_index[variable.name],
                measured_index=None,
                reconstructed_index=reconstructed_index[variable.name],
                dependency_names=dependencies,
                dependency_indices=tuple(diagnostic_index[item] for item in dependencies),
                outgoing_dependency_names=tuple(variable.outputs),
                provenance=variable.provenance or variable.source,
            )
        )
    return specs


class TargetUpdateHead(nn.Module):
    """One affine virtual sensor plus a zero-initialized nonlinear residual."""

    def __init__(
        self,
        dependency_count: int,
        context_dim: int,
        residual_hidden_dim: int,
        nonlinear_enabled: bool,
    ) -> None:
        super().__init__()
        # Incoming variables use measurements where available and causal
        # predictions otherwise. Ridge matches the full basis only if every
        # dependency is observed. Context enters only the nonlinear path.
        direct_dim = dependency_count
        self.affine = nn.Linear(direct_dim, 1)
        self.nonlinear_enabled = bool(nonlinear_enabled)
        if self.nonlinear_enabled:
            self.residual = nn.Sequential(
                nn.Linear(direct_dim + 1 + context_dim, residual_hidden_dim),
                nn.Tanh(),
                nn.Linear(residual_hidden_dim, 1),
            )
            nn.init.zeros_(self.residual[-1].weight)
            nn.init.zeros_(self.residual[-1].bias)
        else:
            self.residual = None

    def forward(
        self,
        dependencies: torch.Tensor,
        prior_target: torch.Tensor,
        context: torch.Tensor,
    ) -> torch.Tensor:
        result, _direct, _residual = self.components(
            dependencies, prior_target, context
        )
        return result

    def components(
        self,
        dependencies: torch.Tensor,
        prior_target: torch.Tensor,
        context: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        direct_input = dependencies
        direct = self.affine(direct_input).squeeze(-1)
        residual = torch.zeros_like(direct)
        if self.residual is not None and self.nonlinear_enabled:
            residual = self.residual(
                torch.cat([direct_input, prior_target.unsqueeze(-1), context], dim=-1)
            ).squeeze(-1)
        return direct + residual, direct, residual


class StructuredPredictUpdateObserver(nn.Module):
    """V18 observer with fixed target-specific update heads."""

    method_version = METHOD_VERSION
    architecture = "structured_predict_update_v18"
    enable_virtual_prior = True

    def __init__(
        self,
        *,
        num_features: int,
        reconstructed_variable_count: int,
        hidden_dim: int,
        target_specs: list[DiagnosticTargetSpec],
        binary_diagnostic_indices: list[int],
        feature_mean: list[float],
        feature_std: list[float],
        reconstructed_mean: list[float],
        reconstructed_std: list[float],
        residual_hidden_dim: int,
        nonlinear_enabled: bool,
        detach_causal_history: bool,
        observed_command_contract=None,
        nominal_history_steps: int | None = None,
    ) -> None:
        super().__init__()
        self.num_features = int(num_features)
        self.reconstructed_variable_count = int(reconstructed_variable_count)
        self.diagnostic_dim = self.num_features + self.reconstructed_variable_count
        self.hidden_dim = int(hidden_dim)
        self.target_specs = tuple(target_specs)
        self.target_names = tuple(spec.name for spec in target_specs)
        self.target_keys = tuple(_module_key(spec.name) for spec in target_specs)
        self.target_index_by_name = {
            spec.name: position for position, spec in enumerate(target_specs)
        }
        self.nonlinear_enabled = bool(nonlinear_enabled)
        self.detach_causal_history = bool(detach_causal_history)
        self.observed_command_contract = observed_command_contract
        self.nominal_history_steps = nominal_history_steps
        self.nominal_shutdown = None
        if nominal_history_steps is not None and (
                type(nominal_history_steps) is not int or nominal_history_steps < 1):
            raise ConfigError("Nominal history must be a positive integer")
        if observed_command_contract is not None:
            from .observed_commands import METHOD
            self.method_version = METHOD
        self.observed_command_indices = (() if observed_command_contract is None
                                         else observed_command_contract.indices)
        command_width = 3 * len(self.observed_command_indices)
        if observed_command_contract is not None:
            self.register_buffer("_observed_command_index", torch.tensor(
                self.observed_command_indices, dtype=torch.long))
            self.register_buffer("_command_support_off", torch.tensor(observed_command_contract.off))
            self.register_buffer("_command_support_on", torch.tensor(observed_command_contract.on))

        self.causal_cell = nn.LSTMCell(self.diagnostic_dim, self.hidden_dim)
        self.causal_heads = nn.ModuleList(
            nn.Linear(self.hidden_dim + command_width, 1) for _ in range(self.diagnostic_dim)
        )
        self.update_heads = nn.ModuleDict(
            {
                key: TargetUpdateHead(
                    len(spec.dependency_indices),
                    self.hidden_dim,
                    int(residual_hidden_dim),
                    self.nonlinear_enabled,
                )
                for key, spec in zip(self.target_keys, self.target_specs)
            }
        )
        # Unavailable inputs have no measured-input ridge estimate. Their
        # affine coefficients start at zero but remain trainable, also for
        # named reconstructed states and configurations without ridge.
        unavailable = set(range(self.num_features, self.diagnostic_dim))
        unavailable.update(
            int(spec.measured_index) for spec in self.target_specs
            if spec.measured_index is not None
        )
        with torch.no_grad():
            for spec, key in zip(self.target_specs, self.target_keys):
                positions = [
                    position for position, index in enumerate(spec.dependency_indices)
                    if index in unavailable
                ]
                if positions:
                    self.update_heads[key].affine.weight[0, positions] = 0.
        mean = list(feature_mean) + list(reconstructed_mean)
        std = list(feature_std) + list(reconstructed_std)
        if len(mean) != self.diagnostic_dim or len(std) != self.diagnostic_dim:
            raise ConfigError(
                "Structured observer scaling does not match diagnostic state: "
                f"{len(mean)} means/{len(std)} stds for {self.diagnostic_dim} values"
            )
        mean_tensor = torch.as_tensor(mean, dtype=torch.float32)
        std_tensor = torch.as_tensor(std, dtype=torch.float32)
        if (not bool(torch.isfinite(mean_tensor).all())
                or not bool(torch.isfinite(std_tensor).all())
                or bool((std_tensor <= 0).any())):
            raise ConfigError("Structured observer scaling requires finite means and positive finite standard deviations")
        self.register_buffer("diagnostic_mean", mean_tensor)
        self.register_buffer("diagnostic_std", std_tensor)
        binary = torch.zeros(self.diagnostic_dim, dtype=torch.bool)
        for index in binary_diagnostic_indices:
            binary[int(index)] = True
        self.register_buffer("binary_diagnostic_mask", binary)
        # Identity metadata stays on the host. Device-side nonzero would
        # synchronize CUDA at every recurrent step.
        self.binary_diagnostic_indices = tuple(int(i) for i in binary_diagnostic_indices)
        self.register_buffer("_binary_indices", torch.tensor(self.binary_diagnostic_indices, dtype=torch.long), persistent=False)
        self.recurrence_backend = "eager"
        self.recurrence_chunk_size = 8
        object.__setattr__(self, "_recurrence_functions", None)

    @property
    def measured_dependency_indices(self) -> dict[int, tuple[int, ...]]:
        return {
            int(spec.measured_index): tuple(
                idx for idx in spec.dependency_indices if idx < self.num_features
            )
            for spec in self.target_specs
            if spec.measured_index is not None
        }

    def target_manifest(self) -> list[dict[str, Any]]:
        return [spec.to_dict() for spec in self.target_specs]

    def _standardized_from_logit(self, logit: torch.Tensor, index: int) -> torch.Tensor:
        raw = torch.sigmoid(logit)
        return (raw - self.diagnostic_mean[index]) / torch.clamp(
            self.diagnostic_std[index], min=1.0e-8
        )

    def _packed_causal_parameters(self) -> tuple[torch.Tensor, torch.Tensor]:
        """Fuse evaluation, retaining separate parameters and checkpoint keys."""
        return (torch.cat([head.weight for head in self.causal_heads], 0),
                torch.cat([head.bias for head in self.causal_heads], 0))

    def _causal_state(
        self, context: torch.Tensor,
        packed: tuple[torch.Tensor, torch.Tensor] | None = None,
        command_context: torch.Tensor | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        weight, bias = packed if packed is not None else self._packed_causal_parameters()
        if self.observed_command_indices:
            if command_context is None:
                raise ConfigError("A conditioned prediction requires current recorded commands")
            context = torch.cat([context, command_context], -1)
        logits = nn.functional.linear(context, weight, bias)
        values = logits.clone()
        binary_indices = self._binary_indices
        if self.binary_diagnostic_indices:
            binary_logits = logits.index_select(1, binary_indices)
            means = self.diagnostic_mean.index_select(0, binary_indices)
            stds = torch.clamp(
                self.diagnostic_std.index_select(0, binary_indices), min=1.0e-8
            )
            binary_values = (torch.sigmoid(binary_logits) - means) / stds
            values = values.index_copy(1, binary_indices, binary_values)
        return values, logits

    def _packed_update_parameters(self):
        """Batch independent heads of equal shape without sharing weights."""
        groups: dict[tuple[int, bool], list[int]] = {}
        for position, (spec, key) in enumerate(zip(self.target_specs, self.target_keys)):
            head = self.update_heads[key]
            groups.setdefault((len(spec.dependency_indices), head.residual is not None and head.nonlinear_enabled), []).append(position)
        result = []
        for (width, nonlinear), positions in groups.items():
            heads = [self.update_heads[self.target_keys[p]] for p in positions]
            device = heads[0].affine.weight.device
            dependencies = torch.tensor([i for p in positions for i in self.target_specs[p].dependency_indices], device=device, dtype=torch.long)
            targets = torch.tensor([self.target_specs[p].diagnostic_index for p in positions], device=device, dtype=torch.long)
            params = [torch.stack([h.affine.weight for h in heads]), torch.stack([h.affine.bias for h in heads])]
            if nonlinear:
                params.extend([torch.stack([h.residual[layer].weight for h in heads]) for layer in (0, 2)])
                params.extend([torch.stack([h.residual[layer].bias for h in heads]) for layer in (0, 2)])
            result.append((positions, width, dependencies, targets, params))
        return result

    def _batched_updates(self, online: torch.Tensor, prior: torch.Tensor,
                         context: torch.Tensor, groups):
        logits, affine, residual = ([None] * len(self.target_specs) for _ in range(3))
        for positions, width, dependencies, targets, params in groups:
            count = len(positions)
            x = online.index_select(1, dependencies).reshape(online.shape[0], count, width).transpose(0, 1)
            direct = torch.bmm(x, params[0].transpose(1, 2)) + params[1][:, None, :]
            nonlinear = torch.zeros_like(direct)
            if len(params) > 2:
                features = torch.cat([x, prior.index_select(1, targets).T.unsqueeze(-1), context.unsqueeze(0).expand(count, -1, -1)], -1)
                hidden = torch.tanh(torch.bmm(features, params[2].transpose(1, 2)) + params[4][:, None, :])
                nonlinear = torch.bmm(hidden, params[3].transpose(1, 2)) + params[5][:, None, :]
            for local, position in enumerate(positions):
                affine[position] = direct[local, :, 0]
                residual[position] = nonlinear[local, :, 0]
                logits[position] = affine[position] + residual[position]
        return logits, affine, residual

    def _dependency_values(
        self,
        spec: DiagnosticTargetSpec,
        values_t: torch.Tensor,
        mask_t: torch.Tensor,
        prior_full: torch.Tensor,
    ) -> torch.Tensor:
        columns: list[torch.Tensor] = []
        for index in spec.dependency_indices:
            if index < self.num_features:
                current = values_t[:, index]
                available = mask_t[:, index] > 0.5
                columns.append(torch.where(available, current, prior_full[:, index]))
            else:
                columns.append(prior_full[:, index])
        if not columns:
            return values_t.new_zeros((values_t.shape[0], 0))
        return torch.stack(columns, dim=1)

    def observed_command_features(self, values, mask):
        """Validate genuine available inputs before any compiled region."""
        if not self.observed_command_indices:
            return values.new_empty((*values.shape[:2], 0)), None
        from .observed_commands import causal_command_features
        commands = values.index_select(-1, self._observed_command_index)
        available = mask.index_select(-1, self._observed_command_index) > .5
        if not bool((available & torch.isfinite(commands)).all()):
            raise ConfigError("Recorded commands must be available and finite")
        mean = self.diagnostic_mean.index_select(0, self._observed_command_index)
        std = self.diagnostic_std.index_select(0, self._observed_command_index)
        physical = commands * std + mean
        supported = (torch.isclose(physical, self._command_support_off, atol=2.e-5, rtol=1.e-6)
                     | torch.isclose(physical, self._command_support_on, atol=2.e-5, rtol=1.e-6))
        if not bool(supported.all()):
            raise ConfigError("Recorded command lies outside its declared support")
        return causal_command_features(commands, self.observed_command_contract.age_cap_steps)

    def predict_update_sequence(
        self, values: torch.Tensor, mask: torch.Tensor
    ) -> StructuredObserverOutput:
        if self._recurrence_functions is not None:
            from .compiled_recurrence import predict_update_compiled
            return predict_update_compiled(self, values, mask)
        return self._predict_update_sequence_eager(values, mask)

    def _predict_update_sequence_eager(
        self, values: torch.Tensor, mask: torch.Tensor
    ) -> StructuredObserverOutput:
        if values.ndim != 3 or mask.shape != values.shape:
            raise ValueError("values and mask must have identical [batch,time,feature] shape")
        if values.shape[-1] != self.num_features:
            raise ValueError(
                f"Expected {self.num_features} measured features, got {values.shape[-1]}"
            )
        batch, steps, _ = values.shape
        command_context, _command_age = self.observed_command_features(values, mask)
        hidden = values.new_zeros((batch, self.hidden_dim))
        cell = values.new_zeros((batch, self.hidden_dim))
        previous = values.new_zeros((batch, self.diagnostic_dim))

        posterior_measured: list[torch.Tensor] = []
        posterior_reconstructed: list[torch.Tensor] = []
        prior_measured: list[torch.Tensor] = []
        prior_reconstructed: list[torch.Tensor] = []
        posterior_latent: list[torch.Tensor] = []
        prior_latent: list[torch.Tensor] = []
        filter_logits: list[torch.Tensor] = []
        prior_logits: list[torch.Tensor] = []
        affine_sequence: list[torch.Tensor] = []
        nonlinear_residual_sequence: list[torch.Tensor] = []

        measured_target_specs = [
            (position, spec, key)
            for position, (spec, key) in enumerate(zip(self.target_specs, self.target_keys))
            if spec.measured_index is not None
        ]
        reconstructed_target_specs = [
            (position, spec, key)
            for position, (spec, key) in enumerate(zip(self.target_specs, self.target_keys))
            if spec.reconstructed_index is not None
        ]
        causal_parameters = self._packed_causal_parameters()
        update_parameters = self._packed_update_parameters()
        # Immutable selectors must not be constructed and transferred to CUDA
        # at every recurrent step. They do not depend on measurements or time.
        measured_index_tensor = torch.tensor(
            [spec.measured_index for _, spec, _ in measured_target_specs],
            dtype=torch.long, device=values.device,
        )
        reconstructed_index_tensor = torch.tensor(
            [spec.reconstructed_index for _, spec, _ in reconstructed_target_specs],
            dtype=torch.long, device=values.device,
        )
        measured_positions = torch.tensor(
            [position for position, _, _ in measured_target_specs],
            dtype=torch.long, device=values.device,
        )
        reconstructed_positions = torch.tensor(
            [position for position, _, _ in reconstructed_target_specs],
            dtype=torch.long, device=values.device,
        )
        binary_positions_host = [
            position for position, spec in enumerate(self.target_specs)
            if spec.output_type == "binary"
        ]
        binary_positions = torch.tensor(binary_positions_host, dtype=torch.long, device=values.device)
        binary_targets = torch.tensor(
            [self.target_specs[position].diagnostic_index for position in binary_positions_host],
            dtype=torch.long, device=values.device,
        )
        binary_means = self.diagnostic_mean.index_select(0, binary_targets)
        binary_stds = self.diagnostic_std.index_select(0, binary_targets).clamp(min=1.e-8)

        for time_index in range(steps):
            if time_index > 0:
                hidden, cell = self.causal_cell(previous, (hidden, cell))
            prior_full, causal_logits = (
                self._causal_state(hidden, causal_parameters, command_context[:, time_index])
                if self.observed_command_indices else self._causal_state(hidden, causal_parameters))
            values_t = values[:, time_index, :]
            mask_t = mask[:, time_index, :]
            measured_b = torch.where(mask_t > 0.5, values_t, prior_full[:, : self.num_features])
            reconstructed_b = prior_full[:, self.num_features :]
            # Build the tensor from the head outputs instead of assigning the
            # outputs into a preallocated tensor.  Besides being clearer, this
            # keeps an explicit autograd path from every target loss to its
            # dedicated head.
            online = torch.cat([measured_b, reconstructed_b], dim=1)
            target_logit_values, target_affine_values, target_residual_values = self._batched_updates(
                online, prior_full, hidden, update_parameters
            )

            if target_logit_values:
                if any(item is None for item in target_logit_values):
                    raise RuntimeError("A structured target head did not produce an output")
                target_logits_t = torch.stack(target_logit_values, dim=1)
            else:
                target_logits_t = values.new_zeros((batch, 0))
            target_updates = target_logits_t
            if binary_positions_host:
                binary_updates = (
                    target_logits_t.index_select(1, binary_positions).sigmoid() - binary_means
                ) / binary_stds
                target_updates = target_updates.index_copy(1, binary_positions, binary_updates)
            if measured_target_specs:
                measured_b = measured_b.index_copy(
                    1, measured_index_tensor, target_updates.index_select(1, measured_positions)
                )

            if reconstructed_target_specs:
                reconstructed_b = reconstructed_b.index_copy(
                    1, reconstructed_index_tensor, target_updates.index_select(1, reconstructed_positions)
                )

            # Re-clamp every available current measurement after all heads.
            measured_b = torch.where(mask_t > 0.5, values_t, measured_b)
            target_affine_t = (
                torch.stack(
                    [item for item in target_affine_values if item is not None], dim=1
                )
                if target_affine_values
                else values.new_zeros((batch, 0))
            )
            target_residual_t = (
                torch.stack(
                    [item for item in target_residual_values if item is not None], dim=1
                )
                if target_residual_values
                else values.new_zeros((batch, 0))
            )
            full_b = torch.cat([measured_b, reconstructed_b], dim=1)
            latent_b = torch.cat([reconstructed_b, hidden], dim=1)
            latent_a = torch.cat(
                [prior_full[:, self.num_features :], hidden], dim=1
            )
            posterior_measured.append(measured_b)
            posterior_reconstructed.append(reconstructed_b)
            prior_measured.append(prior_full[:, : self.num_features])
            prior_reconstructed.append(prior_full[:, self.num_features :])
            posterior_latent.append(latent_b)
            prior_latent.append(latent_a)
            filter_logits.append(target_logits_t)
            prior_logits.append(causal_logits)
            affine_sequence.append(target_affine_t)
            nonlinear_residual_sequence.append(target_residual_t)
            previous = full_b.detach() if self.detach_causal_history else full_b

        def stack(items: list[torch.Tensor], width: int) -> torch.Tensor:
            if items:
                return torch.stack(items, dim=1)
            return values.new_zeros((batch, 0, width))

        return StructuredObserverOutput(
            posterior_measured=stack(posterior_measured, self.num_features),
            posterior_reconstructed=stack(
                posterior_reconstructed, self.reconstructed_variable_count
            ),
            prior_measured=stack(prior_measured, self.num_features),
            prior_reconstructed=stack(prior_reconstructed, self.reconstructed_variable_count),
            posterior_latent=stack(
                posterior_latent, self.reconstructed_variable_count + self.hidden_dim
            ),
            prior_latent=stack(
                prior_latent, self.reconstructed_variable_count + self.hidden_dim
            ),
            filter_logits=stack(filter_logits, len(self.target_specs)),
            prior_logits=stack(prior_logits, self.diagnostic_dim),
            filter_affine=stack(affine_sequence, len(self.target_specs)),
            filter_nonlinear_residual=stack(
                nonlinear_residual_sequence, len(self.target_specs)
            ),
        )

    def reconstruct_sequence(
        self, values: torch.Tensor, mask: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        output = self.predict_update_sequence(values, mask)
        return output.posterior_measured, output.posterior_latent

    def forward(
        self, values: torch.Tensor, mask: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        sequence, latent = self.reconstruct_sequence(values, mask)
        return sequence[:, -1, :], latent[:, -1, :]

    def predict_virtual_prior(
        self, reconstructed_history: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if reconstructed_history.ndim != 3 or reconstructed_history.shape[1] < 1:
            raise ValueError("reconstructed_history must contain at least one past time step")
        batch = reconstructed_history.shape[0]
        if reconstructed_history.shape[-1] == self.num_features:
            reconstructed_padding = reconstructed_history.new_zeros(
                (batch, reconstructed_history.shape[1], self.reconstructed_variable_count)
            )
            history = torch.cat([reconstructed_history, reconstructed_padding], dim=-1)
        elif reconstructed_history.shape[-1] == self.diagnostic_dim:
            history = reconstructed_history
        else:
            raise ValueError(
                "Structured causal history must contain measured or complete diagnostic state"
            )
        if self._recurrence_functions is not None:
            from .compiled_recurrence import history_state
            hidden, _cell = history_state(self, history)
            prior, _logits = self._causal_state(hidden)
            prior_latent = torch.cat([prior[:, self.num_features:], hidden], dim=1)
            return prior[:, :self.num_features], prior_latent
        hidden = history.new_zeros((batch, self.hidden_dim))
        cell = history.new_zeros((batch, self.hidden_dim))
        for index in range(history.shape[1]):
            hidden, cell = self.causal_cell(history[:, index, :], (hidden, cell))
        prior, _logits = self._causal_state(hidden)
        prior_latent = torch.cat([prior[:, self.num_features :], hidden], dim=1)
        return prior[:, : self.num_features], prior_latent

    def nominal_real_trajectories(
        self,
        values: torch.Tensor,
        mask: torch.Tensor,
        *,
        delta_t_steps: int,
        exogenous_measured_indices: tuple[int, ...] = (),
        p_real_output: StructuredObserverOutput | None = None,
    ) -> NominalRealTrajectoryOutput:
        """Construct non-leaking real and nominal trajectories.

        The boundary is the state at ``t-delta_t``. Later process measurements
        are excluded from the nominal rollout. The recurrent model consumes
        its own previous complete diagnostic state. Declared exogenous values
        are the only permitted within-window values copied from ``values``.
        """

        if values.ndim != 3 or values.shape != mask.shape:
            raise ValueError("values and mask must have identical [batch,time,feature] shape")
        steps = int(delta_t_steps)
        if steps < 1 or steps >= values.shape[1]:
            raise ValueError(
                "delta_t_steps must be positive and smaller than the input window"
            )
        exogenous = tuple(dict.fromkeys(int(index) for index in exogenous_measured_indices))
        command_context, _command_age = self.observed_command_features(values, mask)
        if self.observed_command_indices:
            if exogenous and exogenous != self.observed_command_indices:
                raise ConfigError("A recorded-command model cannot mix another exogenous policy")
            exogenous = self.observed_command_indices
        if any(index < 0 or index >= self.num_features for index in exogenous):
            raise ValueError("exogenous measured index lies outside the measured state")
        exogenous_index = torch.tensor(exogenous, dtype=torch.long, device=values.device)
        if exogenous:
            # A safe command identity does not make an unavailable value
            # observable. Reject missing rollout commands before copying any
            # raw values, including when a precomputed real output is supplied.
            available = mask[:, -steps:, :].index_select(2, exogenous_index) > 0.5
            commands = values[:, -steps:, :].index_select(2, exogenous_index)
            if not bool((available & torch.isfinite(commands)).all()):
                raise ConfigError("Exogenous rollout inputs must be available and finite")

        real_output = p_real_output or self.predict_update_sequence(values, mask)
        p_real_sequence = torch.cat(
            [real_output.posterior_measured, real_output.posterior_reconstructed], dim=-1
        )
        boundary_index = values.shape[1] - steps - 1
        if (self.observed_command_contract is not None
                and boundary_index + 1 < self.observed_command_contract.age_cap_steps):
            raise ConfigError("Recorded-command history must resolve the capped command age")
        history = p_real_sequence[:, : boundary_index + 1, :]
        if self.observed_command_indices and self.nominal_history_steps is not None:
            if boundary_index + 1 < self.nominal_history_steps:
                raise ConfigError("The declared nominal initial history is unavailable")
            start = boundary_index + 1 - self.nominal_history_steps
            if start:
                # Do not borrow reconstructed states whose recurrent memory
                # includes older observations outside the declared history.
                initial = self.predict_update_sequence(values[:, start:boundary_index + 1],
                                                       mask[:, start:boundary_index + 1])
                history = torch.cat([initial.posterior_measured, initial.posterior_reconstructed], -1)
        if self._recurrence_functions is not None:
            from .compiled_recurrence import nominal_sequence
            commands = values[:, boundary_index + 1:, :].index_select(2, exogenous_index)
            nominal, logits = nominal_sequence(
                self, history, commands, exogenous_index, self._packed_causal_parameters(),
                command_context[:, boundary_index + 1:])
            real = p_real_sequence[:, boundary_index + 1:, :]
            return NominalRealTrajectoryOutput(
                real[:, -1], nominal[:, -1], real, nominal,
                int(boundary_index), steps, logits)
        # The previous implementation replayed this prefix for EVERY horizon.
        # The identical recurrent state can be reused because subsequent
        # inputs are solely the preceding open-loop predictions.
        hidden = values.new_zeros((values.shape[0], self.hidden_dim))
        cell = torch.zeros_like(hidden)
        for index in range(history.shape[1]):
            hidden, cell = self.causal_cell(history[:, index, :], (hidden, cell))
        causal_parameters = self._packed_causal_parameters()
        from .nominal_shutdown import shutdown_initial, shutdown_step
        shutdown_state = shutdown_initial(self, history)
        nominal_horizons: list[torch.Tensor] = []
        binary_logits: list[torch.Tensor] = []
        for horizon in range(1, steps + 1):
            predicted_full, logits = (
                self._causal_state(hidden, causal_parameters, command_context[:, boundary_index + horizon])
                if self.observed_command_indices else self._causal_state(hidden, causal_parameters))
            if self.binary_diagnostic_indices:
                binary_logits.append(logits.index_select(1, self._binary_indices))
            if exogenous:
                source_time = boundary_index + horizon
                predicted_full = predicted_full.index_copy(
                    1, exogenous_index, values[:, source_time, :].index_select(1, exogenous_index)
                )
            predicted_full, shutdown_state = shutdown_step(
                self, predicted_full, shutdown_state, command_context[:, boundary_index + horizon])
            nominal_horizons.append(predicted_full)
            if horizon < steps:
                hidden, cell = self.causal_cell(predicted_full, (hidden, cell))

        nominal_sequence = torch.stack(nominal_horizons, dim=1)
        real_horizons = p_real_sequence[:, boundary_index + 1 :, :]
        return NominalRealTrajectoryOutput(
            p_real=real_horizons[:, -1, :],
            p_nominal=nominal_sequence[:, -1, :],
            p_real_horizons=real_horizons,
            p_nominal_horizons=nominal_sequence,
            boundary_index=int(boundary_index),
            delta_t_steps=steps,
            nominal_binary_logits=torch.stack(binary_logits, dim=1) if binary_logits else None,
        )

    def decode_reconstructed_variables(self, latent: torch.Tensor) -> torch.Tensor:
        return latent[..., : self.reconstructed_variable_count]

    def decode_prior_reconstructed_latents(self, latent: torch.Tensor) -> torch.Tensor:
        return latent[..., : self.reconstructed_variable_count]

    def set_nonlinear_enabled(self, enabled: bool) -> None:
        for head in self.update_heads.values():
            head.nonlinear_enabled = bool(enabled)
        self.nonlinear_enabled = bool(enabled)

    def initialize_affine_from_ridge(
        self, baselines: dict[str, Any]
    ) -> None:
        """Embed dependency-matched ridge maps exactly into measured heads."""

        models = baselines.get("target_models", {}) if baselines else {}
        for spec, key in zip(self.target_specs, self.target_keys):
            if spec.measured_index is None:
                continue
            model = models.get(str(spec.measured_index))
            if not model:
                continue
            coefficients = torch.as_tensor(
                model["coefficients"],
                dtype=self.update_heads[key].affine.weight.dtype,
                device=self.update_heads[key].affine.weight.device,
            )
            baseline_indices = [int(i) for i in model.get("dependency_indices", spec.dependency_indices)]
            if coefficients.numel() != len(baseline_indices) or not set(baseline_indices).issubset(spec.dependency_indices):
                raise ConfigError(
                    f"Ridge coefficients for {spec.name} do not match its dependencies"
                )
            with torch.no_grad():
                self.update_heads[key].affine.weight.zero_()
                positions = [spec.dependency_indices.index(i) for i in baseline_indices]
                self.update_heads[key].affine.weight[0, positions] = coefficients
                self.update_heads[key].affine.bias.fill_(float(model["intercept"]))


def build_structured_observer(
    config: dict[str, Any],
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    masked_feature_columns: list[str] | tuple[str, ...],
) -> StructuredPredictUpdateObserver:
    model_cfg = config["model"]
    structured_cfg = model_cfg.get("structured_observer") or {}
    scaling = config.get("_reconstructed_variable_scaling") or {}
    feature_mean = list(scaling.get("feature_mean") or [0.0] * len(feature_columns))
    feature_std = list(scaling.get("feature_std") or [1.0] * len(feature_columns))
    reconstructed_mean = list(
        scaling.get("reconstructed_mean") or [0.0] * len(knowledge.reconstructed_variables)
    )
    reconstructed_std = list(
        scaling.get("reconstructed_std") or [1.0] * len(knowledge.reconstructed_variables)
    )
    specs = build_diagnostic_target_specs(
        feature_columns,
        knowledge,
        masked_feature_columns,
        config,
    )
    explicit_binary = {
        str(name) for name in structured_cfg.get("binary_targets", [])
    }
    explicit_continuous = {
        str(name) for name in structured_cfg.get("continuous_targets", [])
    }
    diagnostic_names = list(feature_columns) + list(knowledge.reconstructed_variable_names)
    from .observed_commands import command_contract
    recorded_commands = command_contract(config, feature_columns, masked_feature_columns)
    kind_by_name = {variable.name: variable.kind for variable in knowledge.reconstructed_variables}
    binary_indices = [
        index
        for index, name in enumerate(diagnostic_names)
        if name in explicit_binary
        or (
            name not in explicit_continuous
            and _looks_binary(name, kind_by_name.get(name, ""))
        )
    ]
    observer = StructuredPredictUpdateObserver(
        num_features=len(feature_columns),
        reconstructed_variable_count=len(knowledge.reconstructed_variables),
        hidden_dim=int(structured_cfg.get("causal_hidden_dim", model_cfg.get("hidden_dim", 128))),
        target_specs=specs,
        binary_diagnostic_indices=binary_indices,
        feature_mean=feature_mean,
        feature_std=feature_std,
        reconstructed_mean=reconstructed_mean,
        reconstructed_std=reconstructed_std,
        residual_hidden_dim=int(structured_cfg.get("residual_hidden_dim", 64)),
        nonlinear_enabled=bool(structured_cfg.get("nonlinear_enabled", True)),
        detach_causal_history=bool(
            config.get("training", {}).get("detach_causal_history", True)
        ),
        observed_command_contract=recorded_commands,
        nominal_history_steps=(int(config.get("training", {}).get("history_steps", 240))
                               if recorded_commands is not None else None),
    )
    observer.feature_names = tuple(diagnostic_names)
    from .nominal_shutdown import configure_nominal_shutdown
    configure_nominal_shutdown(observer, structured_cfg.get('nominal_shutdown'))
    from .compiled_recurrence import configure_recurrence
    configure_recurrence(observer, structured_cfg.get("recurrence_backend", "eager"),
                         structured_cfg.get("recurrence_chunk_size", 8))
    return observer
