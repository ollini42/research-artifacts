"""Normal pump quality checks, independent of anomaly labels and thresholds."""
import numpy as np
import torch

from .config import ConfigError

PHASES = ("off", "starting", "on", "stopping")


def pump_phases(physical_commands, *, age_cap=64, transient=5):
    """Label offline NumPy recordings without copying them into PyTorch.

    As in causal_command_features, age is uncapped for phase assignment.
    age_cap affects the command feature, not these existing phase labels.
    """
    values = np.asarray(physical_commands, dtype=np.float32)
    if values.shape[1] == 0:
        return np.empty(values.shape, dtype=np.int64)
    previous = np.concatenate([values[:, :1], values[:, :-1]], axis=1)
    tick = np.arange(values.shape[1], dtype=np.int64)[None, :, None]
    last_change = np.maximum.accumulate(np.where(values != previous, tick, 0), axis=1)
    age = tick - last_change
    on = values > 75
    return np.where(on, np.where(age < transient, 1, 2),
                    np.where(age < transient, 3, 0))


def fit_normal_pump_references(frame, oracle, oracle_names, *, target_to_oracle=None):
    """Fit two simple references on every full normal training recording."""
    training = frame[frame.run_id.str.endswith("__train")]
    if not len(training) or not training.run_id.str.contains("_healthy__train$").all():
        raise ConfigError("Pump reference fitting requires normal training recordings only")
    references = {}
    mapping = target_to_oracle or {name: name for name in oracle_names}
    if set(mapping.values()) != set(oracle_names):
        raise ConfigError("Every normal pump target needs its declared offline reference")
    for name, oracle_column in mapping.items():
        command = name.rsplit(".", 1)[0].replace(".pump_", ".command.pump_") + ".speed"
        values, phases = [], []
        for _, group in training.groupby("run_id", sort=False):
            group = group.sort_values("timestamp")
            values.append(oracle.loc[group.row_id, oracle_column].to_numpy(np.float64))
            phases.append(pump_phases(group[command].to_numpy()[None, :, None]).reshape(-1))
        values, phases = np.concatenate(values), np.concatenate(phases)
        counts = [int((phases == p).sum()) for p in range(4)]
        if min(counts) < 1:
            raise ConfigError("Every normal pump phase needs training support")
        references[name] = dict(command=command, oracle_column=oracle_column, constant=float(values.mean()),
            phase_means=[float(values[phases == p].mean()) for p in range(4)],
            phase_counts=counts, training_rows=len(values), fitted_split="normal_train_only")
    return references


@torch.no_grad()
def update_pump_quality(totals, model, trajectory, bundle, start, count, values, mask, references):
    """Pool physical-unit errors and counts over normal validation batches."""
    if not references:
        return
    _, ages = model.observed_command_features(values, mask)
    targets = [model.feature_names.index(name) for name in references]
    positions = [model.observed_command_contract.names.index(r["command"]) for r in references.values()]
    commands = [model.observed_command_indices[position] for position in positions]
    on = values[..., commands] * model.diagnostic_std[commands] + model.diagnostic_mean[commands] > 75
    transient = ages[..., positions] < model.observed_command_contract.transient_steps
    phases = torch.where(on, torch.where(transient, 1, 2), torch.where(transient, 3, 0))
    phases = phases[:, -trajectory.delta_t_steps:].cpu().numpy()
    # One transfer for both trajectories and every pump replaces two transfers
    # per pump. Keep float32 physical conversion and float64 host reductions
    # identical to the original metric, including partial batches.
    physical = torch.stack([
        trajectory.p_real_horizons[..., targets] * model.diagnostic_std[targets] + model.diagnostic_mean[targets],
        trajectory.p_nominal_horizons[..., targets] * model.diagnostic_std[targets] + model.diagnostic_mean[targets],
    ]).cpu().numpy().astype(np.float64)
    for position, (name, reference) in enumerate(references.items()):
        phase = phases[..., position]
        oracle_index = bundle.oracle_columns.index(reference["oracle_column"])
        truth = bundle.oracle_windows[start:start + count, -trajectory.delta_t_steps:, oracle_index].astype(np.float64)
        real, prediction = physical[0, ..., position], physical[1, ..., position]
        baselines = dict(constant=np.full_like(truth, reference["constant"]),
                         command_phase=np.asarray(reference["phase_means"])[phase])
        estimates = dict(reconstruction=real, prediction=prediction, **baselines)
        for p in range(4):
            keep = phase == p
            n = int(keep.sum())
            if not n:
                continue
            row = totals.setdefault((name, p), dict(count=0, negative_predictions=0,
                prediction_sum=0., truth_sum=0., errors={key: 0. for key in estimates}))
            row["count"] += n
            row["negative_predictions"] += int((prediction[keep] < 0).sum())
            row["prediction_sum"] += float(prediction[keep].sum())
            row["truth_sum"] += float(truth[keep].sum())
            for key, estimate in estimates.items():
                row["errors"][key] += float(np.abs(estimate[keep] - truth[keep]).sum())


def summarize_pump_quality(totals):
    report = {}
    for (name, p), row in totals.items():
        n = row["count"]
        report.setdefault(name, {})[PHASES[p]] = dict(samples=n,
            mean_prediction=row["prediction_sum"] / n, mean_reference=row["truth_sum"] / n,
            negative_prediction_fraction=row["negative_predictions"] / n,
            mae={key: value / n for key, value in row["errors"].items()})
    return dict(unit="rev/min", split="normal_validation_only", threshold_not_used=True,
                sample_counts_include_overlapping_windows=True, pumps=report)
