"""Metrics for reconstruction, anomaly scoring, and root-cause ranking."""

from __future__ import annotations

import json
import math
import re
from typing import Any, Iterable

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score
from sklearn.metrics import precision_score, recall_score, roc_auc_score, top_k_accuracy_score

from .config import ConfigError


def reconstruction_metrics(prediction: np.ndarray, target: np.ndarray) -> dict[str, float]:
    """Score aligned finite values without broadcasting or integer overflow."""
    try:
        prediction, target = [np.asarray(value, dtype=np.float64) for value in (prediction, target)]
    except (TypeError, ValueError) as exc:
        raise ConfigError("Reconstruction values must be numeric arrays") from exc
    if prediction.shape != target.shape or prediction.size == 0:
        raise ConfigError("Reconstruction values must be nonempty aligned arrays")
    if not np.isfinite(prediction).all() or not np.isfinite(target).all():
        raise ConfigError("Reconstruction values must be finite")
    error = prediction - target
    return {
        "mse": float(np.mean(error ** 2)),
        "mae": float(np.mean(np.abs(error))),
        "rmse": float(np.sqrt(np.mean(error ** 2))),
    }


def _validate_candidate_universe(candidates: list[str]) -> set[str]:
    """A supplied candidate set cannot contain repeated or empty identities."""
    if any(not isinstance(value, str) or not value.strip() for value in candidates):
        raise ConfigError("Root-cause candidates must have nonempty string identities")
    candidate_set = set(candidates)
    if len(candidate_set) != len(candidates):
        raise ConfigError("Duplicate root-cause candidates")
    return candidate_set


def anomaly_metrics(
    labels: list[Any] | None,
    scores: np.ndarray,
    normal_labels: list[Any],
    *,
    threshold: float | None = None,
) -> dict[str, float]:
    if labels is None:
        return {}
    label_values = np.asarray(labels, dtype=object)
    try:
        scores = np.asarray(scores, dtype=float)
    except (TypeError, ValueError) as exc:
        raise ConfigError("Anomaly scores must be a finite one-dimensional numeric array") from exc
    if label_values.ndim != 1 or scores.ndim != 1 or len(label_values) != len(scores):
        raise ConfigError("Anomaly labels and scores must be aligned one-dimensional arrays")
    if pd.isna(label_values).any():
        raise ConfigError("Anomaly labels must not contain missing targets")
    if not np.isfinite(scores).all():
        raise ConfigError("Anomaly scores must be finite")
    if len(label_values) == 0:
        return {}
    y_true = np.asarray([0 if label in normal_labels else 1 for label in labels], dtype=int)
    if threshold is None or not math.isfinite(float(threshold)):
        raise ConfigError("Anomaly metrics require a finite threshold fixed before scoring")
    decision_threshold = float(threshold)
    y_pred = (scores >= decision_threshold).astype(int)
    normal_count = int((y_true == 0).sum())
    fault_count = int((y_true == 1).sum())
    false_positives = int(((y_true == 0) & (y_pred == 1)).sum())
    true_positives = int(((y_true == 1) & (y_pred == 1)).sum())
    result = {
        "anomaly_label_classes": float(len(np.unique(y_true))),
        "normal_sample_count": float(normal_count),
        "fault_sample_count": float(fault_count),
        "false_positive_count": float(false_positives),
        "true_negative_count": float(normal_count - false_positives),
        "true_positive_count": float(true_positives),
        "false_negative_count": float(fault_count - true_positives),
        "decision_threshold": decision_threshold,
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
    }
    if normal_count:
        result["false_alarm_rate"] = false_positives / normal_count
        result["specificity"] = (normal_count - false_positives) / normal_count
    if fault_count:
        result["recall"] = true_positives / fault_count
    if normal_count and fault_count:
        try:
            result["auroc"] = float(roc_auc_score(y_true, scores))
        except ValueError:
            pass
    return result


def _partial_ranking_quality(case: dict[str, Any]) -> tuple[float, float]:
    """Score only returned candidates, preserving score-tie averaging."""
    ranked = case["ranked_root_causes"]
    relevant = set(case["true_root_causes"])
    supplied_scores = case.get("scores_by_root_cause") or {}
    scores = np.asarray([
        float(supplied_scores.get(root, 0.0)) if supplied_scores else len(ranked) - rank
        for rank, root in enumerate(ranked)
    ], dtype=float)
    if not np.isfinite(scores).all():
        raise ConfigError("Ranking scores must be finite")
    gain = np.asarray([root in relevant for root in ranked], dtype=float)
    dcg = precision_sum = 0.0
    seen = found = 0
    for score in sorted(set(scores), reverse=True):
        tied = scores == score
        size, hits = int(tied.sum()), float(gain[tied].sum())
        dcg += hits / size * sum(
            1.0 / math.log2(rank + 1) for rank in range(seen + 1, seen + size + 1)
        )
        seen += size
        found += hits
        precision_sum += hits * found / seen
    ideal = sum(1.0 / math.log2(rank + 1) for rank in range(1, len(relevant) + 1))
    return dcg / ideal, precision_sum / len(relevant)


def root_cause_ranking_metrics(
    cases: list[dict[str, Any]],
    candidate_root_causes: list[str],
    k_values: Iterable[int] = (1, 3),
) -> dict[str, float]:
    """Evaluate ranked root-cause lists.

    Each case must contain `true_root_causes`, `ranked_root_causes`, and optional
    `scores_by_root_cause`. The function returns common diagnosis and information
    retrieval metrics: hit@k/top-k accuracy, mean reciprocal rank, mean rank,
    nDCG, and label ranking average precision.
    """

    candidate_set = _validate_candidate_universe(candidate_root_causes)
    valid_cases = []
    for case in cases:
        true = list(dict.fromkeys(
            root for root in case.get("true_root_causes", []) if root in candidate_set
        ))
        ranked = list(dict.fromkeys(
            root for root in case.get("ranked_root_causes", []) if root in candidate_set
        ))
        if true and ranked:
            valid_cases.append({**case, "true_root_causes": true, "ranked_root_causes": ranked})
    if not valid_cases:
        return {"diagnosis_case_count": 0.0}

    candidate_index = {
        root_cause: idx
        for idx, root_cause in enumerate(candidate_root_causes)
    }
    hit_counts = {int(k): 0 for k in k_values}
    reciprocal_ranks: list[float] = []
    best_ranks: list[float] = []
    y_true_rows: list[np.ndarray] = []
    y_score_rows: list[np.ndarray] = []
    single_true_labels: list[int] = []
    single_true_scores: list[np.ndarray] = []

    for case in valid_cases:
        true = [module for module in case["true_root_causes"] if module in candidate_index]
        ranked = [module for module in case["ranked_root_causes"] if module in candidate_index]
        if not true or not ranked:
            continue
        ranks = {module: rank + 1 for rank, module in enumerate(ranked)}
        first_correct = min((ranks[module] for module in true if module in ranks), default=np.inf)
        if np.isfinite(first_correct):
            reciprocal_ranks.append(1.0 / float(first_correct))
            best_ranks.append(float(first_correct))
        else:
            reciprocal_ranks.append(0.0)
            best_ranks.append(float(len(candidate_root_causes) + 1))
        for k in hit_counts:
            if set(true).intersection(ranked[:k]):
                hit_counts[k] += 1

        y_true = np.zeros(len(candidate_root_causes), dtype=int)
        for module in true:
            y_true[candidate_index[module]] = 1
        scores_by_root_cause = case.get("scores_by_root_cause") or {}
        y_score = np.zeros(len(candidate_root_causes), dtype=float)
        if scores_by_root_cause:
            for module, score in scores_by_root_cause.items():
                if module in candidate_index:
                    y_score[candidate_index[module]] = float(score)
        else:
            for rank, module in enumerate(ranked):
                y_score[candidate_index[module]] = len(ranked) - rank
        y_true_rows.append(y_true)
        y_score_rows.append(y_score)
        if int(y_true.sum()) == 1:
            single_true_labels.append(int(np.argmax(y_true)))
            single_true_scores.append(y_score)

    n = max(len(valid_cases), 1)
    result = {
        "diagnosis_case_count": float(len(valid_cases)),
        "mrr": float(np.mean(reciprocal_ranks)) if reciprocal_ranks else 0.0,
        "mean_rank": float(np.mean(best_ranks)) if best_ranks else float("nan"),
        "candidate_root_cause_count": float(len(candidate_root_causes)),
    }
    for k, count in hit_counts.items():
        result[f"hit_at_{k}"] = float(count / n)
        result[f"top_{k}_accuracy"] = float(count / n)
        result[f"hit_at_{k}_is_nontrivial"] = float(int(k) < len(candidate_root_causes))
    if y_true_rows and y_score_rows:
        # A missing candidate is not an implicitly returned zero-score tail.
        # Retain the conditional case denominator, but score only the output.
        quality = np.asarray([_partial_ranking_quality(case) for case in valid_cases])
        result["ndcg"] = float(quality[:, 0].mean())
        result["label_ranking_average_precision"] = float(quality[:, 1].mean())
    if single_true_labels and len(set(single_true_labels)) > 1:
        scores = np.stack(single_true_scores)
        for k in hit_counts:
            if k < scores.shape[1]:
                if scores.shape[1] == 2:
                    # Scikit-learn treats two labels as binary classification
                    # and requires a one-dimensional score, whereas diagnosis
                    # supplies one score per candidate root cause.  Since only
                    # k=1 can satisfy k < 2, argmax is the exact top-k result.
                    predicted = np.argmax(scores, axis=1)
                    result[f"sklearn_top_{k}_accuracy"] = float(
                        np.mean(predicted == np.asarray(single_true_labels, dtype=int))
                    )
                else:
                    result[f"sklearn_top_{k}_accuracy"] = float(
                        top_k_accuracy_score(
                            single_true_labels,
                            scores,
                            k=k,
                            labels=list(range(scores.shape[1])),
                        )
                    )
    return result


def root_cause_case_outcomes(
    cases: list[dict[str, Any]],
    candidate_root_causes: list[str],
    k_values: Iterable[int] = (1, 3),
) -> list[dict[str, Any]]:
    """Return one unconditional outcome row for every eligible case.

    Unlike ``root_cause_ranking_metrics``, this representation retains
    abstentions and diagnoses that omit the true root cause. Those cases receive
    zero Hit@k, reciprocal-rank, and nDCG contribution. It also records the
    exact expectation under a uniformly random root-cause permutation truncated
    to the actual output length. Ordered Hit@1 is distinct from the paper's
    ``Correct``, which requires the explicit earliest symptom group.
    """

    candidate_set = _validate_candidate_universe(candidate_root_causes)
    candidate_count = len(candidate_root_causes)
    k_values = tuple(sorted({max(1, int(k)) for k in k_values}))
    rows: list[dict[str, Any]] = []
    case_ids: set[str] = set()
    for case in cases:
        true_root_causes = list(dict.fromkeys(
            module for module in case.get("true_root_causes", []) if module in candidate_set
        ))
        if not true_root_causes or candidate_count < 1:
            continue
        raw_case_id = case.get("case_id")
        case_id = "" if raw_case_id is None else str(raw_case_id)
        if case_id:
            if case_id in case_ids:
                raise ConfigError(f"Duplicate diagnosis case identifier: {case_id}")
            case_ids.add(case_id)
        ranked_root_causes = list(dict.fromkeys(
            module for module in case.get("ranked_root_causes", []) if module in candidate_set
        ))
        possible_root_causes = list(dict.fromkeys(
            module for module in case.get("candidate_root_causes", []) if module in candidate_set
        ))
        if not set(possible_root_causes).issubset(ranked_root_causes):
            raise ConfigError("Possible root causes must be a subset of active candidates")
        decision = str(
            case.get("diagnosis_decision")
            or ("unique" if case.get("unique_root_cause") else ("candidate_set" if ranked_root_causes else "no_diagnosis"))
        )
        if decision == "no_diagnosis" and ranked_root_causes:
            raise ConfigError("No diagnosis cannot contain active candidates")
        true_set = set(true_root_causes)
        ranks = {module: rank + 1 for rank, module in enumerate(ranked_root_causes)}
        first_correct = min(
            (ranks[module] for module in true_root_causes if module in ranks),
            default=None,
        )
        reciprocal_rank = 1.0 / float(first_correct) if first_correct is not None else 0.0
        relevant_count = min(len(true_root_causes), candidate_count)
        returned_count = len(ranked_root_causes)
        random_mrr = _random_expected_reciprocal_rank(
            candidate_count, relevant_count, returned_count
        )
        observed_rank = float(first_correct) if first_correct is not None else float(candidate_count + 1)
        if candidate_count == 1:
            normalized_rank_score = float(first_correct is not None)
            random_normalized_rank_score = float(returned_count > 0)
        else:
            normalized_rank_score = (
                (candidate_count - observed_rank) / float(candidate_count - 1)
                if first_correct is not None
                else 0.0
            )
            random_normalized_rank_score = sum(
                probability * (candidate_count - rank) / (candidate_count - 1)
                for rank, probability in _random_first_rank_distribution(
                    candidate_count, relevant_count, returned_count
                )
            )
        ideal_dcg = sum(1.0 / math.log2(rank + 1.0) for rank in range(1, relevant_count + 1))
        observed_dcg = sum(
            1.0 / math.log2(rank + 1.0)
            for rank, module in enumerate(ranked_root_causes, start=1)
            if module in true_set
        )
        random_dcg = (
            (relevant_count / candidate_count)
            * sum(1.0 / math.log2(rank + 1.0) for rank in range(1, returned_count + 1))
        )
        unique_decisions = {
            "unique",
            "unique_component_fault_pair",
            "unique_component_unknown_fault_type",
        }
        unique_diagnosis = decision in unique_decisions
        unique_root = str(case.get("unique_root_cause") or "")
        if unique_diagnosis and not ranked_root_causes:
            raise ConfigError("A unique diagnosis requires an active candidate")
        if unique_diagnosis and decision != "unique_component_unknown_fault_type":
            if unique_root not in ranked_root_causes:
                raise ConfigError("A unique root cause must be an active candidate")
            if "candidate_root_causes" in case and possible_root_causes != [unique_root]:
                raise ConfigError("A unique diagnosis must match its singleton possible-cause group")
        if decision == "unique_component_unknown_fault_type":
            unique_correct = bool(unique_root) and any(
                _root_cause_component(unique_root)
                == _root_cause_component(value)
                for value in true_root_causes
            )
        else:
            unique_correct = unique_diagnosis and unique_root in true_set
        if unique_diagnosis:
            primary_outcome = (
                "correct_unique_diagnosis"
                if unique_correct
                else "incorrect_unique_diagnosis"
            )
        elif decision == "no_diagnosis" or not ranked_root_causes:
            primary_outcome = "no_diagnosis"
        else:
            primary_outcome = "ambiguous_diagnosis"
        earliest = case.get("earliest_root_causes")
        if earliest is None and returned_count <= 1:
            earliest = ranked_root_causes
        if earliest is not None:
            earliest = list(dict.fromkeys(earliest))
            if not set(earliest).issubset(ranked_root_causes) or (ranked_root_causes and not earliest):
                raise ConfigError("The earliest symptom group must be a nonempty subset of active candidates")
        potential = bool(true_set.intersection(possible_root_causes))
        exact_unique = len(possible_root_causes) == 1 and potential
        row: dict[str, Any] = {
            "case_id": str(case.get("case_id", "")),
            "true_root_causes": json.dumps(true_root_causes),
            "ranked_root_causes": json.dumps(ranked_root_causes),
            "diagnosed": bool(ranked_root_causes),
            "diagnosis_decision": decision,
            "candidate_root_causes": json.dumps(possible_root_causes),
            "candidate_set_size": float(len(possible_root_causes)),
            "candidate_contains_true": float(potential),
            "earliest_group_available": earliest is not None,
            "earliest_root_causes": json.dumps(earliest),
            "correct": float(bool(true_set.intersection(earliest))) if earliest is not None else None,
            "potentially_correct": float(potential),
            "uniquely_correct": float(exact_unique),
            "random_expected_correct": (
                _random_hit_probability(candidate_count, relevant_count, len(earliest))
                if earliest is not None else None
            ),
            "random_expected_potentially_correct": _random_hit_probability(
                candidate_count, relevant_count, len(possible_root_causes)
            ),
            "random_expected_uniquely_correct": (
                _random_hit_probability(candidate_count, relevant_count, 1)
                if len(possible_root_causes) == 1 else 0.0
            ),
            "unique_root_cause": unique_root,
            "unique_diagnosis": float(unique_diagnosis),
            "unique_diagnosis_correct": float(unique_correct),
            "primary_diagnosis_outcome": primary_outcome,
            "first_correct_rank": float(first_correct) if first_correct is not None else float(candidate_count + 1),
            "reciprocal_rank": float(reciprocal_rank),
            "ndcg": float(observed_dcg / ideal_dcg) if ideal_dcg > 0.0 else 0.0,
            "random_expected_mrr": random_mrr,
            "chance_adjusted_mrr": float(
                (reciprocal_rank - random_mrr) / max(1.0 - random_mrr, 1.0e-12)
            ),
            "normalized_rank_score": float(normalized_rank_score),
            "random_expected_normalized_rank_score": float(random_normalized_rank_score),
            "random_expected_ndcg": float(random_dcg / ideal_dcg) if ideal_dcg > 0.0 else 0.0,
            "candidate_root_cause_count": float(candidate_count),
            "true_root_cause_count": float(relevant_count),
            "evaluation_subgroup": str(
                case.get("evaluation_subgroup", "main_evaluation")
            ),
            "general_detectability_claim_allowed": bool(
                case.get("general_detectability_claim_allowed", True)
            ),
            "detectability_claims": str(case.get("detectability_claims", "")),
            "evaluation_limitation": str(case.get("evaluation_limitation", "")),
        }
        for k in k_values:
            effective_k = min(k, returned_count)
            row[f"hit_at_{k}"] = float(bool(true_set.intersection(ranked_root_causes[:effective_k])))
            row[f"hit_at_{k}_is_nontrivial"] = float(k < candidate_count)
            row[f"random_expected_hit_at_{k}"] = _random_hit_probability(
                candidate_count,
                relevant_count,
                effective_k,
            )
        rows.append(row)
    return rows


_ROOT_CAUSE_PAIR = re.compile(r"^<\s*(?P<component>[^,>]+)\s*,")


def _root_cause_component(value: str) -> str:
    match = _ROOT_CAUSE_PAIR.match(str(value))
    return match.group("component").strip() if match else str(value).strip()


def unconditional_root_cause_metrics(
    cases: list[dict[str, Any]],
    candidate_root_causes: list[str],
    k_values: Iterable[int] = (1, 3),
    *,
    bootstrap_samples: int = 4000,
    bootstrap_seed: int = 2026,
) -> dict[str, float]:
    """Evaluate all eligible cases, treating abstentions as failed rankings."""

    k_values = tuple(sorted({max(1, int(k)) for k in k_values}))
    rows = root_cause_case_outcomes(cases, candidate_root_causes, k_values)
    if not rows:
        return {"unconditional_case_count": 0.0}
    result: dict[str, float] = {
        "unconditional_case_count": float(len(rows)),
        "unconditional_mrr": float(np.mean([row["reciprocal_rank"] for row in rows])),
        "unconditional_ndcg": float(np.mean([row["ndcg"] for row in rows])),
        "random_expected_mrr": float(np.mean([row["random_expected_mrr"] for row in rows])),
        "random_expected_ndcg": float(np.mean([row["random_expected_ndcg"] for row in rows])),
        "unconditional_chance_adjusted_mrr": float(
            np.mean([row["chance_adjusted_mrr"] for row in rows])
        ),
        "unconditional_normalized_rank_score": float(
            np.mean([row["normalized_rank_score"] for row in rows])
        ),
        "random_expected_normalized_rank_score": float(
            np.mean([row["random_expected_normalized_rank_score"] for row in rows])
        ),
    }
    earliest_available = all(row["earliest_group_available"] for row in rows)
    result["earliest_group_available_case_count"] = float(sum(
        row["earliest_group_available"] for row in rows
    ))
    # Never silently reduce the denominator to cases with available onsets.
    for name in ("correct", "potentially_correct", "uniquely_correct"):
        if name == "correct" and not earliest_available:
            continue
        result[f"{name}_rate"] = float(np.mean([row[name] for row in rows]))
        result[f"random_expected_{name}"] = float(np.mean([
            row[f"random_expected_{name}"] for row in rows
        ]))
    diagnosed = np.asarray([float(row["diagnosed"]) for row in rows], dtype=float)
    # These fixed top-1 summaries are independent of the optional Hit@k list.
    top1 = np.asarray([row["first_correct_rank"] == 1 for row in rows], dtype=float)
    unique = np.asarray([row.get("unique_diagnosis", 0.0) for row in rows], dtype=float)
    unique_correct = np.asarray([row.get("unique_diagnosis_correct", 0.0) for row in rows], dtype=float)
    candidate_contains_true = np.asarray(
        [row.get("candidate_contains_true", 0.0) for row in rows],
        dtype=float,
    )
    candidate_sizes = np.asarray([row.get("candidate_set_size", 0.0) for row in rows], dtype=float)
    diagnosed_count = int(diagnosed.sum())
    correct_count = int(top1.sum())
    unique_count = int(unique.sum())
    primary_outcomes = [str(row["primary_diagnosis_outcome"]) for row in rows]
    outcome_counts = {
        name: primary_outcomes.count(name)
        for name in (
            "correct_unique_diagnosis",
            "incorrect_unique_diagnosis",
            "ambiguous_diagnosis",
            "no_diagnosis",
        )
    }
    result.update({
        "anomaly_detected_case_count": float(diagnosed_count),
        "anomaly_detection_case_rate": float(diagnosed.mean()),
        "detected_and_correct_top1_case_count": float(correct_count),
        "detected_but_incorrect_top1_case_count": float(diagnosed_count - correct_count),
        "detected_but_incorrect_top1_rate": float((diagnosed - top1).mean()),
        "diagnosis_given_detection_accuracy": (
            float(correct_count / diagnosed_count) if diagnosed_count else 0.0
        ),
        "abstention_case_rate": float(1.0 - diagnosed.mean()),
        "unique_diagnosis_case_rate": float(unique.mean()),
        "unique_diagnosis_unconditional_accuracy": float(unique_correct.mean()),
        "unique_diagnosis_conditional_accuracy": (
            float(unique_correct.sum() / unique_count) if unique_count else 0.0
        ),
        "correct_unique_diagnosis_count": float(
            outcome_counts["correct_unique_diagnosis"]
        ),
        "correct_unique_diagnosis_rate": float(
            outcome_counts["correct_unique_diagnosis"] / len(rows)
        ),
        "incorrect_unique_diagnosis_count": float(
            outcome_counts["incorrect_unique_diagnosis"]
        ),
        "incorrect_unique_diagnosis_rate": float(
            outcome_counts["incorrect_unique_diagnosis"] / len(rows)
        ),
        "ambiguous_diagnosis_count": float(
            outcome_counts["ambiguous_diagnosis"]
        ),
        "ambiguous_diagnosis_rate": float(
            outcome_counts["ambiguous_diagnosis"] / len(rows)
        ),
        "no_diagnosis_count": float(outcome_counts["no_diagnosis"]),
        "no_diagnosis_rate": float(outcome_counts["no_diagnosis"] / len(rows)),
        "candidate_set_contains_true_unconditional_rate": float(candidate_contains_true.mean()),
        "candidate_set_contains_true_given_diagnosis_rate": (
            float(candidate_contains_true.sum() / diagnosed_count) if diagnosed_count else 0.0
        ),
        "mean_candidate_set_size": float(candidate_sizes.mean()),
        "mean_candidate_set_size_given_diagnosis": (
            float(candidate_sizes.sum() / diagnosed_count) if diagnosed_count else 0.0
        ),
    })
    subgroup_names = sorted({str(row["evaluation_subgroup"]) for row in rows})
    result["evaluation_subgroup_count"] = float(len(subgroup_names))
    for subgroup in subgroup_names:
        selected = [row for row in rows if row["evaluation_subgroup"] == subgroup]
        safe_name = re.sub(r"[^a-zA-Z0-9]+", "_", subgroup).strip("_").lower()
        result[f"subgroup_{safe_name}_case_count"] = float(len(selected))
        result[f"subgroup_{safe_name}_hit_at_1"] = float(
            np.mean([row["first_correct_rank"] == 1 for row in selected])
        )
        result[f"subgroup_{safe_name}_mrr"] = float(
            np.mean([row["reciprocal_rank"] for row in selected])
        )
        result[f"subgroup_{safe_name}_general_detectability_claim_allowed"] = float(
            all(bool(row["general_detectability_claim_allowed"]) for row in selected)
        )
    result["unconditional_mrr_improvement_over_random"] = (
        result["unconditional_mrr"] - result["random_expected_mrr"]
    )
    result["unconditional_ndcg_improvement_over_random"] = (
        result["unconditional_ndcg"] - result["random_expected_ndcg"]
    )
    rng = np.random.default_rng(bootstrap_seed)
    for metric, random_metric, output_prefix in (
        ("reciprocal_rank", "random_expected_mrr", "mrr"),
        ("ndcg", "random_expected_ndcg", "ndcg"),
    ):
        differences = np.asarray([row[metric] - row[random_metric] for row in rows], dtype=float)
        low, high = _bootstrap_mean_ci(differences, bootstrap_samples, rng)
        result[f"unconditional_{output_prefix}_improvement_ci95_low"] = low
        result[f"unconditional_{output_prefix}_improvement_ci95_high"] = high
    for k in k_values:
        observed = np.asarray([row[f"hit_at_{k}"] for row in rows], dtype=float)
        random_probabilities = np.asarray(
            [row[f"random_expected_hit_at_{k}"] for row in rows],
            dtype=float,
        )
        nontrivial = np.asarray(
            [row[f"hit_at_{k}_is_nontrivial"] for row in rows],
            dtype=bool,
        )
        result[f"unconditional_hit_at_{k}"] = float(observed.mean())
        result[f"random_expected_hit_at_{k}"] = float(random_probabilities.mean())
        result[f"hit_at_{k}_nontrivial_case_count"] = float(nontrivial.sum())
        result[f"hit_at_{k}_trivial_case_count"] = float((~nontrivial).sum())
        result[f"hit_at_{k}_all_cases_nontrivial"] = float(bool(nontrivial.all()))
        if bool(nontrivial.any()):
            result[f"unconditional_hit_at_{k}_nontrivial_cases"] = float(
                observed[nontrivial].mean()
            )
            result[f"random_expected_hit_at_{k}_nontrivial_cases"] = float(
                random_probabilities[nontrivial].mean()
            )
        result[f"unconditional_hit_at_{k}_improvement_over_random"] = float(
            observed.mean() - random_probabilities.mean()
        )
        result[f"unconditional_hit_at_{k}_random_upper_tail_p_value"] = _poisson_binomial_upper_tail(
            random_probabilities,
            int(observed.sum()),
        )
        low, high = _bootstrap_mean_ci(observed - random_probabilities, bootstrap_samples, rng)
        result[f"unconditional_hit_at_{k}_improvement_ci95_low"] = low
        result[f"unconditional_hit_at_{k}_improvement_ci95_high"] = high
    return result


def _random_hit_probability(candidate_count: int, relevant_count: int, k: int) -> float:
    if candidate_count < 1 or relevant_count < 1 or k < 1:
        return 0.0
    relevant_count = min(relevant_count, candidate_count)
    k = min(k, candidate_count)
    if candidate_count - relevant_count < k:
        return 1.0
    return float(1.0 - math.comb(candidate_count - relevant_count, k) / math.comb(candidate_count, k))


def _random_first_rank_distribution(candidate_count: int, relevant_count: int, output_count: int):
    """Finite first-hit probabilities with missing outputs contributing zero."""
    if candidate_count < 1 or relevant_count < 1 or output_count < 1:
        return
    relevant_count = min(relevant_count, candidate_count)
    denominator = math.comb(candidate_count, relevant_count)
    for rank in range(1, min(output_count, candidate_count - relevant_count + 1) + 1):
        yield rank, math.comb(candidate_count - rank, relevant_count - 1) / denominator


def _random_expected_reciprocal_rank(
    candidate_count: int, relevant_count: int, output_count: int | None = None,
) -> float:
    if candidate_count < 1 or relevant_count < 1:
        return 0.0
    return float(sum(
        probability / rank
        for rank, probability in _random_first_rank_distribution(
            candidate_count, relevant_count,
            candidate_count if output_count is None else output_count,
        )
    ))


def _random_expected_first_rank(candidate_count: int, relevant_count: int) -> float:
    """Expected first relevant rank under a uniform random permutation."""

    if candidate_count < 1 or relevant_count < 1:
        return float(candidate_count + 1)
    relevant_count = min(relevant_count, candidate_count)
    denominator = math.comb(candidate_count, relevant_count)
    return float(sum(
        rank
        * math.comb(candidate_count - rank, relevant_count - 1)
        / denominator
        for rank in range(1, candidate_count - relevant_count + 2)
    ))


def _poisson_binomial_upper_tail(probabilities: np.ndarray, observed_hits: int) -> float:
    """Exact P(S >= observed_hits) for unequal independent Bernoulli trials."""

    if observed_hits <= 0:
        return 1.0
    distribution = np.asarray([1.0], dtype=float)
    for probability in np.asarray(probabilities, dtype=float):
        probability = float(np.clip(probability, 0.0, 1.0))
        updated = np.zeros(len(distribution) + 1, dtype=float)
        updated[:-1] += distribution * (1.0 - probability)
        updated[1:] += distribution * probability
        distribution = updated
    if observed_hits >= len(distribution):
        return 0.0
    return float(np.clip(distribution[observed_hits:].sum(), 0.0, 1.0))


def _bootstrap_mean_ci(
    values: np.ndarray,
    samples: int,
    rng: np.random.Generator,
) -> tuple[float, float]:
    values = np.asarray(values, dtype=float)
    if values.size == 0:
        return float("nan"), float("nan")
    if values.size == 1 or samples < 2:
        mean = float(values.mean())
        return mean, mean
    means = np.empty(samples, dtype=float)
    for idx in range(samples):
        means[idx] = float(rng.choice(values, size=values.size, replace=True).mean())
    low, high = np.quantile(means, [0.025, 0.975])
    return float(low), float(high)


def mean_std_ci(values: list[float], confidence_z: float = 1.96) -> dict[str, float]:
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return {"mean": float("nan"), "std": float("nan"), "ci95_half_width": float("nan")}
    std = float(np.std(arr, ddof=1)) if arr.size > 1 else 0.0
    return {
        "mean": float(np.mean(arr)),
        "std": std,
        "ci95_half_width": float(confidence_z * std / np.sqrt(arr.size)) if arr.size > 1 else 0.0,
    }
