"""Private, atomic checkpoints and exact single-worker minibatch continuation."""

from __future__ import annotations

import dataclasses
from contextlib import contextmanager
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import pickle
import random
import stat
import struct
import sys
import tempfile

import numpy as np
import torch
from torch.utils.data import DataLoader

from .config import ConfigError


VERSION = 1
MAGIC = b"LGD-TRAIN-RESUME\x01"
CHECKPOINT_NAME = "checkpoint-v1.pt"


def enable_reproducible_execution(device):
    """Set the process policy before creating resume identities or models.

    CUDA workspace configuration belongs to the launcher, before CUDA/cuBLAS
    initialization. Validate it without initializing CUDA or changing precision.
    The policy remains active through lazy compilation and repeated backward.
    """
    device = torch.device(device)
    if device.type not in {"cpu", "cuda"}:
        raise ConfigError("Exact training resume is supported only on CPU and CUDA")
    if device.type == "cuda" and os.environ.get("CUBLAS_WORKSPACE_CONFIG") not in {
        ":4096:8", ":16:8",
    }:
        raise ConfigError(
            "Exact CUDA resume requires CUBLAS_WORKSPACE_CONFIG=:4096:8 or :16:8 "
            "in the launcher before CUDA initialization. It is not set during training."
        )
    import torch._functorch.config as autograd_config
    import torch._inductor.config as inductor_config

    torch.use_deterministic_algorithms(True, warn_only=False)
    # Audit gradients retain the graph. Saved buffers must also survive later
    # audit calls and the final backward, including its lazy compilation.
    autograd_config.donated_buffer = False
    if (not torch.are_deterministic_algorithms_enabled()
            or torch.is_deterministic_algorithms_warn_only_enabled()
            or not inductor_config.deterministic):
        raise ConfigError("The runtime did not enable deterministic PyTorch and Inductor execution")


class TrainingInterrupted(RuntimeError):
    """A requested stop completed after its training state was durably saved."""


def _json_default(value):
    if dataclasses.is_dataclass(value):
        return dataclasses.asdict(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, Path):
        return str(value)
    if hasattr(value, "isoformat"):
        return value.isoformat()
    raise TypeError(f"Unsupported resume identity value: {type(value).__name__}")


def content_identity(value):
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"),
                         default=_json_default, allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def source_identity():
    """Use the same executable-file contract as scripts/source_digest.py."""
    root = Path(__file__).resolve().parents[2]
    files = []
    excluded = {"__pycache__", ".pytest_cache", ".mypy_cache"}
    for relative in ("adapters", "configs", "scripts", "src", "tests", "pyproject.toml", "requirements.txt"):
        path = root / relative
        if path.is_file():
            files.append(path)
        elif path.is_dir():
            files.extend(p for p in path.rglob("*") if p.is_file()
                         and p.name != ".DS_Store" and not excluded.intersection(p.parts)
                         and not any(part.endswith(".egg-info") for part in p.parts))
    digest = hashlib.sha256()
    for path in sorted(files, key=lambda p: p.relative_to(root).as_posix()):
        digest.update(path.relative_to(root).as_posix().encode())
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def _array_identity(value):
    if value is None:
        return None
    array = np.asarray(value)
    if array.dtype.hasobject:
        raise ConfigError("Object arrays cannot identify training tensors")
    digest = hashlib.sha256()
    digest.update(str((array.shape, array.dtype.str)).encode())
    if array.size:
        rows = max(1, (8 * 1024 * 1024) // max(1, array[0].nbytes))
        for start in range(0, len(array), rows):
            block = np.ascontiguousarray(array[start:start + rows])
            digest.update(memoryview(block).cast("B"))
    return digest.hexdigest()


def dataset_identity(prepared):
    result = {"features": prepared.feature_columns, "scaler": prepared.scaler.to_dict()}
    for split in ("train", "val"):
        bundle = getattr(prepared, split)
        result[split] = {
            "arrays": {key: _array_identity(getattr(bundle, key))
                       for key in ("windows", "targets", "oracle_windows")},
            "rows": bundle.row_ids, "groups": bundle.groups, "times": bundle.times,
            "labels": bundle.labels, "oracle_columns": bundle.oracle_columns,
            "metadata": bundle.metadata,
        }
    return content_identity(result)


def device_identity(device):
    import torch._functorch.config as autograd_config
    import torch._inductor.config as inductor_config
    from .compiled_recurrence import INDUCTOR_OPTIONS

    device = torch.device(device)
    result = {
        "device_type": device.type, "machine": platform.machine(),
        "python": sys.version, "torch": str(torch.__version__), "numpy": np.__version__,
        "threads": torch.get_num_threads(), "interop_threads": torch.get_num_interop_threads(),
        "default_dtype": str(torch.get_default_dtype()),
        "deterministic": torch.are_deterministic_algorithms_enabled(),
        "deterministic_warn_only": torch.is_deterministic_algorithms_warn_only_enabled(),
        "inductor_deterministic": bool(inductor_config.deterministic),
        "inductor_options": {"deterministic": bool(inductor_config.deterministic),
                             **INDUCTOR_OPTIONS},
        "functorch_donated_buffer": bool(autograd_config.donated_buffer),
        "mkldnn": torch.backends.mkldnn.enabled,
        "float32_matmul_precision": torch.get_float32_matmul_precision(),
        "cudnn_benchmark": torch.backends.cudnn.benchmark,
        "cudnn_deterministic": torch.backends.cudnn.deterministic,
        "cudnn_tf32": torch.backends.cudnn.allow_tf32,
        "matmul_tf32": torch.backends.cuda.matmul.allow_tf32,
        "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
        "tf32_override": os.environ.get("NVIDIA_TF32_OVERRIDE"),
        "torch_tf32_override": os.environ.get("TORCH_ALLOW_TF32_CUBLAS_OVERRIDE"),
    }
    if device.type == "cuda":
        properties = torch.cuda.get_device_properties(device)
        result.update(cuda=torch.version.cuda, cudnn=torch.backends.cudnn.version(),
                      gpu=properties.name, capability=[properties.major, properties.minor],
                      gpu_memory=properties.total_memory,
                      device_count=torch.cuda.device_count())
    elif device.type != "cpu":
        raise ConfigError("Exact training resume is supported only on CPU and CUDA")
    return result


def device_provenance(device):
    """Record placement without rejecting an equivalent Slurm GPU allocation."""
    device = torch.device(device)
    result = {"host": platform.node(), "device": str(device),
              "visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES")}
    if device.type == "cuda":
        properties = torch.cuda.get_device_properties(device)
        result["gpu_uuid"] = str(getattr(properties, "uuid", "unavailable"))
    return result


def make_identity(prepared, config, knowledge, device, extra=None):
    # This derived field is written back to the caller after a successful fit.
    # Its authoritative value is stored separately inside the checkpoint.
    scientific_config = {k: v for k, v in config.items() if k != "_reconstructed_variable_scaling"}
    return {"config": content_identity(scientific_config),
            "dataset": dataset_identity(prepared), "knowledge": content_identity(knowledge),
            "source": source_identity(), "device": device_identity(device),
            "caller": content_identity(extra)}


def capture_rng(device=None):
    return {"python": random.getstate(), "numpy": np.random.get_state(),
            "torch_cpu": torch.get_rng_state().clone(),
            "torch_cuda": [state.clone() for state in torch.cuda.get_rng_state_all()]
            if torch.cuda.is_initialized() else None,
            "active_cuda_index": (torch.device(device).index
                                  if torch.device(device).index is not None else torch.cuda.current_device())
            if device is not None and torch.device(device).type == "cuda" else None}


def restore_rng(state, device=None):
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch_cpu"].cpu())
    if state["torch_cuda"] is not None:
        if len(state["torch_cuda"]) != torch.cuda.device_count():
            raise ConfigError("Resume CUDA RNG device count mismatch")
        streams = [value.cpu() for value in state["torch_cuda"]]
        source = state.get("active_cuda_index")
        if source is not None and device is not None and torch.device(device).type == "cuda":
            target = torch.device(device).index
            target = torch.cuda.current_device() if target is None else target
            # The training stream follows the equivalent GPU, not its local slot.
            streams[source], streams[target] = streams[target], streams[source]
        torch.cuda.set_rng_state_all(streams)


def cpu_snapshot(value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, dict):
        return {key: cpu_snapshot(item) for key, item in value.items()}
    if isinstance(value, list):
        return [cpu_snapshot(item) for item in value]
    if isinstance(value, tuple):
        return tuple(cpu_snapshot(item) for item in value)
    return value


def _atomic_bytes(path, payload):
    path = Path(path)
    if path.is_symlink():
        raise ConfigError("Refusing a symbolic checkpoint target")
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            os.fchmod(handle.fileno(), 0o600)
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        Path(temporary).unlink(missing_ok=True)


def atomic_torch_save(value, path):
    buffer = io.BytesIO()
    torch.save(value, buffer)
    _atomic_bytes(path, buffer.getvalue())


class ResumeCheckpoint:
    """One checksummed commit, atomically replaced inside a private directory."""

    def __init__(self, directory, identity):
        self.directory = Path(directory) / "training_resume"
        if self.directory.is_symlink():
            raise ConfigError("Refusing a symbolic resume directory")
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        mode = self.directory.stat()
        if mode.st_uid != os.getuid() or stat.S_IMODE(mode.st_mode) & 0o077:
            raise ConfigError("Resume directory must be private and owned by this account")
        self.path = self.directory / CHECKPOINT_NAME
        self.marker = self.directory / "initialized-v1.json"
        self.identity = identity

    def _marker_value(self):
        return {"version": VERSION, "identity_sha256": content_identity(self.identity)}

    def _validate_marker(self):
        if self.marker.is_symlink():
            raise ConfigError("Refusing a symbolic resume initialization marker")
        mode = self.marker.stat()
        if mode.st_uid != os.getuid() or stat.S_IMODE(mode.st_mode) & 0o077:
            raise ConfigError("Resume initialization marker must be private and owned by this account")
        try:
            value = json.loads(self.marker.read_text())
        except (ValueError, UnicodeError) as error:
            raise ConfigError("Invalid resume initialization marker") from error
        if value != self._marker_value():
            raise ConfigError("Resume Config/Dataset/Source/Device identity mismatch in initialization marker")

    @contextmanager
    def lock(self):
        descriptor = os.open(self.directory / "writer.lock",
                             os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "a") as handle:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            yield

    def load(self):
        if self.path.is_symlink():
            raise ConfigError("Refusing a symbolic resume checkpoint")
        if self.marker.exists() or self.marker.is_symlink():
            self._validate_marker()
            if not self.path.exists():
                raise ConfigError("Initialized training lost its checkpoint. Refusing a silent restart")
        elif self.path.exists():
            raise ConfigError("Resume checkpoint lost its initialization marker")
        if not self.path.exists():
            if list(self.directory.glob(f".{CHECKPOINT_NAME}.*.tmp")):
                raise ConfigError("Incomplete initial resume checkpoint, manual inspection required")
            return None
        mode = self.path.stat()
        if mode.st_uid != os.getuid() or stat.S_IMODE(mode.st_mode) & 0o077:
            raise ConfigError("Resume checkpoint must be private and owned by this account")
        raw = self.path.read_bytes()
        header = len(MAGIC) + 8 + 32
        if len(raw) < header or raw[:len(MAGIC)] != MAGIC:
            raise ConfigError("Invalid or truncated resume checkpoint header")
        size = struct.unpack(">Q", raw[len(MAGIC):len(MAGIC) + 8])[0]
        expected = raw[len(MAGIC) + 8:header]
        payload = raw[header:]
        if len(payload) != size or hashlib.sha256(payload).digest() != expected:
            raise ConfigError("Invalid or truncated resume checkpoint payload")
        try:
            # Only this account's private, integrity-checked checkpoint is read.
            result = torch.load(io.BytesIO(payload), map_location="cpu", weights_only=False)
        except (EOFError, RuntimeError, ValueError, KeyError, pickle.UnpicklingError) as error:
            raise ConfigError("Unreadable resume checkpoint") from error
        if not isinstance(result, dict) or result.get("version") != VERSION:
            raise ConfigError("Unsupported resume checkpoint version")
        if result.get("identity") != self.identity:
            raise ConfigError("Resume Config/Dataset/Source/Device identity mismatch")
        if not isinstance(result.get("state"), dict):
            raise ConfigError("Resume checkpoint has no training state")
        return result["state"]

    def save(self, state):
        if self.marker.exists() or self.marker.is_symlink():
            self._validate_marker()
        else:
            # Persist intent before the first checkpoint. A missing payload is
            # subsequently an incomplete commit, never a new training request.
            if self.path.exists():
                raise ConfigError("Existing checkpoint has no initialization marker")
            _atomic_bytes(self.marker, json.dumps(self._marker_value(), sort_keys=True).encode())
        buffer = io.BytesIO()
        torch.save({"version": VERSION, "identity": self.identity, "state": cpu_snapshot(state)}, buffer)
        payload = buffer.getvalue()
        envelope = MAGIC + struct.pack(">Q", len(payload)) + hashlib.sha256(payload).digest() + payload
        _atomic_bytes(self.path, envelope)


def replay_loader(loader, order=None, completed_batches=0):
    """Retain the original DataLoader seed consumption and explicit batch order.

    A fresh single-process iterator consumes its base seed before the random
    sampler consumes its seed. Materializing the sampler after that step
    preserves both the batch order and global RNG state of the original path.
    The replay iterator uses a private generator, including on continuation.
    """
    if loader.num_workers != 0:
        raise ConfigError("Exact resume requires a single-process DataLoader")
    if order is None:
        if completed_batches:
            raise ConfigError("A resume cursor requires an explicit batch order")
        iter(loader)
        order = [list(batch) for batch in loader.batch_sampler]
    expected = len(loader.dataset)
    flattened = [index for batch in order for index in batch]
    if (sorted(flattened) != list(range(expected))
            or any(len(batch) != min(loader.batch_size, expected - i * loader.batch_size)
                   for i, batch in enumerate(order))
            or type(completed_batches) is not int or not 0 <= completed_batches <= len(order)):
        raise ConfigError("Invalid saved batch order or cursor")
    replay = DataLoader(loader.dataset, batch_sampler=order[completed_batches:],
                        num_workers=0, pin_memory=loader.pin_memory,
                        generator=torch.Generator().manual_seed(0))
    return replay, order
