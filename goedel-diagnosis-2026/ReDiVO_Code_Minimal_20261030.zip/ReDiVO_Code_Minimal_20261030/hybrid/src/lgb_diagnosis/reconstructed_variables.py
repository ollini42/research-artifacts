"""Reconstructed diagnostic-variable targets derived from explicit structural knowledge."""

from __future__ import annotations

import numpy as np
import torch

from .config import ConfigError
from .knowledge import ReconstructedVariableSpec, SystemKnowledge


def diagnostic_state_columns(
    feature_columns: list[str], knowledge: SystemKnowledge
) -> list[str]:
    """Return measured/reconstructed channels followed by named latent states."""

    return list(feature_columns) + list(knowledge.reconstructed_variable_names)


def _scaling_tensor(
    scaling: dict[str, list[float]], name: str, width: int, reference: torch.Tensor,
) -> torch.Tensor:
    """Validate host-side scaling before transferring it to the execution device."""

    value = torch.as_tensor(scaling[name], dtype=reference.dtype, device="cpu")
    if (value.shape != (width,) or not bool(torch.isfinite(value).all())
            or (name.endswith("_std") and bool((value <= 0).any()))):
        raise ConfigError(
            f"Invalid {name} scaling: expected {width} finite values and positive standard deviations"
        )
    return value.to(device=reference.device)


def reconstructed_variable_targets_torch(
    values: torch.Tensor,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    scaling: dict[str, list[float]] | None = None,
    oracle_values: torch.Tensor | None = None,
    oracle_columns: list[str] | None = None,
    prefer_oracle: bool = False,
) -> torch.Tensor:
    """Evaluate supplied latent-state functions for a complete sequence.

    ``values`` is expected to contain offline-complete simulator channels while
    training/evaluating the structural target.  Online inference never calls
    this function with unavailable ground truth; it obtains the corresponding
    state from the neural reconstructed-variable head.
    """

    if values.ndim != 3:
        raise ConfigError("diagnostic reconstructed targets require [batch, time, feature] values")
    if not knowledge.reconstructed_variables:
        return values.new_zeros((*values.shape[:2], 0))
    physical_values = values
    needs_structural_inputs = any(
        not (prefer_oracle and variable.oracle_column is not None)
        for variable in knowledge.reconstructed_variables
    )
    if scaling and needs_structural_inputs:
        feature_mean = _scaling_tensor(scaling, "feature_mean", len(feature_columns), values)
        feature_std = _scaling_tensor(scaling, "feature_std", len(feature_columns), values)
        physical_values = values * feature_std.view(1, 1, -1) + feature_mean.view(
            1, 1, -1
        )
    named: dict[str, torch.Tensor] = {
        name: physical_values[:, :, idx] for idx, name in enumerate(feature_columns)
    }
    oracle_named: dict[str, torch.Tensor] = {}
    if oracle_values is not None and oracle_values.shape[-1]:
        if oracle_values.ndim != 3 or oracle_values.shape[:2] != values.shape[:2]:
            raise ConfigError(
                "Oracle reconstructed-variable targets must align with feature windows as "
                "[batch, time, oracle_state]"
            )
        names = list(oracle_columns or [])
        if len(names) != int(oracle_values.shape[-1]):
            raise ConfigError(
                "oracle_columns does not match the final dimension of oracle_values"
            )
        oracle_named = {
            name: oracle_values[:, :, idx] for idx, name in enumerate(names)
        }
    outputs: list[torch.Tensor] = []
    for variable in knowledge.reconstructed_variables:
        if prefer_oracle and variable.oracle_column is not None:
            if variable.oracle_column not in oracle_named:
                raise ConfigError(
                    f"Configured oracle target {variable.oracle_column!r} for "
                    f"technical state {variable.name!r} is unavailable"
                )
            oracle_result = oracle_named[str(variable.oracle_column)]
            if not bool(torch.isfinite(oracle_result).all()):
                raise ConfigError(
                    f"Configured oracle target {variable.oracle_column!r} for "
                    f"technical state {variable.name!r} contains non-finite values"
                )
            result = oracle_result
        else:
            # Normal offline supervision and structural evaluation are
            # alternative target sources. An oracle-only state has no
            # structural function to evaluate before selecting its oracle.
            missing = [name for name in variable.inputs if name not in named]
            if missing or not variable.inputs:
                raise ConfigError(
                    f"Cannot evaluate diagnostic reconstructed variable '{variable.name}'. "
                    f"Missing structural inputs: {missing or 'none declared'}. "
                    "Supply its configured oracle target or identifying structural inputs."
                )
            inputs = torch.stack([named[name] for name in variable.inputs], dim=-1)
            result = _evaluate_function(inputs, variable)
            if not bool(torch.isfinite(result).all()):
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' produced "
                    "non-finite structural targets before bound clipping"
                )
        if variable.lower_bound is not None or variable.upper_bound is not None:
            result = torch.clamp(
                result,
                min=variable.lower_bound,
                max=variable.upper_bound,
            )
        named[variable.name] = result
        outputs.append(result)
    result = torch.stack(outputs, dim=-1)
    if scaling:
        width = len(knowledge.reconstructed_variables)
        reconstructed_mean = _scaling_tensor(scaling, "reconstructed_mean", width, result)
        reconstructed_std = _scaling_tensor(scaling, "reconstructed_std", width, result)
        result = (result - reconstructed_mean.view(1, 1, -1)) / reconstructed_std.view(
            1, 1, -1
        )
    return result


def reconstructed_variable_targets_numpy(
    values: np.ndarray,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    scaling: dict[str, list[float]] | None = None,
    oracle_values: np.ndarray | None = None,
    oracle_columns: list[str] | None = None,
    prefer_oracle: bool = False,
) -> np.ndarray:
    tensor = torch.as_tensor(values, dtype=torch.float32)
    return reconstructed_variable_targets_torch(
        tensor,
        knowledge,
        feature_columns,
        scaling=scaling,
        oracle_values=(
            torch.as_tensor(oracle_values, dtype=torch.float32)
            if oracle_values is not None
            else None
        ),
        oracle_columns=oracle_columns,
        prefer_oracle=prefer_oracle,
    ).cpu().numpy()


def augmented_final_targets_numpy(
    windows: np.ndarray,
    targets: np.ndarray,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    scaling: dict[str, list[float]] | None = None,
    oracle_windows: np.ndarray | None = None,
    oracle_columns: list[str] | None = None,
) -> np.ndarray:
    if not knowledge.reconstructed_variables:
        return np.asarray(targets, dtype=np.float32)
    # Keep each complete temporal window, including history-dependent target
    # functions. Only independent windows are chunked. No recording is split.
    reconstructed = np.empty((len(windows), len(knowledge.reconstructed_variables)), dtype=np.float32)
    chunk = max(1, min(4096, 16_777_216 // max(1, int(np.prod(windows.shape[1:])))))
    for start in range(0, len(windows), chunk):
        stop = start + chunk
        reconstructed[start:stop] = reconstructed_variable_targets_numpy(
            windows[start:stop], knowledge, feature_columns, scaling=scaling,
            oracle_values=oracle_windows[start:stop] if oracle_windows is not None else None,
            oracle_columns=oracle_columns, prefer_oracle=oracle_windows is not None,
        )[:, -1, :]
    return np.concatenate([np.asarray(targets, dtype=np.float32), reconstructed], axis=1)


def fit_reconstructed_variable_scaling(
    standardized_windows: np.ndarray,
    knowledge: SystemKnowledge,
    feature_columns: list[str],
    feature_mean: np.ndarray,
    feature_std: np.ndarray,
    oracle_windows: np.ndarray | None = None,
    oracle_columns: list[str] | None = None,
    *,
    chunk_size: int = 4096,
) -> dict[str, list[float]]:
    """Fit semantic-state scaling on normal training windows only.

    Structural equations are evaluated in original physical units.  Their
    outputs are standardized only afterwards, avoiding invalid balances over
    independently standardized sensor channels.
    """

    base = {
        "feature_mean": np.asarray(feature_mean, dtype=np.float32).tolist(),
        "feature_std": np.asarray(feature_std, dtype=np.float32).tolist(),
        "reconstructed_mean": [],
        "reconstructed_std": [],
        "fit_scope": "normal_training_windows_only",
    }
    if not len(standardized_windows):
        raise ConfigError("Cannot fit diagnostic reconstructed scaling on an empty training set")
    if not knowledge.reconstructed_variables:
        # Masked measured-state heads still need the physical feature scale.
        # There are no additional semantic targets whose moments can be fitted.
        return base
    count = 0
    mean = np.zeros(len(knowledge.reconstructed_variables), dtype=np.float64)
    centered_square = np.zeros_like(mean)
    physical_scaling = {
        "feature_mean": base["feature_mean"],
        "feature_std": base["feature_std"],
        "reconstructed_mean": [0.0] * len(knowledge.reconstructed_variables),
        "reconstructed_std": [1.0] * len(knowledge.reconstructed_variables),
    }
    chunk_size = max(1, min(int(chunk_size),
        16_777_216 // max(1, int(np.prod(standardized_windows.shape[1:])))))
    for start in range(0, len(standardized_windows), chunk_size):
        block = reconstructed_variable_targets_numpy(
            standardized_windows[start : start + chunk_size],
            knowledge,
            feature_columns,
            scaling=physical_scaling,
            oracle_values=(
                oracle_windows[start : start + chunk_size]
                if oracle_windows is not None
                else None
            ),
            oracle_columns=oracle_columns,
            prefer_oracle=oracle_windows is not None,
        ).astype(np.float64, copy=False)
        flattened = block.reshape(-1, block.shape[-1])
        block_count = int(flattened.shape[0])
        if not block_count:
            continue
        block_mean = flattened.mean(axis=0)
        block_square = np.square(flattened - block_mean).sum(axis=0)
        combined_count = count + block_count
        delta = block_mean - mean
        # Merge centered moments. Subtracting E[x]^2 from E[x^2] loses
        # the variance when physical offsets are large relative to changes.
        centered_square += block_square + np.square(delta) * (count * block_count / combined_count)
        mean += delta * (block_count / combined_count)
        count = combined_count
    if not count:
        raise ConfigError("Cannot fit diagnostic reconstructed scaling on an empty training set")
    variance = np.maximum(centered_square / count, 0.0)
    std = np.sqrt(variance)
    std[std < 1.0e-8] = 1.0
    base["reconstructed_mean"] = mean.astype(np.float32).tolist()
    base["reconstructed_std"] = std.astype(np.float32).tolist()
    return base


def _evaluate_function(inputs: torch.Tensor, variable: ReconstructedVariableSpec) -> torch.Tensor:
    function = variable.function
    if function == "identity":
        if inputs.shape[-1] != 1:
            raise ConfigError(f"identity state '{variable.name}' requires one input")
        return inputs[:, :, 0]
    if function == "mean":
        return inputs.mean(dim=-1)
    if function == "mean_absolute":
        return inputs.abs().mean(dim=-1)
    if function == "max":
        return inputs.max(dim=-1).values
    if function == "weighted_sum":
        coefficients = variable.coefficients or [1.0] * inputs.shape[-1]
        weights = torch.as_tensor(coefficients, dtype=inputs.dtype, device=inputs.device)
        return (inputs * weights).sum(dim=-1) + float(variable.bias)
    if function == "cumulative_weighted_sum":
        coefficients = variable.coefficients or [1.0] * inputs.shape[-1]
        weights = torch.as_tensor(coefficients, dtype=inputs.dtype, device=inputs.device)
        increment = (inputs * weights).sum(dim=-1)
        return torch.cumsum(increment, dim=1) + float(variable.bias)
    if function == "reciprocal_affine":
        coefficients = variable.coefficients or [1.0] * inputs.shape[-1]
        weights = torch.as_tensor(coefficients, dtype=inputs.dtype, device=inputs.device)
        denominator = (inputs * weights).sum(dim=-1) + float(variable.bias)
        epsilon = float(variable.epsilon)
        safe = torch.where(
            denominator >= 0.0,
            torch.clamp(denominator, min=epsilon),
            torch.clamp(denominator, max=-epsilon),
        )
        return 1.0 / safe
    if function == "pressure_flow_resistance":
        if inputs.shape[-1] != 3:
            raise ConfigError(
                f"pressure_flow_resistance state '{variable.name}' requires "
                "upstream pressure, downstream pressure, and flow"
            )
        pressure_drop = torch.abs(inputs[:, :, 0] - inputs[:, :, 1])
        flow = torch.abs(inputs[:, :, 2])
        return pressure_drop / torch.clamp(flow, min=float(variable.epsilon))
    if function == "active_flow_resistance_proxy":
        if inputs.shape[-1] < 2:
            raise ConfigError(
                f"active_flow_resistance_proxy state '{variable.name}' requires "
                "one or more activation states followed by flow"
            )
        activity = torch.clamp(inputs[:, :, :-1], min=0.0, max=1.0).max(
            dim=-1
        ).values
        flow = torch.abs(inputs[:, :, -1])
        active_resistance = activity / torch.clamp(
            flow, min=float(variable.epsilon)
        )
        return torch.where(
            activity > 0.0,
            active_resistance,
            torch.zeros_like(active_resistance),
        )
    if function == "flow_per_command":
        if inputs.shape[-1] != 2:
            raise ConfigError(
                f"flow_per_command state '{variable.name}' requires flow and command"
            )
        flow = inputs[:, :, 0]
        command = inputs[:, :, 1]
        epsilon = float(variable.epsilon)
        safe_command = torch.where(
            command >= 0.0,
            torch.clamp(command, min=epsilon),
            torch.clamp(command, max=-epsilon),
        )
        return flow / safe_command
    if function == "difference":
        if inputs.shape[-1] < 2:
            raise ConfigError(f"difference state '{variable.name}' requires two inputs")
        return inputs[:, :, 0] - inputs[:, :, 1]
    if function == "delayed_difference":
        if inputs.shape[-1] < 2:
            raise ConfigError(
                f"delayed_difference state '{variable.name}' requires two inputs"
            )
        lag = max(1, int(variable.lag_steps or 1))
        upstream = inputs[:, :, 0]
        delayed_upstream = (
            torch.cat(
                [
                    upstream[:, :1].expand(-1, min(lag, upstream.shape[1])),
                    upstream[:, :-lag],
                ],
                dim=1,
            )
            if upstream.shape[1] > lag
            else upstream[:, :1].expand_as(upstream)
        )
        return delayed_upstream - inputs[:, :, 1]
    if function == "mean_delta":
        current = inputs.mean(dim=-1)
        lag = max(1, int(variable.lag_steps or 1))
        previous = torch.cat(
            [current[:, :1].expand(-1, lag), current[:, :-lag]], dim=1
        ) if current.shape[1] > lag else current[:, :1].expand_as(current)
        return current - previous
    if function == "delayed_mean":
        current = inputs.mean(dim=-1)
        lag = max(1, int(variable.lag_steps or 1))
        return torch.cat(
            [current[:, :1].expand(-1, min(lag, current.shape[1])), current[:, :-lag]],
            dim=1,
        ) if current.shape[1] > lag else current[:, :1].expand_as(current)
    if function == "product":
        return inputs.prod(dim=-1)
    raise ConfigError(
        f"Unsupported diagnostic reconstructed function '{function}' for '{variable.name}'"
    )
