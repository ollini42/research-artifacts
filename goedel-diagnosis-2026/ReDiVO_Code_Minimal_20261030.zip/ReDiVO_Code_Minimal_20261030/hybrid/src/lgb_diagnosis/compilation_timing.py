"""Read-only compiler wall intervals, including lazy backward compilation.

PyTorch 2.12 emits wall-clock microsecond intervals for Dynamo and backward
compilation. Their union avoids charging nested compilation twice. Runtime
events are not compilation. Missing or evicted telemetry fails closed.
"""
from __future__ import annotations

import math
import time


def metrics():
    from torch._dynamo.utils import get_compilation_metrics
    return get_compilation_metrics()


def interval_union_seconds(intervals):
    end = None
    total = 0
    for start, stop in sorted(intervals):
        if not all(math.isfinite(x) for x in (start, stop)) or stop < start:
            raise ValueError('Invalid compiler interval')
        total += max(0, stop - max(start, end if end is not None else start))
        end = max(stop, end if end is not None else stop)
    return total / 1.e6


class CompilationWindow:
    def __init__(self):
        self.before = metrics()  # Retain objects, so identities cannot be reused.
        self.started_us = time.time_ns() // 1000

    def finish(self, elapsed):
        ended_us = time.time_ns() // 1000
        after = metrics()
        if not self.before and len(after) >= 64:
            raise ValueError('Compiler telemetry may have overflowed its initial buffer')
        ids = {id(item) for item in self.before}
        if self.before and not any(id(x) == id(self.before[-1]) for x in after):
            raise ValueError('Compiler telemetry was cleared or overflowed')
        events = []
        for item in after:
            if id(item) in ids or getattr(item, 'is_runtime', False):
                continue
            start, end = item.start_time_us, item.end_time_us
            if start is None or end is None or item.fail_type:
                raise ValueError('Incomplete or failed compiler telemetry')
            if start < self.started_us or end > ended_us or end < start:
                raise ValueError('Compiler event outside measurement window')
            events.append(dict(start_time_us=start, end_time_us=end,
                               forward=item.is_forward, compile_id=str(item.compile_id)))
        seconds = interval_union_seconds([(e['start_time_us'], e['end_time_us']) for e in events])
        if seconds > elapsed + .001 or abs((ended_us-self.started_us)/1.e6-elapsed) > max(.1, .01*elapsed):
            raise ValueError('Compiler and phase clocks disagree')
        return dict(timing_schema='compiler_wall_union_v1', compilation_seconds=seconds,
                    compute_seconds=max(0., elapsed-seconds), compiler_events=events)
