#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2026 Oliver Niggemann
# Affiliation: Helmut Schmidt University / University of the Federal Armed Forces Hamburg
# SPDX-License-Identifier: AGPL-3.0-or-later
# Use at your own risk. No warranty. Liability is excluded where law permits.
# See NOTICE and LICENSES/AGPL-3.0-or-later.txt.
"""Verify the release manifest without importing models or running generators."""
import ast
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root/'MANIFEST.json').read_text())
checked = 0
for name, row in manifest['files'].items():
    path = root/name
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Unsafe manifest path')
    content = path.read_bytes()
    if len(content) != row['bytes'] or hashlib.sha256(content).hexdigest() != row['sha256']:
        raise ValueError('Checksum mismatch: '+name)
    if path.suffix == '.py':
        ast.parse(content, filename=name)
        compile(content, name, 'exec')
    if row.get('notice') and not (root/row['notice']).is_file():
        raise ValueError('Missing notice: '+name)
    checked += 1
print(json.dumps(dict(verified_files=checked, simulations_started=0, training_started=0)))
