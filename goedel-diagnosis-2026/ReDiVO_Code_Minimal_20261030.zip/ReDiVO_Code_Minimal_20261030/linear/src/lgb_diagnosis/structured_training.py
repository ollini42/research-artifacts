"""Training, baselines, completion, and diagnostics for the V18 observer."""

from __future__ import annotations

from typing import Any

import numpy as np
import torch
from torch import nn

from .structured_observer import (
    StructuredObserverOutput,
    StructuredPredictUpdateObserver,
)


STRUCTURED_OBSERVER_METHOD_VERSIONS = {
    "v18_audited_range_open_loop_component_fault_observer",
}


def is_structured_observer(model: nn.Module) -> bool:
    """Return whether a model implements the structured predict-update API."""

    return str(getattr(model, "method_version", "")) in (
        STRUCTURED_OBSERVER_METHOD_VERSIONS
    )


def _binary_truth(
    standardized: torch.Tensor,
    model: StructuredPredictUpdateObserver,
    diagnostic_index: int,
) -> torch.Tensor:
    raw = (
        standardized * model.diagnostic_std[diagnostic_index]
        + model.diagnostic_mean[diagnostic_index]
    )
    return torch.clamp(raw, min=0.0, max=1.0)


def structured_target_balanced_losses(
    model: StructuredPredictUpdateObserver,
    output: StructuredObserverOutput,
    measured_targets: torch.Tensor,
    reconstructed_targets: torch.Tensor,
    values: torch.Tensor,
    mask: torch.Tensor,
    *,
    delta_t_steps: int,
    exogenous_measured_indices: tuple[int, ...] = (),
) -> dict[str, Any]:
    """Return target-balanced losses over one fixed open-loop window.

    The nominal branch is evaluated at every horizon of the same rollout used
    for diagnosis. It is never re-anchored with a process measurement inside
    that window. The real branch is evaluated over the corresponding horizons
    and contains only online-unavailable targets.
    """

    trajectory = model.nominal_real_trajectories(
        values,
        mask,
        delta_t_steps=int(delta_t_steps),
        exogenous_measured_indices=exogenous_measured_indices,
        p_real_output=output,
    )
    target_start = int(trajectory.boundary_index) + 1
    measured_horizons = measured_targets[:, target_start:, :]
    reconstructed_horizons = reconstructed_targets[:, target_start:, :]

    complete_targets = torch.cat(
        [measured_horizons, reconstructed_horizons], dim=-1
    )
    target_indices = [spec.diagnostic_index for spec in model.target_specs]
    real_expected = complete_targets[..., target_indices]
    real_errors = (trajectory.p_real_horizons[..., target_indices] - real_expected).square()
    binary_positions = [p for p, spec in enumerate(model.target_specs) if spec.output_type == "binary"]
    if binary_positions:
        diagnostic_indices = [target_indices[p] for p in binary_positions]
        truth = (real_expected[..., binary_positions] * model.diagnostic_std[diagnostic_indices] + model.diagnostic_mean[diagnostic_indices]).clamp(0, 1)
        real_errors[..., binary_positions] = nn.functional.binary_cross_entropy_with_logits(
            output.filter_logits[:, target_start:, binary_positions], truth, reduction="none"
        )
    real_losses = real_errors.mean(dim=(0, 1))
    per_real_target = {spec.name: real_losses[p] for p, spec in enumerate(model.target_specs)}
    zero = output.posterior_measured.sum() * 0.0
    real_macro = real_losses.mean() if model.target_specs else zero

    nominal_errors = (trajectory.p_nominal_horizons - complete_targets).square()
    binary_indices = list(model.binary_diagnostic_indices)
    if binary_indices:
        mean = model.diagnostic_mean[binary_indices]
        std = model.diagnostic_std[binary_indices]
        truth = (complete_targets[..., binary_indices] * std + mean).clamp(0, 1)
        probability = (trajectory.p_nominal_horizons[..., binary_indices] * std + mean).clamp(1e-6, 1 - 1e-6)
        nominal_errors[..., binary_indices] = nn.functional.binary_cross_entropy(probability, truth, reduction="none")
    nominal_losses = nominal_errors.mean(dim=(0, 1))
    per_nominal_target: dict[str, torch.Tensor] = {}
    for index in range(model.diagnostic_dim):
        name = (
            model.feature_names[index]
            if hasattr(model, "feature_names") and index < len(model.feature_names)
            else str(index)
        )
        per_nominal_target[name] = nominal_losses[index]
    nominal_macro = nominal_losses.mean() if model.diagnostic_dim else zero
    return {
        "real_trajectory_loss": real_macro,
        "nominal_trajectory_loss": nominal_macro,
        "per_real_target": per_real_target,
        "per_nominal_target": per_nominal_target,
        "real_target_count": len(real_losses),
        "nominal_target_count": len(nominal_losses),
        "delta_t_steps": int(delta_t_steps),
        "trajectory": trajectory,
    }


def fit_dependency_matched_ridge(
    targets: np.ndarray,
    model: StructuredPredictUpdateObserver,
    *,
    alpha: float = 1.0e-3,
) -> dict[str, Any]:
    """Fit ridge on available supplied inputs, never hidden input oracles.

    Heads that also depend on predicted coordinates have only a restricted
    available-input comparator. This limitation is explicit in its manifest.
    """

    values = np.asarray(targets, dtype=np.float64)
    result: dict[str, Any] = {
        "baseline": "dependency_matched_ridge",
        "alpha": float(alpha),
        "target_models": {},
        "target_manifest": model.target_manifest(),
    }
    hidden_measured = {spec.measured_index for spec in model.target_specs if spec.measured_index is not None}
    for spec in model.target_specs:
        if spec.measured_index is None:
            continue
        available_dependencies = [(i,n) for i,n in zip(spec.dependency_indices,spec.dependency_names)
                                  if i < model.num_features and i not in hidden_measured]
        dependencies = np.asarray([i for i,_ in available_dependencies], dtype=int)
        exact_dependency_match = len(available_dependencies) == len(spec.dependency_indices)
        x = values[:, dependencies]
        y = values[:, spec.measured_index]
        if spec.output_type == "binary":
            # A binary virtual sensor is an affine logit followed by sigmoid;
            # fit its fair comparator in exactly that output space.
            y_binary = np.clip(
                y * float(model.diagnostic_std[spec.diagnostic_index].cpu())
                + float(model.diagnostic_mean[spec.diagnostic_index].cpu()),
                0.0,
                1.0,
            )
            design = np.column_stack([np.ones(len(x), dtype=np.float64), x])
            beta = np.zeros(design.shape[1], dtype=np.float64)
            for _ in range(50):
                logits = np.clip(design @ beta, -30.0, 30.0)
                probability = 1.0 / (1.0 + np.exp(-logits))
                weights = np.maximum(probability * (1.0 - probability), 1.0e-6)
                hessian = design.T @ (design * weights[:, None])
                regularizer = np.eye(design.shape[1], dtype=np.float64) * float(alpha)
                regularizer[0, 0] = 0.0
                gradient = design.T @ (probability - y_binary) + regularizer @ beta
                try:
                    step = np.linalg.solve(hessian + regularizer, gradient)
                except np.linalg.LinAlgError:
                    step = np.linalg.pinv(hessian + regularizer) @ gradient
                beta -= step
                if float(np.max(np.abs(step))) < 1.0e-8:
                    break
            intercept = float(beta[0])
            coefficients = beta[1:]
            prediction_raw = 1.0 / (
                1.0 + np.exp(-np.clip(x @ coefficients + intercept, -30.0, 30.0))
            )
            prediction = (
                prediction_raw
                - float(model.diagnostic_mean[spec.diagnostic_index].cpu())
            ) / max(float(model.diagnostic_std[spec.diagnostic_index].cpu()), 1.0e-8)
            comparator = "dependency_matched_logistic_ridge"
        else:
            if x.shape[1]:
                x_mean = x.mean(axis=0)
                y_mean = float(y.mean())
                centered = x - x_mean
                gram = centered.T @ centered
                gram.flat[:: gram.shape[0] + 1] += float(alpha)
                cross = centered.T @ (y - y_mean)
                try:
                    coefficients = np.linalg.solve(gram, cross)
                except np.linalg.LinAlgError:
                    coefficients = np.linalg.pinv(gram) @ cross
                intercept = y_mean - float(x_mean @ coefficients)
            else:
                coefficients = np.zeros(0, dtype=np.float64)
                intercept = float(y.mean())
            prediction = x @ coefficients + intercept
            comparator = "dependency_matched_linear_ridge"
        error = prediction - y
        result["target_models"][str(spec.measured_index)] = {
            "name": spec.name,
            "dependency_indices": dependencies.astype(int),
            "dependency_names": [n for _,n in available_dependencies],
            "observer_dependency_names": list(spec.dependency_names),
            "exact_dependency_match": exact_dependency_match,
            "input_information_scope": "available_measurements_only",
            "coefficients": coefficients.astype(np.float32),
            "intercept": float(intercept),
            "normal_mean": float(y.mean()),
            "output_type": spec.output_type,
            "comparator": comparator if exact_dependency_match else comparator.replace("dependency_matched", "available_subset"),
            "diagnostic_mean": float(model.diagnostic_mean[spec.diagnostic_index].cpu()),
            "diagnostic_std": float(model.diagnostic_std[spec.diagnostic_index].cpu()),
            "train_rmse": float(np.sqrt(np.mean(np.square(error)))),
            "train_mae": float(np.mean(np.abs(error))),
        }
    return result


def dependency_matched_ridge_metrics(
    targets: np.ndarray,
    baselines: dict[str, Any],
) -> dict[str, Any]:
    values = np.asarray(targets, dtype=np.float64)
    per_target: dict[str, dict[str, float]] = {}
    errors: list[np.ndarray] = []
    for target_index, spec in (baselines.get("target_models") or {}).items():
        model_spec = spec
        index = int(target_index)
        dependencies = np.asarray(model_spec["dependency_indices"], dtype=int)
        coefficients = np.asarray(model_spec["coefficients"], dtype=np.float64)
        affine = values[:, dependencies] @ coefficients + float(model_spec["intercept"])
        if str(model_spec.get("output_type", "continuous")) == "binary":
            raw = 1.0 / (1.0 + np.exp(-np.clip(affine, -30.0, 30.0)))
            prediction = (
                raw - float(model_spec["diagnostic_mean"])
            ) / max(float(model_spec["diagnostic_std"]), 1.0e-8)
        else:
            prediction = affine
        error = prediction - values[:, index]
        errors.append(error)
        per_target[str(model_spec["name"])] = {
            "mae": float(np.mean(np.abs(error))),
            "rmse": float(np.sqrt(np.mean(np.square(error)))),
        }
    if not errors:
        return {"mae": 0.0, "rmse": 0.0, "masked_features": {}}
    concatenated = np.concatenate([error.reshape(-1) for error in errors])
    return {
        "mae": float(np.mean(np.abs(concatenated))),
        "rmse": float(np.sqrt(np.mean(np.square(concatenated)))),
        "masked_features": per_target,
    }
