"""System knowledge model for modules, signals, predicates, and rules."""

from __future__ import annotations

from dataclasses import dataclass, field
import math
from pathlib import Path
from typing import Any

import yaml

from .config import ConfigError, expand_path


@dataclass
class ModuleSpec:
    name: str
    description: str = ""
    inputs: list[str] = field(default_factory=list)
    outputs: list[str] = field(default_factory=list)
    states: list[str] = field(default_factory=list)
    external_inputs: list[str] = field(default_factory=list)
    max_latency_steps: int = 0
    latency_prior_steps: float | None = None
    # True only when supplied system knowledge guarantees that every fault
    # mode considered for this module must create persistent local evidence
    # in the declared diagnostic variables. Merely measuring all CSV columns
    # is not sufficient for this certificate.
    local_fault_detectability_certified: bool = False

    @property
    def signals(self) -> list[str]:
        ordered = self.inputs + self.outputs + self.states + self.external_inputs
        return list(dict.fromkeys(ordered))


@dataclass
class ConnectionSpec:
    source_module: str
    source_signal: str
    target_module: str
    target_signal: str
    relation: str = ""
    min_latency_steps: int = 0
    max_latency_steps: int = 0
    # -1 denotes an inverse effect, +1 an equal-direction effect, and 0 an
    # unspecified sign. The sign is supplied engineering knowledge.
    influence_sign: int = 0
    # Optional value-bearing mode or command variables that gate this edge.
    # They must belong to the canonical diagnostic register V.
    operating_condition_signals: list[str] = field(default_factory=list)
    operating_condition: str = "always"
    provenance: str = ""
    # Optional source-reviewed relation types for this exact signal pair.
    # An empty list preserves the generic builder behavior.  A non-empty list
    # prevents a global ablation setting from imposing an unsupported
    # monotonic relation on every physical edge.
    qualitative_relations: list[str] = field(default_factory=list)
    minimum_source_change: float = 0.0
    minimum_response_change: float = 0.0


@dataclass
class PredicateSpec:
    name: str
    kind: str
    module: str
    signal: str | None = None
    source: str | None = None
    target: str | None = None
    signals: list[str] = field(default_factory=list)
    relation: str = ""
    lag_steps: int = 0
    min_lag_steps: int = 0
    max_lag_steps: int = 0
    influence_sign: int = 0
    operating_condition_signals: list[str] = field(default_factory=list)
    operating_condition: str = "always"
    group: str = "module_nominality"
    description: str = ""
    # Positive scale for a dimensionless predicate violation. Data scaling is
    # fitted on normal training values, never on test fault trajectories.
    tolerance: float = 1.0
    condition_threshold: float = 0.5
    minimum_source_change: float = 0.0
    minimum_response_change: float = 0.0


@dataclass
class RuleSpec:
    name: str
    type: str
    module: str
    weight: float = 1.0
    group: str = "module_nominality"
    predicate: str | None = None
    predicates: list[str] = field(default_factory=list)
    antecedent: str | None = None
    consequent: str | None = None
    # V18 contains only fault-preserving training rules. The unspecified value
    # is accepted while a dataset builder assembles its rule list.
    role: str = "unspecified"
    fault_preserving: bool = False


@dataclass
class ReconstructedVariableSpec:
    """A named diagnostic variable unavailable during online use.

    The state is not a CSV feature.  ``inputs`` and ``function`` define an
    auditable structural target that can be computed from complete simulator
    traces during training/evaluation and from reconstructed/observed inputs
    online. The neural model represents the value in a dedicated target head.
    Diagnostic roles are independent of online availability and may overlap.
    """

    name: str
    module: str
    kind: str
    inputs: list[str] = field(default_factory=list)
    outputs: list[str] = field(default_factory=list)
    output_relations: dict[str, str] = field(default_factory=dict)
    function: str = "mean"
    coefficients: list[float] = field(default_factory=list)
    bias: float = 0.0
    epsilon: float = 1.0e-6
    lag_steps: int = 0
    lower_bound: float | None = None
    upper_bound: float | None = None
    source: str = "structural_prior"
    equation_class: str = "derived_structural_proxy"
    unit: str = ""
    valid_modes: list[str] = field(default_factory=list)
    online_observable: bool = False
    oracle_column: str | None = None
    fault_preserving: bool = True
    provenance: str = ""
    description: str = ""
    diagnostic_roles: list[str] = field(default_factory=lambda: ["state"])


@dataclass
class VirtualFaultSensorSpec:
    """Supplied engineering design of one component fault sensor.

    A component is a physical item into which a fault can be injected. It may
    be smaller than a plant module. The sensor estimates one component variable
    and represents the root-cause pair of component and fault type. Fault labels
    and offline oracle values are never online inputs.
    """

    name: str
    module: str
    root_cause: str = ""
    physical_component: str = ""
    fault_type: str = "?"
    physical_quantity: str = ""
    component_variables: list[str] = field(default_factory=list)
    primary_cause_sensitive_variable: str = ""
    response_horizon_steps: int = 0
    response_horizon_source: str = "supplied_system_structure"
    expected_deviation_sign: int = 0
    diagnostic_variables: list[str] = field(default_factory=list)
    measured_dependencies: list[str] = field(default_factory=list)
    causal_inputs: list[str] = field(default_factory=list)
    observable_effects: list[str] = field(default_factory=list)
    covered_fault_modes: list[str] = field(default_factory=list)
    fault_mode_evidence: dict[str, list[str]] = field(default_factory=dict)
    aggregation: str = "earliest_persistent_constituent_innovation"
    online_input_policy: str = "available_measurements_and_reconstructed_dependencies"
    uses_fault_labels_online: bool = False
    engineering_source: str = "supplied_component_analysis"
    detectability_claim: str = "designed_coverage_requires_empirical_validation"
    description: str = ""

    @property
    def candidate_id(self) -> str:
        return self.root_cause or format_root_cause(
            self.physical_component, self.fault_type
        )

def format_root_cause(component: str, fault_type: str = "?") -> str:
    """Return the canonical root-cause pair used in exports and metrics."""

    return f"<{component}, {fault_type or '?'}>"


@dataclass
class SystemKnowledge:
    modules: list[ModuleSpec]
    connections: list[ConnectionSpec]
    predicates: list[PredicateSpec]
    rules: list[RuleSpec]
    reconstructed_variables: list[ReconstructedVariableSpec] = field(default_factory=list)
    virtual_fault_sensors: list[VirtualFaultSensorSpec] = field(default_factory=list)

    @property
    def module_names(self) -> list[str]:
        return [module.name for module in self.modules]

    @property
    def predicate_names(self) -> list[str]:
        return [predicate.name for predicate in self.predicates]

    @property
    def reconstructed_variable_names(self) -> list[str]:
        return [variable.name for variable in self.reconstructed_variables]

    @property
    def virtual_fault_sensor_names(self) -> list[str]:
        return [sensor.name for sensor in self.virtual_fault_sensors]

    def virtual_fault_sensor_for_module(
        self, module_name: str
    ) -> VirtualFaultSensorSpec | None:
        return next(
            (
                sensor
                for sensor in self.virtual_fault_sensors
                if sensor.module == module_name
            ),
            None,
        )

    def virtual_fault_sensors_for_module(
        self, module_name: str
    ) -> list[VirtualFaultSensorSpec]:
        return [
            sensor
            for sensor in self.virtual_fault_sensors
            if sensor.module == module_name
        ]

    def virtual_fault_sensor_for_fault(
        self, owner_name: str, fault_mode: str
    ) -> VirtualFaultSensorSpec | None:
        """Resolve an offline label to its supplied component-fault sensor.

        HAI labels provide the structural plant module, whereas the Extended
        TEP adapter provides the disturbance component ID directly. Supporting
        both forms keeps the evaluation ontology explicit without changing the
        online observer input boundary.
        """

        eligible = [
            sensor
            for sensor in self.virtual_fault_sensors
            if owner_name in {sensor.module, sensor.physical_component}
        ]
        exact = next(
            (
                sensor
                for sensor in eligible
                if fault_mode == sensor.fault_type
                or fault_mode in sensor.covered_fault_modes
            ),
            None,
        )
        if exact is not None:
            return exact
        return next(
            (
                sensor
                for sensor in eligible
                if sensor.fault_type == "?"
            ),
            None,
        )

    @property
    def fault_component_names(self) -> list[str]:
        return sorted(
            {sensor.physical_component for sensor in self.virtual_fault_sensors}
        )

    def component_to_variables(self) -> dict[str, list[str]]:
        mapping: dict[str, set[str]] = {}
        for sensor in self.virtual_fault_sensors:
            variables = sensor.component_variables or [
                sensor.primary_cause_sensitive_variable
            ]
            mapping.setdefault(sensor.physical_component, set()).update(variables)
        return {
            component: sorted(variables)
            for component, variables in sorted(mapping.items())
        }

    def component_for_signal(self, signal: str) -> str | None:
        matches = [
            component
            for component, variables in self.component_to_variables().items()
            if signal in variables
        ]
        return matches[0] if len(matches) == 1 else None

    def virtual_fault_sensor_coverage(self) -> dict[str, bool]:
        covered = {sensor.module for sensor in self.virtual_fault_sensors}
        return {module.name: module.name in covered for module in self.modules}

    def signal_to_module(self) -> dict[str, str]:
        mapping: dict[str, str] = {}
        for module in self.modules:
            for signal in module.signals:
                mapping.setdefault(signal, module.name)
        for variable in self.reconstructed_variables:
            mapping.setdefault(variable.name, variable.module)
        return mapping

    def diagnostic_variable_registry(
        self,
        feature_columns: list[str],
        masked_feature_columns: list[str] | tuple[str, ...] = (),
    ) -> dict[str, Any]:
        """Return the V18 register with orthogonal availability and roles."""

        measured = list(dict.fromkeys(str(name) for name in feature_columns))
        reconstructed = list(self.reconstructed_variable_names)
        masked = list(dict.fromkeys(str(name) for name in masked_feature_columns))
        unknown_masked = set(masked).difference(measured)
        if unknown_masked:
            raise ConfigError(
                "The observation mask contains variables outside the measured "
                f"dataset variables: {sorted(unknown_masked)}"
            )
        overlap = set(measured).intersection(reconstructed)
        if overlap:
            raise ConfigError(
                "Measured and named reconstructed variables require distinct "
                f"names: {sorted(overlap)}"
            )
        observed = [name for name in measured if name not in set(masked)]
        unavailable = masked + reconstructed
        variable_order = measured + reconstructed
        role_by_variable: dict[str, set[str]] = {
            name: set() for name in variable_order
        }
        for variable in self.reconstructed_variables:
            role_by_variable[variable.name].update(variable.diagnostic_roles)
        for sensor in self.virtual_fault_sensors:
            for name in dict.fromkeys(
                sensor.component_variables
                + sensor.diagnostic_variables
                + [sensor.primary_cause_sensitive_variable]
            ):
                if name in role_by_variable:
                    role_by_variable[name].add("cause")
        unsupported_roles = {
            role
            for roles in role_by_variable.values()
            for role in roles
            if role not in {"state", "cause"}
        }
        if unsupported_roles:
            raise ConfigError(
                f"Unsupported diagnostic roles: {sorted(unsupported_roles)}"
            )
        state_variables = [
            name for name in variable_order if "state" in role_by_variable[name]
        ]
        cause_variables = [
            name for name in variable_order if "cause" in role_by_variable[name]
        ]
        return {
            "V": variable_order,
            "V_obs": observed,
            "V_rec": unavailable,
            "V_state": state_variables,
            "V_cause": cause_variables,
            "masked_variables": masked,
            "availability_partition_disjoint": not bool(
                set(observed).intersection(unavailable)
            ),
            "availability_partition_complete": set(variable_order)
            == set(observed).union(unavailable),
            "role_overlap_allowed": True,
            "state_cause_overlap": sorted(
                set(state_variables).intersection(cause_variables)
            ),
            "availability": {
                **{name: "observed" for name in observed},
                **{name: "reconstructed" for name in unavailable},
            },
            "roles": {
                name: sorted(role_by_variable[name]) for name in variable_order
            },
            "module_assignment": {
                name: self.module_for_signal(name)
                for name in variable_order
            },
        }

    def module_for_signal(self, signal: str) -> str | None:
        return self.signal_to_module().get(signal)

    def validate(self, feature_columns: list[str]) -> None:
        """Validate structural modules and diagnostic component ownership.

        Every state keeps one plant-module assignment for topology. Every
        diagnosis variable additionally has one supplied fault-injection
        component. Neither assignment is learned from fault labels.
        """

        modules = set(self.module_names)
        predicates = set(self.predicate_names)
        reconstructed_variables = set(self.reconstructed_variable_names)
        virtual_sensor_names = set(self.virtual_fault_sensor_names)
        virtual_root_causes = {
            sensor.candidate_id for sensor in self.virtual_fault_sensors
        }
        if len(modules) != len(self.modules):
            raise ConfigError("Duplicate module names in system knowledge")
        if len(predicates) != len(self.predicates):
            raise ConfigError("Duplicate predicate names in system knowledge")
        if len({rule.name for rule in self.rules}) != len(self.rules):
            raise ConfigError("Duplicate rule names in system knowledge")
        if len(reconstructed_variables) != len(self.reconstructed_variables):
            raise ConfigError("Duplicate diagnostic reconstructed-variable names in system knowledge")
        if len(virtual_sensor_names) != len(self.virtual_fault_sensors):
            raise ConfigError("Duplicate virtual fault-sensor names in system knowledge")
        if len(virtual_root_causes) != len(self.virtual_fault_sensors):
            raise ConfigError("Duplicate virtual fault-sensor root-cause candidates")
        if reconstructed_variables.intersection(feature_columns):
            raise ConfigError(
                "Diagnostic reconstructed variables must not duplicate measured feature names: "
                f"{sorted(reconstructed_variables.intersection(feature_columns))}"
            )
        supported_latent_functions = {
            "identity",
            "mean",
            "mean_absolute",
            "weighted_sum",
            "cumulative_weighted_sum",
            "reciprocal_affine",
            "pressure_flow_resistance",
            "active_flow_resistance_proxy",
            "flow_per_command",
            "difference",
            "delayed_difference",
            "mean_delta",
            "max",
            "product",
            "delayed_mean",
        }
        # Definitions are evaluated in declaration order.  Requiring an input
        # to be measured or already defined prevents silent cycles between
        # technical state equations.
        known_inputs = set(feature_columns)
        for variable in self.reconstructed_variables:
            if variable.module not in modules:
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' references unknown module "
                    f"'{variable.module}'"
                )
            if variable.function not in supported_latent_functions:
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' uses unsupported function "
                    f"'{variable.function}'"
                )
            missing_inputs = set(variable.inputs).difference(known_inputs)
            if missing_inputs:
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' has unknown inputs: "
                    f"{sorted(missing_inputs)}"
                )
            if variable.coefficients and len(variable.coefficients) != len(variable.inputs):
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' requires one coefficient per input"
                )
            if any(not math.isfinite(value) for value in [variable.bias, *variable.coefficients]):
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' requires finite equation parameters"
                )
            if (
                not math.isfinite(variable.lag_steps)
                or variable.lag_steps < 0
                or variable.lag_steps != int(variable.lag_steps)
            ):
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' requires a non-negative integer lag"
                )
            bounds = [value for value in (variable.lower_bound, variable.upper_bound) if value is not None]
            if any(not math.isfinite(value) for value in bounds):
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' requires finite bounds"
                )
            if len(bounds) == 2 and bounds[0] > bounds[1]:
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' has inverted bounds"
                )
            has_normal_offline_target = bool(variable.oracle_column)
            has_identifying_structure = bool(variable.inputs)
            if not (has_normal_offline_target or has_identifying_structure):
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' requires a normal "
                    "offline target or independently identifying structural inputs"
                )
            known_inputs.add(variable.name)
        all_state_names = set(feature_columns).union(reconstructed_variables)
        owners_by_signal: dict[str, set[str]] = {}
        for module in self.modules:
            for signal in module.signals:
                owners_by_signal.setdefault(signal, set()).add(module.name)
        for variable in self.reconstructed_variables:
            owners_by_signal.setdefault(variable.name, set()).add(variable.module)
        for variable in self.reconstructed_variables:
            unknown_outputs = set(variable.outputs).difference(all_state_names)
            if unknown_outputs:
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' has unknown outputs: "
                    f"{sorted(unknown_outputs)}"
                )
            unknown_relation_outputs = set(variable.output_relations).difference(
                variable.outputs
            )
            if unknown_relation_outputs:
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' defines relations for "
                    f"undeclared outputs: {sorted(unknown_relation_outputs)}"
                )
            if not math.isfinite(variable.epsilon) or variable.epsilon <= 0.0:
                raise ConfigError(
                    f"Diagnostic reconstructed variable '{variable.name}' requires finite epsilon > 0"
                )
        for predicate in self.predicates:
            supported = {
                "signal_band", "state_definition", "connection_compatible",
                "co_increase", "inverse_change", "delayed_follow",
                "flow_balance", "value_compatible", "mode_exclusive",
                "state_level_direction", "pressure_level_compatible",
            }
            if predicate.kind not in supported:
                raise ConfigError(f"Unsupported predicate kind {predicate.kind!r}")
            if not math.isfinite(predicate.tolerance) or predicate.tolerance <= 0:
                raise ConfigError(f"Predicate '{predicate.name}' requires finite positive tolerance")
            condition = predicate.operating_condition
            if condition not in {"always", "normal_closed_loop_operation", "all_active", "any_active", "none_active"}:
                raise ConfigError(f"Unsupported operating condition {condition!r}")
            if condition in {"all_active", "any_active", "none_active"} and not predicate.operating_condition_signals:
                raise ConfigError(f"Predicate '{predicate.name}' requires operating condition signals")
            if not math.isfinite(predicate.condition_threshold):
                raise ConfigError("Predicate condition_threshold must be finite")
            if predicate.kind == "delayed_follow" and (
                not math.isfinite(predicate.minimum_source_change)
                or not math.isfinite(predicate.minimum_response_change)
                or min(predicate.minimum_source_change, predicate.minimum_response_change) <= 0
            ):
                raise ConfigError("delayed_follow requires justified positive source and response changes")
            if predicate.kind in {"signal_band", "state_definition"} and not predicate.signal:
                raise ConfigError(f"Predicate '{predicate.name}' requires signal")
            if predicate.kind == "mode_exclusive" and len(predicate.signals) < 2:
                raise ConfigError(f"Predicate '{predicate.name}' requires at least two mode signals")
            if predicate.kind not in {"signal_band", "state_definition", "mode_exclusive"} and not (predicate.source and predicate.target):
                raise ConfigError(f"Predicate '{predicate.name}' requires source and target")
            if predicate.module not in modules:
                raise ConfigError(f"Predicate '{predicate.name}' references unknown module '{predicate.module}'")
            value_arguments = [
                value
                for value in (
                    predicate.signal,
                    predicate.source,
                    predicate.target,
                    *predicate.signals,
                    *predicate.operating_condition_signals,
                )
                if value
            ]
            if predicate.influence_sign not in {-1, 0, 1}:
                raise ConfigError(
                    f"Predicate '{predicate.name}' has invalid influence_sign "
                    f"{predicate.influence_sign}"
                )
            if min(predicate.lag_steps, predicate.min_lag_steps, predicate.max_lag_steps) < 0:
                raise ConfigError(
                    f"Predicate '{predicate.name}' requires non-negative lag bounds"
                )
            if (
                predicate.max_lag_steps
                and predicate.min_lag_steps > predicate.max_lag_steps
            ):
                raise ConfigError(
                    f"Predicate '{predicate.name}' has an inverted lag interval"
                )
            unknown_arguments = set(value_arguments).difference(all_state_names)
            if unknown_arguments:
                raise ConfigError(
                    f"Predicate '{predicate.name}' references variables outside "
                    f"the canonical diagnostic register V: {sorted(unknown_arguments)}"
                )
            ambiguous_arguments = {
                name: sorted(owners_by_signal.get(name, set()))
                for name in value_arguments
                if len(owners_by_signal.get(name, set())) > 1
            }
            if ambiguous_arguments:
                raise ConfigError(
                    f"Predicate '{predicate.name}' has ambiguously assigned variables: "
                    f"{ambiguous_arguments}"
                )
            if predicate.kind in {"signal_band", "state_definition"}:
                for name in value_arguments:
                    owners = owners_by_signal.get(name, set())
                    if owners and predicate.module not in owners:
                        raise ConfigError(
                            f"Predicate '{predicate.name}' assigns variable {name!r} "
                            f"to module {predicate.module!r}, but Z_c assigns it to "
                            f"{sorted(owners)}"
                        )
        for rule in self.rules:
            if not math.isfinite(rule.weight) or rule.weight < 0:
                raise ConfigError(f"Rule '{rule.name}' requires finite non-negative weight")
            if rule.type not in {"require", "all", "any", "implication", "implication_all"}:
                raise ConfigError(f"Unsupported rule type {rule.type!r}")
            if rule.type in {"all", "any", "implication_all"} and not rule.predicates:
                raise ConfigError(f"Rule '{rule.name}' requires predicate operands")
            if rule.type == "require" and not rule.predicate:
                raise ConfigError(f"Rule '{rule.name}' requires predicate")
            if rule.type in {"implication", "implication_all"} and not rule.consequent:
                raise ConfigError(f"Rule '{rule.name}' requires consequent")
            if rule.type == "implication" and not rule.antecedent:
                raise ConfigError(f"Rule '{rule.name}' requires antecedent")
            if rule.module not in modules:
                raise ConfigError(f"Rule '{rule.name}' references unknown module '{rule.module}'")
            if rule.role not in {"unspecified", "training"}:
                raise ConfigError(
                    f"Rule '{rule.name}' has unsupported role {rule.role!r}"
                )
            if rule.role == "training" and not rule.fault_preserving:
                raise ConfigError(
                    f"Training rule '{rule.name}' must be fault preserving"
                )
            for name in _rule_predicates(rule):
                if name not in predicates:
                    raise ConfigError(f"Rule '{rule.name}' references unknown predicate '{name}'")
        for connection in self.connections:
            if connection.source_module not in modules or connection.target_module not in modules:
                raise ConfigError(f"Connection references unknown module: {connection}")
            if connection.influence_sign not in {-1, 0, 1}:
                raise ConfigError(
                    f"Connection has invalid influence_sign: {connection}"
                )
            if connection.min_latency_steps < 0 or connection.max_latency_steps < 0:
                raise ConfigError("Connection latency bounds must be non-negative")
            if connection.min_latency_steps > connection.max_latency_steps:
                raise ConfigError(f"Connection has an inverted latency interval: {connection}")
            unknown_conditions = set(
                connection.operating_condition_signals
            ).difference(all_state_names)
            if unknown_conditions:
                raise ConfigError(
                    "Connection operating conditions reference variables outside V: "
                    f"{sorted(unknown_conditions)}"
                )
        known_measured = set(feature_columns)
        for sensor in self.virtual_fault_sensors:
            if sensor.expected_deviation_sign not in {-1, 0, 1}:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' has invalid "
                    f"expected_deviation_sign {sensor.expected_deviation_sign}"
                )
            if sensor.module not in modules:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' references unknown module "
                    f"'{sensor.module}'"
                )
            unknown_reconstructed = set(sensor.diagnostic_variables).difference(
                reconstructed_variables
            )
            unknown_measured = set(sensor.measured_dependencies).difference(
                known_measured
            )
            if unknown_reconstructed or unknown_measured:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' references unknown inputs. "
                    f"reconstructed={sorted(unknown_reconstructed)}, "
                    f"measured={sorted(unknown_measured)}"
                )
            undeclared_timing_inputs = set(
                sensor.causal_inputs + sensor.observable_effects
            ).difference(sensor.measured_dependencies)
            if undeclared_timing_inputs:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' has timing variables "
                    "outside its measured dependencies: "
                    f"{sorted(undeclared_timing_inputs)}"
                )
            if not sensor.diagnostic_variables and not sensor.measured_dependencies:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' requires at least one "
                    "declared evidence source"
                )
            declared_evidence = set(sensor.diagnostic_variables).union(
                sensor.measured_dependencies
            )
            if not sensor.physical_component or not sensor.physical_quantity:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' requires a physical "
                    "component and quantity"
                )
            if not sensor.fault_type:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' requires a fault type "
                    "or the explicit unknown marker '?'"
                )
            expected_root = format_root_cause(
                sensor.physical_component, sensor.fault_type
            )
            if sensor.root_cause and sensor.root_cause != expected_root:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' has inconsistent root "
                    f"cause {sensor.root_cause!r}; expected {expected_root!r}"
                )
            if not sensor.primary_cause_sensitive_variable:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' requires one primary "
                    "diagnostic variable"
                )
            if sensor.primary_cause_sensitive_variable not in declared_evidence:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' primary variable must "
                    "belong to its declared evidence"
                )
            if not sensor.component_variables:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' requires the supplied "
                    "component-variable assignment"
                )
            unknown_component_variables = set(sensor.component_variables).difference(
                all_state_names
            )
            if unknown_component_variables:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' assigns unknown component "
                    f"variables: {sorted(unknown_component_variables)}"
                )
            if sensor.primary_cause_sensitive_variable not in sensor.component_variables:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' must assign its primary "
                    "diagnostic variable to the fault-injection component"
                )
            if sensor.response_horizon_steps < 0:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' requires a non-negative "
                    "response horizon"
                )
            if sensor.uses_fault_labels_online:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' must not use fault labels online"
                )
            unknown_modes = set(sensor.fault_mode_evidence).difference(
                sensor.covered_fault_modes
            )
            if unknown_modes:
                raise ConfigError(
                    f"Virtual fault sensor '{sensor.name}' maps undeclared fault "
                    f"modes: {sorted(unknown_modes)}"
                )
            for fault_mode, evidence_names in sensor.fault_mode_evidence.items():
                unknown_evidence = set(evidence_names).difference(declared_evidence)
                if unknown_evidence:
                    raise ConfigError(
                        f"Virtual fault sensor '{sensor.name}' maps fault mode "
                        f"'{fault_mode}' to unknown evidence: "
                        f"{sorted(unknown_evidence)}"
                    )
                if not evidence_names:
                    raise ConfigError(
                        f"Virtual fault sensor '{sensor.name}' has no evidence for "
                        f"fault mode '{fault_mode}'"
                    )
        component_variable_owners: dict[str, set[str]] = {}
        for sensor in self.virtual_fault_sensors:
            for variable in sensor.component_variables:
                component_variable_owners.setdefault(variable, set()).add(
                    sensor.physical_component
                )
        ambiguous_component_variables = {
            variable: sorted(components)
            for variable, components in component_variable_owners.items()
            if len(components) != 1
        }
        if ambiguous_component_variables:
            raise ConfigError(
                "Every diagnosis variable must have exactly one supplied "
                "fault-injection component. Invalid ownership: "
                f"{ambiguous_component_variables}"
            )
        owners: dict[str, list[str]] = {}
        for module in self.modules:
            for signal in module.signals:
                owners.setdefault(signal, []).append(module.name)
        for variable in self.reconstructed_variables:
            owners.setdefault(variable.name, []).append(variable.module)
        required_ownership = list(feature_columns) + list(self.reconstructed_variable_names)
        required_ownership_set = set(required_ownership)
        missing = [feature for feature in required_ownership if not owners.get(feature)]
        if missing:
            raise ConfigError(
                "The system knowledge does not assign every measured and diagnostic variable "
                "to a module: "
                f"{missing}. Edit the knowledge file or enable a dataset-specific builder."
            )
        duplicate_owners = {
            feature: module_names
            for feature, module_names in owners.items()
            if feature in required_ownership_set and len(module_names) != 1
        }
        if duplicate_owners:
            raise ConfigError(
                "Every measured and diagnostic variable must have exactly one supplied "
                f"plant-module assignment. Invalid ownership: {duplicate_owners}"
            )


def _rule_predicates(rule: RuleSpec) -> list[str]:
    names: list[str] = []
    if rule.predicate:
        names.append(rule.predicate)
    names.extend(rule.predicates)
    if rule.antecedent:
        names.append(rule.antecedent)
    if rule.consequent:
        names.append(rule.consequent)
    return names


def load_knowledge_file(path: str | Path) -> SystemKnowledge:
    with Path(path).open("r", encoding="utf-8") as handle:
        payload = yaml.safe_load(handle) or {}
    return knowledge_from_dict(payload)


def knowledge_from_dict(payload: dict[str, Any]) -> SystemKnowledge:
    return SystemKnowledge(
        modules=[ModuleSpec(**item) for item in payload.get("modules", [])],
        connections=[ConnectionSpec(**item) for item in payload.get("connections", [])],
        predicates=[PredicateSpec(**item) for item in payload.get("predicates", [])],
        rules=[RuleSpec(**item) for item in payload.get("rules", [])],
        reconstructed_variables=[
            ReconstructedVariableSpec(**item) for item in payload.get("reconstructed_variables", [])
        ],
        virtual_fault_sensors=[
            VirtualFaultSensorSpec(**item)
            for item in payload.get("virtual_fault_sensors", [])
        ],
    )


def load_system_knowledge(config: dict[str, Any], feature_columns: list[str]) -> SystemKnowledge:
    from .dataset_knowledge import apply_dataset_builder

    project_root = config["_project_root"]
    knowledge_cfg = config.get("knowledge", {})
    file_value = knowledge_cfg.get("file")
    if file_value:
        knowledge = load_knowledge_file(expand_path(file_value, project_root))
    else:
        knowledge = SystemKnowledge([], [], [], [])
    knowledge = apply_dataset_builder(config, feature_columns, knowledge)
    knowledge.validate(feature_columns)
    return knowledge


def render_knowledge_text(knowledge: SystemKnowledge) -> str:
    lines: list[str] = []
    lines.append("SYSTEM KNOWLEDGE")
    lines.append("================")
    lines.append("")
    lines.append("Modules")
    lines.append("-------")
    for module in knowledge.modules:
        lines.append(f"* {module.name}")
        if module.description:
            lines.append(f"  description: {module.description}")
        lines.append(f"  inputs: {', '.join(module.inputs) or '-'}")
        lines.append(f"  outputs: {', '.join(module.outputs) or '-'}")
        lines.append(f"  states: {', '.join(module.states) or '-'}")
        lines.append(f"  external_inputs: {', '.join(module.external_inputs) or '-'}")
        lines.append(f"  max_latency_steps: {module.max_latency_steps}")
        lines.append(
            "  local_fault_detectability_certified: "
            f"{module.local_fault_detectability_certified}"
        )
        if module.latency_prior_steps is not None:
            lines.append(f"  latency_prior_steps: {module.latency_prior_steps}")
        lines.append("")
    lines.append("Connections")
    lines.append("-----------")
    if not knowledge.connections:
        lines.append("* none")
    for connection in knowledge.connections:
        lines.append(
            f"* {connection.source_module}.{connection.source_signal} -> "
            f"{connection.target_module}.{connection.target_signal} "
            f"(latency_steps=[{connection.min_latency_steps}, "
            f"{connection.max_latency_steps}], sign={connection.influence_sign}, "
            f"condition={connection.operating_condition}; {connection.relation}; "
            f"source={connection.provenance or '-'})"
        )
    lines.append("")
    lines.append("Diagnostic reconstructed variables")
    lines.append("-------------------------")
    if not knowledge.reconstructed_variables:
        lines.append("* none")
    for variable in knowledge.reconstructed_variables:
        bounds = f"[{variable.lower_bound}, {variable.upper_bound}]"
        lines.append(
            f"* {variable.name} [{variable.module}, kind={variable.kind}, source={variable.source}]"
        )
        lines.append(
            f"  function: {variable.function}({', '.join(variable.inputs)}) "
            f"lag={variable.lag_steps}; bounds={bounds}; bias={variable.bias}"
        )
        lines.append(f"  outputs: {', '.join(variable.outputs) or '-'}")
        if variable.output_relations:
            lines.append(
                "  output_relations: "
                + ", ".join(
                    f"{target}={relation}"
                    for target, relation in sorted(variable.output_relations.items())
                )
            )
        lines.append(
            f"  equation_class: {variable.equation_class}; unit={variable.unit or '-'}; "
            f"fault_preserving={variable.fault_preserving}; online_observable={variable.online_observable}"
        )
        if variable.valid_modes:
            lines.append(f"  valid_modes: {', '.join(variable.valid_modes)}")
        if variable.oracle_column:
            lines.append(f"  oracle_column: {variable.oracle_column}")
        if variable.provenance:
            lines.append(f"  provenance: {variable.provenance}")
        if variable.coefficients:
            lines.append(f"  coefficients: {variable.coefficients}")
        if variable.description:
            lines.append(f"  {variable.description}")
    lines.append("")
    lines.append("Virtual fault sensors")
    lines.append("---------------------")
    if not knowledge.virtual_fault_sensors:
        lines.append("* none")
    for sensor in knowledge.virtual_fault_sensors:
        lines.append(
            f"* {sensor.name} [{sensor.candidate_id}, owner={sensor.module}, "
            f"aggregation={sensor.aggregation}]"
        )
        lines.append(f"  physical_component: {sensor.physical_component}")
        lines.append(f"  fault_type: {sensor.fault_type}")
        lines.append(f"  physical_quantity: {sensor.physical_quantity}")
        lines.append(
            "  component_variables: "
            + (", ".join(sensor.component_variables) or "-")
        )
        lines.append(
            f"  primary_cause_sensitive_variable: {sensor.primary_cause_sensitive_variable}"
        )
        lines.append(f"  response_horizon_steps: {sensor.response_horizon_steps}")
        lines.append(
            f"  response_horizon_source: {sensor.response_horizon_source}"
        )
        lines.append(
            "  diagnostic_variables: "
            + (", ".join(sensor.diagnostic_variables) or "-")
        )
        lines.append(
            "  measured_dependencies: "
            + (", ".join(sensor.measured_dependencies) or "-")
        )
        lines.append(
            "  covered_fault_modes: "
            + (", ".join(sensor.covered_fault_modes) or "-")
        )
        for fault_mode, evidence_names in sorted(
            sensor.fault_mode_evidence.items()
        ):
            lines.append(
                f"  fault_mode_evidence.{fault_mode}: "
                + (", ".join(evidence_names) or "-")
            )
        lines.append(f"  online_input_policy: {sensor.online_input_policy}")
        lines.append(f"  detectability_claim: {sensor.detectability_claim}")
        lines.append(f"  engineering_source: {sensor.engineering_source}")
        if sensor.description:
            lines.append(f"  {sensor.description}")
    lines.append("")
    lines.append("Predicates in tau")
    lines.append("-----------------")
    for idx, predicate in enumerate(knowledge.predicates):
        if predicate.signal:
            subject = predicate.signal
        elif predicate.signals:
            subject = ",".join(predicate.signals)
        else:
            subject = f"{predicate.source}->{predicate.target}"
        lines.append(
            f"* tau[{idx}] {predicate.name}: {predicate.kind} "
            f"[group={predicate.group}] on {predicate.module}.{subject}"
        )
        if predicate.relation:
            lines.append(f"  relation: {predicate.relation}")
        if predicate.lag_steps:
            lines.append(f"  lag_steps: {predicate.lag_steps}")
        if predicate.description:
            lines.append(f"  {predicate.description}")
    lines.append("")
    lines.append("Goedel normal rules")
    lines.append("-------------------")
    for rule in knowledge.rules:
        if rule.type == "require":
            expr = str(rule.predicate)
        elif rule.type == "all":
            expr = " AND ".join(rule.predicates)
        elif rule.type == "any":
            expr = " OR ".join(rule.predicates)
        elif rule.type == "implication":
            expr = f"{rule.antecedent} => {rule.consequent}"
        elif rule.type == "implication_all":
            expr = f"({' AND '.join(rule.predicates)}) => {rule.consequent}"
        else:
            expr = f"{rule.type}: {_rule_predicates(rule)}"
        lines.append(f"* {rule.name} [{rule.module}, group={rule.group}, weight={rule.weight}]: {expr}")
    return "\n".join(lines) + "\n"


def module_signal_indices(knowledge: SystemKnowledge, feature_columns: list[str]) -> dict[str, list[int]]:
    signal_to_module = knowledge.signal_to_module()
    result = {module.name: [] for module in knowledge.modules}
    for idx, feature in enumerate(feature_columns):
        module_name = signal_to_module.get(feature)
        if module_name:
            result[module_name].append(idx)
    return result
