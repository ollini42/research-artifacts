# TRACE V15.3 Compact Data and Reproduction Specification

This package contains original concepts, generation settings, prompts and
small saved result tables. It is not the complete generated answer corpus.
Use the code ZIP's scripts/main.py levels command to replay all 200 cases.

## Scientific Scope

V15.3 tests whether black-box language-model answers contain regularities
associated with predefined concepts. It is not a competition to outperform
text classifiers and does not identify internal neural representations.
The reference labels are the original question-construction assignments.
Additional content checks and unmet automaton size targets remain diagnostic.
They do not remove cases or prevent exploratory level assignments.

There are 100 target concepts and two answer-model groups, hence 200 cases.
Each group uses three reconstructions. Means include all three runs.
Methods are selected using saved validation MCC values, not test performance.
MCC denotes the Matthews correlation coefficient. L1 requires MCC >= 0.20.
L2 additionally requires a combination gain >= 0.05 over a single state.
An ordered path also requires a gain >= 0.03 over its shuffled comparison.
L3 additionally requires a gain >= 0.02 over the selected text comparison.
These are exploratory descriptive thresholds, not simultaneous statistical
guarantees. The highest levels are L1: 59, L2: 140 and L3: 1.
The cumulative counts are L1: 200, L2: 141 and L3: 1.

## Reproduction Limits

The two ZIPs deliberately omit the generated question/answer corpus, learned
automata, model weights, databases, checkpoints and cluster operations.
They support exact replay of the published level assignments from saved
metrics, inspection of the scientific algorithms and small synthetic tests.
They are not a complete archive for rerunning the empirical evaluation.
Fitting the detectors again requires the omitted original answers, mappings,
automata and question manifest. New generation from a model and seed need
not reproduce the original bytes across hardware or library versions.

The original concept design is included. Its derived definitions are not
represented as the later automatically checked production catalog.
Prompt examples illustrate the deterministic renderer and are not sampled
LLM outputs. The full historic candidate schedules and rejected proposals
are excluded. No new LLM inference or scientific learning was run for export.

## Attribution, Licenses and Publication Status

Copyright 2026 Oliver Niggemann, for his contributions.
Affiliation: Helmut Schmidt University / University of the Federal Armed
Forces Hamburg, Germany. Professorship of Computer Science in Mechanical
Engineering. Contact: https://www.hsu-hh.de/imb/team

See NOTICE, LICENSE.md and LICENSES/. Each payload has a companion .license
file. MANIFEST.json records its SHA-256, byte count, license and notice path.
Scientific Python sources retain their original bytes. Original source
checksums and campaign bindings are recorded in provenance.json.

This is a locally prepared release candidate. Institutional and any additional
rightsholder authorization must be confirmed before public distribution.
No upload, public DOI or repository release is implied. Cite the associated
paper together with release trace-v15.3-minimal-20261103-r1 and archive hashes.
Do not invent a DOI for this local export.

The software and data come without warranties or guarantees.
Use is at your own risk. As far as applicable law allows,
Oliver Niggemann, the identified rightsholders, contributors,
and the identified institution exclude liability for loss
or damage connected with these materials. Legally mandatory
liabilities remain unaffected. The applicable license contains
the governing warranty and liability provisions.
