# Data Dictionary

concepts/original-design.yaml is the unchanged 100-target, four-control
construction specification. concepts/definitions.json contains its derived
definitions and intended contrast assignments, not production-check claims.

setup/experiment.json separates the original generator and reconstruction
parameters from the approved V15.3 evaluation objective. The original V15.2
strict assurance gates are not the V15.3 decision rule and are not exported
as an active configuration. Original hash references remain in provenance.json.

prompts/templates.json contains the generator and diagnostic system templates,
question conditions and response system prompt. prompts/examples.json contains
ten offline-rendered examples, six target forms and affirmative/negative forms
of each of the two absence controls. They are illustrations, not empirical data.
The renderer in the code ZIP also includes the bounded recovery profiles.

results/all-200-cases.json contains all concept/model cases. source_summary
retains stored scores per reconstruction, means, uncertainty and diagnostics.
validation_mcc supplies the values used for method selection. levels gives
nested Boolean membership. highest_level gives the highest attained level.
criteria and selected_roles are the saved decision details. The source JSON's
private file references are omitted, not scientific values or cases.
results/all-200-levels.csv and results/level-counts.json are unchanged originals.

An absent or undefined metric is not zero. floor_attained remains false where
the requested floor was not reached. Diagnostic disagreements remain recorded.
One case means one target concept evaluated within one answer-model group.
It does not mean an individual answer or a separate learned automaton.
