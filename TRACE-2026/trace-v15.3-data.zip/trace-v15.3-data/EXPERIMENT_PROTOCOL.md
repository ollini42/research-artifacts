# Experiment Protocol

Start from 100 defined European-food concepts and four auxiliary contrasts.
Construct six target-present forms and two target-absent conditions, with
affirmative and negative variants of both absent conditions. Negation does
not by itself change the intended presence label. Each source family has
ten forms. Discovery, development and test have 20, 20 and 168 families per
concept. Related variants stay within the same split.

Question generation uses the specified Llama 8B revision. Two Llama answer
models each use three seeds. M-06-r4 reconstructs an automaton from discovery
answers without labels. Existing mappings provide states and ordered paths.
V15.3 uses original question assignments, not automatically re-evaluated labels.
Six bounded detector roles compare single states, state sets, paths, shuffled
paths, answer token features and answer length. Detector fitting uses discovery
data and selection uses development data. Test data are held out.

Saved evaluation summaries report all three reconstructions. The separately
approved exploratory level rule uses their arithmetic means and validation-only
role selection. Original pointwise cluster-bootstrap intervals are retained as
diagnostics, not repurposed as a joint guarantee for the descriptive levels.

The CPU command in this release replays only saved level decisions. It does
not fit detectors or regenerate inputs. Full regeneration and full empirical
evaluation are separate, resource-intensive workflows needing excluded data.
