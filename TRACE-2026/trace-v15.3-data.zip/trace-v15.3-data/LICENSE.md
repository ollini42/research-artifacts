# Licenses

Software: AGPL-3.0-or-later. Original data, configuration and documentation: CC-BY-SA-4.0. Full texts are in LICENSES/. Third-party dependencies and excluded weights are not relicensed. See NOTICE for scope and publication status.
