# Source Guide

The scientific implementation is preserved without changes. Only the modules
reachable by Python imports from eight scientific entry points are included.
dependency-closure.json lists those entry points and the resulting modules.
Legacy validation functions remain where required by these imports. They do
not define the approved V15.3 objective or the exploratory level decision.

## Main Interfaces

- esm_lcd.presence_catalog.load_catalog_design reads the original concepts.
- esm_lcd.concept_presence_data defines question conditions and planning.
- esm_lcd.presence_generation_runtime.question_generation_request renders
  the original bounded question-generation messages without loading an LLM.
- esm_lcd.presence_model_adapter.OfflineCausalBackend is an explicit offline
  PyTorch/Transformers adapter. It requires separately licensed local weights.
- esm_lcd.presence_reconstruction.reconstruct_presence runs M-06-r4 on
  discovery answers. Reconstruction does not use concept labels.
- esm_lcd.presence_reconstruction.map_presence_responses maps answers to
  existing states, preserving unknown-token breaks.
- esm_lcd.construction_evaluation.original_labels binds examples to original
  construction assignments. fit, score and evaluate implement E-07-construction-r1.
- esm_lcd.exploratory_levels.evaluate_case and summarize implement
  E-07-exploratory-levels-r1 from validation and test metrics.

The code uses project-native schemas rather than a new scientific abstraction.
tests/test_presence_reconstruction.py contains a small manifest/response
fixture. tests/test_exploratory_levels.py documents the saved metric schema.
The portable scripts/main.py never downloads a model, submits a job or starts
training. No project-specific scheduler or one-time recovery script is shipped.

## Environment

Use Python 3.12. requirements.txt pins the small CPU test environment used for
this export, not an asserted reconstruction of every original HPC dependency.
The original V15.3 runtime observation reports Python 3.12.12 with NumPy and
PyYAML available, but does not record their exact versions. The optional LLM
adapter additionally imports PyTorch and Transformers. Their original exact
versions are not established by the included metadata. No GPU qualification
or LLM regeneration is claimed for this release. The two Llama revisions and
the diagnostic Qwen revision are fixed in the accompanying data package.
Those dependencies and weights retain their own licenses and access terms.
