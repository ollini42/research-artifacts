"""Small offline interface to the unchanged V15.3 scientific modules."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def verify(directory: Path) -> dict:
    """Check the finite payload manifest without executing package contents."""
    manifest = json.loads((directory / "MANIFEST.json").read_text())
    seen = set()
    for row in manifest["files"]:
        if row["path"] in seen:
            raise ValueError("Duplicate manifest path")
        seen.add(row["path"])
        path = directory / row["path"]
        if path.is_symlink() or not path.resolve().is_relative_to(directory.resolve()):
            raise ValueError("Unsafe manifest path")
        content = path.read_bytes()
        if len(content) != row["bytes"] or hashlib.sha256(content).hexdigest() != row["sha256"]:
            raise ValueError("Changed payload: " + row["path"])
        notice = directory / row["notice"]
        if notice.is_symlink() or not notice.resolve().is_relative_to(directory.resolve()):
            raise ValueError("Unsafe notice path")
        if hashlib.sha256(notice.read_bytes()).hexdigest() != row["notice_sha256"]:
            raise ValueError("Changed file notice")
    for name, digest in manifest["license_texts"].items():
        path = directory / name
        if path.is_symlink() or not path.resolve().is_relative_to(directory.resolve()):
            raise ValueError("Unsafe license path")
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError("Changed full license text")
    return {"verified_payload_files": len(manifest["files"])}


def levels(directory: Path) -> dict:
    """Replay saved validation selection and descriptive level assignments."""
    from esm_lcd.exploratory_levels import evaluate_case, summarize

    verify(directory)
    saved = json.loads((directory / "results/all-200-cases.json").read_text())
    results = []
    for row in saved["cases"]:
        actual = evaluate_case(row["source_summary"], row["validation_mcc"])
        for field in ("levels", "highest_level", "criteria", "selected_roles"):
            if actual[field] != row[field]:
                raise ValueError("Stored result mismatch: " + row["concept_id"] + ":" + field)
        results.append(actual)
    summary = summarize(results)
    expected = json.loads((directory / "results/level-counts.json").read_text())
    if summary != expected:
        raise ValueError("Stored level counts differ")
    if len(results) != 200:
        raise ValueError("Expected all 200 concept/model cases")
    return summary


def main() -> None:
    """Run local checks only. No model loading, training or network access."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("verify", "levels", "catalog"))
    parser.add_argument("--data", type=Path, help="Extracted trace-v15.3-data directory")
    args = parser.parse_args()
    if args.action == "verify":
        result = {"code": verify(ROOT)}
        if args.data:
            result["data"] = verify(args.data)
    elif args.action == "levels":
        if not args.data:
            parser.error("levels requires --data")
        result = levels(args.data)
    else:
        if not args.data:
            parser.error("catalog requires --data")
        from esm_lcd.presence_catalog import load_catalog_design
        catalog = load_catalog_design(args.data / "concepts/original-design.yaml")
        result = {"targets": len(catalog["target_concept_ids"]),
                  "definitions": len(catalog["catalog"]),
                  "scientific_checks_complete": catalog["scientific_checks_complete"]}
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))


if __name__ == "__main__":
    main()
