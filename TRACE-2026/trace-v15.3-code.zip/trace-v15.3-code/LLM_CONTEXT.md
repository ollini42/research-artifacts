# LLM Context

Use V15.3 original construction labels and the approved exploratory rule.
Do not make diagnostics into gates, change thresholds, select favorable runs,
or claim latent neural identity. The default CLI is offline and read-only.
Never load untrusted pickle or SQLite artifacts. See SOURCE_GUIDE.md.
