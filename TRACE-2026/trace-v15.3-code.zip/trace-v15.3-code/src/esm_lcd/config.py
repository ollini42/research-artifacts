"""Configuration loading for ESM-LCD experiments."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict

try:
    import yaml
except ModuleNotFoundError:  # pragma: no cover - exercised when PyYAML is absent.
    yaml = None

from .tokenization import TokenizationConfig


@dataclass(frozen=True)
class DatabaseConfig:
    path: str = "probing.db"
    question_run_id: str | None = None
    model_id: str | None = None
    device: str | None = None
    limit: int | None = None


@dataclass(frozen=True)
class ReconstructionConfig:
    method_version: str = "M-06"
    implementation_revision: str = "M-06-r4"
    backend: str = "pta_state_merger"
    suffix_length: int = 4
    max_suffixes_per_state: int = 32
    min_depth: int = 1
    profile_neighbor_window: int = 8
    priority_candidate_scope: str = "retrieved"
    priority_refresh_interval_merges: int = 10000
    priority_max_candidate_pairs: int = 10000000
    adaptive_neighbor_window_max: int = 2048
    adaptive_neighbor_growth_factor: float = 2.0
    best_first_neighbors_per_state: int = 4
    best_first_heuristic_orderings: int = 3
    best_first_mutual_neighbors: bool = False
    minimum_state_count: int | None = None
    merge_curve_interval_merges: int = 10000
    lambda_next: float = 0.60
    lambda_suffix: float = 0.25
    lambda_transition: float = 0.15
    hoeffding_compatibility_alpha: float = 0.18
    priority_retrieval_batch_pairs: int = 100000


@dataclass(frozen=True)
class EvaluationConfig:
    max_pairs: int = 50000
    semantic_beta: float = 0.75
    automaton_alpha: float = 0.75
    random_seed: int = 17
    random_baseline_repeats: int = 5
    random_path_baseline_repeats: int = 3
    shuffled_semantics_repeats: int = 3
    semantic_reference_mode: str = "keyword_topic"
    topic_relation_path: str | None = None
    topic_relation_weight: float = 0.50
    path_ignore_root_state: bool = True
    path_semantic_high_threshold: float = 0.75
    path_semantic_low_threshold: float = 0.25
    topic_state_coverage_threshold: float = 0.70
    topic_state_specificity_threshold: float = 0.30
    topic_state_near_all_threshold: float = 0.95
    max_topic_state_candidates_per_topic: int = 25


@dataclass(frozen=True)
class OutputConfig:
    dir: str = "outputs/esm_lcd"
    write_traces: bool = True
    write_state_paths: bool = True


@dataclass(frozen=True)
class ExperimentConfig:
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    tokenization: TokenizationConfig = field(default_factory=TokenizationConfig)
    reconstruction: ReconstructionConfig = field(default_factory=ReconstructionConfig)
    evaluation: EvaluationConfig = field(default_factory=EvaluationConfig)
    output: OutputConfig = field(default_factory=OutputConfig)


def read_config_mapping(path: str | Path) -> Dict[str, Any]:
    config_path = Path(path)
    text = config_path.read_text(encoding="utf-8")
    if config_path.suffix.lower() == ".json":
        return json.loads(text)
    if yaml is None:
        raise RuntimeError(
            "PyYAML is required to read YAML configs. Install pyyaml or use JSON."
        )
    loaded = yaml.safe_load(text)
    if loaded is None:
        return {}
    if not isinstance(loaded, dict):
        raise ValueError("Config file must contain a mapping at the top level.")
    return loaded


def _dataclass_from_dict(cls, raw: Dict[str, Any]):
    valid_keys = {field_name for field_name in cls.__dataclass_fields__}
    if cls is ReconstructionConfig and (unknown := set(raw) - valid_keys):
        raise ValueError(
            "Unsupported M-06 reconstruction fields: {}. Historical merge policies "
            "require their archived source and must not be silently migrated."
            .format(", ".join(sorted(unknown)))
        )
    filtered = {key: value for key, value in raw.items() if key in valid_keys}
    return cls(**filtered)


def load_experiment_config(path: str | Path) -> ExperimentConfig:
    raw = read_config_mapping(path)
    return ExperimentConfig(
        database=_dataclass_from_dict(DatabaseConfig, raw.get("database", {})),
        tokenization=_dataclass_from_dict(TokenizationConfig, raw.get("tokenization", {})),
        reconstruction=_dataclass_from_dict(
            ReconstructionConfig, raw.get("reconstruction", {})
        ),
        evaluation=_dataclass_from_dict(EvaluationConfig, raw.get("evaluation", {})),
        output=_dataclass_from_dict(OutputConfig, raw.get("output", {})),
    )
