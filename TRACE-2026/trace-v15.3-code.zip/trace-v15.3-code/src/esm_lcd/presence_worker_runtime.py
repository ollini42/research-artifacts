"""Small process guards shared by offline presence workers."""

from pathlib import Path
import os
import signal


def install_stop_handler():
    """Announce readiness only after Python can safely receive the warning."""
    requested = False

    def stop(signum, frame):
        nonlocal requested
        requested = True

    signal.signal(signal.SIGUSR1, stop)
    ready = os.environ.get("PRESENCE_WORKER_READY_FILE")
    if ready:
        Path(ready).touch(exist_ok=False)
    return lambda: requested


def validate_worker_paths(*, journal, report=None, inputs=(), source_root=None):
    """Reject output aliases before a model load or journal creation."""
    journal = Path(journal)
    outputs = [journal.resolve(), journal.with_name('.' + journal.name + '.checkpoint.lock').resolve()]
    outputs.extend(Path(str(journal) + suffix).resolve() for suffix in ('-journal', '-wal', '-shm'))
    if report is not None:
        report = Path(report)
        outputs.extend((report.resolve(), report.with_suffix(report.suffix + '.tmp').resolve()))
    protected = [Path(path).resolve() for path in inputs]
    all_paths = outputs + protected
    for i, output in enumerate(outputs):
        for other in all_paths[i + 1:]:
            if output == other or (output.exists() and other.exists() and output.samefile(other)):
                raise ValueError("Worker outputs must not overwrite journals or inputs.")
        if source_root is not None:
            root = Path(source_root).resolve()
            if output.parent == root or any(output.is_relative_to(root / name) for name in ('esm_lcd', 'scripts', 'tests', 'configs')):
                raise ValueError("Worker outputs must not overwrite source files.")
