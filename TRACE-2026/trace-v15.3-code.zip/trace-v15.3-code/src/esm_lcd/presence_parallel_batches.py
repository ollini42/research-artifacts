"""Durable transport for unchanged fixed form-check batches.

Public API
----------
``parallel_batches(queue_root, authorization)`` installs a ContextVar executor.
``maybe_parallel_batches(...)`` returns the fixed-batch report or None outside
that context and outside ``form-checks``. Only its coordinator uses the journal.
``consume_one(...)`` returns a completed envelope, or None when stopped or no
claim is available. Backend and validation errors are saved and raised.

Authorization is a JSON dictionary sealed with ``authorization_sha256``, using
the project's ``_json_sha256`` over every other field. ``checker_binding`` must
contain campaign_id, source_sha256 (the original scientific source),
config_sha256, model_id, model_revision, model_manifest_sha256, condition_id,
condition_sha256, the exact condition and stage="form-checks". It also requires
schema_version=1, scope="parallel_question_checks", execution_authorized=True,
runtime_source_sha256 and queue_root. Extra document fields remain sealed.
Extra binding constraints are checked exactly. Optional max_inflight (32) and
poll_interval_seconds (1.0, minimum 0.1)
are transport settings, never scientific settings. External launch code is
responsible for authenticating this authorization and the executing source.

Use a dedicated shared POSIX filesystem with cross-process flock and atomic
rename support. There is one envelope per batch, one full schedule per binding,
one authorization and one coordinator lock. Pending envelopes are atomically
replaced with results and then archived after journal commit. Neither workers
nor this transport migrate journal bindings. Hash seals detect corruption, not
an adversary able to replace the authorization and every sealed artifact.
"""

from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from dataclasses import dataclass
from collections import OrderedDict
import errno
import fcntl
import json
import logging
import math
import os
from pathlib import Path
import stat
import time
import traceback
import uuid

from .concept_presence_data import _json_sha256
from .presence_model_adapter import parse_model_json


_EXECUTOR = ContextVar("presence_parallel_batches", default=None)
_REVISION = "presence-parallel-batches-1"
_MANIFEST_CACHE = OrderedDict()
_ARCHIVE_BUSY_DELAYS = (0.1, 0.2, 0.4, 0.8, 1.6)
_LOGGER = logging.getLogger(__name__)
_REQUIRED = (
    "campaign_id", "source_sha256", "config_sha256", "model_id",
    "model_revision", "model_manifest_sha256", "condition_id",
    "condition_sha256", "stage",
)


class ParallelBatchError(RuntimeError):
    """A durable worker error. Resumption never silently retries this batch."""


def _sealed(value, field):
    return {**value, field: _json_sha256(value)}


def _verify(value, field):
    if not isinstance(value, dict) or value.get(field) != _json_sha256(
            {key: item for key, item in value.items() if key != field}):
        raise ValueError("Invalid " + field + " seal.")


def _authorization(value):
    # Reject non-JSON values and nonfinite numbers before hashing or copying.
    value = parse_model_json(json.dumps(value, allow_nan=False))
    _verify(value, "authorization_sha256")
    if (type(value.get("schema_version")) is not int or value["schema_version"] != 1
            or value.get("scope") != "parallel_question_checks"
            or value.get("execution_authorized") is not True):
        raise ValueError("Invalid parallel authorization schema, scope or execution permission.")
    runtime = value.get("runtime_source_sha256")
    if (not isinstance(runtime, str) or len(runtime) != 64
            or any(char not in "0123456789abcdef" for char in runtime)):
        raise ValueError("Authorization requires runtime_source_sha256.")
    allowed = value.get("checker_binding")
    if not isinstance(allowed, dict) or any(
            not isinstance(allowed.get(key), str) or not allowed[key].strip()
            for key in _REQUIRED):
        raise ValueError("Authorization requires the complete checker_binding.")
    if allowed["stage"] != "form-checks":
        raise ValueError("Only form-checks may use parallel batches.")
    if (not isinstance(allowed.get("condition"), dict)
            or _json_sha256(allowed["condition"]) != allowed["condition_sha256"]):
        raise ValueError("Authorization must seal the exact checker condition.")
    root = value.get("queue_root")
    if not isinstance(root, str) or not Path(root).is_absolute() or ".." in Path(root).parts:
        raise ValueError("Authorization requires an absolute queue_root without traversal.")
    limit = value.get("max_inflight", 32)
    poll = value.get("poll_interval_seconds", 1.0)
    if type(limit) is not int or limit < 1:
        raise ValueError("max_inflight must be a positive integer.")
    if type(poll) not in (int, float) or not math.isfinite(poll) or poll < 0.1:
        raise ValueError("poll_interval_seconds must be finite and at least 0.1.")
    return value


def _binding(binding, authorization):
    if not isinstance(binding, dict) or any(
            binding.get(key) != value
            for key, value in authorization["checker_binding"].items()):
        raise ValueError("Batch binding differs from the authorized scientific binding.")
    for key in ("shard_id", "request_schedule_sha256"):
        if not isinstance(binding.get(key), str) or not binding[key]:
            raise ValueError("Batch binding is missing " + key)
    condition = binding.get("condition")
    if not isinstance(condition, dict) or _json_sha256(condition) != binding["condition_sha256"]:
        raise ValueError("Checker condition differs from its authorized hash.")


@dataclass(frozen=True)
class _Executor:
    root: Path
    authorization: dict


@contextmanager
def parallel_batches(queue_root, authorization: dict):
    """Install this transport in the current context and restore on every exit."""
    executor = _Executor(Path(queue_root).absolute(), _authorization(authorization))
    _queue_root(executor.root, executor.authorization)
    token = _EXECUTOR.set(executor)
    try:
        yield executor
    finally:
        _EXECUTOR.reset(token)


def _regular(fd):
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_nlink > 1:
        raise ValueError("Queue entries must be regular files, without links.")


def _directory(path, create):
    """Walk with directory descriptors so even replaced parents cannot redirect IO."""
    path = Path(path).absolute()
    if ".." in path.parts:
        raise ValueError("Queue paths cannot contain traversal.")
    read_flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    walk_flags = getattr(os, "O_PATH", os.O_RDONLY) | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open(path.anchor, walk_flags if len(path.parts) > 1 else read_flags)
    try:
        for index, part in enumerate(path.parts[1:], start=1):
            if create:
                try:
                    os.mkdir(part, mode=0o700, dir_fd=fd)
                    # Linux O_PATH permits traversal of execute-only ancestors,
                    # but a newly changed parent needs a readable fd for fsync.
                    sync_fd = os.open(".", read_flags, dir_fd=fd)
                    try:
                        os.fsync(sync_fd)
                    finally:
                        os.close(sync_fd)
                except FileExistsError:
                    pass
            flags = read_flags if index == len(path.parts) - 1 else walk_flags
            child = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = child
        return fd
    except BaseException:
        os.close(fd)
        raise


def _read(fd, name):
    handle = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=fd)
    with os.fdopen(handle, "r", encoding="utf-8") as stream:
        _regular(stream.fileno())
        return parse_model_json(stream.read())


def _exists(fd, name):
    try:
        info = os.stat(name, dir_fd=fd, follow_symlinks=False)
    except FileNotFoundError:
        return False
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise ValueError("Queue entry is a symbolic link or not a regular file: " + name)
    return True


def _write(fd, name, value, *, replace=False):
    if _exists(fd, name) and not replace:
        if _read(fd, name) != value:
            raise ValueError("An immutable queue entry changed: " + name)
        return
    temporary = "." + name + "." + uuid.uuid4().hex + ".tmp"
    handle = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=fd)
    try:
        with os.fdopen(handle, "w", encoding="utf-8") as stream:
            json.dump(value, stream, sort_keys=True, ensure_ascii=False, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        # Initial publication belongs to the sole coordinator. Replacement
        # belongs to the process holding the batch's flock.
        _exists(fd, name)
        os.replace(temporary, name, src_dir_fd=fd, dst_dir_fd=fd)
        os.fsync(fd)
    finally:
        try:
            os.unlink(temporary, dir_fd=fd)
        except FileNotFoundError:
            pass


@contextmanager
def _claim(fd, name, *, create=False):
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
    if create:
        flags |= os.O_CREAT
    try:
        handle = os.open(name, flags, 0o600, dir_fd=fd)
    except FileNotFoundError:
        yield None
        return
    try:
        _regular(handle)
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            if exc.errno not in (errno.EACCES, errno.EAGAIN):
                raise
            yield None
            return
        # Atomic replacement changes the inode. A waiter holding the old inode
        # must never compute a second copy after the winner publishes its result.
        try:
            current = os.stat(name, dir_fd=fd, follow_symlinks=False)
        except FileNotFoundError:
            yield None
            return
        original = os.fstat(handle)
        if (current.st_dev, current.st_ino) != (original.st_dev, original.st_ino):
            yield None
            return
        yield handle
    finally:
        os.close(handle)


def _queue_root(root, authorization):
    if str(Path(root).absolute()) != authorization["queue_root"]:
        raise ValueError("Queue root differs from its authorization.")


class _Queue:
    def __init__(self, root, authorization, *, create):
        self.root = root
        self.authorization = authorization
        self.fds = {}
        try:
            _queue_root(root, authorization)
            self.fds["root"] = _directory(root, create)
            if not create:
                self.authorize(create=False)
            for name in ("schedules", "pending", "completed"):
                if create:
                    try:
                        os.mkdir(name, mode=0o700, dir_fd=self.fds["root"])
                        os.fsync(self.fds["root"])
                    except FileExistsError:
                        pass
                self.fds[name] = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                                         dir_fd=self.fds["root"])
        except BaseException:
            self.close()
            raise

    def close(self):
        for fd in self.fds.values():
            os.close(fd)
        self.fds.clear()

    def authorize(self, *, create):
        if create:
            _write(self.fds["root"], "authorization.json", self.authorization)
        if _read(self.fds["root"], "authorization.json") != self.authorization:
            raise ValueError("Queue authorization differs from the supplied authorization.")

    def names(self):
        return sorted(name for name in os.listdir(self.fds["pending"]) if not name.startswith("."))

    def envelope(self, task):
        name = task["batch_id"] + ".json"
        locations = [area for area in ("pending", "completed") if _exists(self.fds[area], name)]
        if len(locations) > 1:
            raise ValueError("Batch exists in both pending and completed queues.")
        if not locations:
            return None
        value = _read(self.fds[locations[0]], name)
        _envelope(value, task)
        return value

    def archive(self, task):
        name = task["batch_id"] + ".json"
        expected = self.envelope(task)
        if expected is None or expected["status"] != "complete":
            raise ValueError("Only a complete, preserved batch may be archived.")
        # The journal is already committed. Retry only transient rename refusal,
        # without recomputing results or accepting changed queue evidence.
        for attempt in range(len(_ARCHIVE_BUSY_DELAYS) + 1):
            if self.envelope(task) != expected:
                raise ValueError("Batch evidence changed during archival.")
            if not _exists(self.fds["pending"], name):
                break
            try:
                os.rename(name, name, src_dir_fd=self.fds["pending"],
                          dst_dir_fd=self.fds["completed"])
                break
            except OSError as exc:
                if exc.errno != errno.EBUSY or attempt == len(_ARCHIVE_BUSY_DELAYS):
                    raise
                delay = _ARCHIVE_BUSY_DELAYS[attempt]
                _LOGGER.warning("Archive busy for batch %s, retry %d/%d in %.1fs",
                                task["batch_id"], attempt + 1,
                                len(_ARCHIVE_BUSY_DELAYS), delay)
                time.sleep(delay)
        os.fsync(self.fds["completed"])
        os.fsync(self.fds["pending"])


def _schedule(requests, binding, batch_size, base_seed, authorization):
    if type(batch_size) is not int or batch_size < 1 or type(base_seed) is not int or base_seed < 0:
        raise ValueError("Batch size and seed must be valid integers.")
    ids = [row.get("request_id") for row in requests]
    if any(not isinstance(key, str) or not key for key in ids) or len(ids) != len(set(ids)):
        raise ValueError("Model request identities must be unique and nonempty.")
    ordered = sorted(deepcopy(requests), key=lambda row: row["request_id"])
    schedule = {"requests": ordered, "batch_size": batch_size, "base_seed": base_seed}
    _binding(binding, authorization)
    if _json_sha256(schedule) != binding["request_schedule_sha256"]:
        raise ValueError("Journal must bind the full fixed request schedule.")
    if binding["condition"].get("batch_size") != batch_size or binding["condition"].get("seed") != base_seed:
        raise ValueError("Batch size or seed differs from the authorized condition.")
    return _sealed({"revision": _REVISION, "binding": deepcopy(binding), "schedule": schedule,
                    "authorization_sha256": authorization["authorization_sha256"]}, "manifest_sha256")


def _task(manifest, offset):
    schedule, binding = manifest["schedule"], manifest["binding"]
    rows = schedule["requests"][offset:offset + schedule["batch_size"]]
    seed = int(_json_sha256([schedule["base_seed"], [row["request_id"] for row in rows]])[:8], 16)
    batch_id = _json_sha256({"binding": _json_sha256(binding), "requests": rows, "seed": seed})
    return {"revision": _REVISION, "binding": binding, "requests": rows, "seed": seed,
            "offset": offset, "batch_id": batch_id, "batch_size": schedule["batch_size"],
            "base_seed": schedule["base_seed"], "schedule_sha256": binding["request_schedule_sha256"],
            "manifest_sha256": manifest["manifest_sha256"],
            "authorization_sha256": manifest["authorization_sha256"]}


def _pack(task, status, *, result=None, error=None, worker_id=None):
    return _sealed({"task": task, "task_sha256": _json_sha256(task), "status": status,
                    "result": result, "error": error, "worker_id": worker_id}, "envelope_sha256")


def _envelope(value, expected=None):
    _verify(value, "envelope_sha256")
    if value.get("task_sha256") != _json_sha256(value.get("task")):
        raise ValueError("Invalid task_sha256 seal.")
    if expected is not None and value["task"] != expected:
        raise ValueError("Queue task differs from the fixed batch, seed or binding.")
    if value.get("status") == "error":
        raise ParallelBatchError("Worker " + str(value.get("worker_id")) + ": " + str(value.get("error")))
    if value.get("status") not in ("pending", "complete") or value.get("error") is not None:
        raise ValueError("Invalid queue envelope status.")
    if value["status"] == "pending" and value.get("result") is not None:
        raise ValueError("A pending batch cannot have a result.")


def _validated_task(queue, value, name):
    _envelope(value)
    task = value["task"]
    binding = task["binding"]
    _binding(binding, queue.authorization)
    manifest = _worker_manifest(queue, binding)
    schedule = manifest["schedule"]
    offset = task["offset"]
    if (type(offset) is not int or offset < 0 or offset >= len(schedule["requests"])
            or offset % schedule["batch_size"]):
        raise ValueError("Invalid fixed batch offset.")
    expected = _task(manifest, offset)
    if task != expected or name != expected["batch_id"] + ".json":
        raise ValueError("Task differs from the fixed requests, seed, hash or binding.")
    return task


def _worker_manifest(queue, binding):
    name = _json_sha256(binding) + ".json"
    handle = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=queue.fds["schedules"])
    with os.fdopen(handle, "r", encoding="utf-8") as stream:
        _regular(stream.fileno())
        info = os.fstat(stream.fileno())
        key = (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns,
               name, queue.authorization["authorization_sha256"])
        if key in _MANIFEST_CACHE:
            _MANIFEST_CACHE.move_to_end(key)
            return _MANIFEST_CACHE[key]
        manifest = parse_model_json(stream.read())
    _verify(manifest, "manifest_sha256")
    schedule = manifest["schedule"]
    expected = _schedule(schedule["requests"], binding, schedule["batch_size"],
                         schedule["base_seed"], queue.authorization)
    if manifest != expected:
        raise ValueError("Schedule manifest differs from its authorized binding.")
    _MANIFEST_CACHE[key] = manifest
    while len(_MANIFEST_CACHE) > 2:
        _MANIFEST_CACHE.popitem(last=False)
    return manifest


def _result(rows, result):
    # Workers have no journal. The coordinator still applies journal.batch's
    # authoritative validation before committing any returned completion.
    if not isinstance(result, list) or len(result) != len(rows):
        raise ValueError("Backend must return exactly one completion per request.")
    for request, completion in zip(rows, result):
        if (not isinstance(completion, dict) or completion.get("request_id") != request["request_id"]
                or not isinstance(completion.get("text"), str)
                or completion.get("finish_reason") not in ("stop", "length")
                or type(completion.get("input_tokens")) is not int or completion["input_tokens"] < 1
                or type(completion.get("output_tokens")) is not int or completion["output_tokens"] < 0):
            raise ValueError("Malformed or reordered model completion.")


def _consume(queue, names, backend_factory, worker_id, stop_requested):
    for name in names:
        if stop_requested():
            return None
        with _claim(queue.fds["pending"], name) as handle:
            if handle is None:
                continue
            value = None
            try:
                # The coordinator may archive completed envelopes after the
                # claim. Read the claimed inode, not a pathname that can move.
                with os.fdopen(os.dup(handle), "r", encoding="utf-8") as stream:
                    value = parse_model_json(stream.read())
                task = _validated_task(queue, value, name)
                if value["status"] == "complete":
                    continue
                if stop_requested():
                    return None
                backend = backend_factory(deepcopy(task["binding"]))
                if stop_requested():
                    return None
                result = backend(deepcopy(task["requests"]), seed=task["seed"])
                _result(task["requests"], result)
                output = _pack(task, "complete", result=result, worker_id=worker_id)
                _write(queue.fds["pending"], name, output, replace=True)
                return output
            except ParallelBatchError:
                raise
            except Exception as exc:
                task = value.get("task") if isinstance(value, dict) else None
                error = {"type": type(exc).__name__, "message": str(exc),
                         "traceback": traceback.format_exc()}
                _write(queue.fds["pending"], name,
                       _pack(task, "error", error=error, worker_id=worker_id), replace=True)
                raise
    return None


def consume_one(queue_root, authorization: dict, backend_factory, worker_id,
                stop_requested=lambda: False):
    """Claim at most one batch, holding flock throughout model computation.

    ``backend_factory(binding)`` supplies the worker's cached model backend.
    A stop after computation still publishes the completed work. Process death
    releases the claim without a lease timeout. Incomplete work can be retried.
    This function never opens SQLite and never sleeps or launches a process.
    """
    authorization = _authorization(authorization)
    _queue_root(queue_root, authorization)
    if not isinstance(worker_id, str) or not worker_id.strip():
        raise ValueError("worker_id must be a nonempty string.")
    if stop_requested():
        return None
    try:
        queue = _Queue(Path(queue_root).absolute(), authorization, create=False)
    except FileNotFoundError:
        return None
    try:
        return _consume(queue, queue.names(), backend_factory, worker_id, stop_requested)
    finally:
        queue.close()


class _CacheMiss(Exception):
    pass


def _cache_only(requests, *, seed):
    raise _CacheMiss


def maybe_parallel_batches(requests, journal, backend, batch_size, base_seed,
                           stop_requested=lambda: False):
    """Run fixed batches with bounded helper work and a local GPU fallback.

    Pass ``backend=None`` only for a coordinator deliberately without a GPU.
    Reports have exactly run_fixed_batches' keys. Partial completions include
    every committed batch in canonical request order, even across missing gaps.
    There is no walltime deadline. Stop requests are observed between batches
    and within at most 0.1 seconds of an idle wait.
    """
    executor = _EXECUTOR.get()
    if executor is None or journal.binding.get("stage") != "form-checks":
        return None
    authorization = executor.authorization
    manifest = _schedule(requests, journal.binding, batch_size, base_seed, authorization)
    existing = journal.connection.execute("SELECT value FROM binding WHERE id=1").fetchone()
    if (existing is None or parse_model_json(existing[0]) != journal.binding
            or journal.binding_sha256 != _json_sha256(journal.binding)):
        raise ValueError("Journal binding changed after opening.")
    schedule = manifest["schedule"]
    tasks = [_task(manifest, offset) for offset in range(0, len(schedule["requests"]), batch_size)]
    completed = {}

    def report():
        rows = [row for offset in sorted(completed) for row in completed[offset]]
        return {"complete": len(completed) == len(tasks), "completed_records": len(rows),
                "schedule_sha256": journal.binding["request_schedule_sha256"], "completions": rows}

    if stop_requested():
        return report()
    queue = _Queue(executor.root, authorization, create=True)
    try:
        with _claim(queue.fds["root"], "coordinator.lock", create=True) as owner:
            if owner is None:
                raise RuntimeError("This queue already has a coordinator.")
            queue.authorize(create=True)
            _write(queue.fds["schedules"], _json_sha256(journal.binding) + ".json", manifest)
            for task in tasks:
                if stop_requested():
                    break
                try:
                    completed[task["offset"]] = journal.batch(task["requests"], _cache_only, seed=task["seed"])
                except _CacheMiss:
                    pass
                saved = queue.envelope(task)
                if saved is not None and saved["status"] == "complete":
                    if task["offset"] in completed:
                        if saved["result"] != completed[task["offset"]]:
                            raise ValueError("Queue result differs from the committed journal batch.")
                    else:
                        completed[task["offset"]] = journal.batch(
                            task["requests"], lambda rows, seed: deepcopy(saved["result"]), seed=task["seed"])
                    queue.archive(task)
                elif saved is not None and task["offset"] in completed:
                    raise ValueError("A committed batch still has an unfinished queue task.")

            active = {}
            next_task = 0
            limit = authorization.get("max_inflight", 32)
            while len(completed) < len(tasks):
                stopping = stop_requested()
                # Harvest all ready results before another local model call.
                for offset, task in list(active.items()):
                    saved = queue.envelope(task)
                    if saved is None:
                        raise ValueError("An in-flight queue task disappeared.")
                    if saved["status"] == "complete":
                        completed[offset] = journal.batch(task["requests"],
                            lambda rows, seed: deepcopy(saved["result"]), seed=task["seed"])
                        queue.archive(task)
                        del active[offset]
                if stopping:
                    return report()
                while len(active) < limit and next_task < len(tasks):
                    task = tasks[next_task]
                    next_task += 1
                    if task["offset"] in completed:
                        continue
                    saved = queue.envelope(task)
                    if saved is None:
                        if len(queue.names()) >= limit:
                            raise ValueError("Queue contains unrelated or excess in-flight work. Resume its original schedule.")
                        _write(queue.fds["pending"], task["batch_id"] + ".json", _pack(task, "pending"))
                    active[task["offset"]] = task
                    if stop_requested():
                        break
                if stop_requested():
                    continue
                if backend is not None and active:
                    output = _consume(queue, [task["batch_id"] + ".json" for task in active.values()],
                                      lambda binding: backend, "coordinator-" + str(os.getpid()), stop_requested)
                    if output is not None:
                        continue
                if active:
                    deadline = time.monotonic() + authorization.get("poll_interval_seconds", 1.0)
                    while not stop_requested() and time.monotonic() < deadline:
                        time.sleep(min(0.1, max(0, deadline - time.monotonic())))
            return report()
    finally:
        queue.close()
