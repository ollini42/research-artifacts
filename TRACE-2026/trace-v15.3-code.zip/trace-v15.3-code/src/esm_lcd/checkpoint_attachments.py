"""Stream candidate databases inside a single atomic checkpoint generation."""

import json
import pickle
import struct

from .candidate_storage import DiskCandidateStore, MAX_DATABASE_BYTES


MAGIC = b"ESMCKP02"
_LENGTH = struct.Struct(">Q")
_MAX_INDEX_BYTES = 65536
_MAX_STORES = 8
_TAG = "esm-candidate-store-v1"


class AttachedPickler(pickle.Pickler):
    def __init__(self, handle):
        super().__init__(handle, protocol=pickle.HIGHEST_PROTOCOL)
        self.stores = []
        self.store_ids = {}

    def persistent_id(self, value):
        if isinstance(value, DiskCandidateStore):
            key = id(value)
            if key not in self.store_ids:
                if len(self.stores) >= _MAX_STORES:
                    raise ValueError("Too many candidate stores in one checkpoint.")
                self.store_ids[key] = len(self.stores)
                self.stores.append(value)
            return (_TAG, self.store_ids[key])
        return None

    def finish(self, handle):
        pickle_end = handle.tell()
        entries = []
        for store in self.stores:
            offset = handle.tell()
            size = store.write_snapshot(handle)
            if handle.tell() != offset + size:
                raise ValueError("Candidate snapshot size changed during publication.")
            entries.append({"offset": offset, "size": size, "max_bytes": store.max_bytes})
        raw = json.dumps(
            {"pickle_end": pickle_end, "stores": entries}, sort_keys=True,
        ).encode("ascii")
        if len(raw) > _MAX_INDEX_BYTES:
            raise ValueError("Checkpoint attachment index exceeds its limit.")
        handle.write(raw)
        handle.write(_LENGTH.pack(len(raw)))


def read_attached(handle, size, *, scope=None):
    """Restore only from the already verified, still-open checkpoint descriptor."""
    if size < _LENGTH.size:
        raise ValueError("Missing checkpoint attachment index.")
    handle.seek(size - _LENGTH.size)
    index_size = _LENGTH.unpack(handle.read(_LENGTH.size))[0]
    if not 0 < index_size <= min(_MAX_INDEX_BYTES, size - _LENGTH.size):
        raise ValueError("Invalid checkpoint attachment index size.")
    index_start = size - _LENGTH.size - index_size
    handle.seek(index_start)
    index = json.loads(handle.read(index_size))
    if set(index) != {"pickle_end", "stores"}:
        raise ValueError("Invalid checkpoint attachment index fields.")
    pickle_end = index["pickle_end"]
    entries = index["stores"]
    if (type(pickle_end) is not int or not 0 < pickle_end < index_start
            or not isinstance(entries, list) or not 0 < len(entries) <= _MAX_STORES):
        raise ValueError("Invalid checkpoint attachment index.")
    end = pickle_end
    for entry in entries:
        if set(entry) != {"offset", "size", "max_bytes"}:
            raise ValueError("Invalid candidate attachment fields.")
        offset, length, limit = (entry[key] for key in ("offset", "size", "max_bytes"))
        if (any(type(value) is not int for value in (offset, length, limit))
                or offset != end or not 0 < length <= limit <= MAX_DATABASE_BYTES):
            raise ValueError("Invalid candidate attachment bounds.")
        end += length
    if end != index_start:
        raise ValueError("Candidate attachment layout has gaps or overlaps.")

    loaded = {}

    class AttachedUnpickler(pickle.Unpickler):
        def persistent_load(self, identifier):
            if (not isinstance(identifier, tuple) or len(identifier) != 2
                    or identifier[0] != _TAG or type(identifier[1]) is not int
                    or not 0 <= identifier[1] < len(entries)):
                raise ValueError("Unknown checkpoint attachment identity.")
            number = identifier[1]
            if number not in loaded:
                entry = entries[number]
                position = handle.tell()
                try:
                    handle.seek(entry["offset"])
                    loaded[number] = DiskCandidateStore.read_snapshot(
                        handle, entry["size"], entry["max_bytes"], scope=scope,
                    )
                finally:
                    handle.seek(position)
            return loaded[number]

    try:
        handle.seek(0)
        value = AttachedUnpickler(handle).load()
        if handle.tell() != pickle_end or len(loaded) != len(entries):
            raise ValueError("Checkpoint pickle or attachment inventory mismatch.")
        return value
    except BaseException:
        for store in loaded.values():
            store.close()
        raise
