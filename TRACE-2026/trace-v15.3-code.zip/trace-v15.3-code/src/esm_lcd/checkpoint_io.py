"""Atomic checkpoint I/O for trusted pickles on POSIX filesystems.

Format 1 is an unchanged pickle followed by a 48-byte footer: big-endian
uint64 payload length, 32 raw SHA-256 bytes, and the eight bytes ESMCKP01.
Ordinary pickle.load still reads the original object. Payload schemas do not
change. Legacy raw pickles require their existing raw hexadecimal .sha256.
New writes do not create sidecars and leave existing legacy sidecars untouched.
The footer alone is authoritative for new files.

Format 2 adds streamed candidate database attachments and a bounded index
inside the same hashed payload. It requires load_verified_pickle. Files
without attached stores retain the original format and raw pickle support.

One fixed staging file and one persistent per-checkpoint flock file bound disk
usage after repeated crashes. The old file survives until one atomic replace
publishes the complete new generation. There is no historical-file fallback.
File fsync precedes replacement and directory fsync follows it. Power-loss
durability requires an already durable parent directory and filesystem support
for atomic replacement and fsync. A failure after replacement leaves the new
complete file visible, with durability uncertain until directory fsync succeeds.

Hashing uses bounded buffers. Loading verifies before deserialization on the
same descriptor, so concurrent atomic replacement cannot substitute the bytes.
All writers must use this API and must not edit published files in place.
The directory and pickle producers must be trusted. SHA-256 is not a signature
and does not make untrusted pickle execution safe.
"""

from __future__ import annotations

from contextlib import contextmanager, suppress
import fcntl
import hashlib
import hmac
import os
from pathlib import Path
import pickle
import struct

from .checkpoint_attachments import AttachedPickler, MAGIC as _ATTACHED_MAGIC, read_attached


_MAGIC = b"ESMCKP01"
_FOOTER = struct.Struct(">Q32s8s")
_CHUNK_SIZE = 1024 * 1024


class CheckpointError(RuntimeError):
    """A checkpoint cannot be written, verified, or deserialized safely."""


def _digest(handle, size: int) -> bytes:
    digest = hashlib.sha256()
    while size:
        chunk = handle.read(min(size, _CHUNK_SIZE))
        if not chunk:
            raise CheckpointError("Checkpoint payload is truncated.")
        digest.update(chunk)
        size -= len(chunk)
    return digest.digest()


def _sync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


@contextmanager
def _writer_lock(path: Path, *, blocking: bool = True):
    lock = path.with_name("." + path.name + ".checkpoint.lock")
    descriptor = os.open(lock, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        yield
    finally:
        # Keep the pathname so concurrent writers always lock the same inode.
        os.close(descriptor)


def _write_payload(value, handle, *, attached_stores=False):
    if not attached_stores:
        pickle.dump(value, handle, protocol=pickle.HIGHEST_PROTOCOL)
        return _MAGIC
    pickler = AttachedPickler(handle)
    pickler.dump(value)
    if pickler.stores:
        pickler.finish(handle)
        return _ATTACHED_MAGIC
    return _MAGIC


def atomic_pickle(path: str | os.PathLike[str], value: object, *, attached_stores=False) -> None:
    """Publish one verified generation. Interruptions propagate unchanged.

    CheckpointError identifies the failure phase and retains the original
    exception as its cause. Publication is not rolled back after replacement.
    """
    path = Path(path)
    temporary = path.with_name("." + path.name + ".checkpoint.tmp")
    phase = "before publication"
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with _writer_lock(path):
            temporary.unlink(missing_ok=True)
            try:
                descriptor = os.open(temporary, os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(descriptor, "w+b") as handle:
                    magic = _write_payload(value, handle, attached_stores=attached_stores)
                    size = handle.tell()
                    handle.flush()
                    handle.seek(0)
                    digest = _digest(handle, size)
                    handle.seek(size)
                    handle.write(_FOOTER.pack(size, digest, magic))
                    handle.flush()
                    os.fsync(handle.fileno())
                phase = "during publication (outcome uncertain)"
                os.replace(temporary, path)
                phase = "after publication (new file complete, durability unconfirmed)"
                _sync_directory(path.parent)
            finally:
                # A failed cleanup leaves at most one reusable staging file.
                with suppress(OSError):
                    temporary.unlink(missing_ok=True)
    except Exception as exc:
        raise CheckpointError("Checkpoint write failed {}: {}".format(phase, path)) from exc


def _legacy_digest(path: Path) -> bytes:
    sidecar = path.with_suffix(path.suffix + ".sha256")
    try:
        with sidecar.open("rb") as handle:
            raw = handle.read(129)
    except FileNotFoundError as exc:
        raise CheckpointError("Checkpoint footer or legacy checksum is missing: {}".format(path)) from exc
    text = raw.strip()
    if len(raw) > 128 or len(text) != 64 or any(c not in b"0123456789abcdefABCDEF" for c in text):
        raise CheckpointError("Invalid raw legacy SHA-256 checksum: {}".format(sidecar))
    return bytes.fromhex(text.decode("ascii"))


def load_verified_pickle(path: str | os.PathLike[str], *, generation=None) -> object:
    """Verify the current file before unpickling, without any backup fallback."""
    path = Path(path)
    try:
        with path.open("rb") as handle:
            total = os.fstat(handle.fileno()).st_size
            footer = b""
            magic = None
            if total >= _FOOTER.size:
                handle.seek(-_FOOTER.size, os.SEEK_END)
                footer = handle.read(_FOOTER.size)
            if footer[-8:].startswith(_MAGIC[:6]):
                size, expected, magic = _FOOTER.unpack(footer)
                if magic not in (_MAGIC, _ATTACHED_MAGIC):
                    raise CheckpointError("Unsupported checkpoint footer version: {}".format(path))
                if size != total - _FOOTER.size:
                    raise CheckpointError("Checkpoint payload length mismatch: {}".format(path))
            else:
                size, expected = total, _legacy_digest(path)
            if generation is not None:
                if (not isinstance(generation, dict)
                        or set(generation) != {"payload_size", "payload_sha256", "format"}
                        or type(generation["payload_size"]) is not int
                        or generation["payload_size"] != size
                        or generation["payload_sha256"] != expected.hex()
                        or magic not in (_MAGIC, _ATTACHED_MAGIC)
                        or generation["format"] != magic.decode("ascii")):
                    raise CheckpointError("Checkpoint differs from its authorized generation.")
            handle.seek(0)
            if not hmac.compare_digest(_digest(handle, size), expected):
                raise CheckpointError("Checkpoint checksum mismatch: {}".format(path))
            if magic == _ATTACHED_MAGIC:
                return read_attached(handle, size, scope=str(path.resolve()))
            handle.seek(0)
            value = pickle.load(handle)
            if handle.tell() != size:
                raise CheckpointError("Checkpoint contains trailing pickle data: {}".format(path))
            return value
    except CheckpointError:
        raise
    except Exception as exc:
        raise CheckpointError("Cannot read or unpickle checkpoint {}: {}".format(path, exc)) from exc
