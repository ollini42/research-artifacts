"""Lossless, bounded-memory storage for the M-06-r4 candidate history.

The database is disposable working storage. Only atomic checkpoints publish
durable generations. No candidate or rejection is evicted to meet a limit.
"""

from __future__ import annotations

from collections.abc import Mapping
from contextlib import contextmanager
import math
import sqlite3

from .candidate_workspace import CandidateWorkspace, current_scope, register_store


MAX_DATABASE_BYTES = 8 * 1024 ** 3
SQLITE_CACHE_KIB = 32 * 1024
SCHEMA_VERSION = 1
MAX_RETRIEVAL_AUDIT_ROWS = 16384


class CandidateStorageError(RuntimeError):
    """A storage limit or invalid legacy state prevents exact continuation."""


def validate_retrieval_audit(rows):
    if type(rows) is not list or len(rows) > MAX_RETRIEVAL_AUDIT_ROWS:
        raise CandidateStorageError("Retrieval audit exceeds its technical row limit.")
    counts = {"neighbor_window", "state_count", "evidence_eligible_state_count",
              "candidate_pairs", "scored_pairs", "cached_rejections"}
    for row in rows:
        if (type(row) is not dict or set(row) != counts | {"has_deferred_pairs"}
                or type(row["has_deferred_pairs"]) is not bool
                or any(type(row[key]) is not int or not 0 <= row[key] < 2 ** 63 for key in counts)):
            raise CandidateStorageError("Retrieval audit contains an invalid bounded record.")


class DiskCandidateStore:
    """One store for queue edges, rejections and their reverse dependencies."""

    def __init__(self, *, max_bytes=MAX_DATABASE_BYTES, scope=None):
        if type(max_bytes) is not int or not 65536 <= max_bytes <= MAX_DATABASE_BYTES:
            raise ValueError("Invalid candidate database byte limit.")
        self._workspace = CandidateWorkspace(current_scope(scope))
        self.path = self._workspace.path
        self.max_bytes = max_bytes
        self._closed = False
        try:
            self._connect()
            self._initialize()
        except BaseException:
            self.close()
            raise
        register_store(self)

    def _initialize(self):
        self.db.executescript("""
            CREATE TABLE edges (
                l INTEGER NOT NULL, r INTEGER NOT NULL,
                score REAL, PRIMARY KEY(l,r), CHECK(l < r)
            ) WITHOUT ROWID;
            CREATE INDEX edges_right ON edges(r,l);
            CREATE INDEX edges_min ON edges(score,l,r) WHERE score IS NOT NULL;
            CREATE TABLE rejected (
                l INTEGER NOT NULL, r INTEGER NOT NULL,
                PRIMARY KEY(l,r), CHECK(l < r)
            ) WITHOUT ROWID;
            CREATE TABLE dependencies (
                l INTEGER NOT NULL, r INTEGER NOT NULL, root INTEGER NOT NULL,
                PRIMARY KEY(l,r,root)
            ) WITHOUT ROWID;
            CREATE INDEX dependency_root ON dependencies(root,l,r);
            PRAGMA user_version=1;
        """)

    def _connect(self):
        self.db = sqlite3.connect(str(self.path), isolation_level=None)
        self.db.execute("PRAGMA journal_mode=DELETE")
        self.db.execute("PRAGMA synchronous=OFF")
        self.db.execute("PRAGMA temp_store=FILE")
        self.db.execute("PRAGMA mmap_size=0")
        self.db.execute("PRAGMA cache_size=-{}".format(SQLITE_CACHE_KIB))
        page_size = self.db.execute("PRAGMA page_size").fetchone()[0]
        self.db.execute("PRAGMA max_page_count={}".format(self.max_bytes // page_size))

    @contextmanager
    def transaction(self):
        self.db.execute("SAVEPOINT candidate_operation")
        try:
            yield
            self.db.execute("RELEASE candidate_operation")
        except BaseException:
            if self.db.in_transaction:
                self.db.execute("ROLLBACK TO candidate_operation")
                self.db.execute("RELEASE candidate_operation")
            raise

    def close(self):
        if not self._closed:
            try:
                if hasattr(self, "db"):
                    self.db.close()
            finally:
                self._closed = True
                self._workspace.close()

    def __reduce_ex__(self, protocol):
        raise TypeError("Candidate stores require atomic_pickle checkpoint attachments.")

    def write_snapshot(self, handle):
        if self.db.in_transaction:
            raise CandidateStorageError("Cannot snapshot an incomplete candidate operation.")
        size = self.path.stat().st_size
        if size > self.max_bytes:
            raise CandidateStorageError("Candidate database exceeds its byte limit.")
        with self.path.open("rb") as source:
            while True:
                chunk = source.read(1024 * 1024)
                if not chunk:
                    break
                handle.write(chunk)
        return size

    @classmethod
    def read_snapshot(cls, handle, size, max_bytes, *, scope=None):
        if type(size) is not int or not 0 < size <= max_bytes <= MAX_DATABASE_BYTES:
            raise CandidateStorageError("Invalid candidate snapshot size.")
        store = cls(max_bytes=max_bytes, scope=scope)
        store.db.close()
        try:
            with store.path.open("wb") as destination:
                remaining = size
                while remaining:
                    chunk = handle.read(min(remaining, 1024 * 1024))
                    if not chunk:
                        raise CandidateStorageError("Truncated candidate snapshot.")
                    destination.write(chunk)
                    remaining -= len(chunk)
            store._connect()
            if store.db.execute("PRAGMA user_version").fetchone()[0] != SCHEMA_VERSION:
                raise CandidateStorageError("Unsupported candidate storage schema.")
            if store.db.execute("PRAGMA quick_check").fetchall() != [("ok",)]:
                raise CandidateStorageError("Candidate snapshot integrity check failed.")
            store.validate()
            return store
        except BaseException:
            store.close()
            raise

    def validate(self):
        expected = object.__new__(DiskCandidateStore)
        expected.db = sqlite3.connect(":memory:")
        try:
            expected._initialize()
            schema_query = "SELECT type,name,tbl_name,sql FROM sqlite_master ORDER BY type,name"
            if self.db.execute(schema_query).fetchall() != expected.db.execute(schema_query).fetchall():
                raise CandidateStorageError("Candidate snapshot schema or indices disagree.")
        finally:
            expected.db.close()
        queries = (
            "SELECT 1 FROM edges WHERE typeof(l)!='integer' OR typeof(r)!='integer' OR l<0 OR l>=r "
            "OR (score IS NOT NULL AND typeof(score) NOT IN ('real','integer')) LIMIT 1",
            "SELECT 1 FROM rejected WHERE typeof(l)!='integer' OR typeof(r)!='integer' OR l<0 OR l>=r LIMIT 1",
            "SELECT 1 FROM dependencies d WHERE typeof(d.root)!='integer' OR d.root<0 "
            "OR NOT EXISTS (SELECT 1 FROM rejected r WHERE r.l=d.l AND r.r=d.r) LIMIT 1",
            "SELECT 1 FROM rejected r WHERE NOT EXISTS "
            "(SELECT 1 FROM dependencies d WHERE d.l=r.l AND d.r=r.r AND d.root=r.l) "
            "OR NOT EXISTS (SELECT 1 FROM dependencies d WHERE d.l=r.l AND d.r=r.r AND d.root=r.r) LIMIT 1",
        )
        if any(self.db.execute(query).fetchone() is not None for query in queries):
            raise CandidateStorageError("Candidate snapshot contains inconsistent logical records.")

    def validate_roots(self, profiles, active_pair):
        for (root,) in self.db.execute(
            "SELECT l FROM edges UNION SELECT r FROM edges UNION SELECT root FROM dependencies"
        ):
            if root not in profiles:
                raise CandidateStorageError("Candidate snapshot refers to an inactive component.")
        if active_pair is not None:
            score, left, right = active_pair
            row = self.db.execute("SELECT score FROM edges WHERE l=? AND r=?", (left, right)).fetchone()
            if row != (None,) or left not in profiles or right not in profiles or math.isnan(score):
                raise CandidateStorageError("Selected candidate binding is inconsistent.")

    @classmethod
    def from_legacy(cls, rejected, reverse, queue):
        """Validate and copy old state without altering the supplied generation."""
        if (type(rejected) is not dict or type(reverse) is not dict
                or any(type(roots) is not set for roots in rejected.values())
                or any(type(pairs) is not set for pairs in reverse.values())):
            raise CandidateStorageError("Legacy rejection indices require exact dictionaries and sets.")
        if queue is not None and (
            type(queue._active) is not dict or type(queue._neighbors) is not dict
            or type(queue._heap) is not list
            or any(type(neighbors) is not set for neighbors in queue._neighbors.values())
            or (hasattr(queue, "_inactive_neighbors") and (
                type(queue._inactive_neighbors) is not dict
                or any(type(neighbors) is not set for neighbors in queue._inactive_neighbors.values())
            ))
        ):
            raise CandidateStorageError("Legacy queue indices have unexpected container types.")
        store = cls()
        try:
            with store.transaction():
                cache = DiskRejectedPairs(store)
                for pair, roots in rejected.items():
                    cache[pair] = roots
                reference_count = 0
                for root, pairs in reverse.items():
                    for pair in pairs:
                        if store.db.execute(
                            "SELECT 1 FROM dependencies WHERE l=? AND r=? AND root=?",
                            (*pair, root),
                        ).fetchone() is None:
                            raise CandidateStorageError("Legacy rejection reverse index disagrees.")
                        reference_count += 1
                if reference_count != store.db.execute(
                    "SELECT count(*) FROM dependencies"
                ).fetchone()[0]:
                    raise CandidateStorageError("Legacy rejection dependencies are incomplete.")
                if queue is not None:
                    if type(queue._version) is not int or queue._version < 0:
                        raise CandidateStorageError("Legacy queue version is invalid.")
                    for index, entry in enumerate(queue._heap):
                        if (type(entry) is not tuple or len(entry) != 4
                                or type(entry[0]) not in (float, int) or math.isnan(entry[0])
                                or any(type(value) is not int for value in entry[1:])
                                or not 0 <= entry[1] < entry[2]
                                or not 0 < entry[3] <= queue._version
                                or (index and entry < queue._heap[(index - 1) // 2])):
                            raise CandidateStorageError("Legacy heap structure or ordering is invalid.")
                    for score, version in queue._active.values():
                        if (type(score) not in (int, float) or math.isnan(score)
                                or type(version) is not int or not 0 < version <= queue._version):
                            raise CandidateStorageError("Legacy active score or version is invalid.")
                    for left, neighbors in queue._neighbors.items():
                        for right in neighbors:
                            if left not in queue._neighbors.get(right, ()):
                                raise CandidateStorageError("Legacy queue adjacency is asymmetric.")
                            if left == right:
                                raise CandidateStorageError("Legacy queue contains a self edge.")
                            if left < right:
                                active = queue._active.get((left, right))
                                score = None if active is None else float(active[0])
                                if score is not None and math.isnan(score):
                                    raise CandidateStorageError("Legacy queue contains a NaN score.")
                                store.db.execute("INSERT INTO edges VALUES (?,?,?)", (left, right, score))
                    for pair in queue._active:
                        if store.db.execute(
                            "SELECT 1 FROM edges WHERE l=? AND r=? AND score IS NOT NULL", pair,
                        ).fetchone() is None:
                            raise CandidateStorageError("Legacy active queue edge is missing.")
                    store.db.execute(
                        "CREATE TABLE heap_seen(l INTEGER,r INTEGER,PRIMARY KEY(l,r)) WITHOUT ROWID"
                    )
                    for distance, left, right, version in queue._heap:
                        pair = (left, right)
                        active = queue._active.get(pair)
                        if active is not None and active[1] == version:
                            if (distance != active[0] or type(version) is not int
                                    or not 0 < version <= queue._version):
                                raise CandidateStorageError("Legacy active heap score or version disagrees.")
                            store.db.execute("INSERT OR IGNORE INTO heap_seen VALUES (?,?)", pair)
                    if store.db.execute("SELECT count(*) FROM heap_seen").fetchone()[0] != len(queue._active):
                        raise CandidateStorageError("Legacy heap omits an active candidate.")
                    store.db.execute("DROP TABLE heap_seen")
                    if hasattr(queue, "_inactive_neighbors"):
                        inactive_references = 0
                        for left, neighbors in queue._inactive_neighbors.items():
                            for right in neighbors:
                                pair = (min(left, right), max(left, right))
                                if store.db.execute(
                                    "SELECT 1 FROM edges WHERE l=? AND r=? AND score IS NULL", pair,
                                ).fetchone() is None:
                                    raise CandidateStorageError("Legacy inactive queue index disagrees.")
                                inactive_references += 1
                        inactive_count = store.db.execute(
                            "SELECT count(*) FROM edges WHERE score IS NULL"
                        ).fetchone()[0]
                        if inactive_references != 2 * inactive_count:
                            raise CandidateStorageError("Legacy inactive queue index is incomplete.")
                    known = store.db.execute("SELECT count(*) FROM edges").fetchone()[0]
                    if hasattr(queue, "_known_pairs") and queue._known_pairs != known:
                        raise CandidateStorageError("Legacy queue cardinality disagrees with adjacency.")
            store.validate()
            return store
        except BaseException:
            store.close()
            raise


class DiskRejectedPairs(Mapping):
    def __init__(self, store):
        self.store = store

    def __len__(self):
        return self.store.db.execute("SELECT count(*) FROM rejected").fetchone()[0]

    def __iter__(self):
        yield from self.store.db.execute("SELECT l,r FROM rejected ORDER BY l,r")

    def __contains__(self, pair):
        return self.store.db.execute(
            "SELECT 1 FROM rejected WHERE l=? AND r=?", pair,
        ).fetchone() is not None

    def __getitem__(self, pair):
        if pair not in self:
            raise KeyError(pair)
        return {row[0] for row in self.store.db.execute(
            "SELECT root FROM dependencies WHERE l=? AND r=?", pair,
        )}

    def __setitem__(self, pair, roots):
        left, right = pair
        if type(left) is not int or type(right) is not int or left >= right:
            raise CandidateStorageError("Rejected pair must contain ordered distinct integer roots.")
        if left not in roots or right not in roots:
            raise CandidateStorageError("Rejected pair omits an endpoint dependency.")
        with self.store.transaction():
            self.store.db.execute("INSERT OR IGNORE INTO rejected VALUES (?,?)", pair)
            self.store.db.execute("DELETE FROM dependencies WHERE l=? AND r=?", pair)
            for root in roots:
                if type(root) is not int:
                    raise CandidateStorageError("Rejection dependency is not an integer.")
                self.store.db.execute(
                    "INSERT OR IGNORE INTO dependencies VALUES (?,?,?)", (left, right, root),
                )

    def invalidate(self, changed):
        """Yield invalidated pairs in exact order without a large Python set."""
        db = self.store.db
        with self.store.transaction():
            db.execute("CREATE TABLE invalidated (l INTEGER,r INTEGER,PRIMARY KEY(l,r)) WITHOUT ROWID")
            try:
                for root in sorted(changed):
                    db.execute(
                        "INSERT OR IGNORE INTO invalidated SELECT l,r FROM dependencies WHERE root=?",
                        (root,),
                    )
                for pair in db.execute("SELECT l,r FROM invalidated ORDER BY l,r"):
                    db.execute("DELETE FROM rejected WHERE l=? AND r=?", pair)
                    db.execute("DELETE FROM dependencies WHERE l=? AND r=?", pair)
                    yield pair
            finally:
                db.execute("DROP TABLE invalidated")


class DiskCandidateQueue:
    def __init__(self, store, *, clear=False):
        self.store = store
        if clear:
            store.db.execute("DELETE FROM edges")

    def __len__(self):
        return self.store.db.execute(
            "SELECT count(*) FROM edges WHERE score IS NOT NULL"
        ).fetchone()[0]

    @staticmethod
    def _score(pair, callback):
        score = float(callback(*pair))
        if math.isnan(score):
            raise ValueError("Candidate distance must not be NaN.")
        return score

    def add_pairs(self, pairs, distance_callback):
        for left, right in pairs:
            if left == right:
                continue
            pair = (min(left, right), max(left, right))
            active = self.store.db.execute(
                "SELECT score FROM edges WHERE l=? AND r=?", pair,
            ).fetchone()
            if active is None or active[0] is None:
                score = self._score(pair, distance_callback)
                self.store.db.execute(
                    "INSERT OR REPLACE INTO edges VALUES (?,?,?)", (*pair, score),
                )

    def pop(self):
        db = self.store.db
        result = db.execute(
            "SELECT score,l,r FROM edges WHERE score IS NOT NULL ORDER BY score,l,r LIMIT 1"
        ).fetchone()
        if result is not None:
            db.execute("UPDATE edges SET score=NULL WHERE l=? AND r=?", result[1:])
        return result

    def remap(self, merged_groups, find_callback, distance_callback, *, score_preserving_roots=None):
        changed = {root for group in merged_groups for root in group}
        changed.update(find_callback(root) for root in tuple(changed))
        preserved = score_preserving_roots or frozenset()
        if not preserved <= changed or any(find_callback(root) != root for root in preserved):
            raise ValueError("Score-preserving roots must be surviving changed roots.")
        db = self.store.db
        # Work tables are in the capped database. Callback failure rolls back
        # their creation and every queue mutation.
        with self.store.transaction():
            db.execute("CREATE TABLE affected (l INTEGER,r INTEGER,PRIMARY KEY(l,r)) WITHOUT ROWID")
            db.execute("""CREATE TABLE remapped (
                l INTEGER,r INTEGER,score REAL,retained INTEGER DEFAULT 0,
                PRIMARY KEY(l,r)) WITHOUT ROWID""")
            for root in sorted(changed):
                condition = " AND score IS NULL" if root in preserved else ""
                for column in ("l", "r"):
                    db.execute(
                        "INSERT OR IGNORE INTO affected SELECT l,r FROM edges WHERE "
                        + column + "=?" + condition, (root,),
                    )
            for left, right in db.execute("SELECT l,r FROM affected ORDER BY l,r"):
                left, right = find_callback(left), find_callback(right)
                if left != right:
                    db.execute(
                        "INSERT OR IGNORE INTO remapped(l,r) VALUES (?,?)",
                        (min(left, right), max(left, right)),
                    )
            for pair in db.execute("SELECT l,r FROM remapped ORDER BY l,r"):
                active = db.execute("SELECT score FROM edges WHERE l=? AND r=?", pair).fetchone()
                retained = (active is not None and active[0] is not None
                            and all(root not in changed or root in preserved for root in pair))
                score = active[0] if retained else self._score(pair, distance_callback)
                db.execute(
                    "UPDATE remapped SET score=?,retained=? WHERE l=? AND r=?",
                    (score, int(retained), *pair),
                )
            db.execute("""DELETE FROM edges WHERE (l,r) IN (SELECT l,r FROM affected)
                AND (l,r) NOT IN (SELECT l,r FROM remapped WHERE retained=1)""")
            db.execute("""INSERT OR REPLACE INTO edges SELECT l,r,score
                FROM remapped WHERE retained=0""")
            db.execute("DROP TABLE affected")
            db.execute("DROP TABLE remapped")


def migrate_priority_storage(state, *, profiles=None):
    """Convert a legacy priority state once, preserving every scientific value."""
    cache = state["rejected_pairs"]
    if isinstance(cache, DiskRejectedPairs):
        queue = state["queue"]
        if queue is not None and (
            not isinstance(queue, DiskCandidateQueue) or queue.store is not cache.store
        ):
            raise CandidateStorageError("Priority queue and rejection store bindings differ.")
        return
    store = DiskCandidateStore.from_legacy(cache, state["rejected_by_root"], state["queue"])
    try:
        if profiles is not None:
            store.validate_roots(profiles, state["active_pair"])
    except BaseException:
        store.close()
        raise
    queue = None if state["queue"] is None else DiskCandidateQueue(store)
    state.update(rejected_pairs=DiskRejectedPairs(store), rejected_by_root=None, queue=queue)
