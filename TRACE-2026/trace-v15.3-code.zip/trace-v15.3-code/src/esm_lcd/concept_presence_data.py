"""Concept-first planning and content-bound checks for concept presence.

Catalogs are JSON arrays, or objects with ``label_objective`` and ``concepts``.
No existing proposition catalog is converted. Conditions describe the intended
question, not the measured answer. These APIs never generate model output or
infer semantic labels. The legacy status name ``reviewed`` means checked,
not human-annotated. Automatic check provenance is recorded separately.
These checks cannot establish infallible semantic correctness.

``build_concept_presence_generation_plan`` creates instructions only. Explicit
contrast assignments distinguish reviewed nearby and unrelated controls.
``materialize_concept_presence_questions`` validates supplied question records
and returns an in-memory manifest. Records include the annotation fields,
``prompt_id``, reviewed ``source_family_ids``, ``source_family_audit_status``
and ``source_family_annotation_source``. Absent variants additionally require
a reviewed, content-bound pair audit. Publication and launch remain separate.
``attach_response_presence_annotations`` joins independently supplied answer
annotations by model run, prompt, concept, full source lineage and exact UTF-8
content, never by question intent.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping, Sequence
from copy import deepcopy
from pathlib import Path


LABEL_OBJECTIVE = "concept_presence"
RESPONSE_OVERLAP_POLICY = "response-origin-overlap-2"
RESPONSE_LABEL_POLICY = "retain-recorded-automatic-assessment-1"
SPLITS = ("discovery", "development", "test")
CONDITIONS = {
    "present_asserted": (1, "affirmative", "Express the target in an asserted statement."),
    "present_negated": (1, "negative", "Deny a statement that contains the target concept."),
    "present_quoted": (1, "unspecified", "Quote content that contains the target concept."),
    "present_query": (1, "unspecified", "Ask a question that contains the target concept."),
    "present_paraphrased": (1, "unspecified", "Paraphrase the target content without changing its meaning."),
    "present_in_composition": (1, "unspecified", "Combine target content with an additional concept."),
    "absent_unrelated": (0, "unspecified", "Replace all target content with the reviewed unrelated control."),
    "absent_related": (0, "unspecified", "Replace all target content with the reviewed nearby control."),
}
_ANNOTATION_FIELDS = {
    "label_objective", "concept_id", "text", "content_sha256", "presence_label",
    "audit_status", "annotation_source",
}
RESPONSE_IDENTITY_FIELDS = ("model_seed", "prompt_id", "concept_id", "source_family_id")
AUTOMATIC_ANNOTATION_FIELDS = (
    "verification_mode", "automatic_check", "automatic_check_sha256",
    "human_annotation_used", "semantic_correctness_guaranteed",
    "construction_label", "construction_label_matches_answer",
    "construction_binding",
)


class PresenceAnnotationConflict(ValueError):
    """Preserve completed automatic checks when their reference labels conflict."""

    def __init__(self, message: str, checked_records: list[dict]):
        super().__init__(message)
        self.checked_records = deepcopy(checked_records)


def _nonempty(value: object, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("{} must be a nonempty string.".format(field))
    return value


def content_sha256(text: str) -> str:
    """Hash exact UTF-8 content without normalization or whitespace removal."""
    if not isinstance(text, str):
        raise ValueError("Annotation text must be a string.")
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _json_sha256(value: object) -> str:
    return content_sha256(json.dumps(value, sort_keys=True, ensure_ascii=False))


def _validate_presence_check_assessment(check: Mapping, definition: Mapping, text: str,
                                        *, request: Mapping | None = None) -> None:
    """Replay source-unit checks, including resolved and retained unknown output.

    Stored checks add definition and content metadata to the parser result.
    Validate that enrichment separately, without masking any parser-owned field.
    Legacy checks retain their existing full-text assessment requirement.
    """
    enrichment = {"definition": definition, "definition_sha256": _json_sha256(definition),
                  "content_sha256": content_sha256(text)}
    for key, expected in enrichment.items():
        if key in check and _json_sha256(check[key]) != _json_sha256(expected):
            raise ValueError("Automatic check enrichment differs from its source: " + key)
    configuration = check["checker_configuration"]
    condition = configuration.get("condition")
    profile = condition.get("checker_profile") if isinstance(condition, Mapping) else None
    source_units = (
        isinstance(profile, Mapping) and "presence_prompt_variant" in profile
        or any(key in configuration for key in ("presence_evidence_binding", "presence_evidence_request_binding"))
        or any(key in check for key in ("evidence_unit_ids", "evidence_resolution", "model_full_text_assessed"))
    )
    replay = None
    if source_units:
        from .presence_evidence_units import parse
        from .presence_generation_runtime import presence_check_request

        if (not isinstance(check.get("raw_completion"), Mapping)
                or "presence_evidence_request_binding" not in configuration):
            raise ValueError("Source-unit checks require raw output and their exact record binding.")
        if request is None:
            request = presence_check_request(definition, text)
        if request is None:
            raise ValueError("Source-unit checks require a nonempty complete source.")
        replay = parse(request, check["raw_completion"], checker_binding=configuration)
        if (set(check) - set(enrichment) != set(replay)
                or _json_sha256({key: check[key] for key in replay}) != _json_sha256(replay)):
            raise ValueError("Source-unit check fields differ from exact raw replay.")
    if check.get("full_text_assessed") is not True and not (
            replay is not None and check.get("full_text_assessed") is False
            and check.get("presence_label") is None and check.get("failure_reason")):
        raise ValueError("A full-text automatic check or replay-verified unresolved failure is required.")


def validate_presence_annotation(
    record: Mapping, *, concept_id: str | None = None,
    text: str | None = None, require_reviewed: bool = False,
    response_identity: Mapping | None = None,
) -> dict:
    """Validate annotation structure and binding, not semantic correctness."""
    if not isinstance(record, Mapping) or not _ANNOTATION_FIELDS.issubset(record):
        raise ValueError("A presence annotation requires all annotation fields.")
    if record["label_objective"] != LABEL_OBJECTIVE:
        raise ValueError("Annotation label_objective must be concept_presence.")
    _nonempty(record["concept_id"], "concept_id")
    if concept_id is not None and record["concept_id"] != concept_id:
        raise ValueError("Annotation concept_id differs from the target.")
    if record["content_sha256"] != content_sha256(record["text"]):
        raise ValueError("Annotation content_sha256 does not match its exact text.")
    if text is not None and record["text"] != text:
        raise ValueError("Annotation text differs from the supplied content.")
    label = record["presence_label"]
    if label is not None and (type(label) is not int or label not in (0, 1)):
        raise ValueError("presence_label must be integer 0, integer 1, or null.")
    status = record["audit_status"]
    if status not in ("reviewed", "constructed", "unresolved"):
        raise ValueError("audit_status must be reviewed, constructed, or unresolved.")
    if status in ("reviewed", "constructed"):
        if label is None:
            raise ValueError("A reviewed annotation requires a resolved presence_label.")
        _nonempty(record["annotation_source"], "annotation_source")
        if status == "constructed" and record.get("verification_mode") is not None:
            raise ValueError("Constructed examples cannot claim completed verification.")
    elif label is not None:
        raise ValueError("An unresolved annotation must have a null presence_label.")
    elif not isinstance(record["annotation_source"], str):
        raise ValueError("annotation_source must be a string.")
    if require_reviewed and status != "reviewed":
        raise ValueError("A reviewed annotation is required.")
    automatic_fields_present = any(key in record for key in AUTOMATIC_ANNOTATION_FIELDS if key != "construction_label")
    if automatic_fields_present or str(record.get("annotation_source", "")).startswith("automatic:"):
        if record.get("verification_mode") != "automatic":
            raise ValueError("Automatic annotation evidence requires explicit automatic mode.")
        check = record.get("automatic_check")
        if (not isinstance(check, Mapping)
                or record.get("automatic_check_sha256") != _json_sha256(check)
                or check.get("presence_label") != label
                or check.get("content_sha256") != record["content_sha256"]
                or not isinstance(check.get("definition"), Mapping)
                or check["definition"].get("concept_id") != record["concept_id"]
                or check.get("definition_sha256") != _json_sha256(check.get("definition"))
                or check.get("mode") != "automatic"
                or record.get("human_annotation_used") is not False
                or record.get("semantic_correctness_guaranteed") is not False):
            raise ValueError("Automatic annotation evidence is missing or inconsistent.")
        for field in ("request_sha256", "definition_sha256", "checker_id", "checker_revision", "rationale"):
            _nonempty(check.get(field), field)
        if not isinstance(check.get("checker_configuration"), Mapping) or not check["checker_configuration"]:
            raise ValueError("Automatic check requires its checker configuration.")
        _validate_presence_check_assessment(check, check["definition"], record["text"])
        spans = check.get("evidence_spans")
        if not isinstance(spans, list) or (label == 1 and not spans):
            raise ValueError("Automatic annotation requires bound evidence spans.")
        for span in spans:
            if not isinstance(span, Mapping):
                raise ValueError("Automatic annotation evidence spans must be objects.")
            start, end = span.get("start"), span.get("end")
            if (type(start) is not int or type(end) is not int
                    or not 0 <= start < end <= len(record["text"])
                    or span.get("text") != record["text"][start:end]):
                raise ValueError("Automatic annotation evidence span differs from text.")
        if label == 0 and check.get("exclusion_assessed") is not True:
            raise ValueError("Automatic absence requires full-text exclusion assessment.")
    if response_identity is not None:
        if _response_identity(record) != _response_identity(response_identity):
            raise ValueError("Response annotation identity or complete source-family binding differs.")
        if record.get("response_id") != response_identity.get("response_id"):
            raise ValueError("Response annotation response_id binding differs.")
        if (("generation_request_id" in record or "generation_request_id" in response_identity)
                and record.get("generation_request_id") != response_generation_request_id(response_identity)):
            raise ValueError("Response annotation generation_request_id binding differs.")
    return deepcopy(dict(record))


def dependency_family_id(record: Mapping) -> str | None:
    """Preserve a supplied canonical question group through response interfaces."""
    value = record.get("dependency_family_id")
    return None if value is None else _nonempty(value, "dependency_family_id")


def _response_identity(record: Mapping) -> tuple:
    if not isinstance(record, Mapping):
        raise ValueError("Response identity must be an object.")
    values = tuple(_nonempty(record.get(field), field) for field in RESPONSE_IDENTITY_FIELDS)
    families = record.get("source_family_ids")
    if not isinstance(families, (list, tuple)) or not families:
        raise ValueError("Response identity requires the complete source_family_ids set.")
    for family in families:
        _nonempty(family, "source_family_ids entry")
    return values + (
        tuple(sorted(set(families) | {record["source_family_id"]})),
        dependency_family_id(record),
    )


def validate_concept_presence_definition(
    concept: Mapping, *, require_reviewed: bool = True,
) -> dict:
    """Validate one definition. Only full-catalog validation resolves contrast IDs."""
    if not isinstance(concept, Mapping):
        raise ValueError("Each catalog concept must be an object.")
    row = deepcopy(dict(concept))
    for field in ("concept_id", "name", "inclusion_definition", "exclusion_definition"):
        _nonempty(row.get(field), field)
    concept_id = row["concept_id"]
    status = row.get("definition_status")
    if status not in ("reviewed", "draft", "unresolved"):
        raise ValueError("definition_status must explicitly record review status.")
    if require_reviewed and status != "reviewed":
        raise ValueError("Catalog definitions must be reviewed.")
    contrasts = row.get("verified_absent_contrast_ids")
    if not isinstance(contrasts, list):
        raise ValueError("verified_absent_contrast_ids must be a list.")
    for contrast_id in contrasts:
        _nonempty(contrast_id, "verified_absent_contrast_ids entry")
    if len(contrasts) != len(set(contrasts)) or concept_id in contrasts:
        raise ValueError("Absent contrast IDs must be distinct and exclude the target.")
    examples = row.get("examples")
    if not isinstance(examples, list) or (require_reviewed and not examples):
        raise ValueError("A reviewed catalog requires nonempty reviewed examples.")
    row["examples"] = [validate_presence_annotation(
        example, concept_id=concept_id, require_reviewed=require_reviewed
    ) for example in examples]
    current_definition = {key: row[key] for key in (
        "concept_id", "name", "inclusion_definition", "exclusion_definition"
    )}
    for example in row["examples"]:
        if example.get("verification_mode") == "automatic" and example["automatic_check"]["definition"] != current_definition:
            raise ValueError("Automatic example check uses an obsolete concept definition.")
    if row.get("definition_check_mode") == "automatic" and (
        row.get("human_annotation_used") is not False
        or any(example.get("verification_mode") != "automatic" for example in row["examples"])
    ):
        raise ValueError("Automatic concepts require automatic example checks without humans.")
    labels_by_content = {}
    for example in row["examples"]:
        digest = example["content_sha256"]
        if digest in labels_by_content:
            raise ValueError("Catalog examples contain duplicate or conflicting content-bound labels.")
        labels_by_content[digest] = example["presence_label"]
    if require_reviewed and set(labels_by_content.values()) != {0, 1}:
        raise ValueError("A reviewed definition requires reviewed presence and absence examples.")
    return row


def validate_concept_presence_catalog(
    concepts: Sequence[Mapping], *, require_reviewed: bool = True,
) -> list[dict]:
    """Validate a new catalog. Draft definitions never become reviewed implicitly."""
    if not isinstance(concepts, (list, tuple)) or not concepts:
        raise ValueError("The concept-presence catalog must be a nonempty list.")
    result = [validate_concept_presence_definition(row, require_reviewed=require_reviewed) for row in concepts]
    ids = {row["concept_id"] for row in result}
    if len(ids) != len(result):
        raise ValueError("Duplicate concept_id in presence catalog.")
    for row in result:
        if not set(row["verified_absent_contrast_ids"]).issubset(ids):
            raise ValueError("An absent contrast ID is missing from the catalog.")
        if row.get("definition_check_mode") == "automatic":
            by_id = {entry["concept_id"]: entry for entry in result}
            expected = {
                (cid, example["content_sha256"])
                for cid in row["verified_absent_contrast_ids"]
                for example in by_id[cid]["examples"] if example["presence_label"] == 1
            }
            checked = set()
            labels_by_text = {example["content_sha256"]: example["presence_label"] for example in row["examples"]}
            audits = row.get("automatic_contrast_checks")
            if not isinstance(audits, list):
                raise ValueError("Automatic concept contrasts require complete check evidence.")
            definition = {key: row[key] for key in ("concept_id", "name", "inclusion_definition", "exclusion_definition")}
            for audit in audits:
                check = validate_presence_annotation(audit["check"], concept_id=row["concept_id"], require_reviewed=True)
                key = (audit["control_concept_id"], check["content_sha256"])
                if (key in checked or check["presence_label"] != 0 or check.get("verification_mode") != "automatic"
                        or check["automatic_check"]["definition"] != definition):
                    raise ValueError("Automatic contrast evidence is duplicate or inconsistent.")
                if labels_by_text.setdefault(check["content_sha256"], check["presence_label"]) != check["presence_label"]:
                    raise PresenceAnnotationConflict(
                        "Automatic concept examples and contrast checks assign conflicting labels.",
                        row["examples"] + [entry["check"] for entry in audits],
                    )
                checked.add(key)
            if checked != expected:
                raise ValueError("Automatic contrast checks do not cover current contrast examples.")
    return result


def load_concept_presence_catalog(
    path: str | Path, *, require_reviewed: bool = True,
) -> list[dict]:
    if Path(path).suffix.lower() != ".json":
        raise ValueError("Concept presence requires a new JSON catalog, not legacy CSV.")
    try:
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError("Concept presence requires a new JSON catalog, not legacy CSV.") from exc
    if isinstance(payload, dict):
        if payload.get("label_objective") != LABEL_OBJECTIVE:
            raise ValueError("Catalog wrapper must declare label_objective=concept_presence.")
        payload = payload.get("concepts")
    return validate_concept_presence_catalog(payload, require_reviewed=require_reviewed)


def protocol_label_objective(protocol_config: str | Path | None) -> str | None:
    """Read the existing resolved protocol, including its supported inheritance."""
    if protocol_config is None:
        return None
    from .confirmatory_plan import load_confirmatory_config

    return load_confirmatory_config(protocol_config)["protocol"].get("label_objective")


def guard_legacy_objective(
    protocol_config: str | Path | None = None, *, label_objective: str | None = None,
) -> None:
    if LABEL_OBJECTIVE in (label_objective, protocol_label_objective(protocol_config)):
        raise ValueError(
            "concept_presence cannot use the legacy polarity generator or materializer. "
            "Use the concept-first generator and automatic content checks."
        )


def build_concept_presence_generation_plan(
    concepts: Sequence[Mapping] | None, *, run_id: str,
    families_per_split: Mapping[str, int] | None = None,
    contrast_assignments: Mapping[str, Mapping[str, str]] | None = None,
    target_concept_ids: Sequence[str] | None = None,
) -> dict:
    """Plan complete eight-condition source families without generating text.

    ``contrast_assignments[cid]`` has ``unrelated`` and ``nearby`` concept IDs.
    Both must belong to that target's reviewed absent-contrast list. The
    supplied assignment asserts a reviewed relation, not a computed ranking.
    Both absent controls have affirmative and negative variants, yielding ten
    records per family. Counts are not a validated experimental sample size.
    """
    _nonempty(run_id, "run_id")
    counts = dict(families_per_split) if families_per_split is not None else dict.fromkeys(SPLITS, 1)
    if not counts or set(counts) - set(SPLITS):
        raise ValueError("Use discovery, development, or test family counts.")
    if any(type(n) is not int or n < 0 for n in counts.values()) or not sum(counts.values()):
        raise ValueError("Family counts must be nonnegative integers with a positive total.")
    catalog = validate_concept_presence_catalog(concepts, require_reviewed=False) if concepts is not None else []
    assignments = deepcopy(dict(contrast_assignments or {}))
    by_id = {row["concept_id"]: row for row in catalog}
    targets = list(by_id) if target_concept_ids is None else list(target_concept_ids)
    if (len(targets) != len(set(targets)) or set(targets) - set(by_id)
            or (catalog and not targets)):
        raise ValueError("Target concepts must be unique nonempty catalog members.")
    if set(assignments) - set(by_id):
        raise ValueError("Contrast assignments contain unknown target IDs.")
    blockers = []
    if not catalog:
        blockers.append("reviewed_concept_catalog")
    for row in catalog:
        cid = row["concept_id"]
        if row["definition_status"] != "reviewed" or not row["examples"] or any(
            ex["audit_status"] != "reviewed" for ex in row["examples"]
        ):
            blockers.append("catalog_review:" + cid)
        if {ex["presence_label"] for ex in row["examples"] if ex["audit_status"] == "reviewed"} != {0, 1}:
            blockers.append("reviewed_example_class_coverage:" + cid)
        if cid not in targets:
            continue
        assignment = assignments.get(cid, {})
        if not isinstance(assignment, Mapping) or set(assignment) - {"unrelated", "nearby"}:
            raise ValueError("Contrast assignments require unrelated and nearby keys.")
        for kind in ("unrelated", "nearby"):
            contrast = assignment.get(kind)
            if contrast is None:
                blockers.append("reviewed_{}_contrast:{}".format(kind, cid))
            elif contrast not in row["verified_absent_contrast_ids"]:
                raise ValueError("A control must be a verified absent contrast for its target.")
        if assignment.get("unrelated") is not None and assignment.get("unrelated") == assignment.get("nearby"):
            raise ValueError("Nearby and unrelated controls must be distinct reviewed concepts.")
    items = []
    for row in sorted(catalog, key=lambda entry: entry["concept_id"]):
        cid = row["concept_id"]
        if cid not in targets:
            continue
        family_index = 0
        for split in SPLITS:
            for _ in range(counts.get(split, 0)):
                family_index += 1
                family_id = "cp:" + _json_sha256([run_id, cid, family_index])
                for condition, (intent, polarity, instruction) in CONDITIONS.items():
                    contrast_kind = {"absent_unrelated": "unrelated", "absent_related": "nearby"}.get(condition)
                    control_id = assignments.get(cid, {}).get(contrast_kind) if contrast_kind else None
                    polarities = ("affirmative", "negative") if intent == 0 else (polarity,)
                    for variant_polarity in polarities:
                        suffix = condition + ":" + variant_polarity if intent == 0 else condition
                        items.append({
                            "label_objective": LABEL_OBJECTIVE, "concept_id": cid,
                            "prompt_id": family_id + ":" + suffix,
                            "source_family_id": family_id, "split": split,
                            "condition": condition, "statement_polarity": variant_polarity,
                            "question_intent_label": intent,
                            "paired_prompt_id": None if condition == "present_asserted" else family_id + ":present_asserted",
                            "target_change": "replace" if intent == 0 else "preserve",
                            "control_concept_id": control_id,
                            "generation_instruction": instruction + (
                                " Use {} statement polarity about the control concept. "
                                "Remove all references to the target, including negation, quotations, "
                                "and prompt echoes. Do not merely deny the original statement.".format(variant_polarity)
                                if intent == 0 else
                                " Presence is independent of factual truth and statement polarity."
                            ),
                        })
    plan = {
        "schema_version": 1, "label_objective": LABEL_OBJECTIVE, "run_id": run_id,
        "generation_origin": "concept_catalog_not_proposition_polarity",
        "human_annotation_required": False,
        "catalog": catalog, "catalog_sha256": _json_sha256(catalog),
        "target_concept_ids": sorted(targets),
        "families_per_split": counts, "contrast_assignments": assignments,
        "questions_per_family": 10,
        "condition_templates": list(CONDITIONS), "items": items,
        "planning_blockers": sorted(set(blockers)),
        "generation_plan_ready": not blockers, "launchable": False,
        "blocked_stages": sorted(set(blockers)) + [
            "automatic_question_content_and_source_family_checks",
            "automatic_response_content_checks", "campaign_integration_and_release",
        ],
    }
    plan["plan_sha256"] = _json_sha256(plan)
    return plan


def materialize_concept_presence_questions(plan: Mapping, records: Sequence[Mapping]) -> dict:
    """Return reviewed questions in memory. Do not publish or unlock a campaign.

    Absent records require ``target_change`` equal to ``removed`` or
    ``replaced``, ``paired_content_sha256``, ``pair_audit_status='reviewed'``
    and a nonempty ``pair_annotation_source``. These supplied audits establish
    the claimed edit, since character or word differences cannot establish it.
    Output ``dependency_family_id`` joins all related planned families,
    supplied ancestry and repeated exact content, including cross-concept ties.
    Downstream splitting and grouped inference must retain these components.
    """
    if not isinstance(plan, Mapping) or plan.get("label_objective") != LABEL_OBJECTIVE:
        raise ValueError("A concept-presence generation plan is required.")
    payload = {key: value for key, value in plan.items() if key != "plan_sha256"}
    if plan.get("plan_sha256") != _json_sha256(payload):
        raise ValueError("The generation plan content digest has changed.")
    if plan["planning_blockers"] or not plan["generation_plan_ready"]:
        raise ValueError("Question materialization requires a reviewed catalog and contrasts.")
    validate_concept_presence_catalog(plan["catalog"])
    planned_concepts = {row["concept_id"]: row for row in plan["catalog"]}
    supplied = {}
    for record in records:
        if not isinstance(record, Mapping):
            raise ValueError("Question records must be objects.")
        prompt_id = _nonempty(record.get("prompt_id"), "prompt_id")
        if prompt_id in supplied:
            raise ValueError("Duplicate supplied prompt_id.")
        supplied[prompt_id] = record
    if set(supplied) != {item["prompt_id"] for item in plan["items"]}:
        raise ValueError("Supply exactly one question record for every planned prompt.")
    rows = []
    split_by_dependency = {}
    labels_by_content = {}
    for item in plan["items"]:
        record = supplied[item["prompt_id"]]
        annotation = validate_presence_annotation(record, concept_id=item["concept_id"], require_reviewed=True)
        if "expected_label" in record:
            raise ValueError("Legacy expected_label is not a concept-presence annotation.")
        for field in ("condition", "statement_polarity", "question_intent_label", "source_family_id", "paired_prompt_id"):
            if field in record and record[field] != item[field]:
                raise ValueError("Supplied question metadata differs from the plan: " + field)
        _nonempty(annotation["text"], "question text")
        if annotation["presence_label"] != item["question_intent_label"]:
            raise ValueError("Reviewed question presence differs from the planned question intent.")
        if annotation.get("verification_mode") == "automatic":
            definition = {key: planned_concepts[item["concept_id"]][key] for key in (
                "concept_id", "name", "inclusion_definition", "exclusion_definition"
            )}
            if (annotation["automatic_check"]["definition"] != definition
                    or any(record.get(key, plan[key]) != plan[key] for key in ("catalog_sha256", "plan_sha256"))):
                raise ValueError("Automatic question check differs from the frozen catalog or plan.")
            contract = annotation.get("automatic_question_contract")
            if (not isinstance(contract, Mapping)
                    or annotation.get("automatic_question_contract_sha256") != _json_sha256(contract)):
                raise ValueError("Automatic question condition evidence is missing or changed.")
            request = contract.get("request", {})
            request_payload = {key: value for key, value in request.items() if key != "request_sha256"}
            if (contract.get("mode") != "automatic" or contract.get("condition_matches") is not True
                    or request.get("request_sha256") != _json_sha256(request_payload)
                    or contract.get("request_sha256") != request.get("request_sha256")
                    or request.get("text") != annotation["text"]
                    or request.get("content_sha256") != annotation["content_sha256"]
                    or request.get("definition") != definition
                    or request.get("control_definition") != planned_concepts.get(item["control_concept_id"])
                    or any(request.get(key) != item[key] for key in (
                        "prompt_id", "condition", "statement_polarity", "control_concept_id"
                    ))):
                raise ValueError("Automatic question condition check differs from the plan or text.")
            if item["question_intent_label"] == 0 and (
                contract.get("control_present") is not True
                or contract.get("target_removed_or_replaced") is not True
                or request.get("paired_content_sha256") != content_sha256(supplied[item["paired_prompt_id"]]["text"])
            ):
                raise ValueError("Automatic question contrast check differs from its paired content.")
        content_key = (item["concept_id"], annotation["content_sha256"])
        if content_key in labels_by_content and labels_by_content[content_key] != annotation["presence_label"]:
            raise ValueError("Questions contain conflicting labels for the same concept and content.")
        labels_by_content[content_key] = annotation["presence_label"]
        families = record.get("source_family_ids")
        if not isinstance(families, list) or not families:
            raise ValueError("Questions require externally supplied source_family_ids.")
        for family in families:
            _nonempty(family, "source_family_ids entry")
        if record.get("source_family_audit_status") != "reviewed":
            raise ValueError("Source-family assignments require review.")
        _nonempty(record.get("source_family_annotation_source"), "source_family_annotation_source")
        if "split" in record and record["split"] != item["split"]:
            raise ValueError("Question split differs from its planned source family.")
        families = sorted(set(families) | {item["source_family_id"]})
        # Use global lineage and content keys, including cross-concept controls.
        dependencies = [("family", family) for family in families]
        dependencies.append(("content", annotation["content_sha256"]))
        for dependency in dependencies:
            previous = split_by_dependency.setdefault(dependency, item["split"])
            if previous != item["split"]:
                raise ValueError("Source-family or exact-content leakage across splits.")
        if item["question_intent_label"] == 0:
            paired = supplied[item["paired_prompt_id"]]
            if record.get("target_change") not in ("removed", "replaced"):
                raise ValueError("An opposite-labelled pair must remove or replace target content.")
            if record.get("pair_audit_status") != "reviewed":
                raise ValueError("Target-removal pairs require an independent reviewed edit audit.")
            _nonempty(record.get("pair_annotation_source"), "pair_annotation_source")
            if record.get("paired_content_sha256") != content_sha256(paired["text"]):
                raise ValueError("Pair audit is not bound to the paired question content.")
            if annotation["text"] == paired["text"]:
                raise ValueError("Opposite-labelled questions cannot have identical content.")
        rows.append({**annotation, **item, "source_family_ids": families,
                     "catalog_sha256": plan["catalog_sha256"], "plan_sha256": plan["plan_sha256"],
                     "target_change": record.get("target_change", item["target_change"])})
    _attach_dependency_families(rows)
    return {
        "schema_version": 1, "label_objective": LABEL_OBJECTIVE,
        "plan_sha256": plan["plan_sha256"], "catalog_sha256": plan["catalog_sha256"],
        "questions": rows, "questions_sha256": _json_sha256(rows),
        "question_materialization_ready": True, "launchable": False,
        "blocked_stages": ["independent_response_annotations", "campaign_integration_and_release"],
    }


def _attach_dependency_families(rows: list[dict]) -> None:
    """Join known lineage and identical content without interpreting wording."""
    parent = {}

    def root(node):
        parent.setdefault(node, node)
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    for row in rows:
        content = ("content", row["content_sha256"])
        for family in row["source_family_ids"]:
            parent[root(("family", family))] = root(content)
    components = {}
    for node in parent:
        components.setdefault(root(node), []).append(node)
    identifiers = {
        key: "cp-group:" + _json_sha256(sorted(nodes))
        for key, nodes in components.items()
    }
    for row in rows:
        row["dependency_family_id"] = identifiers[root(("content", row["content_sha256"]))]


def _observe_response_label(labels: dict, row: Mapping) -> tuple[bool, bool]:
    """Track disagreement without reconciling independent automatic checks."""
    key = (row["concept_id"], row["content_sha256"])
    mask, automatic_only = labels.get(key, (0, True))
    automatic_only = automatic_only and row.get("verification_mode") == "automatic"
    if row["presence_label"] is not None:
        mask |= 1 << row["presence_label"]
    labels[key] = mask, automatic_only
    return mask == 3, automatic_only


def attach_response_presence_annotations(
    responses: Sequence[Mapping], annotations: Sequence[Mapping], *, require_reviewed: bool = False,
) -> list[dict]:
    """Join exact answer content and complete response identity to external labels.

    Responses and annotations require ``model_seed``, ``prompt_id``,
    ``concept_id``, ``source_family_id`` and the complete ``source_family_ids``.
    Optional compact provenance must be retained when supplied on the response.
    Prompt, split and family metadata, including ``question_intent_label``,
    remain unchanged. Reviews cover the full answer including any prompt echo.
    The same text from another model run or prompt requires its own annotation.
    Independent automatic assessments are retained even when they disagree.
    """
    by_content = {}
    labels_by_concept_text = {}
    for record in annotations:
        annotation = validate_presence_annotation(record)
        key = (_response_identity(annotation), annotation["content_sha256"])
        if key in by_content:
            raise ValueError("Duplicate or conflicting identity-bound response annotations.")
        if annotation["audit_status"] == "reviewed":
            disagrees, automatic_only = _observe_response_label(labels_by_concept_text, annotation)
            if disagrees and not automatic_only:
                raise ValueError("Conflicting reviewed labels for the same concept and text across response identities.")
        by_content[key] = annotation
    result, response_ids, used = [], set(), set()
    for response in responses:
        identity = _response_identity(response)
        response_key = identity[:3]
        if response_key in response_ids:
            raise ValueError("Duplicate model_seed, prompt_id and concept_id response identity.")
        response_ids.add(response_key)
        if "expected_label" in response or response.get("label_objective", LABEL_OBJECTIVE) != LABEL_OBJECTIVE:
            raise ValueError("Legacy response labels cannot be inherited as concept presence.")
        cid = _nonempty(response.get("concept_id"), "concept_id")
        text = response.get("text")
        digest = content_sha256(text)
        key = (identity, digest)
        annotation = by_content.get(key)
        if annotation is None:
            annotation = {
                **{field: response[field] for field in RESPONSE_IDENTITY_FIELDS},
                "source_family_ids": response["source_family_ids"],
                "dependency_family_id": dependency_family_id(response),
                "label_objective": LABEL_OBJECTIVE, "concept_id": cid,
                "text": text, "content_sha256": digest, "presence_label": None,
                "audit_status": "unresolved", "annotation_source": "",
                **{field: response[field] for field in ("response_id", "generation_request_id")
                   if field in response},
            }
        else:
            used.add(key)
        annotation = validate_presence_annotation(
            annotation, concept_id=cid, text=text, require_reviewed=require_reviewed,
            response_identity=response,
        )
        clean_response = {key: deepcopy(value) for key, value in response.items()
                          if key not in AUTOMATIC_ANNOTATION_FIELDS}
        result.append({**clean_response, **{
            field: annotation[field] for field in _ANNOTATION_FIELDS
        }, **{
            field: deepcopy(annotation[field]) for field in AUTOMATIC_ANNOTATION_FIELDS
            if field in annotation
        }})
    if set(by_content) != used:
        raise ValueError("Response annotations contain unmatched concept or content bindings.")
    return result


def response_generation_request_id(row: Mapping) -> str | None:
    """Keep the original request identity through compact evaluation records."""
    explicit = row.get("generation_request_id")
    if explicit is not None:
        _nonempty(explicit, "generation_request_id")
    raw = row.get("raw_completion")
    if raw is None:
        return explicit
    if not isinstance(raw, Mapping) or raw.get("text") != row.get("text"):
        raise ValueError("Raw response completion differs from the recorded answer.")
    request = _nonempty(raw.get("request_id"), "request_id")
    if explicit is not None and explicit != request:
        raise ValueError("Compact response request differs from its raw completion.")
    return request


def response_provenance_keys(row: Mapping) -> list[tuple]:
    """Identify shared origins, never infer record reuse from equal answers."""
    identity = _response_identity(row)
    keys = [("family", family) for family in identity[4]]
    keys += [("prompt", identity[1]), ("answer", identity[0], identity[1])]
    if identity[5] is not None:
        keys.append(("canonical_dependency", identity[5]))
    if "response_id" in row:
        keys.append(("response", identity[0], _nonempty(row["response_id"], "response_id")))
    request = response_generation_request_id(row)
    if request is not None:
        keys.append(("generation_request", request))
    return keys


def response_content_overlap(rows: Sequence[Mapping]) -> dict:
    """Describe recurring text, counting each physical answer once per digest.

    An answer can have annotations for several concepts. These annotation
    cells are not additional generations. Text equality alone neither proves
    reuse nor establishes independence of distinct generation requests.
    """
    by_content = {}
    physical_answers = set()
    for row in rows:
        physical = (row["model_seed"], row["prompt_id"])
        physical_answers.add(physical)
        group = by_content.setdefault(row["content_sha256"], {})
        group.setdefault(physical, set()).add(row["split"])
    overlaps = []
    for digest, answers in sorted(by_content.items()):
        splits = sorted({split for values in answers.values() for split in values})
        if len(splits) > 1:
            overlaps.append({"content_sha256": digest, "splits": splits,
                             "physical_answer_count": len(answers),
                             "model_runs": sorted({origin for origin, _ in answers})})
    return {
        "policy_revision": RESPONSE_OVERLAP_POLICY,
        "physical_answer_count": len(physical_answers),
        "distinct_text_count": len(by_content),
        "repeated_text_group_count": sum(len(answers) > 1 for answers in by_content.values()),
        "cross_split_text_group_count": len(overlaps),
        "cross_split_physical_answer_count": sum(row["physical_answer_count"] for row in overlaps),
        "cross_split_groups": overlaps,
        "text_equality_alone_blocks": False,
        "independence_established": False,
    }


def audit_presence_response_collection(rows: Sequence[Mapping]) -> dict:
    """Check split overlap across supplied concepts and answer origins.

    Call on the complete collection before shared reconstruction. A successful
    audit cannot establish collection completeness or statistical independence.
    Exact answer recurrence is reported, not classified as origin leakage.
    Genuine origin overlap still blocks. Automatic label disagreement is
    recorded as uncertainty, not resolved by changing or repeating a check.
    """
    seen = set()
    splits_by_dependency = {}
    labels_by_concept_text = {}
    blockers = set()
    automatic_disagreements = set()
    unknown = 0
    physical_bindings = {}
    origin_owners = {}
    for row in rows:
        validate_presence_annotation(row, response_identity=row)
        identity = _response_identity(row)
        if identity[:3] in seen:
            raise ValueError("Duplicate response identity in collection audit.")
        seen.add(identity[:3])
        split = row.get("split")
        if split not in SPLITS:
            raise ValueError("Every audited response requires a declared split.")
        binding = (row["content_sha256"], split, identity[4], identity[5],
                   row.get("response_id"), response_generation_request_id(row))
        if physical_bindings.setdefault(identity[:2], binding) != binding:
            raise ValueError("One physical answer has different text, split, or source lineage.")
        for key in response_provenance_keys(row):
            splits_by_dependency.setdefault(key, set()).add(split)
            if key[0] in {"response", "generation_request"}:
                if origin_owners.setdefault(key, identity[:2]) != identity[:2]:
                    blockers.add("reused_response_record")
        if row["audit_status"] == "reviewed":
            key = (row["concept_id"], row["content_sha256"])
            disagrees, automatic_only = _observe_response_label(labels_by_concept_text, row)
            if disagrees:
                if automatic_only:
                    automatic_disagreements.add(key)
                else:
                    blockers.add("conflicting_reviewed_presence_labels")
                    automatic_disagreements.discard(key)
        else:
            unknown += 1
    if not rows:
        blockers.add("empty_response_collection")
    if unknown:
        blockers.add("unknown_presence_label")
    for key, splits in splits_by_dependency.items():
        if len(splits) > 1:
            blockers.add("source_family_split_leakage" if key[0] in {"family", "canonical_dependency"}
                         else "response_origin_split_leakage")
    return {
        "label_objective": LABEL_OBJECTIVE,
        "response_concept_record_count": len(rows),
        "unknown_label_count": unknown,
        "response_label_policy": RESPONSE_LABEL_POLICY,
        "automatic_label_disagreement_group_count": len(automatic_disagreements),
        "automatic_labels_reconciled": False,
        "semantic_correctness_guaranteed": False,
        "response_overlap_policy": RESPONSE_OVERLAP_POLICY,
        "response_content_overlap": response_content_overlap(rows),
        "blocking_reasons": sorted(blockers),
        "supplied_collection_consistent": not blockers,
        "collection_completeness_verified": False,
        "independence_established": False,
        "inferential_eligible": False,
    }
