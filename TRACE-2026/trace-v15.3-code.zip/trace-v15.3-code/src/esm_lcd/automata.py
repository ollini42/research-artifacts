"""Prefix-tree preparation and M-06 Hoeffding-priority state merging."""

from __future__ import annotations

import json
from contextlib import suppress
import heapq
import hashlib
import math
import os
import time
from array import array
from collections import Counter, defaultdict, deque
from dataclasses import asdict, dataclass, field, replace
from itertools import combinations
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Sequence, Tuple

from .config import ReconstructionConfig
from .checkpoint_io import atomic_pickle as _atomic_pickle
from .checkpoint_io import load_verified_pickle as _load_verified_pickle
from .checkpoint_io import _sync_directory, _writer_lock
from .data import ResponseTrace
from .sparse_merge import assess_local_compatibility
from .preparation_identity import policy_mapping, profile_config, source_fingerprint
from .metrics import (
    entropy_from_counts,
    jaccard_distance,
    normalize_counts,
)


MERGE_CHECKPOINT_SCHEMA_VERSION = 2
PREPARATION_CHECKPOINT_SCHEMA_VERSION = 1
PREPARATION_CACHE_SCHEMA_VERSION = 1


class MergeCheckpointRequested(RuntimeError):
    """Raised after a requested merge checkpoint has been written safely."""


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _merge_run_fingerprint(
    traces: Sequence["ResponseTrace"], config: ReconstructionConfig
) -> str:
    return source_fingerprint(traces, config)


def _preparation_checkpoint_path(merge_checkpoint: Path) -> Path:
    return merge_checkpoint.with_suffix(
        merge_checkpoint.suffix + ".preparation.pkl"
    )


@dataclass(slots=True)
class PTANode:
    id: int
    depth: int
    parent: int | None
    incoming_label: str | None
    transitions: Dict[str, int] = field(default_factory=dict)
    transition_counts: Counter = field(default_factory=Counter)
    terminal_count: int = 0
    visit_count: int = 0


@dataclass(frozen=True, slots=True)
class StateProfile:
    state_id: int
    visit_count: int
    terminal_count: int
    depth_min: int
    depth_max: int
    next_token_probs: Dict[str, float]
    outgoing_labels: frozenset[str]
    successor_path_probs: Dict[Tuple[str, ...], float]
    entropy: float

    @property
    def suffixes(self):
        """Backward-compatible view of observed successor paths."""

        return self.successor_path_probs.keys()


@dataclass(slots=True)
class PrefixTreeAcceptor:
    nodes: List[PTANode] = field(default_factory=list)
    final_node_by_prompt_id: Dict[str, int] = field(default_factory=dict)

    @classmethod
    def empty(cls) -> "PrefixTreeAcceptor":
        return cls(nodes=[PTANode(id=0, depth=0, parent=None, incoming_label=None)])

    def add_trace(self, prompt_id: str, tokens: Sequence[str]) -> None:
        node_id = 0
        self.nodes[node_id].visit_count += 1
        for token in tokens:
            node = self.nodes[node_id]
            if token not in node.transitions:
                child_id = len(self.nodes)
                node.transitions[token] = child_id
                self.nodes.append(
                    PTANode(
                        id=child_id,
                        depth=node.depth + 1,
                        parent=node_id,
                        incoming_label=token,
                    )
                )
            node.transition_counts[token] += 1
            node_id = node.transitions[token]
            self.nodes[node_id].visit_count += 1
        self.nodes[node_id].terminal_count += 1
        self.final_node_by_prompt_id[prompt_id] = node_id


class UnionFind:
    """Compact union-find for contiguous PTA node IDs.

    PTA IDs are always ``0..n-1``. Arrays avoid the two multi-million-entry
    dictionaries that previously contributed to memory exhaustion on HSUper.
    """

    def __init__(self, values: int | Iterable[int]):
        if isinstance(values, int):
            size = values
        else:
            value_list = list(values)
            if any(value != index for index, value in enumerate(value_list)):
                raise ValueError("UnionFind values must be contiguous integers from zero.")
            size = len(value_list)
        if size < 0:
            raise ValueError("UnionFind size must be non-negative.")
        self.parent = array("I", range(size))
        self.rank = bytearray(size)
        self.component_head = array("I", range(size))
        self.component_tail = array("I", range(size))
        self.next_member = array("I", range(size))

    def find(self, value: int) -> int:
        root = value
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[value] != value:
            parent = self.parent[value]
            self.parent[value] = root
            value = parent
        return root

    def union(self, a: int, b: int) -> bool:
        root_a = self.find(a)
        root_b = self.find(b)
        if root_a == root_b:
            return False
        if self.rank[root_a] < self.rank[root_b]:
            root_a, root_b = root_b, root_a
        tail_a = self.component_tail[root_a]
        self.next_member[tail_a] = self.component_head[root_b]
        self.component_tail[root_a] = self.component_tail[root_b]
        self.parent[root_b] = root_a
        if self.rank[root_a] == self.rank[root_b]:
            self.rank[root_a] += 1
        return True

    def iter_members(self, value: int) -> Iterable[int]:
        """Yield component members without allocating per-component Python sets."""

        root = self.find(value)
        current = self.component_head[root]
        tail = self.component_tail[root]
        while True:
            yield current
            if current == tail:
                return
            current = self.next_member[current]


@dataclass(slots=True)
class LearnedAutomaton:
    backend: str
    threshold: float | None
    pta_node_count: int
    state_count: int
    transition_count: int
    node_to_state: Dict[int, int]
    prompt_to_state: Dict[str, int]
    prompt_to_state_path: Dict[str, tuple[int, ...]]
    prompt_to_pta_node: Dict[str, int]
    state_profiles: Dict[int, StateProfile]
    pta_profiles: Dict[int, StateProfile]
    transitions: List[Dict[str, object]]
    diagnostics: Dict[str, object]

    def export_json(self, output_path: str | Path) -> None:
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2, sort_keys=True)

    def to_dict(self) -> Dict[str, object]:
        return {
            "backend": self.backend,
            "threshold": self.threshold,
            "pta_node_count": self.pta_node_count,
            "state_count": self.state_count,
            "transition_count": self.transition_count,
            "prompt_to_state": self.prompt_to_state,
            "transitions": self.transitions,
            "state_profiles": {
                str(state_id): profile_to_dict(profile)
                for state_id, profile in self.state_profiles.items()
            },
            "diagnostics": self.diagnostics,
        }


def profile_to_dict(profile: StateProfile) -> Dict[str, object]:
    return {
        "state_id": profile.state_id,
        "visit_count": profile.visit_count,
        "terminal_count": profile.terminal_count,
        "depth_min": profile.depth_min,
        "depth_max": profile.depth_max,
        "next_token_probs": profile.next_token_probs,
        "outgoing_labels": sorted(profile.outgoing_labels),
        "suffixes": [" ".join(suffix) for suffix in sorted(profile.suffixes)],
        "successor_path_probs": [
            {"path": " ".join(path), "probability": probability}
            for path, probability in sorted(profile.successor_path_probs.items())
        ],
        "entropy": profile.entropy,
    }


def build_pta(traces: Sequence[ResponseTrace]) -> PrefixTreeAcceptor:
    pta = PrefixTreeAcceptor.empty()
    for trace in traces:
        pta.add_trace(trace.prompt.prompt_id, trace.answer_tokens)
    return pta


def collect_successor_path_probs(
    pta: PrefixTreeAcceptor,
    node_id: int,
    max_length: int,
    max_suffixes: int,
) -> Dict[Tuple[str, ...], float]:
    """Return the most probable successor paths up to the configured depth."""

    if max_length < 1 or max_suffixes < 1:
        return {}
    queue: list[tuple[float, Tuple[str, ...], int]] = []
    root = pta.nodes[node_id]
    root_total = sum(root.transition_counts.values())
    if root_total <= 0:
        return {}
    for label, child_id in sorted(root.transitions.items()):
        probability = root.transition_counts[label] / root_total
        heapq.heappush(queue, (-probability, (label,), child_id))

    path_weights: Dict[Tuple[str, ...], float] = {}
    while queue and len(path_weights) < max_suffixes:
        negative_probability, path, current_id = heapq.heappop(queue)
        probability = -negative_probability
        path_weights[path] = probability
        if len(path) >= max_length:
            continue
        current = pta.nodes[current_id]
        total = sum(current.transition_counts.values())
        if total <= 0:
            continue
        for label, child_id in sorted(current.transitions.items()):
            conditional = current.transition_counts[label] / total
            successor_path = path + (label,)
            heapq.heappush(
                queue,
                (-probability * conditional, successor_path, child_id),
            )
    return normalize_counts(path_weights)


def node_profile(
    pta: PrefixTreeAcceptor,
    node_id: int,
    config: ReconstructionConfig,
) -> StateProfile:
    node = pta.nodes[node_id]
    counts = dict(node.transition_counts)
    return StateProfile(
        state_id=node_id,
        visit_count=node.visit_count,
        terminal_count=node.terminal_count,
        depth_min=node.depth,
        depth_max=node.depth,
        next_token_probs=normalize_counts(counts),
        outgoing_labels=frozenset(node.transitions.keys()),
        successor_path_probs=collect_successor_path_probs(
            pta, node_id, config.suffix_length, config.max_suffixes_per_state
        ),
        entropy=entropy_from_counts(counts),
    )


def prepare_pta_profiles(
    traces: Sequence[ResponseTrace],
    config: ReconstructionConfig,
    checkpoint_path: Path | None,
    checkpoint_interval_seconds: float,
    stop_requested: Callable[[], bool] | None,
    run_fingerprint: str,
) -> tuple[PrefixTreeAcceptor, Dict[int, StateProfile], bool, int]:
    """Build or resume the expensive PTA and state-profile preparation."""

    if checkpoint_path is None:
        pta = build_pta(traces)
        profiles = {
            node.id: node_profile(pta, node.id, config) for node in pta.nodes
        }
        return pta, profiles, False, 0

    preparation_path = _preparation_checkpoint_path(checkpoint_path)
    resumed = False
    write_count = 0
    last_checkpoint_time = time.monotonic()
    last_request_poll_time = last_checkpoint_time
    request_poll_interval = min(1.0, checkpoint_interval_seconds)
    stage = "pta"
    trace_cursor = 0
    profile_cursor = 0
    pta = PrefixTreeAcceptor.empty()
    profiles: Dict[int, StateProfile] = {}

    if preparation_path.is_file():
        loaded = _load_verified_pickle(preparation_path)
        if not isinstance(loaded, dict):
            raise RuntimeError("Preparation checkpoint must contain a mapping.")
        if (
            loaded.get("schema_version")
            != PREPARATION_CHECKPOINT_SCHEMA_VERSION
        ):
            raise RuntimeError("Unsupported preparation checkpoint schema version.")
        if loaded.get("run_fingerprint") != run_fingerprint:
            raise RuntimeError(
                "Preparation checkpoint does not match the locked traces and "
                "configuration."
            )
        if int(loaded.get("trace_count", -1)) != len(traces):
            raise RuntimeError(
                "Preparation checkpoint trace count does not match the input."
            )
        stage = str(loaded["stage"])
        trace_cursor = int(loaded["trace_cursor"])
        profile_cursor = int(loaded["profile_cursor"])
        pta = loaded["pta"]
        profiles = loaded["profiles"]
        resumed = True

    def save_preparation_checkpoint(force: bool = False) -> None:
        nonlocal last_checkpoint_time
        nonlocal last_request_poll_time
        nonlocal write_count
        now = time.monotonic()
        requested = False
        if stop_requested is not None and (
            force or now - last_request_poll_time >= request_poll_interval
        ):
            requested = bool(stop_requested())
            last_request_poll_time = now
        if (
            not force
            and not requested
            and now - last_checkpoint_time < checkpoint_interval_seconds
        ):
            return
        payload = {
            "schema_version": PREPARATION_CHECKPOINT_SCHEMA_VERSION,
            "run_fingerprint": run_fingerprint,
            "trace_count": len(traces),
            "stage": stage,
            "trace_cursor": trace_cursor,
            "profile_cursor": profile_cursor,
            "pta": pta,
            "profiles": profiles,
            "saved_unix_time": time.time(),
        }
        _atomic_pickle(preparation_path, payload)
        write_count += 1
        last_checkpoint_time = time.monotonic()
        if requested:
            raise MergeCheckpointRequested(
                "Preparation checkpoint requested and written to {}.".format(
                    preparation_path
                )
            )

    if stage == "pta":
        if not 0 <= trace_cursor <= len(traces):
            raise RuntimeError("Preparation checkpoint has an invalid trace cursor.")
        for trace_index in range(trace_cursor, len(traces)):
            trace = traces[trace_index]
            pta.add_trace(trace.prompt.prompt_id, trace.answer_tokens)
            trace_cursor = trace_index + 1
            save_preparation_checkpoint()
        stage = "profiles"
        profile_cursor = 0
        save_preparation_checkpoint(force=True)

    if stage == "profiles":
        if trace_cursor != len(traces):
            raise RuntimeError(
                "Profile preparation requires a complete PTA checkpoint."
            )
        if not 0 <= profile_cursor <= len(pta.nodes):
            raise RuntimeError("Preparation checkpoint has an invalid profile cursor.")
        for node_index in range(profile_cursor, len(pta.nodes)):
            node = pta.nodes[node_index]
            profiles[node.id] = node_profile(pta, node.id, config)
            profile_cursor = node_index + 1
            save_preparation_checkpoint()
        stage = "complete"
        save_preparation_checkpoint(force=True)

    if stage != "complete":
        raise RuntimeError("Preparation checkpoint has an invalid stage.")
    if trace_cursor != len(traces) or len(profiles) != len(pta.nodes):
        raise RuntimeError("Preparation checkpoint is incomplete.")
    return pta, profiles, resumed, write_count


def reuse_unmerged_preparation(
    path: Path, traces: Sequence[ResponseTrace], old_config: ReconstructionConfig,
    new_config: ReconstructionConfig,
) -> tuple[PrefixTreeAcceptor, Dict[int, StateProfile], Dict[str, object]]:
    """Read only a complete, verified preparation, never a merge checkpoint."""
    _check_preparation_config(old_config, new_config)
    loaded, digest = _read_preparation_snapshot(path)
    _validate_unmerged_preparation(loaded, old_config, traces)
    return loaded["pta"], loaded["profiles"], {
        "source_path": str(path.resolve()), "source_sha256": digest,
        "source_run_fingerprint": loaded["run_fingerprint"], "unmerged_only": True,
        "imported_merges": 0,
    }


def _check_preparation_config(
    old_config: ReconstructionConfig, new_config: ReconstructionConfig
) -> None:
    for name in ("suffix_length", "max_suffixes_per_state"):
        if policy_mapping(old_config)[name] != getattr(new_config, name):
            raise ValueError("Prepared profile configuration differs: " + name)


def _read_preparation_snapshot(path: Path, expected_sha256: str | None = None):
    before = _sha256_file(path)
    if expected_sha256 is not None and before != expected_sha256:
        raise RuntimeError("Frozen preparation content hash does not match the checkpoint.")
    loaded = _load_verified_pickle(path)
    if _sha256_file(path) != before:
        raise RuntimeError("Preparation changed while it was being verified.")
    return loaded, before


def _check_preparation_header(
    loaded: object, source_config: ReconstructionConfig,
    traces: Sequence[ResponseTrace] | None,
) -> None:
    if not isinstance(loaded, dict) or "union_find" in loaded or "component_profiles" in loaded:
        raise RuntimeError("Only unmerged preparation checkpoints may be imported.")
    fingerprint = loaded.get("run_fingerprint")
    if (not isinstance(fingerprint, str) or len(fingerprint) != 64
            or any(character not in "0123456789abcdef" for character in fingerprint)):
        raise RuntimeError("Preparation source has an invalid run fingerprint.")
    if traces is not None and fingerprint != source_fingerprint(traces, source_config):
        raise RuntimeError("Preparation source does not match the old policy and current traces.")
    pta, profiles = loaded.get("pta"), loaded.get("profiles")
    trace_count = loaded.get("trace_count")
    if (loaded.get("schema_version") != PREPARATION_CHECKPOINT_SCHEMA_VERSION
            or loaded.get("stage") != "complete"
            or type(trace_count) is not int or trace_count <= 0
            or (traces is not None and trace_count != len(traces))
            or loaded.get("trace_cursor") != trace_count
            or not isinstance(pta, PrefixTreeAcceptor)
            or not isinstance(profiles, dict)
            or not pta.nodes
            or loaded.get("profile_cursor") != len(pta.nodes)
            or len(profiles) != len(pta.nodes)):
        raise RuntimeError("Preparation source is incomplete or has an invalid schema.")


def _validate_preparation_structure(loaded: dict) -> None:
    """Check the unmerged tree and its profile counts without suffix traversal."""
    pta, profiles = loaded["pta"], loaded["profiles"]
    root = pta.nodes[0]
    if (root.parent is not None or root.incoming_label is not None
            or root.depth != 0 or root.visit_count != loaded["trace_count"]):
        raise RuntimeError("Preparation has an invalid prefix-tree root.")
    for index, node in enumerate(pta.nodes):
        profile = profiles.get(index)
        if (node.id != index or not isinstance(profile, StateProfile)
                or profile.state_id != index
                or profile.visit_count != node.visit_count
                or profile.terminal_count != node.terminal_count
                or profile.depth_min != node.depth or profile.depth_max != node.depth
                or profile.outgoing_labels != frozenset(node.transitions)):
            raise RuntimeError("Preparation contains inconsistent or merged profiles.")
        if (type(node.visit_count) is not int or type(node.terminal_count) is not int
                or node.visit_count <= 0 or node.terminal_count < 0
                or set(node.transition_counts) != set(node.transitions)
                or any(type(count) is not int or count <= 0
                       for count in node.transition_counts.values())
                or sum(node.transition_counts.values()) + node.terminal_count != node.visit_count):
            raise RuntimeError("Preparation has inconsistent visit or termination counts.")
        if index and (
            type(node.parent) is not int or not 0 <= node.parent < index
            or pta.nodes[node.parent].transitions.get(node.incoming_label) != index
            or node.depth != pta.nodes[node.parent].depth + 1
        ):
            raise RuntimeError("Preparation contains a disconnected prefix-tree node.")
        for label, child in node.transitions.items():
            if (type(child) is not int or not index < child < len(pta.nodes)
                    or pta.nodes[child].parent != index
                    or pta.nodes[child].incoming_label != label
                    or pta.nodes[child].visit_count != node.transition_counts[label]):
                raise RuntimeError("Preparation must contain an unmerged prefix tree.")
    if (not pta.final_node_by_prompt_id
            or any(type(node_id) is not int or not 0 <= node_id < len(pta.nodes)
                   or pta.nodes[node_id].terminal_count <= 0
                   for node_id in pta.final_node_by_prompt_id.values())):
        raise RuntimeError("Preparation has an invalid prompt endpoint mapping.")


def _validate_preparation_trace_binding(
    pta: PrefixTreeAcceptor, traces: Sequence[ResponseTrace],
) -> None:
    """Bind a structurally checked PTA to traces with one uint64 per node.

    Each trace is traversed once. Terminal totals are then accumulated towards
    the root to recover visits. A tree edge count equals its child's visits.
    Prompt IDs follow add_trace's last-write semantics for repeated IDs.
    """
    totals = array("Q", [0]) * len(pta.nodes)
    seen_prompt_ids = set()
    for trace in reversed(traces):
        node_id = 0
        for token in trace.answer_tokens:
            child = pta.nodes[node_id].transitions.get(token)
            if child is None:
                raise RuntimeError("Preparation does not contain an input trace path.")
            node_id = child
        totals[node_id] += 1
        prompt_id = trace.prompt.prompt_id
        if prompt_id not in seen_prompt_ids:
            if pta.final_node_by_prompt_id.get(prompt_id) != node_id:
                raise RuntimeError("Preparation prompt endpoint does not match its input trace.")
            seen_prompt_ids.add(prompt_id)
    if len(seen_prompt_ids) != len(pta.final_node_by_prompt_id):
        raise RuntimeError("Preparation prompt IDs do not match the input traces.")
    for node in pta.nodes:
        if totals[node.id] != node.terminal_count:
            raise RuntimeError("Preparation termination counts do not match the input traces.")
    for node in reversed(pta.nodes):
        if totals[node.id] != node.visit_count:
            raise RuntimeError("Preparation visit counts do not match the input traces.")
        if node.parent is not None:
            totals[node.parent] += totals[node.id]


def _validate_unmerged_preparation(
    loaded: object, source_config: ReconstructionConfig,
    traces: Sequence[ResponseTrace] | None = None,
) -> None:
    """Check the complete tree and recompute profiles once before freezing."""
    _check_preparation_header(loaded, source_config, traces)
    _validate_preparation_structure(loaded)
    pta, profiles = loaded["pta"], loaded["profiles"]
    if traces is not None:
        _validate_preparation_trace_binding(pta, traces)
    # Check topology first, so successor traversal cannot follow invalid edges.
    reconstruction = profile_config(source_config)
    for node in pta.nodes:
        profile = profiles[node.id]
        for probabilities in (profile.next_token_probs, profile.successor_path_probs):
            if (not isinstance(probabilities, dict)
                    or any(not isinstance(value, (int, float))
                           or not math.isfinite(value) or not 0.0 <= value <= 1.0
                           for value in probabilities.values())
                    or (probabilities and not math.isclose(
                        math.fsum(probabilities.values()), 1.0, rel_tol=0.0, abs_tol=1e-12))):
                raise RuntimeError("Preparation probabilities must be finite and normalized.")
        expected = node_profile(pta, node.id, reconstruction)
        if (profile.next_token_probs != expected.next_token_probs
                or profile.successor_path_probs != expected.successor_path_probs
                or not math.isfinite(profile.entropy)
                or not math.isclose(profile.entropy, expected.entropy, rel_tol=1e-12, abs_tol=1e-12)):
            raise RuntimeError("Preparation profiles do not match the prefix-tree counts.")


def _load_frozen_preparation(
    cache_path: Path, traces: Sequence[ResponseTrace] | None,
    new_config: ReconstructionConfig | None = None,
    expected_reference: Dict[str, object] | None = None,
) -> tuple[PrefixTreeAcceptor, Dict[int, StateProfile], Dict[str, object]]:
    if traces is None and new_config is not None and expected_reference is None:
        raise RuntimeError("Loading preparation without traces requires a locked cache reference.")
    expected_hash = None if expected_reference is None else expected_reference["cache_sha256"]
    frozen, digest = _read_preparation_snapshot(cache_path, expected_hash)
    if (not isinstance(frozen, dict)
            or frozen.get("cache_schema_version") != PREPARATION_CACHE_SCHEMA_VERSION
            or frozen.get("validation") != "exact_unmerged_profiles_v1"
            or not isinstance(frozen.get("source_config"), dict)):
        raise RuntimeError("Unsupported frozen preparation schema.")
    source_config = frozen["source_config"]
    if new_config is not None:
        _check_preparation_config(source_config, new_config)
    loaded = frozen.get("preparation")
    _check_preparation_header(loaded, source_config, traces)
    if traces is not None:
        _validate_preparation_structure(loaded)
        _validate_preparation_trace_binding(loaded["pta"], traces)
    reference = {
        "source_path": frozen["source_path"], "source_sha256": frozen["source_sha256"],
        "source_run_fingerprint": loaded["run_fingerprint"],
        "cache_path": str(cache_path.resolve()), "cache_sha256": digest,
        "unmerged_only": True, "imported_merges": 0,
        "validation": frozen["validation"],
    }
    if expected_reference is not None and reference != expected_reference:
        raise RuntimeError("Frozen preparation provenance does not match the checkpoint.")
    # A concurrent reader may observe replace before the publishing writer fsyncs.
    _sync_directory(cache_path.parent)
    return loaded["pta"], loaded["profiles"], reference


def freeze_unmerged_preparation(
    source_path: str | Path, cache_path: str | Path,
    source_config: ReconstructionConfig | Callable[[], ReconstructionConfig] | None,
    *, traces: Sequence[ResponseTrace] | None = None,
) -> Dict[str, object]:
    """Publish one immutable, validated cache and return its full-file SHA-256.

    Use ``preparation_cache/<response_label>/unmerged.pkl`` in a campaign.
    The returned ``cache_path`` and ``cache_sha256`` can be locked before jobs
    start. A source-config loader is called only for the initial import.
    Without traces, input identity is checked later by ``fit`` against the
    frozen original configuration. Cache files are never removed by run cleanup.
    """
    source_path, cache_path = Path(source_path), Path(cache_path)

    def existing_reference():
        _, _, reference = _load_frozen_preparation(cache_path, traces)
        if reference["source_path"] != str(source_path.resolve()):
            raise RuntimeError("Preparation cache belongs to a different source.")
        return reference

    if cache_path.is_file():
        return existing_reference()
    anchor = cache_path.parent
    while not anchor.exists():
        anchor = anchor.parent
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    # Persist new entries through their pre-existing parent, including mkdir races.
    # Continue above it for interrupted imports, but not into read-protected,
    # non-writable system namespaces. Never suppress a required directory sync.
    above_anchor = False
    for directory in (cache_path.parent, *cache_path.parent.parents):
        try:
            _sync_directory(directory)
        except PermissionError:
            if above_anchor and not os.access(directory, os.W_OK):
                break
            raise
        if directory == anchor:
            above_anchor = True
    # Separate from atomic_pickle's lock to avoid nested acquisition of it.
    with _writer_lock(cache_path.with_suffix(cache_path.suffix + ".freeze")):
        if cache_path.is_file():
            return existing_reference()
        original_config = source_config() if callable(source_config) else source_config
        original_config = policy_mapping(original_config)
        loaded, digest = _read_preparation_snapshot(source_path)
        _validate_unmerged_preparation(loaded, original_config, traces)
        frozen = {
            "cache_schema_version": PREPARATION_CACHE_SCHEMA_VERSION,
            "validation": "exact_unmerged_profiles_v1",
            "source_path": str(source_path.resolve()), "source_sha256": digest,
            "source_config": original_config, "preparation": loaded,
        }
        _atomic_pickle(cache_path, frozen)
        del frozen, loaded
        return existing_reference()


def merge_profiles(
    state_id: int,
    profiles: Sequence[StateProfile],
    max_successor_paths: int | None = None,
) -> StateProfile:
    next_counts = Counter()
    outgoing_labels = set()
    successor_counts = Counter()
    visit_count = 0
    terminal_count = 0
    depths = []
    for profile in profiles:
        visit_count += profile.visit_count
        terminal_count += profile.terminal_count
        depths.extend([profile.depth_min, profile.depth_max])
        outgoing_labels.update(profile.outgoing_labels)
        outgoing_count = max(profile.visit_count - profile.terminal_count, 0)
        for path, probability in profile.successor_path_probs.items():
            successor_counts[path] += probability * outgoing_count
        for token, prob in profile.next_token_probs.items():
            next_counts[token] += prob * outgoing_count
    if max_successor_paths is not None:
        successor_counts = Counter(
            dict(
                sorted(
                    successor_counts.items(),
                    key=lambda item: (-item[1], item[0]),
                )[: max(0, int(max_successor_paths))]
            )
        )
    next_probs = normalize_counts(dict(next_counts))
    successor_probs = normalize_counts(dict(successor_counts))
    # Pooling identical distributions is the identity operation. Avoid creating
    # artificial score changes through count multiplication and renormalization.
    observed = [profile for profile in profiles
                if profile.visit_count > profile.terminal_count]
    if observed:
        first = observed[0]
        if all(profile.next_token_probs == first.next_token_probs for profile in observed):
            next_probs = dict(first.next_token_probs)
        if ((max_successor_paths is None or len(first.successor_path_probs) <= max_successor_paths)
                and all(profile.successor_path_probs == first.successor_path_probs
                        for profile in observed)):
            successor_probs = dict(first.successor_path_probs)
    return StateProfile(
        state_id=state_id,
        visit_count=visit_count,
        terminal_count=terminal_count,
        depth_min=min(depths) if depths else 0,
        depth_max=max(depths) if depths else 0,
        next_token_probs=next_probs,
        outgoing_labels=frozenset(outgoing_labels),
        successor_path_probs=successor_probs,
        entropy=entropy_from_counts(dict(next_counts)),
    )


def _priority_jsd(first: Dict, second: Dict) -> float:
    """Use canonical summation for reproducible priority scores across processes."""
    if first == second:
        return 0.0
    # Empirical sparse profiles often have one deterministic event. These
    # exact cases need neither a union sort nor logarithms.
    if (len(first) <= 1 and len(second) <= 1
            and all(value == 1.0 for value in first.values())
            and all(value == 1.0 for value in second.values())):
        return 1.0 if first and second else 0.5
    terms = []
    for key in sorted(first.keys() | second.keys()):
        left = first.get(key, 0.0)
        right = second.get(key, 0.0)
        midpoint = 0.5 * (left + right)
        if left > 0.0:
            terms.append(0.5 * left * math.log2(left / midpoint))
        if right > 0.0:
            terms.append(0.5 * right * math.log2(right / midpoint))
    return max(0.0, min(1.0, math.fsum(terms)))


def profile_distance_components(
    a: StateProfile,
    b: StateProfile,
    config: ReconstructionConfig,
) -> Dict[str, float]:
    divergence = _priority_jsd
    next_distance = divergence(a.next_token_probs, b.next_token_probs)
    successor_distance = divergence(
        a.successor_path_probs, b.successor_path_probs
    )
    transition_distance = jaccard_distance(a.outgoing_labels, b.outgoing_labels)
    weight_total = config.lambda_next + config.lambda_suffix + config.lambda_transition
    combined = (
        config.lambda_next * next_distance
        + config.lambda_suffix * successor_distance
        + config.lambda_transition * transition_distance
    ) / weight_total
    combined = max(0.0, min(1.0, combined))
    return {
        "next_token_jsd": next_distance,
        "successor_path_jsd": successor_distance,
        "transition_jaccard_distance": transition_distance,
        "combined_distance": combined,
    }


def profile_distance(
    a: StateProfile,
    b: StateProfile,
    config: ReconstructionConfig,
) -> float:
    if (a.next_token_probs == b.next_token_probs
            and a.successor_path_probs == b.successor_path_probs
            and a.outgoing_labels == b.outgoing_labels):
        return 0.0
    return profile_distance_components(a, b, config)["combined_distance"]


@dataclass(frozen=True)
class RecursiveCompatibilityCheck:
    left_root: int
    right_root: int
    depth: int
    distances: Dict[str, float]
    hoeffding: Dict[str, object]


@dataclass(frozen=True)
class MergeTransaction:
    """A fully validated deterministic congruence closure for one candidate."""

    groups: tuple[tuple[int, ...], ...]
    checks: tuple[RecursiveCompatibilityCheck, ...]
    reduction_count: int
    maximum_depth: int
    checked_profiles: Dict[tuple[int, ...], StateProfile]


@dataclass(frozen=True)
class RejectedMergeTransaction:
    checks: tuple[RecursiveCompatibilityCheck, ...]
    rejected_depth: int


class ComponentSuccessorIndex:
    """Cache quotient edges, normalizing targets after component unions."""

    def __init__(self, pta: PrefixTreeAcceptor, union_find: UnionFind):
        self.pta = pta
        self.union_find = union_find
        self.cache: Dict[int, Dict[str, set[int]]] = {}

    def get(self, root: int) -> Dict[str, set[int]]:
        root = self.union_find.find(root)
        if root not in self.cache:
            edges: Dict[str, set[int]] = defaultdict(set)
            for member in self.union_find.iter_members(root):
                for label, target in self.pta.nodes[member].transitions.items():
                    edges[label].add(self.union_find.find(target))
            self.cache[root] = dict(edges)
        edges = self.cache[root]
        for label, targets in edges.items():
            edges[label] = {self.union_find.find(target) for target in targets}
        return edges

    def combined(self, roots: Sequence[int]) -> Dict[str, set[int]]:
        edges: Dict[str, set[int]] = defaultdict(set)
        for root in roots:
            for label, targets in self.get(root).items():
                edges[label].update(targets)
        return dict(edges)

    def committed(self, roots: Sequence[int], edges: Dict[str, set[int]]) -> None:
        for root in roots:
            self.cache.pop(root, None)
        self.cache[self.union_find.find(roots[0])] = edges


class _TentativeComponentUnion:
    """Small transactional union-find used before mutating the learned quotient."""

    def __init__(
        self,
        component_profiles: Dict[int, StateProfile],
        max_successor_paths: int,
    ):
        self.component_profiles = component_profiles
        self.max_successor_paths = max_successor_paths
        self.parent: Dict[int, int] = {}
        self.rank: Dict[int, int] = {}
        self.members: Dict[int, set[int]] = {}
        self.profiles: Dict[int, StateProfile] = {}
        self.successors: Dict[int, Dict[str, set[int]]] = {}

    def ensure(self, root: int) -> int:
        root = int(root)
        if root not in self.parent:
            self.parent[root] = root
            self.rank[root] = 0
            self.members[root] = {root}
            self.profiles[root] = self.component_profiles[root]
        return self.find(root)

    def find(self, root: int) -> int:
        root = int(root)
        if root not in self.parent:
            return root
        parent = self.parent[root]
        if parent != root:
            self.parent[root] = self.find(parent)
        return self.parent[root]

    def union(self, left: int, right: int) -> int:
        left = self.ensure(left)
        right = self.ensure(right)
        if left == right:
            return left
        if self.rank[left] < self.rank[right]:
            left, right = right, left
        left_profile = self.profiles[left]
        right_profile = self.profiles[right]
        self.parent[right] = left
        if self.rank[left] == self.rank[right]:
            self.rank[left] += 1
        self.members[left].update(self.members[right])
        self.profiles[left] = merge_profiles(
            left,
            (left_profile, right_profile),
            self.max_successor_paths,
        )
        del self.members[right]
        del self.profiles[right]
        return left


def plan_recursive_merge_transaction(
    pta: PrefixTreeAcceptor,
    union_find: UnionFind,
    component_profiles: Dict[int, StateProfile],
    node_a: int,
    node_b: int,
    config: ReconstructionConfig,
    successor_index: ComponentSuccessorIndex | None = None,
    resume_state: Dict[str, object] | None = None,
    progress_callback: Callable[[Dict[str, object]], None] | None = None,
) -> MergeTransaction | RejectedMergeTransaction:
    """Validate a candidate and every determinization merge it implies.

    Candidate retrieval remains heuristic. Acceptance follows the recursive
    continuation compatibility used by ALERGIA-like inference. The complete
    transaction is checked before the global union-find is changed.
    """

    global_left = union_find.find(node_a)
    global_right = union_find.find(node_b)
    index = successor_index or ComponentSuccessorIndex(pta, union_find)
    state = resume_state if resume_state is not None else {}
    if state:
        if tuple(state["candidate"]) != (global_left, global_right):
            raise RuntimeError("Transaction checkpoint has a different candidate.")
        tentative = state["tentative"]
        tentative.component_profiles = component_profiles
        pending = state["pending"]
        checks = state["checks"]
        maximum_depth = int(state["maximum_depth"])
    else:
        tentative = _TentativeComponentUnion(
            component_profiles, config.max_suffixes_per_state
        )
        pending = deque([(global_left, global_right, 0)])
        checks: list[RecursiveCompatibilityCheck] = []
        maximum_depth = 0
        state.update(candidate=(global_left, global_right), tentative=tentative,
                     pending=pending, checks=checks, maximum_depth=0, steps=0)

    def component_successors(local_root: int) -> Dict[str, set[int]]:
        local_root = tentative.find(local_root)
        if local_root not in tentative.successors:
            tentative.successors[local_root] = {
                label: set(targets) for label, targets in index.get(local_root).items()
            }
        targets = tentative.successors[local_root]
        for label, values in targets.items():
            targets[label] = {
                tentative.find(union_find.find(target)) for target in values
            }
        return targets

    while pending:
        if progress_callback is not None and int(state["steps"]) % 256 == 0:
            state["maximum_depth"] = maximum_depth
            progress_callback(state)
        state["steps"] = int(state["steps"]) + 1
        left, right, depth = pending.popleft()
        left = tentative.ensure(union_find.find(left))
        right = tentative.ensure(union_find.find(right))
        left = tentative.find(left)
        right = tentative.find(right)
        if left == right:
            continue

        profile_left = tentative.profiles[left]
        profile_right = tentative.profiles[right]
        distances = profile_distance_components(profile_left, profile_right, config)
        hoeffding = assess_local_compatibility(
            profile_left, profile_right, alpha=config.hoeffding_compatibility_alpha
        )
        check = RecursiveCompatibilityCheck(
            left_root=left,
            right_root=right,
            depth=depth,
            distances=distances,
            hoeffding=asdict(hoeffding),
        )
        checks.append(check)
        maximum_depth = max(maximum_depth, depth)
        if not hoeffding.permits_proposal:
            return RejectedMergeTransaction(tuple(checks), depth)

        left_successors = component_successors(left)
        right_successors = component_successors(right)
        merged = tentative.union(left, right)
        for label in sorted(set(left_successors) & set(right_successors)):
            for left_target in sorted(left_successors[label]):
                for right_target in sorted(right_successors[label]):
                    pending.append((left_target, right_target, depth + 1))
        # Small-to-large edge unions avoid rescanning original PTA members.
        if len(left_successors) < len(right_successors):
            left_successors, right_successors = right_successors, left_successors
        for label, targets in right_successors.items():
            left_successors.setdefault(label, set()).update(targets)
        tentative.successors.pop(left, None)
        tentative.successors.pop(right, None)
        tentative.successors[merged] = left_successors

    groups = tuple(
        sorted(
            tuple(sorted(members))
            for members in tentative.members.values()
            if len(members) > 1
        )
    )
    reduction_count = sum(len(group) - 1 for group in groups)
    return MergeTransaction(
        groups=groups,
        checks=tuple(checks),
        reduction_count=reduction_count,
        maximum_depth=maximum_depth,
        checked_profiles=(
            {
                tuple(sorted(tentative.members[root])): profile
                for root, profile in tentative.profiles.items()
                if len(tentative.members[root]) > 1
            }
        ),
    )


@dataclass(slots=True)
class DistanceAudit:
    count: int = 0
    total: float = 0.0
    total_squared: float = 0.0
    minimum: float | None = None
    maximum: float | None = None
    histogram: Counter = field(default_factory=Counter)

    def add(self, value: float) -> None:
        bounded = max(0.0, min(1.0, float(value)))
        self.count += 1
        self.total += bounded
        self.total_squared += bounded * bounded
        self.minimum = bounded if self.minimum is None else min(self.minimum, bounded)
        self.maximum = bounded if self.maximum is None else max(self.maximum, bounded)
        bin_index = min(19, int(bounded * 20.0))
        lower = bin_index / 20.0
        upper = (bin_index + 1) / 20.0
        self.histogram["{:.2f}-{:.2f}".format(lower, upper)] += 1

    def to_dict(self) -> Dict[str, object]:
        mean = self.total / self.count if self.count else None
        variance = (
            max(0.0, self.total_squared / self.count - mean * mean)
            if self.count and mean is not None
            else None
        )
        return {
            "count": self.count,
            "mean": mean,
            "variance": variance,
            "std": math.sqrt(variance) if variance is not None else None,
            "min": self.minimum,
            "max": self.maximum,
            "histogram": dict(sorted(self.histogram.items())),
        }


class MergeCurveTracker:
    """Record compression-local similarity without changing merge decisions."""

    def __init__(self, pta_node_count: int, config: ReconstructionConfig):
        self.pta_node_count = int(pta_node_count)
        self.config = config
        self.checkpoints: list[Dict[str, object]] = []
        self._start_attempted = 0
        self._start_evaluated = 0
        self._accepted = DistanceAudit()
        self._components = {
            "next_token_jsd": DistanceAudit(),
            "successor_path_jsd": DistanceAudit(),
            "transition_jaccard_distance": DistanceAudit(),
        }

    def add_accepted(self, distances: Dict[str, float]) -> None:
        self._accepted.add(distances["combined_distance"])
        for name, audit in self._components.items():
            audit.add(distances[name])

    def checkpoint(
        self,
        attempted_pairs: int,
        evaluated_pairs: int,
        accepted_merges: int,
        force: bool = False,
        best_candidate_distance: DistanceAudit | None = None,
        round_merge_yield: float | None = None,
    ) -> bool:
        interval = int(self.config.merge_curve_interval_merges)
        if self._accepted.count == 0 and (
            best_candidate_distance is None
            or best_candidate_distance.count == 0
        ):
            return False
        if not force and self._accepted.count < interval:
            return False
        window_attempted = attempted_pairs - self._start_attempted
        window_evaluated = evaluated_pairs - self._start_evaluated
        checkpoint: Dict[str, object] = {
            "accepted_merges": accepted_merges,
            "state_count": self.pta_node_count - accepted_merges,
            "pta_state_reduction_ratio": accepted_merges / self.pta_node_count,
            "attempted_pairs": attempted_pairs,
            "statistically_evaluated_pairs": evaluated_pairs,
            "window_attempted_pairs": window_attempted,
            "window_statistically_evaluated_pairs": window_evaluated,
            "window_accepted_merges": self._accepted.count,
            "window_acceptance_rate": (
                self._accepted.count / window_evaluated if window_evaluated else None
            ),
            "accepted_distance": self._accepted.to_dict(),
            "accepted_component_distances": {
                name: audit.to_dict() for name, audit in self._components.items()
            },
            "best_candidate_distance": (
                best_candidate_distance.to_dict()
                if best_candidate_distance is not None
                else None
            ),
            "round_merge_yield": round_merge_yield,
        }
        self.checkpoints.append(checkpoint)
        self._start_attempted = attempted_pairs
        self._start_evaluated = evaluated_pairs
        self._accepted = DistanceAudit()
        self._components = {
            "next_token_jsd": DistanceAudit(),
            "successor_path_jsd": DistanceAudit(),
            "transition_jaccard_distance": DistanceAudit(),
        }
        return False


class PTAStateMerger:
    """M-06 priority merging with local Hoeffding checks and state floors."""

    def __init__(self, config: ReconstructionConfig):
        if config.method_version != "M-06":
            raise ValueError("Only M-06 reconstruction is supported. Use archived sources for historical methods.")
        if config.implementation_revision not in {"M-06-r3", "M-06-r4"}:
            raise ValueError("Unsupported M-06 implementation revision.")
        if config.backend != "pta_state_merger":
            raise ValueError("Unsupported reconstruction backend.")
        if config.priority_candidate_scope not in {"retrieved", "all_pairs"}:
            raise ValueError("Priority candidate scope must be retrieved or all_pairs.")
        for name in ("suffix_length", "max_suffixes_per_state", "min_depth"):
            value = getattr(config, name)
            if type(value) is not int or value < 0:
                raise ValueError(name + " must be a nonnegative integer.")
        for name in ("priority_refresh_interval_merges", "priority_max_candidate_pairs",
                     "priority_retrieval_batch_pairs",
                     "profile_neighbor_window", "adaptive_neighbor_window_max",
                     "best_first_neighbors_per_state", "merge_curve_interval_merges"):
            value = getattr(config, name)
            if type(value) is not int or value < 1:
                raise ValueError(name + " must be a positive integer.")
        if config.adaptive_neighbor_window_max < config.profile_neighbor_window:
            raise ValueError("The maximum neighbor window must cover the initial window.")
        if (not math.isfinite(config.adaptive_neighbor_growth_factor)
                or config.adaptive_neighbor_growth_factor <= 1):
            raise ValueError("adaptive_neighbor_growth_factor must be finite and greater than one.")
        if type(config.best_first_heuristic_orderings) is not int or config.best_first_heuristic_orderings not in {1, 2, 3}:
            raise ValueError("best_first_heuristic_orderings must be 1, 2, or 3.")
        if type(config.best_first_mutual_neighbors) is not bool:
            raise ValueError("best_first_mutual_neighbors must be boolean.")
        if config.implementation_revision == "M-06-r4" and config.best_first_mutual_neighbors:
            raise ValueError("M-06-r4 uses progressive pair batches, not mutual-neighbor filtering.")
        if (config.implementation_revision == "M-06-r4"
                and config.priority_retrieval_batch_pairs > config.priority_max_candidate_pairs):
            raise ValueError("The configured retrieval batch exceeds the candidate memory guard.")
        if config.minimum_state_count is not None and (
            type(config.minimum_state_count) is not int or config.minimum_state_count < 1
        ):
            raise ValueError("minimum_state_count must be a positive integer.")
        alpha = config.hoeffding_compatibility_alpha
        if isinstance(alpha, bool) or not math.isfinite(alpha) or not 0 < alpha < 1:
            raise ValueError("hoeffding_compatibility_alpha must lie in (0, 1).")
        weights = (config.lambda_next, config.lambda_suffix, config.lambda_transition)
        if any(not math.isfinite(w) or w < 0 for w in weights) or sum(weights) <= 0:
            raise ValueError("Profile-distance weights must be finite, nonnegative and nonzero.")
        self.config = config

    def fit(
        self,
        traces: Sequence[ResponseTrace],
        checkpoint_path: str | Path | None = None,
        checkpoint_interval_seconds: float = 3600.0,
        stop_requested: Callable[[], bool] | None = None,
        preparation_source_path: str | Path | None = None,
        preparation_source_config: ReconstructionConfig | Callable[[], ReconstructionConfig] | None = None,
        preparation_cache_path: str | Path | None = None,
        checkpoint_progress: Callable[[Dict[str, object]], None] | None = None,
        checkpoint_import_provenance: dict | None = None,
    ) -> LearnedAutomaton:
        from .candidate_workspace import candidate_storage_session
        with candidate_storage_session(checkpoint_path):
            return self._fit(
                traces, checkpoint_path, checkpoint_interval_seconds, stop_requested,
                preparation_source_path, preparation_source_config, preparation_cache_path,
                checkpoint_progress, checkpoint_import_provenance,
            )

    def _fit(
        self,
        traces: Sequence[ResponseTrace],
        checkpoint_path: str | Path | None = None,
        checkpoint_interval_seconds: float = 3600.0,
        stop_requested: Callable[[], bool] | None = None,
        preparation_source_path: str | Path | None = None,
        preparation_source_config: ReconstructionConfig | Callable[[], ReconstructionConfig] | None = None,
        preparation_cache_path: str | Path | None = None,
        checkpoint_progress: Callable[[Dict[str, object]], None] | None = None,
        checkpoint_import_provenance: dict | None = None,
    ) -> LearnedAutomaton:
        if not traces:
            raise ValueError("Cannot fit PTAStateMerger without traces.")
        if checkpoint_interval_seconds <= 0.0:
            raise ValueError("checkpoint_interval_seconds must be positive.")

        checkpoint = Path(checkpoint_path) if checkpoint_path is not None else None
        run_fingerprint = _merge_run_fingerprint(traces, self.config)
        loaded_checkpoint = None
        if checkpoint is not None and checkpoint.is_file():
            loaded_checkpoint = _load_verified_pickle(checkpoint)
            if not isinstance(loaded_checkpoint, dict):
                raise RuntimeError("Merge checkpoint must contain a mapping.")
            if loaded_checkpoint.get("schema_version") != MERGE_CHECKPOINT_SCHEMA_VERSION:
                raise RuntimeError("Unsupported merge checkpoint schema version.")
            if loaded_checkpoint.get("run_fingerprint") != run_fingerprint:
                raise RuntimeError(
                    "Merge checkpoint does not match the locked traces and configuration."
                )
            if loaded_checkpoint.get("checkpoint_import_provenance") != checkpoint_import_provenance:
                raise RuntimeError("Merge checkpoint import provenance differs from its authorization.")
        elif checkpoint_import_provenance is not None:
            raise RuntimeError("An imported history cannot restart without its saved checkpoint.")
        pinned_preparation = (
            loaded_checkpoint.get("preparation_reuse") if loaded_checkpoint is not None else None
        )
        cache = Path(preparation_cache_path) if preparation_cache_path is not None else None
        if pinned_preparation is not None:
            pinned_path = Path(pinned_preparation["cache_path"])
            if cache is not None and cache.resolve() != pinned_path.resolve():
                raise RuntimeError("Cannot change the preparation cache during resume.")
            cache = pinned_path
        elif cache is None and preparation_source_path is not None and checkpoint is not None:
            cache = checkpoint.parent / "preparation_cache" / "unmerged.pkl"
        preparation_reuse = None
        if cache is not None:
            if not cache.is_file() and pinned_preparation is None:
                if preparation_source_path is None:
                    raise FileNotFoundError("Frozen preparation cache is missing: {}".format(cache))
                freeze_unmerged_preparation(
                    preparation_source_path, cache, preparation_source_config, traces=traces
                )
            pta, pta_profiles, preparation_reuse = _load_frozen_preparation(
                cache, traces, self.config, pinned_preparation
            )
            resumed_from_preparation_checkpoint, preparation_checkpoint_write_count = True, 0
        elif preparation_source_path is not None:
            original_config = (
                preparation_source_config() if callable(preparation_source_config)
                else preparation_source_config
            )
            original_config = policy_mapping(original_config)
            pta, pta_profiles, preparation_reuse = reuse_unmerged_preparation(
                Path(preparation_source_path), traces, original_config, self.config
            )
            resumed_from_preparation_checkpoint, preparation_checkpoint_write_count = True, 0
        else:
            (
                pta, pta_profiles, resumed_from_preparation_checkpoint,
                preparation_checkpoint_write_count,
            ) = prepare_pta_profiles(
                traces, self.config, checkpoint, checkpoint_interval_seconds,
                stop_requested, run_fingerprint,
            )
        union_find = UnionFind(len(pta.nodes))
        component_profiles = dict(pta_profiles)
        progressive_search = self.config.implementation_revision == "M-06-r4"

        attempted_pairs = 0
        accepted_merges = 0
        accepted_transactions = 0
        redundant_pairs = 0
        statistically_evaluated_pairs = 0
        recursive_compatibility_checks = 0
        recursive_compatibility_rejections = 0
        recursive_closure_merges = 0
        maximum_recursive_compatibility_depth = 0
        floor_guard_blocked_transactions = 0
        distance_audit = DistanceAudit()
        accepted_distance_audit = DistanceAudit()
        component_distance_audits = {
            "next_token_jsd": DistanceAudit(),
            "successor_path_jsd": DistanceAudit(),
            "transition_jaccard_distance": DistanceAudit(),
        }
        accepted_component_distance_audits = {
            "next_token_jsd": DistanceAudit(),
            "successor_path_jsd": DistanceAudit(),
            "transition_jaccard_distance": DistanceAudit(),
        }
        merge_curve = MergeCurveTracker(len(pta.nodes), self.config)
        minimum_state_count_reached = False
        last_checkpoint_time = time.monotonic()
        resumed_from_checkpoint = False
        checkpoint_write_count = 0
        last_request_poll_time = last_checkpoint_time
        request_poll_interval = min(1.0, checkpoint_interval_seconds)
        active_transaction: Dict[str, object] = {}
        priority_state: Dict[str, object] = {
            "phase": "rank", "queue": None, "active_pair": None,
            "refresh_accepted": 0, "selection_audit": [], "stop_reason": None,
            "rejected_pairs": {}, "rejected_by_root": {},
            "neighbor_window": int(self.config.profile_neighbor_window),
            "retrieval_rounds": [], "hoeffding_audit": {},
        }
        last_transaction_groups: tuple[tuple[int, ...], ...] = ()
        last_transaction_score_preserving_roots: set[int] = set()
        last_transaction_dependencies: set[int] = set()

        if loaded_checkpoint is not None:
            loaded = loaded_checkpoint
            if int(loaded.get("pta_node_count", -1)) != len(pta.nodes):
                raise RuntimeError("Merge checkpoint PTA size does not match the input.")
            union_find = loaded["union_find"]
            component_profiles = loaded["component_profiles"]
            attempted_pairs = int(loaded["attempted_pairs"])
            accepted_merges = int(loaded["accepted_merges"])
            accepted_transactions = int(loaded["accepted_transactions"])
            redundant_pairs = int(loaded["redundant_pairs"])
            statistically_evaluated_pairs = int(
                loaded["statistically_evaluated_pairs"]
            )
            recursive_compatibility_checks = int(
                loaded["recursive_compatibility_checks"]
            )
            recursive_compatibility_rejections = int(
                loaded["recursive_compatibility_rejections"]
            )
            recursive_closure_merges = int(loaded["recursive_closure_merges"])
            maximum_recursive_compatibility_depth = int(
                loaded["maximum_recursive_compatibility_depth"]
            )
            floor_guard_blocked_transactions = int(
                loaded["floor_guard_blocked_transactions"]
            )
            distance_audit = loaded["distance_audit"]
            accepted_distance_audit = loaded["accepted_distance_audit"]
            component_distance_audits = loaded["component_distance_audits"]
            accepted_component_distance_audits = loaded[
                "accepted_component_distance_audits"
            ]
            merge_curve = loaded["merge_curve"]
            minimum_state_count_reached = bool(
                loaded["minimum_state_count_reached"]
            )
            active_transaction = loaded.get("active_transaction", {})
            priority_state = loaded.get("priority_state", priority_state)
            resumed_from_checkpoint = True

        from .candidate_storage import (
            CandidateStorageError, DiskRejectedPairs, MAX_RETRIEVAL_AUDIT_ROWS,
            migrate_priority_storage, validate_retrieval_audit,
        )
        if progressive_search:
            validate_retrieval_audit(priority_state["retrieval_rounds"])
        if progressive_search and isinstance(priority_state["rejected_pairs"], DiskRejectedPairs):
            migrate_priority_storage(priority_state)
            priority_state["rejected_pairs"].store.validate_roots(
                component_profiles, priority_state["active_pair"],
            )
        elif progressive_search:
            priority_state["rejected_reference_count"] = sum(
                map(len, priority_state["rejected_pairs"].values())
            )

        successor_index = ComponentSuccessorIndex(pta, union_find)

        def save_merge_checkpoint(force: bool = False, *, resource_failure: bool = False) -> None:
            nonlocal last_checkpoint_time
            nonlocal last_request_poll_time
            nonlocal checkpoint_write_count
            if checkpoint is None:
                return
            now = time.monotonic()
            requested = False
            if not resource_failure and stop_requested is not None and (
                force or now - last_request_poll_time >= request_poll_interval
            ):
                requested = bool(stop_requested())
                last_request_poll_time = now
            if (
                not force
                and not requested
                and now - last_checkpoint_time < checkpoint_interval_seconds
            ):
                return
            payload = {
                "schema_version": MERGE_CHECKPOINT_SCHEMA_VERSION,
                "run_fingerprint": run_fingerprint,
                "pta_node_count": len(pta.nodes),
                "saved_unix_time": time.time(),
                "union_find": union_find,
                "component_profiles": component_profiles,
                "attempted_pairs": attempted_pairs,
                "accepted_merges": accepted_merges,
                "accepted_transactions": accepted_transactions,
                "redundant_pairs": redundant_pairs,
                "statistically_evaluated_pairs": statistically_evaluated_pairs,
                "recursive_compatibility_checks": recursive_compatibility_checks,
                "recursive_compatibility_rejections": (
                    recursive_compatibility_rejections
                ),
                "recursive_closure_merges": recursive_closure_merges,
                "maximum_recursive_compatibility_depth": (
                    maximum_recursive_compatibility_depth
                ),
                "floor_guard_blocked_transactions": (
                    floor_guard_blocked_transactions
                ),
                "distance_audit": distance_audit,
                "accepted_distance_audit": accepted_distance_audit,
                "component_distance_audits": component_distance_audits,
                "accepted_component_distance_audits": (
                    accepted_component_distance_audits
                ),
                "merge_curve": merge_curve,
                "minimum_state_count_reached": minimum_state_count_reached,
                "active_transaction": active_transaction,
                "priority_state": priority_state,
                "preparation_reuse": preparation_reuse,
            }
            if checkpoint_import_provenance is not None:
                payload["checkpoint_import_provenance"] = checkpoint_import_provenance
            if isinstance(priority_state["rejected_pairs"], DiskRejectedPairs):
                _atomic_pickle(checkpoint, payload, attached_stores=True)
            else:
                _atomic_pickle(checkpoint, payload)
            if checkpoint_progress is not None:
                ranking = priority_state.get("ranking_state", {})
                progress = {
                    "event": "merge_checkpoint", "saved_unix_time": payload["saved_unix_time"],
                    "run_fingerprint": run_fingerprint, "pta_states": len(pta.nodes),
                    "current_states": len(component_profiles), "accepted_merges": accepted_merges,
                    "attempted_pairs": attempted_pairs, "phase": priority_state["phase"],
                    "neighbor_window": priority_state["neighbor_window"],
                    "ranking_scored_pairs": ranking.get("scored_pairs", 0),
                    "ranking_node_count": ranking.get("node_count", 0),
                    "ranking_ordering_index": ranking.get("ordering_index", 0),
                    "ranking_offset": ranking.get("offset", 0),
                    "ranking_position": ranking.get("position", 0),
                }
                # Progress transport must not prevent the checkpoint exit code.
                with suppress(OSError):
                    checkpoint_progress(progress)
            checkpoint_write_count += 1
            last_checkpoint_time = time.monotonic()
            if requested:
                raise MergeCheckpointRequested(
                    "Merge checkpoint requested and written to {}.".format(checkpoint)
                )

        def evaluate_candidate(node_a: int, node_b: int) -> tuple[float | None, bool]:
            nonlocal attempted_pairs
            nonlocal accepted_merges
            nonlocal accepted_transactions
            nonlocal redundant_pairs
            nonlocal statistically_evaluated_pairs
            nonlocal recursive_compatibility_checks
            nonlocal recursive_compatibility_rejections
            nonlocal recursive_closure_merges
            nonlocal maximum_recursive_compatibility_depth
            nonlocal floor_guard_blocked_transactions
            nonlocal minimum_state_count_reached
            nonlocal last_transaction_groups
            nonlocal last_transaction_score_preserving_roots
            nonlocal last_transaction_dependencies

            last_transaction_groups = ()
            last_transaction_score_preserving_roots = set()
            last_transaction_dependencies = {node_a, node_b}

            resuming_transaction = bool(active_transaction)
            if not resuming_transaction:
                attempted_pairs += 1
            root_a = union_find.find(node_a)
            root_b = union_find.find(node_b)
            if root_a == root_b:
                redundant_pairs += 1
                return None, False
            if not resuming_transaction:
                statistically_evaluated_pairs += 1

            def checkpoint_transaction(progress: Dict[str, object]) -> None:
                save_merge_checkpoint()

            transaction = plan_recursive_merge_transaction(
                pta,
                union_find,
                component_profiles,
                root_a,
                root_b,
                self.config,
                successor_index=successor_index,
                resume_state=active_transaction,
                progress_callback=checkpoint_transaction,
            )
            if "tentative" in active_transaction:
                last_transaction_dependencies.update(active_transaction["tentative"].parent)
            active_transaction.clear()
            audit = priority_state.setdefault("hoeffding_audit", {})
            for check in transaction.checks:
                status = check.hoeffding["status"]
                audit[status] = int(audit.get(status, 0)) + 1
            recursive_compatibility_checks += len(transaction.checks)
            maximum_recursive_compatibility_depth = max(
                maximum_recursive_compatibility_depth,
                max((check.depth for check in transaction.checks), default=0),
            )
            root_check = transaction.checks[0]
            distances = root_check.distances
            distance = distances["combined_distance"]
            distance_audit.add(distance)
            for name, audit in component_distance_audits.items():
                audit.add(distances[name])
            if isinstance(transaction, MergeTransaction):
                current_state_count = len(pta.nodes) - accepted_merges
                next_state_count = current_state_count - transaction.reduction_count
                if (
                    self.config.minimum_state_count is not None
                    and next_state_count < self.config.minimum_state_count
                ):
                    floor_guard_blocked_transactions += 1
                    return distance, False
                accepted_transactions += 1
                accepted_distance_audit.add(distance)
                for name, audit in accepted_component_distance_audits.items():
                    audit.add(distances[name])
                for group in transaction.groups:
                    active_roots = tuple(
                        sorted({union_find.find(root) for root in group})
                    )
                    edges = successor_index.combined(active_roots)
                    anchor = active_roots[0]
                    for other in active_roots[1:]:
                        union_find.union(anchor, other)
                        anchor = union_find.find(anchor)
                    merged_root = union_find.find(anchor)
                    old_profile = component_profiles[merged_root]
                    merged_profile = transaction.checked_profiles[group]
                    if (
                        old_profile.next_token_probs == merged_profile.next_token_probs
                        and old_profile.successor_path_probs == merged_profile.successor_path_probs
                        and old_profile.outgoing_labels == merged_profile.outgoing_labels
                    ):
                        last_transaction_score_preserving_roots.add(merged_root)
                    for old_root in active_roots:
                        if old_root != merged_root:
                            component_profiles.pop(old_root, None)
                    component_profiles[merged_root] = replace(
                        transaction.checked_profiles[group], state_id=merged_root
                    )
                    successor_index.committed(active_roots, edges)
                accepted_merges += transaction.reduction_count
                last_transaction_groups = transaction.groups
                recursive_closure_merges += max(
                    0, transaction.reduction_count - 1
                )
                for check in transaction.checks:
                    merge_curve.add_accepted(check.distances)
                merge_curve.checkpoint(
                    attempted_pairs, statistically_evaluated_pairs, accepted_merges
                )
                if (
                    self.config.minimum_state_count is not None
                    and len(pta.nodes) - accepted_merges
                    <= self.config.minimum_state_count
                ):
                    minimum_state_count_reached = True
                return distance, True

            if transaction.rejected_depth > 0:
                recursive_compatibility_rejections += 1
            return distance, False

        from .candidate_queue import DynamicCandidateQueue
        from .candidate_storage import DiskCandidateQueue

        def current_distance(left: int, right: int) -> float:
            return profile_distance(component_profiles[left], component_profiles[right], self.config)

        def spill_if_needed():
            if progressive_search and not isinstance(priority_state["rejected_pairs"], DiskRejectedPairs):
                queue = priority_state["queue"]
                retained_references = (
                    len(priority_state["rejected_pairs"])
                    + priority_state["rejected_reference_count"]
                    + (0 if queue is None else 2 * queue.known_pair_count)
                )
                if retained_references > self.config.priority_max_candidate_pairs:
                    migrate_priority_storage(priority_state, profiles=component_profiles)
                    save_merge_checkpoint(force=True)

        def guard_retrieval_audit():
            if (progressive_search and self.config.priority_candidate_scope == "retrieved"
                    and priority_state["phase"] == "rank" and "ranked_pairs" not in priority_state
                    and len(priority_state["retrieval_rounds"]) == MAX_RETRIEVAL_AUDIT_ROWS
                    and not (self.config.minimum_state_count is not None
                             and len(component_profiles) <= self.config.minimum_state_count)):
                save_merge_checkpoint(force=True, resource_failure=True)
                raise CandidateStorageError(
                    "Retrieval audit reached its technical row limit. This is not candidate exhaustion."
                )

        guard_retrieval_audit()
        spill_if_needed()
        save_merge_checkpoint(force=True)
        while priority_state["phase"] != "complete":
            guard_retrieval_audit()
            spill_if_needed()
            if self.config.minimum_state_count is not None and (
                len(component_profiles) <= self.config.minimum_state_count
            ):
                minimum_state_count_reached = True
                priority_state.update(phase="complete", stop_reason="minimum_state_count")
                break
            if priority_state["phase"] == "rank":
                roots = sorted(
                    root for root, profile in component_profiles.items()
                    if profile.depth_min >= self.config.min_depth
                )
                if self.config.priority_candidate_scope == "all_pairs":
                    pair_count = len(roots) * (len(roots) - 1) // 2
                    if pair_count > self.config.priority_max_candidate_pairs:
                        raise ValueError(
                            "Exhaustive priority search needs {} pairs, above the "
                            "configured memory guard {}. No sampled substitute was used."
                            .format(pair_count, self.config.priority_max_candidate_pairs)
                        )
                if priority_state["queue"] is None:
                    priority_state["queue"] = (
                        DiskCandidateQueue(priority_state["rejected_pairs"].store, clear=True)
                        if isinstance(priority_state["rejected_pairs"], DiskRejectedPairs)
                        else DynamicCandidateQueue()
                    )
                    priority_state["seed_cursor"] = 0
                    if not progressive_search:
                        priority_state["rejected_pairs"] = {}
                        priority_state["rejected_by_root"] = {}
                if self.config.priority_candidate_scope == "all_pairs":
                    pairs = (
                        pair for pair in combinations(roots, 2)
                        if not progressive_search or pair not in priority_state["rejected_pairs"]
                    )
                else:
                    def checkpoint_priority_ranking(progress: Dict[str, object]) -> None:
                        priority_state["ranking_state"] = progress
                        save_merge_checkpoint()

                    if "ranked_pairs" not in priority_state:
                        ranking = rank_best_first_profile_pairs(
                            roots, component_profiles, int(priority_state["neighbor_window"]),
                            self.config, resume_state=priority_state.get("ranking_state"),
                            progress_callback=checkpoint_priority_ranking,
                            excluded_pairs=priority_state["rejected_pairs"] if progressive_search else None,
                        )
                        priority_state["ranked_pairs"] = ranking.pairs
                        priority_state["batch_has_deferred_pairs"] = ranking.has_deferred_pairs
                        priority_state["retrieval_rounds"].append({
                            "neighbor_window": priority_state["neighbor_window"],
                            "state_count": len(component_profiles),
                            "evidence_eligible_state_count": len(roots),
                            "candidate_pairs": len(ranking.pairs),
                            "scored_pairs": ranking.scored_pair_count,
                            **({
                                "has_deferred_pairs": ranking.has_deferred_pairs,
                                "cached_rejections": len(priority_state["rejected_pairs"]),
                            } if progressive_search else {}),
                        })
                    pairs = iter(priority_state["ranked_pairs"])
                queue = priority_state["queue"]
                for seed_index, pair in enumerate(pairs):
                    if seed_index < int(priority_state["seed_cursor"]):
                        continue
                    if seed_index >= self.config.priority_max_candidate_pairs:
                        raise ValueError("Priority candidate memory guard exceeded.")
                    queue.add_pairs((pair,), current_distance)
                    priority_state["seed_cursor"] = seed_index + 1
                    spill_if_needed()
                    queue = priority_state["queue"]
                    if seed_index % 1000 == 0:
                        save_merge_checkpoint()
                priority_state.pop("ranking_state", None)
                priority_state.pop("ranked_pairs", None)
                priority_state.update(phase="merge", refresh_accepted=accepted_merges)
                save_merge_checkpoint()

            queue = priority_state["queue"]
            if priority_state["active_pair"] is None:
                priority_state["active_pair"] = queue.pop()
            selected = priority_state["active_pair"]
            if selected is None:
                if (accepted_merges > int(priority_state["refresh_accepted"])
                        or (progressive_search and self.config.priority_candidate_scope == "retrieved"
                            and priority_state.get("batch_has_deferred_pairs", False))):
                    priority_state.update(phase="rank", queue=None)
                    guard_retrieval_audit()
                    save_merge_checkpoint()
                    continue
                window_limit = self.config.adaptive_neighbor_window_max
                if progressive_search:
                    window_limit = min(window_limit, max(1, sum(
                        profile.depth_min >= self.config.min_depth
                        for profile in component_profiles.values()
                    ) - 1))
                if (self.config.priority_candidate_scope == "retrieved"
                        and int(priority_state["neighbor_window"]) < window_limit):
                    priority_state.update(
                        phase="rank", queue=None,
                        neighbor_window=min(window_limit,
                            max(int(priority_state["neighbor_window"]) + 1,
                                int(priority_state["neighbor_window"] * self.config.adaptive_neighbor_growth_factor))),
                    )
                    guard_retrieval_audit()
                    save_merge_checkpoint()
                    continue
                stop_reason = "candidate_set_exhausted"
                if progressive_search:
                    stop_reason = (
                        "candidate_neighborhood_exhausted"
                        if self.config.priority_candidate_scope == "retrieved"
                        else "eligible_pairs_exhausted"
                    )
                priority_state.update(phase="complete", stop_reason=stop_reason)
                break
            distance, node_a, node_b = selected
            _, accepted = evaluate_candidate(node_a, node_b)
            rejected_pairs = priority_state["rejected_pairs"]
            rejected_by_root = priority_state["rejected_by_root"]
            if accepted:
                queue.remap(
                    last_transaction_groups, union_find.find, current_distance,
                    score_preserving_roots=last_transaction_score_preserving_roots,
                )
                # A rejection can depend on descendants, not only on its endpoints.
                changed = {root for group in last_transaction_groups for root in group}
                if isinstance(rejected_pairs, DiskRejectedPairs):
                    invalidated = rejected_pairs.invalidate(changed)
                else:
                    invalidated = sorted({
                        pair for root in changed for pair in rejected_by_root.get(root, ())
                    })
                try:
                    for pair in invalidated:
                        if not isinstance(rejected_pairs, DiskRejectedPairs):
                            dependencies = rejected_pairs.pop(pair)
                            if progressive_search:
                                priority_state["rejected_reference_count"] -= len(dependencies)
                            for root in dependencies:
                                references = rejected_by_root[root]
                                references.discard(pair)
                                if not references:
                                    del rejected_by_root[root]
                        mapped = tuple(union_find.find(root) for root in pair)
                        queue.add_pairs((mapped,), current_distance)
                finally:
                    if isinstance(rejected_pairs, DiskRejectedPairs):
                        invalidated.close()
            else:
                pair = (node_a, node_b)
                if progressive_search and not isinstance(rejected_pairs, DiskRejectedPairs):
                    priority_state["rejected_reference_count"] += (
                        len(last_transaction_dependencies) - len(rejected_pairs.get(pair, ()))
                    )
                rejected_pairs[pair] = last_transaction_dependencies
                if not isinstance(rejected_pairs, DiskRejectedPairs):
                    for root in last_transaction_dependencies:
                        rejected_by_root.setdefault(root, set()).add(pair)
            audit = priority_state["selection_audit"]
            if len(audit) < 256:
                audit.append({"left": node_a, "right": node_b, "distance": distance,
                              "accepted": accepted, "state_count": len(component_profiles)})
            priority_state["active_pair"] = None
            if accepted_merges - int(priority_state["refresh_accepted"]) >= self.config.priority_refresh_interval_merges:
                priority_state.update(phase="rank", queue=None)
            guard_retrieval_audit()
            spill_if_needed()
            save_merge_checkpoint()
        save_merge_checkpoint(force=True)

        merge_curve.checkpoint(
            attempted_pairs,
            statistically_evaluated_pairs,
            accepted_merges,
            force=True,
        )

        components: Dict[int, List[int]] = defaultdict(list)
        for node in pta.nodes:
            components[union_find.find(node.id)].append(node.id)

        sorted_roots = sorted(components)
        root_to_state = {root: idx for idx, root in enumerate(sorted_roots)}
        node_to_state = {
            node_id: root_to_state[union_find.find(node_id)] for node_id in range(len(pta.nodes))
        }
        state_profiles = {
            root_to_state[root]: replace(
                component_profiles[root], state_id=root_to_state[root]
            )
            for root in components
        }
        prompt_to_state = {
            prompt_id: node_to_state[node_id]
            for prompt_id, node_id in pta.final_node_by_prompt_id.items()
        }
        prompt_to_state_path = {
            prompt_id: tuple(node_to_state[node_id] for node_id in pta_node_path(pta, node_id))
            for prompt_id, node_id in pta.final_node_by_prompt_id.items()
        }
        transitions = export_transitions(pta, node_to_state)
        determinism_conflicts = find_determinism_conflicts(transitions)
        if determinism_conflicts:
            raise RuntimeError(
                "State merging produced a non-deterministic quotient. "
                "This violates the recursive congruence invariant."
            )

        return LearnedAutomaton(
            backend=self.config.backend,
            threshold=None,
            pta_node_count=len(pta.nodes),
            state_count=len(state_profiles),
            transition_count=len(transitions),
            node_to_state=node_to_state,
            prompt_to_state=prompt_to_state,
            prompt_to_state_path=prompt_to_state_path,
            prompt_to_pta_node=dict(pta.final_node_by_prompt_id),
            state_profiles=state_profiles,
            pta_profiles=pta_profiles,
            transitions=transitions,
            diagnostics={
                "method_version": "M-06",
                "implementation_revision": self.config.implementation_revision,
                "attempted_pairs": attempted_pairs,
                "accepted_merges": accepted_merges,
                "statistically_evaluated_pairs": statistically_evaluated_pairs,
                "accepted_transactions": accepted_transactions,
                "redundant_pairs": redundant_pairs,
                "rejected_pairs": statistically_evaluated_pairs - accepted_transactions,
                "recursive_compatibility_checks": recursive_compatibility_checks,
                "recursive_compatibility_rejections": recursive_compatibility_rejections,
                "recursive_closure_merges": recursive_closure_merges,
                "maximum_recursive_compatibility_depth": maximum_recursive_compatibility_depth,
                "floor_guard_blocked_transactions": floor_guard_blocked_transactions,
                "deterministic": True,
                "determinism_conflict_count": 0,
                "pta_state_reduction_ratio": accepted_merges / len(pta.nodes),
                "pta_state_retention_ratio": len(state_profiles) / len(pta.nodes),
                "minimum_state_count": self.config.minimum_state_count,
                "minimum_state_count_reached": minimum_state_count_reached,
                "distance_audit": distance_audit.to_dict(),
                "accepted_distance_audit": accepted_distance_audit.to_dict(),
                "component_distance_audits": {k: v.to_dict() for k, v in component_distance_audits.items()},
                "accepted_component_distance_audits": {k: v.to_dict() for k, v in accepted_component_distance_audits.items()},
                "merge_curve": merge_curve.checkpoints,
                "candidate_search_mode": "priority",
                "priority_candidate_scope": self.config.priority_candidate_scope,
                "priority_stop_reason": priority_state["stop_reason"],
                "priority_selection_audit": priority_state["selection_audit"],
                "priority_retrieval_rounds": priority_state["retrieval_rounds"],
                **({
                    "priority_retrieval_policy": "progressive_distance_batches",
                    "priority_retrieval_batch_pairs": self.config.priority_retrieval_batch_pairs,
                    "priority_rejected_cache_size": len(priority_state["rejected_pairs"]),
                    "priority_order_guarantee": "minimum_current_distance_in_active_queue",
                    "candidate_window_max": self.config.adaptive_neighbor_window_max,
                } if progressive_search else {}),
                "stop_reason": priority_state["stop_reason"],
                "hoeffding_compatibility": {
                    "nominal_per_event_alpha": self.config.hoeffding_compatibility_alpha,
                    "rule": "absolute_event_difference_le_two_sample_hoeffding_radius",
                    "absolute_tolerance": None,
                    "multiple_comparison_correction": False,
                    "positive_equivalence_proven": False,
                    "global_error_guarantee": False,
                    "successor_profiles_used_as_samples": False,
                    "decision_counts": priority_state["hoeffding_audit"],
                },
                "preparation_reuse": preparation_reuse,
                "global_minimality_proven": False,
                "checkpoint_schema_version": MERGE_CHECKPOINT_SCHEMA_VERSION,
                "preparation_checkpoint_schema_version": PREPARATION_CHECKPOINT_SCHEMA_VERSION,
                "resumed_from_preparation_checkpoint": resumed_from_preparation_checkpoint,
                "preparation_checkpoint_write_count": preparation_checkpoint_write_count,
                "resumed_from_checkpoint": resumed_from_checkpoint,
                "checkpoint_write_count": checkpoint_write_count,
                "root_state_id": node_to_state[0],
            },
        )




@dataclass(frozen=True)
class ProfilePairRanking:
    """Exact best-first candidates recovered from several cheap orderings."""

    pairs: tuple[tuple[int, int], ...]
    scored_pair_count: int
    nearest_distance_by_node: Dict[int, float]
    heuristic_ordering_count: int
    has_deferred_pairs: bool = False


def rank_best_first_profile_pairs(
    nodes: Sequence[int],
    profiles: Dict[int, StateProfile],
    neighbor_window: int,
    config: ReconstructionConfig,
    resume_state: Dict[str, object] | None = None,
    progress_callback: Callable[[Dict[str, object]], None] | None = None,
    excluded_pairs: Dict[tuple[int, int], object] | None = None,
) -> ProfilePairRanking:
    """Rank local candidates by exact profile distance.

    Cheap deterministic orderings retrieve candidates that are close in the
    next-token, successor-path, or structural profile. Exact distances then
    determine the search order. Compression never enters this ranking.
    R4 returns the globally closest bounded batch within these neighborhoods,
    excluding still-valid rejections. R3 retains its fixed neighbor proposals.
    """

    node_count = len(nodes)
    if node_count < 2:
        return ProfilePairRanking((), 0, {}, 0)
    progressive = config.implementation_revision == "M-06-r4"
    if (not progressive
            and node_count * config.best_first_neighbors_per_state > config.priority_max_candidate_pairs):
        raise ValueError("Priority retrieval exceeds the preallocation candidate memory guard.")
    window = min(max(1, int(neighbor_window)), node_count - 1)
    ordering_count = int(config.best_first_heuristic_orderings)
    neighbor_limit = int(config.best_first_neighbors_per_state)
    batch_limit = config.priority_retrieval_batch_pairs
    if progressive and batch_limit > config.priority_max_candidate_pairs:
        raise ValueError("The configured retrieval batch exceeds the candidate memory guard.")
    excluded = excluded_pairs if progressive and excluded_pairs is not None else {}
    state = resume_state if resume_state is not None else {}
    if state:
        if int(state.get("node_count", -1)) != node_count:
            raise RuntimeError("Candidate-ranking checkpoint has a different node count.")
        if int(state.get("window", -1)) != window:
            raise RuntimeError("Candidate-ranking checkpoint has a different window.")
        top_neighbors = state.get("top_neighbors", {})
        nearest = state["nearest"]
        scored_pairs = int(state["scored_pairs"])
        if progressive and (
            state.get("batch_limit") != batch_limit
            or state.get("excluded_count") != len(excluded)
        ):
            raise RuntimeError("Progressive ranking checkpoint has a different batch or rejection set.")
    else:
        top_neighbors = {} if progressive else {int(node_id): [] for node_id in nodes}
        nearest = {}
        scored_pairs = 0
        state.update(
            {
                "node_count": node_count,
                "window": window,
                "ordering_count": ordering_count,
                "ordering_index": 0,
                "offset": 1,
                "position": 0,
                "top_neighbors": top_neighbors,
                "nearest": nearest,
                "scored_pairs": 0,
            }
        )
        if progressive:
            state.update(
                best_pairs=[], retained_pairs=set(), has_deferred_pairs=False,
                batch_limit=batch_limit, excluded_count=len(excluded), scanned_pairs=0,
            )

    def retain_batch(pair: tuple[int, int], distance: float) -> None:
        heap = state["best_pairs"]
        retained = state["retained_pairs"]
        candidate = (-distance, -pair[0], -pair[1])
        if len(heap) < batch_limit:
            heapq.heappush(heap, candidate)
            retained.add(pair)
        else:
            state["has_deferred_pairs"] = True
            if candidate > heap[0]:
                _, old_left, old_right = heapq.heapreplace(heap, candidate)
                retained.remove((-old_left, -old_right))
                retained.add(pair)

    def retain(node_id: int, other_id: int, distance: float) -> None:
        heap = top_neighbors[node_id]
        # The same pair can be retrieved by several orderings. One neighbor
        # must occupy only one slot in this bounded nearest-neighbor set.
        if any(other_id == retained_id for _, retained_id in heap):
            return
        candidate = (-distance, int(other_id))
        if len(heap) < neighbor_limit:
            heapq.heappush(heap, candidate)
        elif candidate > heap[0]:
            heapq.heapreplace(heap, candidate)
        previous = nearest.get(node_id)
        if previous is None or distance < previous:
            nearest[node_id] = distance

    starting_ordering = int(state["ordering_index"])
    for ordering_index in range(starting_ordering, ordering_count):
        ordered_nodes = _profile_candidate_ordering(
            nodes, profiles, ordering_index
        )
        offset_start = int(state["offset"]) if ordering_index == int(
            state["ordering_index"]
        ) else 1
        for offset in range(offset_start, window + 1):
            position_start = int(state["position"]) if (
                ordering_index == int(state["ordering_index"])
                and offset == int(state["offset"])
            ) else 0
            for index in range(position_start, node_count - offset):
                node_a = int(ordered_nodes[index])
                node_b = int(ordered_nodes[index + offset])
                pair = (min(node_a, node_b), max(node_a, node_b))
                if not progressive or (
                    pair not in excluded and pair not in state["retained_pairs"]
                ):
                    distance = profile_distance(
                        profiles[node_a], profiles[node_b], config
                    )
                    scored_pairs += 1
                    if progressive:
                        retain_batch(pair, distance)
                    else:
                        retain(node_a, node_b, distance)
                        retain(node_b, node_a, distance)
                scanned_pairs = int(state.get("scanned_pairs", 0)) + 1
                state.update(
                    {
                        "ordering_index": ordering_index,
                        "offset": offset,
                        "position": index + 1,
                        "scored_pairs": scored_pairs,
                        "scanned_pairs": scanned_pairs,
                    }
                )
                if progress_callback is not None and scanned_pairs % 50000 == 0:
                    progress_callback(state)
            state["position"] = 0
            state["offset"] = offset + 1
        state.update(
            {
                "ordering_index": ordering_index + 1,
                "offset": 1,
                "position": 0,
            }
        )
        if progress_callback is not None:
            progress_callback(state)

    if progressive:
        ranked = tuple(
            (left, right) for _, left, right in sorted(
                (-distance, -left, -right) for distance, left, right in state["best_pairs"]
            )
        )
        return ProfilePairRanking(
            pairs=ranked, scored_pair_count=scored_pairs,
            nearest_distance_by_node={},
            heuristic_ordering_count=ordering_count,
            has_deferred_pairs=bool(state["has_deferred_pairs"]),
        )

    neighbor_sets = {
        node_id: {other_id for _, other_id in heap}
        for node_id, heap in top_neighbors.items()
    }
    candidate_pairs = set()
    for node_a, neighbors in neighbor_sets.items():
        for node_b in neighbors:
            if (
                config.best_first_mutual_neighbors
                and node_a not in neighbor_sets.get(node_b, set())
            ):
                continue
            candidate_pairs.add((min(node_a, node_b), max(node_a, node_b)))
    ranked = sorted(
        candidate_pairs,
        key=lambda pair: (
            profile_distance(profiles[pair[0]], profiles[pair[1]], config),
            pair,
        ),
    )
    return ProfilePairRanking(
        pairs=tuple(ranked),
        scored_pair_count=scored_pairs,
        nearest_distance_by_node=nearest,
        heuristic_ordering_count=ordering_count,
    )


def _profile_candidate_ordering(
    nodes: Sequence[int],
    profiles: Dict[int, StateProfile],
    ordering_index: int,
) -> tuple[int, ...]:
    """Create one deterministic heuristic ordering for resumable ranking."""

    def probability_signature(values: Dict[object, float]) -> tuple[object, ...]:
        return tuple(
            (key, int(round(probability * 1000.0)))
            for key, probability in sorted(
                values.items(), key=lambda item: (-item[1], item[0])
            )[:4]
        )

    if ordering_index == 0:
        key = lambda node_id: (
            probability_signature(profiles[node_id].next_token_probs),
            tuple(sorted(profiles[node_id].outgoing_labels)[:4]),
            int(profiles[node_id].terminal_count > 0),
            int(node_id),
        )
    elif ordering_index == 1:
        key = lambda node_id: (
            probability_signature(profiles[node_id].successor_path_probs),
            int(profiles[node_id].entropy * 8.0),
            len(profiles[node_id].outgoing_labels),
            int(node_id),
        )
    elif ordering_index == 2:
        key = lambda node_id: (
            tuple(sorted(profiles[node_id].outgoing_labels)[:8]),
            len(profiles[node_id].outgoing_labels),
            int(profiles[node_id].entropy * 8.0),
            int(profiles[node_id].terminal_count > 0),
            int(math.log2(max(profiles[node_id].visit_count, 1))),
            int(node_id),
        )
    else:
        raise ValueError("Unknown profile candidate ordering index.")
    return tuple(sorted(nodes, key=key))


def pta_node_path(pta: PrefixTreeAcceptor, node_id: int) -> tuple[int, ...]:
    path = []
    current_id: int | None = node_id
    while current_id is not None:
        path.append(current_id)
        current_id = pta.nodes[current_id].parent
    return tuple(reversed(path))


def export_transitions(
    pta: PrefixTreeAcceptor,
    node_to_state: Dict[int, int],
) -> List[Dict[str, object]]:
    counts = Counter()
    for node in pta.nodes:
        source = node_to_state[node.id]
        for label, target_node in node.transitions.items():
            target = node_to_state[target_node]
            count = node.transition_counts[label]
            counts[(source, label, target)] += count
    return [
        {"source": source, "label": label, "target": target, "count": count}
        for (source, label, target), count in sorted(counts.items())
    ]


def find_determinism_conflicts(
    transitions: Sequence[Dict[str, object]],
) -> List[Dict[str, object]]:
    """Return source-label pairs that lead to more than one quotient state."""

    targets: Dict[tuple[int, str], set[int]] = defaultdict(set)
    for transition in transitions:
        key = (int(transition["source"]), str(transition["label"]))
        targets[key].add(int(transition["target"]))
    return [
        {"source": source, "label": label, "targets": sorted(target_ids)}
        for (source, label), target_ids in sorted(targets.items())
        if len(target_ids) > 1
    ]
