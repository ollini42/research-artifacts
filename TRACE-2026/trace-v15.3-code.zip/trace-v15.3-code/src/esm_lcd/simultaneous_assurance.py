"""Simultaneous, model-neutral concept-learning assurance (E-04).

The evaluator treats prompt families as the independent sampling units.  It
uses a finite-sample Hoeffding union bound over all primitive means within a
concept and divides each concept's error budget across configured model groups.
"""

from __future__ import annotations

import itertools
import math
from collections import defaultdict
from collections.abc import Iterable, Sequence

EVALUATOR_VERSION = "E-04"
ORDERED_PATH_FAMILIES = {
    "transition_edge_set",
    "contiguous_state_motif",
    "gapped_state_motif",
}
REQUIRED_ROLES = {
    "selected_rule",
    "individual_state_rule",
    "path_rule",
    "visible_text_rule",
}
L1_THRESHOLDS = {
    "mean_development_mcc": 0.35,
    "minimum_development_mcc": 0.20,
    "minimum_test_mcc": 0.20,
    "minimum_positive_sensitivity": 0.65,
    "minimum_family_balanced_auc": 0.55,
    "minimum_prediction_jaccard": 0.60,
}
L2_THRESHOLDS = {
    "minimum_path_gain": 0.05,
    "minimum_order_gain": 0.03,
}
L3_THRESHOLDS = {"minimum_visible_text_margin": 0.02}


def observation_rows(
    examples: Sequence[object],
    role: str,
    family: str,
    predictions: Sequence[int],
    scores: Sequence[float],
) -> list[dict]:
    """Create the required response-level audit rows for one frozen rule."""

    if not (len(examples) == len(predictions) == len(scores)):
        raise ValueError("Examples, predictions, and scores must have equal lengths.")
    return [
        {
            "role": str(role),
            "detector_family": str(family),
            "prompt_id": str(item.prompt_id),
            "family_id": str(item.pair_id or item.prompt_id),
            "condition": str(item.condition),
            "label": int(item.label),
            "score": float(score),
            "prediction": int(prediction),
        }
        for item, prediction, score in zip(
            examples, predictions, scores, strict=True
        )
    ]


def aggregate_simultaneous_learning(rows: Sequence[dict], protocol: dict) -> dict:
    """Apply E-04 to every configured model group and concept.

    The selected state count is the protocol's development-selected primary
    policy.  Rules and thresholds are already frozen in each detector row.
    """

    settings = protocol.get("simultaneous_nested_learning", {})
    if not settings.get("enabled", False):
        return {}
    eta = float(settings["total_error_budget"])
    concept_budgets = {
        str(name): float(value)
        for name, value in settings["concept_error_budgets"].items()
    }
    model_groups = {
        str(name): tuple(str(label) for label in labels)
        for name, labels in settings["model_groups"].items()
    }
    primary_policy = str(protocol["primary_policy_id"])
    minimum_reconstructions = int(settings["minimum_reconstruction_count"])
    contrast_negative_conditions = {
        str(value) for value in settings["contrast_negative_conditions"]
    }

    present_by_concept: dict[str, set[str]] = defaultdict(set)
    for model_name, labels in model_groups.items():
        for row in rows:
            if (
                str(row.get("policy_id")) == primary_policy
                and str(row.get("model_seed")) in labels
            ):
                present_by_concept[str(row["concept_id"])].add(model_name)

    outcomes = []
    criterion_rows = []
    audits = []
    for model_name, labels in model_groups.items():
        model_rows = [
            row
            for row in rows
            if str(row.get("policy_id")) == primary_policy
            and str(row.get("model_seed")) in labels
        ]
        for concept_id in sorted({str(row["concept_id"]) for row in model_rows}):
            group = [row for row in model_rows if str(row["concept_id"]) == concept_id]
            concept_eta = concept_budgets[concept_id]
            group_count = len(present_by_concept[concept_id])
            unit_eta = concept_eta / group_count
            outcome, criteria, audit = evaluate_concept_group(
                concept_id=concept_id,
                model_name=model_name,
                policy_id=primary_policy,
                rows=group,
                error_budget=unit_eta,
                minimum_reconstructions=minimum_reconstructions,
                contrast_negative_conditions=contrast_negative_conditions,
                thresholds=settings.get("thresholds", {}),
                strict_l1_thresholds=settings.get("strict_l1_thresholds", {}),
            )
            outcomes.append(outcome)
            criterion_rows.extend(criteria)
            audits.append(audit)

    evaluated = [row for row in outcomes if row["l1_decision"] != "not_identifiable"]
    return {
        "evaluator_version": EVALUATOR_VERSION,
        "method_decision": (
            "operational"
            if outcomes and len(evaluated) == len(outcomes)
            else "not_operational"
        ),
        "primary_policy_id": primary_policy,
        "total_error_budget": eta,
        "allocated_error_budget": sum(concept_budgets.values()),
        "interval_method": "family_level_hoeffding_union_bound",
        "auc_aggregation": "equal_weight_over_complete_prompt_families",
        "outcomes": outcomes,
        "criteria": criterion_rows,
        "sample_size_audit": audits,
        "evaluated_concept_count": len(evaluated),
        "supported_concept_count": sum(
            row["l1_decision"] == "supported" for row in evaluated
        ),
        "decision_rule": (
            "supported if every lower bound reaches its threshold, not_supported "
            "if any upper bound is below its threshold, inconclusive otherwise"
        ),
        "claim_boundary": (
            "black-box output paths and externally observable behavioral states"
        ),
    }


def evaluate_concept_group(
    *,
    concept_id: str,
    model_name: str,
    policy_id: str,
    rows: Sequence[dict],
    error_budget: float,
    minimum_reconstructions: int,
    contrast_negative_conditions: set[str],
    thresholds: dict,
    strict_l1_thresholds: dict,
) -> tuple[dict, list[dict], dict]:
    """Evaluate one concept for one model group."""

    l1_limits = _thresholds(L1_THRESHOLDS, thresholds.get("l1", {}))
    l2_limits = _thresholds(L2_THRESHOLDS, thresholds.get("l2", {}))
    l3_limits = _thresholds(L3_THRESHOLDS, thresholds.get("l3", {}))
    strict_limits = _thresholds(L1_THRESHOLDS, strict_l1_thresholds)
    evidence = [row.get("simultaneous_nested_learning", {}) for row in rows]
    reason = _identifiability_reason(rows, evidence, minimum_reconstructions)
    base = {
        "concept_id": concept_id,
        "model": model_name,
        "policy_id": policy_id,
        "evaluator_version": EVALUATOR_VERSION,
        "reconstruction_count": len(rows),
        "error_budget": float(error_budget),
    }
    if reason:
        outcome = {
            **base,
            "l1_decision": "not_identifiable",
            "l2_decision": "not_identifiable",
            "l3_decision": "not_identifiable",
            "LEARNED": "?",
            "strict_l1_robustness": False,
            "not_identifiable_reason": reason,
        }
        return (
            outcome,
            [],
            {
                **base,
                "identifiable": False,
                "reason": reason,
                "primitive_bound_count": 0,
            },
        )

    primitive_count = sum(
        17
        + (
            8
            if str(item["development_selection"]["path_family"])
            in ORDERED_PATH_FAMILIES
            else 0
        )
        for item in evidence
    )
    primitive_count += len(rows) * (len(rows) - 1)
    alpha = float(error_budget) / primitive_count

    per_reconstruction = []
    null_denominators = 0
    incomplete_auc_families = 0
    for row, item in zip(rows, evidence, strict=True):
        observations = item["observations"]
        by_role = _by_role(observations)
        selected = metric_intervals(
            by_role["selected_rule"], alpha, contrast_negative_conditions
        )
        individual = metric_intervals(
            by_role["individual_state_rule"], alpha, contrast_negative_conditions
        )
        path = metric_intervals(
            by_role["path_rule"], alpha, contrast_negative_conditions
        )
        visible = metric_intervals(
            by_role["visible_text_rule"], alpha, contrast_negative_conditions
        )
        selection = item["development_selection"]
        record = {
            "reconstruction": str(row["model_seed"]),
            "development_mcc": float(selection["selected_development_mcc"]),
            "selected": selected,
            "path_gain": subtract_intervals(path["mcc"], individual["mcc"]),
            "visible_text_margin": subtract_intervals(path["mcc"], visible["mcc"]),
            "path_family": str(selection["path_family"]),
        }
        if record["path_family"] in ORDERED_PATH_FAMILIES:
            shuffled = metric_intervals(
                by_role["order_shuffled_rule"],
                alpha,
                contrast_negative_conditions,
            )
            reversed_rule = metric_intervals(
                by_role["order_reversed_rule"],
                alpha,
                contrast_negative_conditions,
            )
            control = {
                "lower": max(shuffled["mcc"]["lower"], reversed_rule["mcc"]["lower"]),
                "upper": max(shuffled["mcc"]["upper"], reversed_rule["mcc"]["upper"]),
            }
            record["order_gain"] = subtract_intervals(path["mcc"], control)
        null_denominators += sum(
            metric.get("null_denominator", False)
            for metric in (selected, individual, path, visible)
        )
        incomplete_auc_families += int(selected["incomplete_auc_family_count"])
        per_reconstruction.append(record)

    jaccard_intervals = []
    for left, right in itertools.combinations(evidence, 2):
        jaccard_intervals.append(
            prediction_jaccard_interval(
                _by_role(left["observations"])["selected_rule"],
                _by_role(right["observations"])["selected_rule"],
                alpha,
            )
        )

    l1 = {
        "mean_development_mcc": _point_interval(
            _mean(item["development_mcc"] for item in per_reconstruction)
        ),
        "minimum_development_mcc": _point_interval(
            min(item["development_mcc"] for item in per_reconstruction)
        ),
        "minimum_test_mcc": _minimum_interval(
            item["selected"]["mcc"] for item in per_reconstruction
        ),
        "minimum_positive_sensitivity": _minimum_interval(
            item["selected"]["sensitivity"] for item in per_reconstruction
        ),
        "minimum_family_balanced_auc": _minimum_interval(
            item["selected"]["family_balanced_auc"] for item in per_reconstruction
        ),
        "minimum_prediction_jaccard": _minimum_interval(jaccard_intervals),
    }
    l2 = {
        "minimum_path_gain": _minimum_interval(
            item["path_gain"] for item in per_reconstruction
        )
    }
    order_gains = [
        item["order_gain"] for item in per_reconstruction if "order_gain" in item
    ]
    if order_gains:
        l2["minimum_order_gain"] = _minimum_interval(order_gains)
    l3 = {
        "minimum_visible_text_margin": _minimum_interval(
            item["visible_text_margin"] for item in per_reconstruction
        )
    }

    l1_decision = decide_level(l1, l1_limits)
    l2_decision = nested_decision(
        l1_decision,
        decide_level(
            l2,
            {name: l2_limits[name] for name in l2},
        ),
    )
    l3_decision = nested_decision(l2_decision, decide_level(l3, l3_limits))
    learned = {"supported": 1, "not_supported": 0}.get(l1_decision, "?")
    strict_pass = all(l1[name]["lower"] >= strict_limits[name] for name in l1)
    criteria = _criterion_rows(base, "L1", l1, l1_limits)
    criteria += _criterion_rows(base, "L2", l2, {name: l2_limits[name] for name in l2})
    criteria += _criterion_rows(base, "L3", l3, l3_limits)
    outcome = {
        **base,
        "l1_decision": l1_decision,
        "l2_decision": l2_decision,
        "l3_decision": l3_decision,
        "LEARNED": learned,
        "strict_l1_robustness": strict_pass,
        "ordered_path_evidence_required": bool(order_gains),
        "not_identifiable_reason": None,
    }
    audit = {
        **base,
        "identifiable": True,
        "primitive_bound_count": primitive_count,
        "alpha_per_primitive_bound": alpha,
        "minimum_prompt_family_count": min(
            item["selected"]["family_count"] for item in per_reconstruction
        ),
        "maximum_hoeffding_radius": max(
            item["selected"]["hoeffding_radius"] for item in per_reconstruction
        ),
        "null_denominator_count": null_denominators,
        "incomplete_auc_family_count": incomplete_auc_families,
        "power_audit_required_before_confirmatory_use": True,
    }
    return outcome, criteria, audit


def metric_intervals(
    observations: Sequence[dict],
    alpha: float,
    contrast_negative_conditions: set[str],
) -> dict:
    """Bound MCC, sensitivity, and equal-family-weighted contrastive AUC."""

    families = _families(observations)
    if not families:
        raise ValueError("At least one prompt family is required.")
    family_rows = list(families.values())
    total_rows = sum(len(family) for family in family_rows)
    weights = [len(family) / total_rows for family in family_rows]
    radius = _weighted_hoeffding_radius(weights, alpha)
    rates = {}
    for name, label, prediction in (
        ("tp", 1, 1),
        ("tn", 0, 0),
        ("fp", 0, 1),
        ("fn", 1, 0),
    ):
        values = [
            _mean(
                int(int(row["label"]) == label and int(row["prediction"]) == prediction)
                for row in family
            )
            for family in family_rows
        ]
        rates[name] = _bounded_weighted_mean_interval(values, weights, radius, 0.0, 1.0)
    mcc, null_mcc = _mcc_interval(rates)
    sensitivity, null_sensitivity = _ratio_interval(rates["tp"], rates["fn"])

    auc_values = []
    incomplete = 0
    for family in families.values():
        positives = [float(row["score"]) for row in family if int(row["label"]) == 1]
        negatives = [
            float(row["score"])
            for row in family
            if int(row["label"]) == 0
            and str(row["condition"]) in contrast_negative_conditions
        ]
        if not positives or not negatives:
            incomplete += 1
            continue
        auc_values.append(_pairwise_auc(positives, negatives))
    if auc_values:
        auc_radius = _hoeffding_radius(len(auc_values), alpha)
        auc = _bounded_mean_interval(auc_values, auc_radius, 0.0, 1.0)
    else:
        auc_radius = 1.0
        auc = {"lower": 0.0, "upper": 1.0, "estimate": None}
    return {
        "mcc": mcc,
        "sensitivity": sensitivity,
        "family_balanced_auc": auc,
        "family_count": len(families),
        "complete_auc_family_count": len(auc_values),
        "incomplete_auc_family_count": incomplete,
        "hoeffding_radius": max(radius, auc_radius),
        "null_denominator": bool(null_mcc or null_sensitivity),
    }


def prediction_jaccard_interval(
    left: Sequence[dict], right: Sequence[dict], alpha: float
) -> dict:
    """Bound positive-prediction Jaccard with prompt families as units."""

    left_by_id = {str(row["prompt_id"]): row for row in left}
    right_by_id = {str(row["prompt_id"]): row for row in right}
    common = sorted(set(left_by_id) & set(right_by_id))
    grouped: dict[str, list[str]] = defaultdict(list)
    for prompt_id in common:
        family_id = str(left_by_id[prompt_id]["family_id"])
        if family_id == str(right_by_id[prompt_id]["family_id"]):
            grouped[family_id].append(prompt_id)
    intersection_values = []
    union_values = []
    family_sizes = []
    for prompt_ids in grouped.values():
        left_positive = {
            prompt_id
            for prompt_id in prompt_ids
            if int(left_by_id[prompt_id]["prediction"]) == 1
        }
        right_positive = {
            prompt_id
            for prompt_id in prompt_ids
            if int(right_by_id[prompt_id]["prediction"]) == 1
        }
        family_sizes.append(len(prompt_ids))
        intersection_values.append(
            len(left_positive & right_positive) / len(prompt_ids)
        )
        union_values.append(len(left_positive | right_positive) / len(prompt_ids))
    if not family_sizes:
        return {"lower": 0.0, "upper": 1.0, "estimate": None}
    total = sum(family_sizes)
    weights = [size / total for size in family_sizes]
    radius = _weighted_hoeffding_radius(weights, alpha)
    intersection = _bounded_weighted_mean_interval(
        intersection_values, weights, radius, 0.0, 1.0
    )
    union = _bounded_weighted_mean_interval(union_values, weights, radius, 0.0, 1.0)
    if union["lower"] <= 0.0:
        return {"lower": 0.0, "upper": 1.0, "estimate": None}
    bounded = _divide(intersection, union)
    return {
        "lower": max(0.0, bounded["lower"]),
        "upper": min(1.0, bounded["upper"]),
        "estimate": intersection["estimate"] / union["estimate"],
    }


def decide_level(intervals: dict, thresholds: dict) -> str:
    """Return the three-valued E-04 decision for one level."""

    if all(intervals[name]["lower"] >= float(thresholds[name]) for name in intervals):
        return "supported"
    if any(intervals[name]["upper"] < float(thresholds[name]) for name in intervals):
        return "not_supported"
    return "inconclusive"


def nested_decision(prerequisite: str, current: str) -> str:
    if prerequisite == "not_identifiable":
        return "not_identifiable"
    if prerequisite == "not_supported" or current == "not_supported":
        return "not_supported"
    if prerequisite == "supported" and current == "supported":
        return "supported"
    return "inconclusive"


def subtract_intervals(left: dict, right: dict) -> dict:
    return {
        "lower": max(-2.0, float(left["lower"]) - float(right["upper"])),
        "upper": min(2.0, float(left["upper"]) - float(right["lower"])),
        "estimate": (
            float(left["estimate"]) - float(right["estimate"])
            if left.get("estimate") is not None and right.get("estimate") is not None
            else None
        ),
    }


def _identifiability_reason(
    rows: Sequence[dict], evidence: Sequence[dict], minimum_reconstructions: int
) -> str | None:
    if len(rows) < minimum_reconstructions:
        return "fewer_than_required_reconstructions"
    if len({str(row.get("model_seed")) for row in rows}) != len(rows):
        return "duplicate_reconstruction_identifiers"
    for item in evidence:
        if not item.get("enabled") or not item.get("evaluated"):
            return "missing_e04_evidence"
        selection = item.get("development_selection", {})
        if not selection.get("admissible_rule", False):
            return "no_admissible_development_rule"
        roles = {str(row.get("role")) for row in item.get("observations", [])}
        required = set(REQUIRED_ROLES)
        if str(selection.get("path_family")) in ORDERED_PATH_FAMILIES:
            required |= {"order_shuffled_rule", "order_reversed_rule"}
        if not required <= roles:
            return "missing_required_response_level_roles"
    return None


def _mcc_interval(rates: dict[str, dict]) -> tuple[dict, bool]:
    tp, tn, fp, fn = (rates[name] for name in ("tp", "tn", "fp", "fn"))
    numerator = _subtract(_multiply(tp, tn), _multiply(fp, fn))
    factors = (
        _add(tp, fp),
        _add(tp, fn),
        _add(tn, fp),
        _add(tn, fn),
    )
    product = {"lower": 1.0, "upper": 1.0}
    for factor in factors:
        product = _multiply(product, factor)
    if product["lower"] <= 0.0:
        return {"lower": -1.0, "upper": 1.0, "estimate": None}, True
    denominator = {
        "lower": math.sqrt(product["lower"]),
        "upper": math.sqrt(product["upper"]),
    }
    result = _divide(numerator, denominator)
    point = _mcc_from_rates(
        *(rates[name]["estimate"] for name in ("tp", "tn", "fp", "fn"))
    )
    return {
        "lower": max(-1.0, result["lower"]),
        "upper": min(1.0, result["upper"]),
        "estimate": point,
    }, False


def _ratio_interval(numerator: dict, other: dict) -> tuple[dict, bool]:
    denominator = _add(numerator, other)
    if denominator["lower"] <= 0.0:
        return {"lower": 0.0, "upper": 1.0, "estimate": None}, True
    result = _divide(numerator, denominator)
    total = numerator["estimate"] + other["estimate"]
    estimate = numerator["estimate"] / total if total else None
    return {
        "lower": max(0.0, result["lower"]),
        "upper": min(1.0, result["upper"]),
        "estimate": estimate,
    }, False


def _families(observations: Sequence[dict]) -> dict[str, list[dict]]:
    result: dict[str, list[dict]] = defaultdict(list)
    for row in observations:
        result[str(row["family_id"])].append(row)
    return result


def _by_role(observations: Sequence[dict]) -> dict[str, list[dict]]:
    result: dict[str, list[dict]] = defaultdict(list)
    for row in observations:
        result[str(row["role"])].append(row)
    return result


def _thresholds(defaults: dict, configured: dict) -> dict:
    return {
        name: float(configured.get(name, value)) for name, value in defaults.items()
    }


def _criterion_rows(base: dict, level: str, values: dict, limits: dict) -> list[dict]:
    rows = []
    for name, interval in values.items():
        threshold = float(limits[name])
        rows.append(
            {
                **base,
                "level": level,
                "criterion": name,
                "estimate": interval.get("estimate"),
                "lower": interval["lower"],
                "upper": interval["upper"],
                "threshold": threshold,
                "decision": decide_level({name: interval}, {name: threshold}),
            }
        )
    return rows


def _minimum_interval(intervals: Iterable[dict]) -> dict:
    values = list(intervals)
    if not values:
        return {"lower": 0.0, "upper": 1.0, "estimate": None}
    estimates = [value.get("estimate") for value in values]
    return {
        "lower": min(float(value["lower"]) for value in values),
        "upper": min(float(value["upper"]) for value in values),
        "estimate": (
            min(float(value) for value in estimates)
            if all(value is not None for value in estimates)
            else None
        ),
    }


def _point_interval(value: float) -> dict:
    return {"lower": float(value), "upper": float(value), "estimate": float(value)}


def _bounded_mean_interval(
    values: Sequence[float], radius: float, lower: float, upper: float
) -> dict:
    estimate = _mean(values)
    return {
        "lower": max(lower, estimate - radius),
        "upper": min(upper, estimate + radius),
        "estimate": estimate,
    }


def _bounded_weighted_mean_interval(
    values: Sequence[float],
    weights: Sequence[float],
    radius: float,
    lower: float,
    upper: float,
) -> dict:
    if len(values) != len(weights) or not values:
        raise ValueError("Weighted intervals require equally sized non-empty inputs.")
    estimate = sum(
        float(value) * float(weight)
        for value, weight in zip(values, weights, strict=True)
    )
    return {
        "lower": max(lower, estimate - radius),
        "upper": min(upper, estimate + radius),
        "estimate": estimate,
    }


def _hoeffding_radius(count: int, alpha: float) -> float:
    if count <= 0 or not 0.0 < alpha < 1.0:
        raise ValueError("Hoeffding bounds require count > 0 and 0 < alpha < 1.")
    return math.sqrt(math.log(2.0 / alpha) / (2.0 * count))


def _weighted_hoeffding_radius(weights: Sequence[float], alpha: float) -> float:
    if not weights or not 0.0 < alpha < 1.0:
        raise ValueError("Weighted Hoeffding bounds require weights and 0 < alpha < 1.")
    if any(weight < 0.0 for weight in weights):
        raise ValueError("Weighted Hoeffding weights must be non-negative.")
    if not math.isclose(sum(weights), 1.0, abs_tol=1e-12):
        raise ValueError("Weighted Hoeffding weights must sum to one.")
    return math.sqrt(
        0.5 * sum(weight * weight for weight in weights) * math.log(2.0 / alpha)
    )


def _pairwise_auc(positives: Sequence[float], negatives: Sequence[float]) -> float:
    comparisons = 0.0
    for positive in positives:
        for negative in negatives:
            comparisons += float(positive > negative) + 0.5 * float(
                positive == negative
            )
    return comparisons / (len(positives) * len(negatives))


def _mcc_from_rates(tp: float, tn: float, fp: float, fn: float) -> float | None:
    denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return (tp * tn - fp * fn) / denominator if denominator else None


def _add(left: dict, right: dict) -> dict:
    return {
        "lower": float(left["lower"]) + float(right["lower"]),
        "upper": float(left["upper"]) + float(right["upper"]),
    }


def _subtract(left: dict, right: dict) -> dict:
    return {
        "lower": float(left["lower"]) - float(right["upper"]),
        "upper": float(left["upper"]) - float(right["lower"]),
    }


def _multiply(left: dict, right: dict) -> dict:
    products = [
        float(left[key]) * float(right[other])
        for key in ("lower", "upper")
        for other in ("lower", "upper")
    ]
    return {"lower": min(products), "upper": max(products)}


def _divide(numerator: dict, denominator: dict) -> dict:
    if float(denominator["lower"]) <= 0.0 <= float(denominator["upper"]):
        return {"lower": float("-inf"), "upper": float("inf")}
    quotients = [
        float(numerator[key]) / float(denominator[other])
        for key in ("lower", "upper")
        for other in ("lower", "upper")
    ]
    return {"lower": min(quotients), "upper": max(quotients)}


def _mean(values: Iterable[float]) -> float:
    items = [float(value) for value in values]
    return sum(items) / len(items) if items else 0.0
