"""Isolated, conditional TRACE inference against automatic presence labels.

This module does not fit rules, inspect neural states, generate answers, write
files, or authorize execution. The finite bounds follow the current paper's
family means and the label-neutral arithmetic in ``audited_assurance``. MCC
differences subtract simultaneous bounds on *matched* answers. They do not
exploit covariance, so small gains can remain unresolved even with perfect L1.

Workflow
--------
``assess_presence_feasibility`` checks an ideal design before any scores exist.
``freeze_presence_inference`` accepts a plan, preparation records, and unscored
reference rows. ``evaluate_presence_inference`` accepts that immutable snapshot
and scored ``presence_observation_rows`` with five extra fields: ``model_group``,
``reconstruction_id``, ``rule_id``, ``rule_sha256``, and ``freeze_sha256``.
The reference rows add only ``model_group``. They include discovery,
development, test, and separate control records with complete automatic checks.

The plan declares ``concept_ids`` (hypotheses only), ``auxiliary_concept_ids``,
``model_groups`` (answer origins and reconstruction IDs), ``concept_definitions``
(definition digests), ``concept_error_budgets``, ``requirements`` copied from
the V14 provenance checker, ``requirements_source_sha256``, a fixed
``positive_class_weight``, ``feature_families``, ``text_families``, and
``feature_budget``. A ``reference_manifest_sha256`` binds the complete supplied
collection. ``comparisons`` contain concept_id, model_group, family, positive,
and negative. Each endpoint is [model_seed, prompt_id]. ``contrast_families``
maps names to minimum pair counts. ``controls`` use an ``answer`` endpoint and
``control_families`` specify minimum_count and minimum_accuracy. Family names
never determine labels. All these choices precede test predictions.

Each preparation record identifies a concept, model group, and reconstruction.
It attests ``reconstruction_split="discovery"`` and
``reconstruction_label_neutral=True``, separately from fitting prediction rules.
Its ``candidates`` map every declared feature/text family to a saved-rule record
with rule_sha256, threshold, feature_budget, feature_count, development_mcc,
fit_split, selection_split, source_revision, discovery_sha256, development_sha256.
The split digests use ``presence_reference_digest`` on the cell's reference
rows in that split. Ordered families additionally supply ``order_controls``
with separately fitted shuffle and reverse records at the same feature limit.
The ``compression`` record attests development-only paired selection and exact
attained sizes. This module validates those records, not the upstream fitting,
compression calculation, or physical artifact contents.

Revision 2 excludes explicitly undefined development MCCs from selection and
records those exclusions. A missing score field is not an undefined metric.
Every declared candidate must still have its preparation record. The primary
family must have finite, eligible development scores in every reconstruction.
Comparators are selected separately from the finite candidates in each role.
No finite comparator leaves the corresponding higher level unavailable.

The current paper's size-selection protocol still requires all five sizes and
the 20,000-state reference. Missing sizes are reported, never forced or renamed.
This is a protocol requirement, not a premise of the held-out rate bounds.
The selected size is shared within one model's concepts and reconstructions.
Different model groups may select different sizes. A fixed-attained-size
alternative is not implemented without a separately agreed protocol. Earlier
snapshots require a new pretest freeze and cannot be reused under this revision.

Revision 3 separately selects localization rules from individual states and
unordered sets of at most four states using development MCC. RQ1 reuses the
explicitly transferred development and L1 test requirements, with the approved
.02 text margin. It does not require TRACE L1. RQ2 gains are reported separately
from cumulative TRACE levels. Seven roles use three bounded means each, with
separate TRACE and localization stability bounds for every reconstruction pair.
The primitive allocation is therefore 21r + 2 choose(r, 2), without reallocating
unused bounds or the budgets of unavailable concepts or model groups.

Revision 4 separates answer origin from recurring answer text. Shared origins,
prompts and source families cannot cross splits. Identical text from distinct
origins is retained and reported, with content links confined to each split's
conservative inference groups. Neither grouping nor distinct call identifiers
establishes independence. Earlier freezes require their original implementation
and are not silently reinterpreted under this policy.

Prerequisite evidence is explicit: plan_id, source_revision, checker (identity,
revision, configuration), sampling_design_id, source_family_audit_sha256,
independent_clusters_assumed, checker_blind_to_trace_and_construction,
frozen_before_test_predictions, and complete_reference_collection. Digests and
declarations are audit bindings, not proof of chronology, completeness, checker
accuracy, or statistical independence. The guarantee is conditional on these
premises. No guarantee for semantic truth or method validity is asserted.

A CPU-authenticated continuation may freeze an exact historical control
collection with its separate checker identity and original artifact provenance.
Only control rows can use that identity. Every main-study row must still match
the current checker. Raw checks and labels are retained without modification.

Revision 5 retains each identity-bound automatic assessment when equal text
received different labels. Disagreement is checker uncertainty, not a reason
to relabel, exclude or repeat observations. Unknown-label and provenance gates
remain unchanged. Results concern recorded automatic labels, not semantic truth.
"""

from __future__ import annotations

import hashlib
import itertools
import json
import math
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from functools import lru_cache
from statistics import mean

from .audited_assurance import _mcc_from_class_rate_intervals
from .concept_presence_data import (
    RESPONSE_OVERLAP_POLICY, RESPONSE_LABEL_POLICY, response_content_overlap, response_provenance_keys,
    response_generation_request_id,
    validate_presence_annotation,
)
from .concept_presence_evaluation import (
    EVALUATOR_VERSION, LABEL_OBJECTIVE, MAPPING_REVISION, _source_families,
)
from .presence_extrapolation import V14_CONFIG_SHA256
from .simultaneous_assurance import L1_THRESHOLDS, L2_THRESHOLDS, L3_THRESHOLDS
from .trace_coverage import SHORT_GAP_FAMILY, conservative_fragment_policy


INFERENCE_REVISION = "E-06-presence-inference-5"
INDIVIDUAL = frozenset({"terminal_state", "best_interior_state"})
ORDERED = frozenset({
    "transition_edge_set", "contiguous_state_motif", "gapped_state_motif",
    SHORT_GAP_FAMILY,
})
PATH = ORDERED | {"unordered_state_set"}
TEXT = frozenset({
    "answer_token_ngram", "answer_position", "answer_template", "answer_length",
    "prompt_tfidf",
})
_SCORED_FIELDS = frozenset({
    "prediction", "score", "reconstruction_id", "rule_id", "rule_sha256",
    "freeze_sha256",
})
_EXPECTED_REQUIREMENTS = {
    "minimum_reconstruction_count": 3, "representation_mcc_tolerance": 0.02,
    "total_error_budget": 0.05, "maximum_tolerable_mcc_drop": 0.02,
    "thresholds": {"l1": L1_THRESHOLDS, "l2": L2_THRESHOLDS, "l3": L3_THRESHOLDS},
}


def _json(value: object) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)


def _digest(value: object) -> str:
    return hashlib.sha256(_json(value).encode("utf-8")).hexdigest()


def _name(value: object) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Expected a nonempty identifier.")
    return value


def _names(value: object) -> list[str]:
    if not isinstance(value, (list, tuple)) or not value:
        raise ValueError("Expected a nonempty identifier list.")
    values = [_name(item) for item in value]
    if len(set(values)) != len(values):
        raise ValueError("Duplicate declared identifier.")
    return values


def _sha(value: object) -> str:
    if (not isinstance(value, str) or len(value) != 64
            or any(char not in "0123456789abcdef" for char in value)):
        raise ValueError("Expected a lowercase SHA-256 digest.")
    return value


def _number(value: object, low: float, high: float) -> float:
    if (isinstance(value, bool) or not isinstance(value, (float, int))
            or not math.isfinite(value) or not low <= value <= high):
        raise ValueError("Invalid finite numeric requirement or observation.")
    return float(value)


def _count(value: object, minimum: int = 1) -> int:
    if type(value) is not int or value < minimum:
        raise ValueError("Invalid integer count.")
    return value


def _key(row: Mapping) -> tuple[str, ...]:
    return tuple(_name(row.get(field)) for field in (
        "concept_id", "model_group", "model_seed", "prompt_id",
    ))


def presence_reference_digest(rows: Sequence[Mapping]) -> str:
    """Bind exact rows independently of row order, without discarding fields."""
    return _digest(sorted((dict(row) for row in rows), key=_key))


_CHECKER_EXECUTION_FIELDS = frozenset({
    "stage", "shard_id", "model_run", "data_task_sha256", "control_task_sha256",
    "questions_sha256", "annotation_plan_sha256", "responses_sha256",
    "semantic_requests_sha256", "request_schedule_sha256", "catalog_sha256",
    "control_plan_sha256", "contrast_assignments_sha256", "control_settings_sha256",
    "control_template_revision", "control_templates_sha256", "control_runtime_revision",
    "evidence_inventories_sha256",
})


def presence_checker_identity(checker: Mapping) -> dict:
    """Project fixed checker settings without changing retained call evidence.

    Only known execution fields may differ across independently journaled stages.
    Unknown fields remain part of the identity. Production conditions and hashes
    are validated before projection. Non-model checker configurations retain the
    previous exact comparison, including the local empty-text rule.
    """
    value = json.loads(_json(checker))
    configuration = value.get("checker_configuration")
    if not isinstance(configuration, dict) or not configuration:
        raise ValueError("A complete frozen checker configuration is required.")
    if not {"model_id", "model_revision", "model_manifest_sha256", "condition_sha256"} & set(configuration):
        return value
    from .presence_generation_runtime import _condition

    _condition(configuration, configuration.get("condition"))
    if (configuration.get("model_id") != value.get("checker_id")
            or configuration.get("model_revision") != value.get("checker_revision")):
        raise ValueError("Checker evidence has inconsistent model identity.")
    _name(configuration.get("runtime_revision"))
    for field in _CHECKER_EXECUTION_FIELDS & set(configuration):
        if field.endswith("_sha256"):
            _sha(configuration[field])
        else:
            _name(configuration[field])
    bound_key, request_key = "presence_evidence_binding", "presence_evidence_request_binding"
    if request_key in configuration and bound_key not in configuration:
        raise ValueError("Presence request evidence lacks its schedule binding.")
    if bound_key in configuration:
        bound = configuration[bound_key]
        if not isinstance(bound, dict):
            raise ValueError("Presence evidence binding must be an object.")
        for field in ("variant", "resolver_revision", "schema_revision", "prompt_revision"):
            _name(bound.get(field))
        _sha(bound.get("schema_sha256"))
        if bound["variant"] != configuration["condition"].get("checker_profile", {}).get("presence_prompt_variant"):
            raise ValueError("Presence evidence variant differs from its checker profile.")
        execution = {"checker_binding_sha256", "evidence_inventories_sha256", "binding_sha256"}
        if execution & set(bound):
            for field in execution:
                _sha(bound.get(field))
            if (bound["binding_sha256"] != _digest({k: v for k, v in bound.items() if k != "binding_sha256"})
                    or bound["checker_binding_sha256"] != _digest({k: v for k, v in configuration.items()
                                                                    if k not in (bound_key, request_key)})):
                raise ValueError("Presence evidence schedule binding changed before identity projection.")
        elif request_key in configuration:
            raise ValueError("Presence request evidence requires its complete schedule binding.")
        if request_key in configuration:
            request = configuration[request_key]
            fields = {"request_sha256", "raw_source_sha256", "inventory_sha256",
                      "messages_sha256", "checker_binding_sha256"}
            if not isinstance(request, dict) or set(request) != fields:
                raise ValueError("Presence request evidence requires its exact compact binding.")
            for field in fields:
                _sha(request[field])
            if request["checker_binding_sha256"] != _digest({k: v for k, v in configuration.items() if k != request_key}):
                raise ValueError("Presence evidence request binding changed before identity projection.")
            del configuration[request_key]
        # Keep fixed transport metadata. Already projected identities stay valid.
        configuration[bound_key] = {k: v for k, v in bound.items() if k not in execution}
    value["checker_configuration"] = {
        key: item for key, item in configuration.items() if key not in _CHECKER_EXECUTION_FIELDS
    }
    return value


_HISTORICAL_CONTROL_FIELDS = frozenset({
    "historical_control_checker", "historical_control_reference_sha256",
    "historical_control_provenance",
})


def _historical_control_identity(plan: Mapping) -> dict | None:
    """Validate the CPU-authenticated control import without rewriting evidence.

    The CPU input validator authenticates original file bytes and receipts.
    This pure inference boundary binds that attestation to an exact collection
    of control rows. It is not an alternative source identity for new answers.
    """
    present = _HISTORICAL_CONTROL_FIELDS & set(plan)
    if not present:
        return None
    if present != _HISTORICAL_CONTROL_FIELDS:
        raise ValueError("Historical controls require their complete frozen provenance.")
    historical = presence_checker_identity(plan["historical_control_checker"])
    current = presence_checker_identity(plan["checker"])
    old = historical["checker_configuration"]
    new = current["checker_configuration"]
    provenance = plan["historical_control_provenance"]
    required = {"continuation_authorization_sha256", "original_release_sha256",
                "controls_artifact_sha256", "source_sha256", "config_sha256", "campaign_id"}
    if not isinstance(provenance, Mapping) or set(provenance) != required:
        raise ValueError("Historical control provenance requires exact import bindings.")
    for field in required - {"campaign_id"}:
        _sha(provenance[field])
    _name(provenance["campaign_id"])
    _sha(plan["historical_control_reference_sha256"])
    _sha(old.get("source_sha256"))
    _sha(new.get("source_sha256"))
    if (old["source_sha256"] == new["source_sha256"]
            or new["source_sha256"] != plan["source_revision"]
            or old["source_sha256"] != provenance["source_sha256"]
            or any(old.get(key) != provenance[key] or new.get(key) != provenance[key]
                   for key in ("config_sha256", "campaign_id"))):
        raise ValueError("Historical control source or campaign differs from its pinned provenance.")
    expected = json.loads(_json(historical))
    expected["checker_configuration"]["source_sha256"] = new["source_sha256"]
    if expected != current:
        raise ValueError("Historical controls require the same checker model and scientific condition.")
    return historical


def _historical_response_identity(plan: Mapping) -> dict | None:
    """Bind old automatic answer checks to the CPU-authenticated import."""
    fields = {"historical_response_checker", "historical_response_reference_sha256",
              "historical_response_provenance"}
    present = fields & set(plan)
    if not present:
        return None
    if present != fields:
        raise ValueError("Historical responses require complete frozen import provenance.")
    old_checker = presence_checker_identity(plan["historical_response_checker"])
    current = presence_checker_identity(plan["checker"])
    old, new = old_checker["checker_configuration"], current["checker_configuration"]
    provenance = plan["historical_response_provenance"]
    required = {"import_authorization_sha256", "producer_release_sha256", "collection_artifact_sha256",
                "source_sha256", "config_sha256", "campaign_id"}
    if not isinstance(provenance, Mapping) or set(provenance) != required:
        raise ValueError("Historical response provenance requires exact import bindings.")
    for key in required - {"campaign_id"}:
        _sha(provenance[key])
    _name(provenance["campaign_id"])
    _sha(plan["historical_response_reference_sha256"])
    _sha(old.get("source_sha256"))
    _sha(new.get("source_sha256"))
    if (old["source_sha256"] == new["source_sha256"]
            or new["source_sha256"] != plan["source_revision"]
            or old["source_sha256"] != provenance["source_sha256"]
            or any(old.get(key) != provenance[key] or new.get(key) != provenance[key]
                   for key in ("campaign_id", "config_sha256"))):
        raise ValueError("Historical response source differs from its authenticated import.")
    expected = json.loads(_json(old_checker))
    expected["checker_configuration"]["source_sha256"] = new["source_sha256"]
    if expected != current:
        raise ValueError("Imported responses require unchanged checker model and condition.")
    return old_checker


def presence_inference_capabilities() -> dict:
    """State the implemented capability without issuing a release or claim."""
    return {
        "inference_revision": INFERENCE_REVISION,
        "response_label_policy": RESPONSE_LABEL_POLICY,
        "response_overlap_policy": RESPONSE_OVERLAP_POLICY,
        "content_grouping": "within_split_only_conservative_not_independence_proof",
        "label_objective": LABEL_OBJECTIVE,
        "uncertainty_method": "simultaneous_family_hoeffding",
        "paired_gain_method": "matched_answers_conservative_box_subtraction",
        "finite_sample_guarantee": "conditional_on_fixed_weights_and_independent_clusters",
        "bootstrap_used": False,
        "automatic_reference_accuracy_guaranteed": False,
        "method_validity_status": "not_assessed",
        "global_neural_learning_claim": False,
        "release_allowed": False,
        "test_ready": False,
        "runtime_dispatch": "not_implemented",
        "full_answer_concept_matrix_audit": "external_prerequisite",
        "upstream_artifact_execution_verified": False,
        "independent_six_eyes_review": "not_attested_by_this_module",
    }


def _interval(estimate: float | None, lower: float, upper: float,
              reason: str | None = None) -> dict:
    return {"estimate": estimate, "lower": lower, "upper": upper,
            "undefined_reason": reason}


def _bounded(values: Sequence[float], alpha: float) -> dict:
    return _mean_bound(mean(values) if values else None, len(values), alpha)


def _mean_bound(center: float | None, count: int, alpha: float) -> dict:
    if not count:
        return _interval(None, 0.0, 1.0, "no_independent_groups")
    radius = math.sqrt((math.log(2.0) - math.log(alpha)) / (2 * count))
    return {**_interval(center, max(0.0, center - radius), min(1.0, center + radius)),
            "cluster_count": count, "radius": radius}


def _mcc(sensitivity: Mapping, specificity: Mapping, rho: float) -> dict:
    if sensitivity["estimate"] is None or specificity["estimate"] is None:
        return _interval(None, -1.0, 1.0, "both_presence_classes_required")
    result = _mcc_from_class_rate_intervals(sensitivity, specificity, rho)
    predicted_min = rho * sensitivity["lower"] + (1 - rho) * (1 - specificity["upper"])
    predicted_max = rho * sensitivity["upper"] + (1 - rho) * (1 - specificity["lower"])
    if result["estimate"] is not None and (predicted_min <= 0 or predicted_max >= 1):
        result.update(lower=-1.0, upper=1.0, interval_status="uninformative_denominator_range")
    return result


def _gain(path: Mapping, comparator: Mapping) -> dict:
    if path["estimate"] is None or comparator["estimate"] is None:
        return _interval(None, -2.0, 2.0, "undefined_paired_mcc")
    return _interval(path["estimate"] - comparator["estimate"],
                     max(-2.0, path["lower"] - comparator["upper"]),
                     min(2.0, path["upper"] - comparator["lower"]))


def _decision(interval: Mapping, threshold: float) -> str:
    if interval["estimate"] is None or interval.get("undefined_reason"):
        return "not_identifiable"
    if interval["lower"] >= threshold:
        return "supported"
    if interval["upper"] < threshold:
        return "not_supported"
    return "inconclusive"


def _conjunction(decisions: Sequence[str]) -> str:
    # Missing evidence is never converted into a negative recognition decision.
    for status in ("not_identifiable", "not_supported", "inconclusive"):
        if status in decisions:
            return status
    return "supported" if decisions else "not_identifiable"


def assess_presence_feasibility(
    *, concept_count: int, model_group_count: int, reconstruction_count: int,
    positive_family_count: int, negative_family_count: int,
    auc_cluster_count: int, stability_family_count: int,
    positive_class_weight: float = 0.5, concept_error_share: float | None = None,
) -> dict:
    """Check perfect L1 and illustrative gain bounds, not power or readiness.

    Counts are independent connected groups, not answers, runs, or pair counts.
    Allocation includes all hypotheses and model groups even when data are
    missing. Auxiliary concepts used only as control content do not enter it.
    This count-only check must be repeated on actual joined, labeled families.
    """
    for count in (concept_count, model_group_count, reconstruction_count):
        _count(count)
    for count in (positive_family_count, negative_family_count,
                  auc_cluster_count, stability_family_count):
        _count(count, 0)
    rho = _number(positive_class_weight, 0.0, 1.0)
    if rho in (0.0, 1.0):
        raise ValueError("The positive-class weight must be strictly between zero and one.")
    share = 0.05 / concept_count if concept_error_share is None else concept_error_share
    _number(share, 0.0, 0.05)
    if share <= 0:
        raise ValueError("Every concept requires a positive error share.")
    # Seven roles each use two class rates and one AUC mean. TRACE and
    # localization each have a same-answer stability mean per repeat pair.
    primitives = 21 * reconstruction_count + 2 * math.comb(reconstruction_count, 2)
    alpha = share / model_group_count / primitives
    if alpha == 0:
        raise ValueError("The error allocation is below numeric resolution.")
    sensitivity = _mean_bound(1.0, positive_family_count, alpha)
    specificity = _mean_bound(1.0, negative_family_count, alpha)
    perfect_mcc = _mcc(sensitivity, specificity, rho)
    criteria = {
        "minimum_test_mcc": perfect_mcc,
        "minimum_positive_sensitivity": sensitivity,
        "minimum_family_balanced_auc": _mean_bound(1.0, auc_cluster_count, alpha),
        "minimum_prediction_jaccard": _mean_bound(1.0, stability_family_count, alpha),
    }
    decisions = {name: _decision(value, L1_THRESHOLDS[name]) for name, value in criteria.items()}
    feasible = reconstruction_count >= 3 and all(value == "supported" for value in decisions.values())
    # Symmetric class rates give the specified comparator MCC at rho = 1/2.
    gain_scenarios = {}
    if rho == 0.5:
        for comparator_mcc in (0.0, 0.5, 0.8, 0.95):
            rate = (comparator_mcc + 1) / 2
            comparator = _mcc(_mean_bound(rate, positive_family_count, alpha),
                              _mean_bound(rate, negative_family_count, alpha), rho)
            gain_scenarios[str(comparator_mcc)] = _gain(perfect_mcc, comparator)
    return {
        **presence_inference_capabilities(), "perfect_l1_feasible": feasible,
        "primitive_bound_count": primitives, "alpha_per_primitive": alpha,
        "concept_error_share": share, "model_group_count": model_group_count,
        "criteria": criteria, "criterion_decisions": decisions,
        "perfect_path_gain_scenarios": gain_scenarios,
        "gain_scenario_assumption": "symmetric_rates_at_class_weight_one_half",
        "power_established": False, "actual_group_check_required": True,
    }


@dataclass(frozen=True)
class FrozenPresenceInference:
    """Immutable JSON snapshot. Copies returned by properties may be edited safely."""

    payload: str

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.payload.encode("utf-8")).hexdigest()

    @property
    def reference_rows(self) -> list[dict]:
        return json.loads(self.payload)["reference_rows"]


def _components(tokens: Sequence[Sequence[tuple]]) -> list[int]:
    parents = list(range(len(tokens)))

    def root(index: int) -> int:
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    owners = {}
    for index, identifiers in enumerate(tokens):
        for token in identifiers:
            other = owners.setdefault(token, index)
            left, right = root(index), root(other)
            parents[max(left, right)] = min(left, right)
    return [root(index) for index in range(len(tokens))]


def _provenance_tokens(rows: Sequence[Mapping]) -> list[list[tuple]]:
    """Reject one stored call relabeled as multiple physical answers."""
    owners, tokens = {}, []
    for row in rows:
        physical = (row["model_seed"], row["prompt_id"])
        dependencies = list(response_provenance_keys(row))
        for key in dependencies:
            if key[0] in {"response", "generation_request"}:
                if owners.setdefault(key, physical) != physical:
                    raise ValueError("Reused response record identifies different physical answers.")
        tokens.append(dependencies)
    return tokens


def _validate_plan(plan: Mapping) -> None:
    if (plan.get("label_objective") != LABEL_OBJECTIVE
            or plan.get("requirements") != _EXPECTED_REQUIREMENTS
            or plan.get("requirements_source_sha256") != V14_CONFIG_SHA256):
        raise ValueError("Explicit presence objective and unchanged V14 requirements are required.")
    concepts = _names(plan.get("concept_ids"))
    auxiliary = plan.get("auxiliary_concept_ids", [])
    if auxiliary and set(_names(auxiliary)) & set(concepts):
        raise ValueError("Auxiliary controls cannot also be scored hypotheses.")
    if set(plan.get("concept_definitions", {})) != set(concepts):
        raise ValueError("Every hypothesis requires exactly one frozen definition.")
    for digest in plan["concept_definitions"].values():
        _sha(digest)
    groups = plan.get("model_groups")
    if not isinstance(groups, Mapping) or not groups:
        raise ValueError("Model groups must be declared before testing.")
    origins = set()
    for group, specification in groups.items():
        _name(group)
        _name(specification.get("model_revision"))
        _names(specification.get("reconstruction_ids"))
        declared = set(_names(specification.get("answer_origins")))
        if origins & declared:
            raise ValueError("One answer origin cannot identify different fixed models.")
        origins.update(declared)
    shares = plan.get("concept_error_budgets", {})
    if set(shares) != set(concepts):
        raise ValueError("Missing preregistered concept error shares.")
    if any(_number(value, 0, 0.05) <= 0 for value in shares.values()) or math.fsum(shares.values()) > 0.05:
        raise ValueError("Concept error shares exceed the fixed total budget.")
    rho = _number(plan.get("positive_class_weight"), 0, 1)
    if rho in (0, 1):
        raise ValueError("Both presence classes need positive weight.")
    features = set(_names(plan.get("feature_families")))
    texts = set(_names(plan.get("text_families")))
    if not features <= INDIVIDUAL | PATH or not texts <= TEXT:
        raise ValueError("Unknown feature family.")
    if not features & INDIVIDUAL or not features & PATH:
        raise ValueError("Individual-state and multi-state candidates are required.")
    _count(plan.get("feature_budget"), 2)
    for field in ("plan_id", "source_revision", "sampling_design_id"):
        _name(plan.get(field))
    for field in ("reference_manifest_sha256", "source_family_audit_sha256"):
        _sha(plan.get(field))
    checker = plan.get("checker", {})
    _name(checker.get("checker_id"))
    _name(checker.get("checker_revision"))
    if not isinstance(checker.get("checker_configuration"), Mapping) or not checker["checker_configuration"]:
        raise ValueError("The automatic checker configuration must be frozen.")
    _historical_control_identity(plan)
    _historical_response_identity(plan)
    for value in plan.get("contrast_families", {}).values():
        _count(value)
    for value in plan.get("control_families", {}).values():
        _count(value.get("minimum_count"))
        _number(value.get("minimum_accuracy"), 0, 1)
    for collection, endpoints in (("comparisons", ("positive", "negative")), ("controls", ("answer",))):
        for item in plan.get(collection, []):
            if item.get("concept_id") not in concepts or item.get("model_group") not in groups:
                raise ValueError("Comparison or control lies outside the planned hypothesis matrix.")
            _name(item.get("family"))
            for endpoint in endpoints:
                value = item.get(endpoint)
                if not isinstance(value, (list, tuple)) or len(value) != 2:
                    raise ValueError("Answer endpoints must contain model_seed and prompt_id.")
                for part in value:
                    _name(part)


def freeze_presence_inference(
    plan: Mapping, preparation: Sequence[Mapping], reference_rows: Sequence[Mapping],
) -> FrozenPresenceInference:
    """Freeze development evidence and unscored automatic references.

    Invalid bindings raise ValueError. Missing evidence and insufficient counts
    are retained as blockers, never repaired through test-dependent selection.
    The caller must create and retain this snapshot before inspecting scores.
    """
    _validate_plan(plan)
    if any(_SCORED_FIELDS & set(row) for row in reference_rows):
        raise ValueError("Freeze requires unscored reference rows, not test predictions.")
    if presence_reference_digest(reference_rows) != plan["reference_manifest_sha256"]:
        raise ValueError("Reference manifest differs from the preregistered collection.")
    rows = sorted((dict(row) for row in reference_rows), key=_key)
    fixed_checker = presence_checker_identity(plan["checker"])
    historical_checker = _historical_control_identity(plan)
    response_checker = _historical_response_identity(plan)
    if response_checker is not None:
        imported = [row for row in rows if row.get("split") != "control"]
        if not imported or presence_reference_digest(imported) != plan["historical_response_reference_sha256"]:
            raise ValueError("Historical response rows differ from the authenticated import.")
    if historical_checker is not None:
        controls = [row for row in rows if row.get("split") == "control"]
        if not controls or presence_reference_digest(controls) != plan["historical_control_reference_sha256"]:
            raise ValueError("Historical control reference rows differ from the authenticated import.")
    index, physical_answers = {}, {}
    for row in rows:
        key = _key(row)
        if key in index:
            raise ValueError("Duplicate answer-concept identity in reference collection.")
        index[key] = row
        concept, group, origin, prompt = key
        if concept not in plan["concept_ids"] or group not in plan["model_groups"]:
            raise ValueError("Reference row is outside the hypothesis/model matrix.")
        if origin not in plan["model_groups"][group]["answer_origins"]:
            raise ValueError("Answer origin is not part of its fixed model group.")
        if row.get("split") not in ("discovery", "development", "test", "control"):
            raise ValueError("Reference rows require a declared split.")
        validate_presence_annotation(row, response_identity=row)
        if (row.get("verification_mode") != "automatic"
                or row.get("evaluator_version") != EVALUATOR_VERSION
                or row.get("mapping_revision") != MAPPING_REVISION):
            raise ValueError("Current automatic presence provenance is required.")
        check = row["automatic_check"]
        if check["definition_sha256"] != plan["concept_definitions"][concept]:
            raise ValueError("Automatic reference uses a different concept definition.")
        checker = plan["checker"]
        expected_checker = fixed_checker
        if row["split"] == "control" and historical_checker is not None:
            checker = plan["historical_control_checker"]
            expected_checker = historical_checker
        elif row["split"] != "control" and response_checker is not None:
            checker = plan["historical_response_checker"]
            expected_checker = response_checker
        if not row["text"].strip():
            checker = {"checker_id": "empty-text-check", "checker_revision": "1",
                       "checker_configuration": {"rule": "no_textual_concept_without_text"}}
            expected_checker = checker
            if row["presence_label"] != 0:
                raise ValueError("The recorded local empty-text rule requires label zero.")
        actual_checker = {field: check.get(field) for field in checker}
        if presence_checker_identity(actual_checker) != expected_checker:
            raise ValueError("Automatic reference uses a different frozen checker.")
        physical = (origin, prompt)
        binding = (row["content_sha256"], row["split"], _source_families(row), row.get("dependency_family_id"),
                   row.get("response_id"), response_generation_request_id(row))
        if physical_answers.setdefault(physical, binding) != binding:
            raise ValueError("One physical answer has different text, split, or source lineage.")
    tokens = _provenance_tokens(rows)
    provenance_components = _components(tokens)
    component_splits = defaultdict(set)
    for row, component in zip(rows, provenance_components, strict=True):
        component_splits[component].add(row["split"])
    if any(len(splits) > 1 for splits in component_splits.values()):
        raise ValueError("Dependent sources, prompts or physical answers cross data splits.")
    # Repeated content remains one conservative group, but only within its split.
    components = _components([dependencies + [("text", row["split"], row["content_sha256"])]
                              for row, dependencies in zip(rows, tokens, strict=True)])
    prepared = {}
    selected_sizes = defaultdict(set)
    for record in preparation:
        key = tuple(_name(record.get(field)) for field in ("concept_id", "model_group", "reconstruction_id"))
        if key in prepared:
            raise ValueError("Duplicate preparation record.")
        if (key[0] not in plan["concept_ids"] or key[1] not in plan["model_groups"]
                or key[2] not in plan["model_groups"][key[1]]["reconstruction_ids"]):
            raise ValueError("Unplanned preparation record.")
        prepared[key] = record
        size = record.get("compression", {}).get("selected_state_count")
        if size is not None:
            _count(size)
            selected_sizes[key[1]].add(size)
    if any(len(sizes) > 1 for sizes in selected_sizes.values()):
        raise ValueError("Prepared rules within one model group must share the development-selected state count.")
    # Retain the complete original fields, including automatic provenance and diagnostics.
    payload = {"revision": INFERENCE_REVISION, "plan": dict(plan),
               "response_label_policy": RESPONSE_LABEL_POLICY,
               "response_overlap_policy": RESPONSE_OVERLAP_POLICY,
               "response_content_overlap": response_content_overlap(rows),
               "preparation": sorted((dict(row) for row in preparation),
                                     key=lambda row: (row["concept_id"], row["model_group"], row["reconstruction_id"])),
               "reference_rows": rows, "components": components}
    frozen = FrozenPresenceInference(_json(payload))
    # Validate selection and coverage at freeze time, without test predictions.
    for concept, group in itertools.product(plan["concept_ids"], plan["model_groups"]):
        _cell_design(payload, concept, group)
    return frozen


def _rule_check(rule: Mapping, family: str, budget: int, plan: Mapping,
                discovery_digest: str, development_digest: str) -> None:
    _sha(rule.get("rule_sha256"))
    _number(rule.get("threshold"), -1e300, 1e300)
    if "development_mcc" not in rule:
        raise ValueError("Missing development MCC is not an explicitly undefined metric.")
    if rule["development_mcc"] is not None:
        _number(rule["development_mcc"], -1, 1)
    if (rule.get("family") != family or type(rule.get("feature_budget")) is not int
            or rule["feature_budget"] != budget
            or _count(rule.get("feature_count"), 0) > budget
            or rule.get("fit_split") != "discovery"
            or rule.get("selection_split") != "development"
            or rule.get("source_revision") != plan["source_revision"]
            or rule.get("discovery_sha256") != discovery_digest
            or rule.get("development_sha256") != development_digest):
        raise ValueError("Rule fitting, development selection, or feature-budget binding differs.")
    if family == SHORT_GAP_FAMILY and rule.get("fragment_policy") != conservative_fragment_policy():
        raise ValueError("Short-gap rule requires the unchanged G-01 policy.")


def _compression_audit(record: Mapping) -> dict:
    """Separate unavailable protocol sizes from observed recognition metrics."""
    compression = record.get("compression", {})
    required = [20000, 10000, 5000, 2000, 1000]
    observed = compression.get("attained_state_counts", [])
    if not isinstance(observed, (list, tuple)):
        raise ValueError("Attained state counts must be an explicit list.")
    attained = sorted({_count(value) for value in observed}, reverse=True)
    missing = [value for value in required if value not in attained]
    reasons = []
    if (compression.get("selection_split") != "development"
            or compression.get("reference_state_count") != 20000
            or compression.get("selected_state_count") not in required
            or missing
            or compression.get("paired_family_selection") is not True
            or compression.get("multiplicity_adjusted") is not True
            or compression.get("loss_upper") is None):
        reasons.append("missing_attained_compression_selection")
    else:
        _sha(compression.get("evidence_sha256"))
        _sha(record.get("automaton_sha256"))
        if _number(compression["loss_upper"], -2, 2) > 0.02:
            reasons.append("development_compression_loss_exceeds_requirement")
    return {
        "required_state_counts": required, "attained_state_counts": attained,
        "missing_required_state_counts": missing,
        "selected_state_count": compression.get("selected_state_count"),
        "selected_size_attained": compression.get("selected_state_count") in attained,
        "reference_size_attained": 20000 in attained,
        "status": "not_identifiable" if reasons else "selection_record_complete",
        "blocking_reasons": reasons, "requirement_scope": "paper_size_selection_protocol",
        "fixed_attained_size_alternative": "not_preregistered_or_implemented",
    }


def _cell_design(payload: Mapping, concept: str, group: str) -> dict:
    plan = payload["plan"]
    cell = (concept, group)
    rows = {tuple(_key(row)[2:]): row for row in payload["reference_rows"] if _key(row)[:2] == cell}
    component = {tuple(_key(row)[2:]): value for row, value in zip(
        payload["reference_rows"], payload["components"], strict=True) if _key(row)[:2] == cell}
    blockers = []
    for field in ("independent_clusters_assumed", "checker_blind_to_trace_and_construction",
                  "frozen_before_test_predictions", "complete_reference_collection"):
        if plan.get(field) is not True:
            blockers.append("missing_" + field)
    for split in ("discovery", "development", "test"):
        labels = {row["presence_label"] for row in rows.values() if row["split"] == split}
        if labels != {0, 1}:
            blockers.append(split + "_requires_both_resolved_classes")
    if any(row["presence_label"] is None for row in rows.values()):
        blockers.append("unresolved_automatic_reference")
    pairs = []
    coverage = {family: 0 for family in plan.get("contrast_families", {})}
    seen_pairs = set()
    for pair in plan.get("comparisons", []):
        if (pair.get("concept_id"), pair.get("model_group")) != cell:
            continue
        family = pair["family"]
        if family not in coverage:
            raise ValueError("Undeclared contrast family.")
        positive, negative = tuple(pair["positive"]), tuple(pair["negative"])
        identity = (family, positive, negative)
        if identity in seen_pairs:
            raise ValueError("Duplicate contrast contribution.")
        seen_pairs.add(identity)
        if positive not in rows or negative not in rows:
            blockers.append("missing_contrast_answer:" + family)
            continue
        if rows[positive]["split"] != "test" or rows[negative]["split"] != "test":
            raise ValueError("AUC pairs must use held-out test answers.")
        if rows[positive]["presence_label"] != 1 or rows[negative]["presence_label"] != 0:
            blockers.append("contrast_requires_actual_opposite_labels:" + family)
            continue
        pairs.append((positive, negative))
        coverage[family] += 1
    if not coverage:
        blockers.append("missing_preregistered_contrast_families")
    for family, minimum in plan.get("contrast_families", {}).items():
        if coverage[family] < minimum:
            blockers.append("incomplete_contrast_family:" + family)
    pair_clusters = _components([[("component", component[left]), ("component", component[right])]
                                 for left, right in pairs])
    controls = defaultdict(list)
    for control in plan.get("controls", []):
        if (control.get("concept_id"), control.get("model_group")) != cell:
            continue
        family, answer = control["family"], tuple(control["answer"])
        if family not in plan.get("control_families", {}):
            raise ValueError("Undeclared control family.")
        if answer in controls[family]:
            raise ValueError("Duplicate predefined control example.")
        if answer not in rows:
            blockers.append("missing_control_answer:" + family)
            continue
        if rows[answer]["split"] != "control":
            raise ValueError("Predefined example checks require separate control records.")
        controls[family].append(answer)
    if not plan.get("control_families"):
        blockers.append("missing_preregistered_control_families")
    for family, spec in plan.get("control_families", {}).items():
        if len({rows[key]["content_sha256"] for key in controls[family]}) < spec["minimum_count"]:
            blockers.append("incomplete_control_family:" + family)
    if {rows[answer]["presence_label"] for answers in controls.values() for answer in answers} != {0, 1}:
        blockers.append("controls_require_both_actual_classes")
    test = [key for key, row in rows.items() if row["split"] == "test"]
    reconstructions = plan["model_groups"][group]["reconstruction_ids"]
    feasibility = assess_presence_feasibility(
        concept_count=len(plan["concept_ids"]), model_group_count=len(plan["model_groups"]),
        reconstruction_count=len(reconstructions),
        positive_family_count=len({component[key] for key in test if rows[key]["presence_label"] == 1}),
        negative_family_count=len({component[key] for key in test if rows[key]["presence_label"] == 0}),
        auc_cluster_count=len(set(pair_clusters)), stability_family_count=len({component[key] for key in test}),
        positive_class_weight=plan["positive_class_weight"],
        concept_error_share=plan["concept_error_budgets"][concept],
    )
    if not feasibility["perfect_l1_feasible"]:
        blockers.append("perfect_case_l1_infeasible_on_actual_groups")
    candidates, order, compression_audits, exclusions = {}, {}, {}, {}
    families = plan["feature_families"] + plan["text_families"]
    split_digests = {split: presence_reference_digest([row for row in rows.values() if row["split"] == split])
                     for split in ("discovery", "development")}
    records = {row["reconstruction_id"]: row for row in payload["preparation"]
               if (row["concept_id"], row["model_group"]) == cell}
    for reconstruction in reconstructions:
        record = records.get(reconstruction, {})
        if (record.get("reconstruction_split") != "discovery"
                or record.get("reconstruction_label_neutral") is not True):
            blockers.append("missing_discovery_only_label_neutral_reconstruction:" + reconstruction)
        compression_audits[reconstruction] = _compression_audit(record)
        blockers.extend(reason + ":" + reconstruction
                        for reason in compression_audits[reconstruction]["blocking_reasons"])
        available = record.get("candidates", {})
        if set(available) - set(families):
            raise ValueError("Unregistered candidate family in preparation.")
        if set(available) != set(families):
            blockers.append("missing_candidate_development_evidence:" + reconstruction)
            continue
        for family, rule in available.items():
            _rule_check(rule, family, 1 if family in INDIVIDUAL else plan["feature_budget"],
                        plan, split_digests["discovery"], split_digests["development"])
        exclusions[reconstruction] = {
            family: "undefined_development_mcc" for family, rule in available.items()
            if rule["development_mcc"] is None
        }
        candidates[reconstruction] = available
        order[reconstruction] = record.get("order_controls", {})
        if set(order[reconstruction]) - (set(available) & ORDERED):
            raise ValueError("Order controls must refer to declared ordered candidates.")
        for family, transforms in order[reconstruction].items():
            if set(transforms) - {"shuffle", "reverse"}:
                raise ValueError("Unknown order transformation.")
            for transform, rule in transforms.items():
                _rule_check(rule, family, plan["feature_budget"], plan,
                            split_digests["discovery"], split_digests["development"])
                if (rule.get("transform") != transform or rule.get("refitted") is not True
                        or rule.get("preserves_state_counts_and_gaps") is not True
                        or rule.get("transform_applied_to_all_splits") is not True
                        or rule.get("parent_rule_sha256") != available[family]["rule_sha256"]):
                    raise ValueError("Order comparison requires a matched, separately refitted control.")
                _sha(rule.get("transform_evidence_sha256"))
                if rule["development_mcc"] is None:
                    exclusions[reconstruction][family + ":" + transform] = "undefined_development_mcc"
    shared_blockers = list(blockers)
    localization_blockers = list(shared_blockers)
    selected = {}
    if len(candidates) == len(reconstructions):
        complete = {family: [candidates[r][family]["development_mcc"] for r in reconstructions]
                    for family in plan["feature_families"]
                    if all(candidates[r][family]["development_mcc"] is not None for r in reconstructions)}
        eligible = {family: mean(values) for family, values in complete.items()
                    if mean(values) >= 0.35 and min(values) >= 0.20}
        primary = None
        if eligible:
            near_best = [family for family, value in eligible.items() if value >= max(eligible.values()) - 0.02]
            primary = min(near_best, key=lambda family: (
                max(candidates[r][family]["feature_count"] for r in reconstructions),
                family not in INDIVIDUAL, family in ORDERED, family))
        else:
            blockers.append("development_selected_rule_ineligible")
        for reconstruction in reconstructions:
            def best(options: Sequence[str]) -> str | None:
                finite = [family for family in options
                          if candidates[reconstruction][family]["development_mcc"] is not None]
                return min(finite, key=lambda family: (
                    -candidates[reconstruction][family]["development_mcc"], family)) if finite else None

            selected[reconstruction] = {
                "selected": primary, "path": best(sorted(set(families) & PATH)),
                "individual": best(sorted(set(families) & INDIVIDUAL)),
                "text": best(plan["text_families"]),
                "localization": best(sorted(family for family in set(families) & (INDIVIDUAL | {"unordered_state_set"})
                                            if candidates[reconstruction][family]["feature_count"] <= 4)),
            }
        localization_scores = [candidates[r][selected[r]["localization"]]["development_mcc"]
                               for r in reconstructions if selected[r]["localization"] is not None]
        if (len(localization_scores) != len(reconstructions) or min(localization_scores, default=-1) < 0.20
                or mean(localization_scores or [-1]) < 0.35):
            localization_blockers.append("localization_development_rule_ineligible")
    return {"rows": rows, "components": component, "test": test, "pairs": pairs,
            "pair_clusters": pair_clusters, "contrast_coverage": coverage,
            "controls": dict(controls), "candidates": candidates, "order": order,
            "selected": selected, "reconstructions": reconstructions,
            "compression_audits": compression_audits, "development_exclusions": exclusions,
            "split_digests": split_digests, "feasibility": feasibility,
            "shared_blocking_reasons": sorted(set(shared_blockers)),
            "localization_blocking_reasons": sorted(set(localization_blockers)),
            "blocking_reasons": sorted(set(blockers))}


def _metrics(design: Mapping, observations: Mapping, alpha: float, rho: float) -> dict:
    families = defaultdict(list)
    for key in design["test"]:
        families[design["components"][key]].append(observations[key])
    sensitivity = _bounded([mean(row["prediction"] for row in family if row["presence_label"] == 1)
                            for family in families.values() if any(row["presence_label"] == 1 for row in family)], alpha)
    specificity = _bounded([mean(1 - row["prediction"] for row in family if row["presence_label"] == 0)
                            for family in families.values() if any(row["presence_label"] == 0 for row in family)], alpha)
    auc_groups = defaultdict(list)
    for (left, right), cluster in zip(design["pairs"], design["pair_clusters"], strict=True):
        positive, negative = observations[left]["score"], observations[right]["score"]
        auc_groups[cluster].append(float(positive > negative) + 0.5 * (positive == negative))
    return {"mcc": _mcc(sensitivity, specificity, rho), "sensitivity": sensitivity,
            "specificity": specificity,
            "auc": _bounded([mean(values) for values in auc_groups.values()], alpha)}


def _jaccard(design: Mapping, left: Mapping, right: Mapping, alpha: float) -> dict:
    families = defaultdict(list)
    for key in design["test"]:
        families[design["components"][key]].append(key)
    values = []
    for keys in families.values():
        a = {key for key in keys if left[key]["prediction"] == 1}
        b = {key for key in keys if right[key]["prediction"] == 1}
        values.append(len(a & b) / len(a | b) if a | b else 1.0)
    return _bounded(values, alpha)


@lru_cache(maxsize=1)
def _verified_presence_context(frozen: FrozenPresenceInference):
    """Reuse validation of an immutable full snapshot, not a reduced plan."""
    payload = json.loads(frozen.payload)
    if payload.get("revision") != INFERENCE_REVISION:
        raise ValueError("Incompatible inference snapshot. Use its original implementation or a new pretest freeze.")
    verified = freeze_presence_inference(payload["plan"], payload["preparation"], payload["reference_rows"])
    if verified.payload != frozen.payload:
        raise ValueError("Frozen snapshot or computed dependency groups were modified.")
    cells = {cell: {"plan": payload["plan"], "reference_rows": [], "components": [], "preparation": []}
             for cell in itertools.product(payload["plan"]["concept_ids"], payload["plan"]["model_groups"])}
    for row, component in zip(payload["reference_rows"], payload["components"], strict=True):
        cell = cells[row["concept_id"], row["model_group"]]
        cell["reference_rows"].append(row)
        cell["components"].append(component)
    for row in payload["preparation"]:
        cells[row["concept_id"], row["model_group"]]["preparation"].append(row)
    return payload, cells


def evaluate_presence_inference(frozen: FrozenPresenceInference, observations: Sequence[Mapping], *, cells=None) -> dict:
    """Evaluate selected cells under the unchanged FULL frozen plan and budget.

    ``cells`` is an optional nonempty sequence of (concept_id, model_group).
    Observations outside that selection are rejected. Partial results explicitly
    retain the full hypothesis count, reference hash, and primitive allocation.
    Selection controls execution only and cannot change fitted roles or tests.
    """
    payload, cell_payloads = _verified_presence_context(frozen)
    plan = payload["plan"]
    _validate_plan(plan)
    requested = list(cell_payloads) if cells is None else list(cells)
    if not requested or any(not isinstance(cell, (tuple, list)) or len(cell) != 2 for cell in requested):
        raise ValueError("Cell selection requires nonempty concept/group pairs.")
    selected_cells = [tuple(_name(value) for value in cell) for cell in requested]
    if len(set(selected_cells)) != len(selected_cells) or not set(selected_cells) <= set(cell_payloads):
        raise ValueError("Duplicate or unplanned inference cell selection.")
    selected_set = set(selected_cells)
    selected_cells = [cell for cell in cell_payloads if cell in selected_set]
    freeze_digest = frozen.sha256
    reference = {_key(row): row for cell in selected_cells for row in cell_payloads[cell]["reference_rows"]}
    reference_digests = {key: _digest(row) for key, row in reference.items()}
    scored = defaultdict(dict)
    for row in observations:
        key = _key(row)
        if key[:2] not in selected_set:
            raise ValueError("Observation lies outside the selected inference cells.")
        if key not in reference:
            raise ValueError("Scored answer is not in the frozen reference manifest.")
        if _digest({field: value for field, value in row.items() if field not in _SCORED_FIELDS}) != reference_digests[key]:
            raise ValueError("Scored answer text, label, or automatic provenance differs from freeze.")
        if row.get("freeze_sha256") != freeze_digest:
            raise ValueError("Scored observation is not bound to this frozen evaluation.")
        if reference[key]["split"] not in ("test", "control"):
            raise ValueError("Inference accepts held-out test and control predictions only.")
        reconstruction, rule_id = _name(row.get("reconstruction_id")), _name(row.get("rule_id"))
        if reconstruction not in plan["model_groups"][key[1]]["reconstruction_ids"]:
            raise ValueError("Unplanned reconstruction.")
        _sha(row.get("rule_sha256"))
        _number(row.get("score"), -1e300, 1e300)
        if type(row.get("prediction")) is not int or row["prediction"] not in (0, 1):
            raise ValueError("Presence predictions must be binary integers.")
        cell_rule = key[:2] + (reconstruction, rule_id)
        if key[2:] in scored[cell_rule]:
            raise ValueError("Duplicate scored answer within a reconstruction/rule.")
        scored[cell_rule][key[2:]] = row
    outcomes = []
    consumed = set()
    for concept, group in selected_cells:
        design = _cell_design(cell_payloads[concept, group], concept, group)
        base = {"concept_id": concept, "model_group": group,
                "blocking_reasons": design["blocking_reasons"],
                "scoring_blocking_reasons": design["shared_blocking_reasons"],
                "feasibility": design["feasibility"], "selected_families": design["selected"],
                "compression_audits": design["compression_audits"],
                "development_exclusions": design["development_exclusions"],
                "contrast_coverage": design["contrast_coverage"],
                "unknown_label_count": sum(row["presence_label"] is None for row in design["rows"].values()),
                "reference_record_count": len(design["rows"])}
        criteria = {"L1": [], "L2": [], "L3": []}
        localization_criteria = []
        diagnostics = []

        def add(level: str, name: str, interval: Mapping, threshold: float) -> None:
            target = localization_criteria if level == "RQ1" else criteria[level]
            target.append({"criterion": name, **interval, "threshold": threshold,
                           "decision": _decision(interval, threshold)})

        if not design["shared_blocking_reasons"]:
            alpha = design["feasibility"]["alpha_per_primitive"]
            selected_observations, localization_observations = {}, {}
            for reconstruction in design["reconstructions"]:
                rule_metrics, role_rows = {}, {}
                roles = {role: (family, design["candidates"][reconstruction].get(family))
                         for role, family in design["selected"][reconstruction].items()}
                path_family = design["selected"][reconstruction]["path"]
                if path_family in ORDERED:
                    for transform in ("shuffle", "reverse"):
                        rule = design["order"][reconstruction].get(path_family, {}).get(transform)
                        roles[transform] = (path_family + ":" + transform, rule)
                for role, (rule_id, rule) in roles.items():
                    if rule_id is None:
                        role_rows[role] = None
                        continue
                    cell_rule = (concept, group, reconstruction, rule_id)
                    consumed.add(cell_rule)
                    values = scored.get(cell_rule, {})
                    required = set(design["test"])
                    if role == "selected":
                        required |= {key for answers in design["controls"].values() for key in answers}
                    if rule is None or rule["development_mcc"] is None or not required <= set(values):
                        role_rows[role] = None
                        continue
                    for row in values.values():
                        if row["rule_sha256"] != rule["rule_sha256"] or row["prediction"] != int(row["score"] >= rule["threshold"]):
                            raise ValueError("Prediction differs from the frozen rule digest or threshold.")
                    role_rows[role] = values
                    rule_metrics[role] = _metrics(design, values, alpha, plan["positive_class_weight"])
                undefined = _interval(None, -1, 1, "missing_matched_rule_observations")
                if not design["blocking_reasons"]:
                    for metric, threshold in (("mcc", 0.20), ("sensitivity", 0.65), ("auc", 0.55)):
                        add("L1", reconstruction + ":" + metric, rule_metrics.get("selected", {}).get(metric, undefined), threshold)
                if role_rows.get("selected") is not None and not design["blocking_reasons"]:
                    values = role_rows["selected"]
                    selected_observations[reconstruction] = values
                    for family, keys in design["controls"].items():
                        accuracy = mean(values[key]["prediction"] == design["rows"][key]["presence_label"] for key in keys)
                        add("L1", reconstruction + ":control:" + family, _interval(accuracy, accuracy, accuracy),
                            plan["control_families"][family]["minimum_accuracy"])
                if not design["localization_blocking_reasons"]:
                    for metric, threshold in (("mcc", 0.20), ("sensitivity", 0.65), ("auc", 0.55)):
                        add("RQ1", reconstruction + ":" + metric,
                            rule_metrics.get("localization", {}).get(metric, undefined), threshold)
                    add("RQ1", reconstruction + ":text_margin",
                        _gain(rule_metrics.get("localization", {}).get("mcc", undefined),
                              rule_metrics.get("text", {}).get("mcc", undefined)), 0.02)
                    if role_rows.get("localization") is not None:
                        localization_observations[reconstruction] = role_rows["localization"]
                path = rule_metrics.get("path", {}).get("mcc", undefined)
                add("L2", reconstruction + ":path_gain", _gain(path, rule_metrics.get("individual", {}).get("mcc", undefined)), 0.05)
                if path_family in ORDERED:
                    add("L2", reconstruction + ":order_gain", _gain(path, rule_metrics.get("shuffle", {}).get("mcc", undefined)), 0.03)
                    diagnostics.append({"reconstruction_id": reconstruction,
                                        "reversal_mcc": rule_metrics.get("reverse", {}).get("mcc", undefined),
                                        "inferential_gate": False})
                add("L3", reconstruction + ":text_gain", _gain(path, rule_metrics.get("text", {}).get("mcc", undefined)), 0.02)
            for left, right in itertools.combinations(design["reconstructions"], 2):
                interval = _interval(None, 0, 1, "missing_same_answer_stability")
                if left in selected_observations and right in selected_observations:
                    interval = _jaccard(design, selected_observations[left], selected_observations[right], alpha)
                if not design["blocking_reasons"]:
                    add("L1", left + ":" + right + ":jaccard", interval, 0.60)
                if not design["localization_blocking_reasons"]:
                    localization_interval = _interval(None, 0, 1, "missing_same_answer_localization_stability")
                    if left in localization_observations and right in localization_observations:
                        localization_interval = _jaccard(design, localization_observations[left], localization_observations[right], alpha)
                    add("RQ1", left + ":" + right + ":jaccard", localization_interval, 0.60)
        local = {level: _conjunction([item["decision"] for item in values]) for level, values in criteria.items()}
        decisions = {"L1": local["L1"]}
        for level, previous in (("L2", "L1"), ("L3", "L2")):
            decisions[level] = _conjunction([decisions[previous], local[level]])
        supported = [level for level, decision in decisions.items() if decision == "supported"]
        order_decision = "not_identifiable"
        if (not design["shared_blocking_reasons"] and design["selected"]
                and all(roles["path"] is not None for roles in design["selected"].values())):
            order_criteria = [row["decision"] for row in criteria["L2"] if row["criterion"].endswith(":order_gain")]
            order_decision = _conjunction(order_criteria) if order_criteria else "not_applicable"
        outcomes.append({**base, "criteria": criteria, "decisions": decisions,
                         "rq1": {"decision": _conjunction([row["decision"] for row in localization_criteria]),
                             "criteria": localization_criteria, "blocking_reasons": design["localization_blocking_reasons"],
                             "selected_localization_families": {r: roles["localization"] for r, roles in design["selected"].items()},
                             "maximum_state_count": 4, "threshold_source": "explicit_transferred_L1_requirements_and_L3_text_margin",
                             "requires_TRACE_L1": False},
                         "rq2": {"path_gain_decision": _conjunction([row["decision"] for row in criteria["L2"] if row["criterion"].endswith(":path_gain")]),
                             "order_gain_decision": order_decision,
                             "joint_decision": local["L2"], "requires_TRACE_L1": False,
                             "blocking_reasons": design["shared_blocking_reasons"]},
                         "incremental_decisions": local, "diagnostics": diagnostics,
                         "recognition_decision": {"supported": 1, "not_supported": 0}.get(decisions["L1"]),
                         "highest_supported_level": supported[-1] if supported else (0 if decisions["L1"] == "not_supported" else None),
                         "inferential_eligible": not design["blocking_reasons"] and local["L1"] != "not_identifiable"})
    # Unknown rule IDs cannot be silently ignored. Blocked cells retain no decisions.
    for cell_rule in set(scored) - consumed:
        concept, group, reconstruction, rule_id = cell_rule
        record = next((row for row in payload["preparation"] if
                       (row["concept_id"], row["model_group"], row["reconstruction_id"]) == cell_rule[:3]), {})
        if rule_id not in record.get("candidates", {}) and rule_id not in {
            family + ":" + transform for family in record.get("order_controls", {}) for transform in ("shuffle", "reverse")
        }:
            raise ValueError("Observation names an unregistered rule.")
    return {**presence_inference_capabilities(), "freeze_sha256": freeze_digest,
            "response_label_policy": payload["response_label_policy"],
            "reference_manifest_sha256": plan["reference_manifest_sha256"],
            "response_content_overlap": payload["response_content_overlap"],
            "partial": len(selected_cells) != len(cell_payloads),
            "evaluated_cells": [list(cell) for cell in selected_cells],
            "planned_cell_count": len(cell_payloads), "evaluated_cell_count": len(selected_cells),
            "outcomes": outcomes, "planned_hypothesis_count": len(plan["concept_ids"]),
            "auxiliary_control_concept_count": len(plan.get("auxiliary_concept_ids", [])),
            "missing_cells_do_not_reallocate_error": True,
            "claim_scope": "recognition_against_frozen_automatic_answer_presence_reference",
            "control_error_guarantee": "finite_predefined_examples_only_not_population",
            "assumptions": ["independent_joined_source_clusters", "fixed_class_weight_and_comparison_groups",
                            "pretest_freeze_and_complete_collection_attested_externally",
                            "upstream_saved_rules_and_order_transforms_executed_as_recorded"],
            "limitations": ["no_reference_label_error_bound", "no_empirical_power_estimate",
                            "independent_automatic_label_disagreements_retained_without_adjudication",
                            "recurring_text_groups_do_not_establish_independent_clusters",
                            "conservative_gain_bounds_do_not_exploit_pair_covariance",
                            "no_runtime_or_launch_integration", "no_method_validity_or_neural_learning_claim"]}


def combine_presence_inference_cells(frozen: FrozenPresenceInference, results) -> dict:
    """Combine complete cell coverage without changing the full plan's budget.

    This validates coverage and metadata. Each input result must originate from
    evaluate_presence_inference. Export independently recomputes those results
    from the retained observations before accepting the combined report.
    """
    _, cells = _verified_presence_context(frozen)
    prototype = evaluate_presence_inference(frozen, [], cells=[next(iter(cells))])
    varying = {"outcomes", "partial", "evaluated_cells", "evaluated_cell_count"}
    header = {key: value for key, value in prototype.items() if key not in varying}
    outcomes = {}
    for result in results:
        if {key: value for key, value in result.items() if key not in varying} != header:
            raise ValueError("Partial inference uses a different full frozen plan or error budget.")
        declared = [tuple(cell) for cell in result["evaluated_cells"]]
        actual = [(row["concept_id"], row["model_group"]) for row in result["outcomes"]]
        if (actual != declared or len(set(actual)) != len(actual)
                or result["evaluated_cell_count"] != len(actual)
                or result["partial"] != (len(actual) != len(cells))):
            raise ValueError("Partial inference cell inventory changed.")
        for key, row in zip(actual, result["outcomes"], strict=True):
            if key not in cells or key in outcomes:
                raise ValueError("Duplicate or unplanned combined inference cell.")
            outcomes[key] = row
    if set(outcomes) != set(cells):
        raise ValueError("Combined inference is missing planned cells.")
    return {**header, "outcomes": [outcomes[key] for key in cells], "partial": False,
            "evaluated_cells": [list(key) for key in cells], "evaluated_cell_count": len(cells)}
