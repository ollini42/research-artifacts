"""Content-bound concept presence evaluation inputs for E-06-draft.

Presence is independent of truth, affirmation and prompt intent. These APIs
validate annotations and reuse label-neutral detector software. They do not
authorize experiments, establish learned internal representations, or approve
finite-sample or paired MCC inference. Missing labels block the complete cell.
"""

from __future__ import annotations

import math
from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from copy import deepcopy
from pathlib import Path

from .concept_presence_data import (
    LABEL_OBJECTIVE,
    RESPONSE_LABEL_POLICY,
    AUTOMATIC_ANNOTATION_FIELDS,
    content_sha256,
    response_content_overlap,
    response_provenance_keys,
    response_generation_request_id,
    dependency_family_id,
    load_concept_presence_catalog,
    validate_concept_presence_definition as _validate_concept,
    validate_presence_annotation,
    _json_sha256,
    _observe_response_label,
)
from .trace_coverage import SHORT_GAP_FAMILY, conservative_fragment_policy

EVALUATOR_VERSION = "E-06-draft"
MAPPING_REVISION = "concept-presence-v1"
IDENTITY_FIELDS = ("concept_id", "model_seed", "prompt_id", "source_family_id")


def _annotation_metadata(item) -> dict:
    metadata = deepcopy(dict(item.annotation_metadata))
    if set(metadata) - set(AUTOMATIC_ANNOTATION_FIELDS):
        raise ValueError("Annotation metadata cannot override answer content or reference provenance.")
    return metadata


class PresenceIntegrationRequired(ValueError):
    """The historical runtime cannot evaluate the new objective."""


def reject_presence_in_legacy(*values: object) -> None:
    """Fail before a presence artifact enters a polarity-dependent routine."""
    pending = list(values)
    while pending:
        value = pending.pop()
        if isinstance(value, Mapping):
            if (
                value.get("label_objective") == LABEL_OBJECTIVE
                or "presence_label" in value
                or "inclusion_definition" in value
                or any(str(value.get(key, "")).startswith("E-06") for key in (
                    "version", "evaluator_version", "evaluator_implementation_revision"
                ))
            ):
                raise PresenceIntegrationRequired(
                    "E-06-draft concept_presence requires the presence input API. "
                    "Legacy polarity evaluation is prohibited. Runtime integration "
                    "and statistical release remain unapproved."
                )
            pending.extend(value.values())
        elif isinstance(value, (list, tuple)):
            pending.extend(value)
        elif getattr(value, "label_objective", None) == LABEL_OBJECTIVE:
            raise PresenceIntegrationRequired(
                "Concept presence cannot enter a legacy polarity routine."
            )


def _nonempty(record: Mapping, key: str) -> str:
    value = record.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ValueError("{} must be a nonempty string.".format(key))
    return value


def _source_families(record: Mapping) -> tuple[str, ...]:
    primary = _nonempty(record, "source_family_id")
    supplied = record.get("source_family_ids")
    if not isinstance(supplied, (list, tuple)) or not supplied or any(
        not isinstance(value, str) or not value.strip() for value in supplied
    ):
        raise ValueError("source_family_ids must contain nonempty source identities.")
    return tuple(sorted(set(supplied) | {primary}))


def load_presence_catalog(path: str | Path) -> dict[str, dict]:
    """Load reviewed presence definitions, never E-05 canonical/negated pairs."""
    path = Path(path)
    if path.suffix.lower() != ".json":
        raise ValueError("The E-06-draft concept catalog must be JSON.")
    return {
        row["concept_id"]: row
        for row in load_concept_presence_catalog(path, require_reviewed=True)
    }


@dataclass(frozen=True)
class PresenceExample:
    """A response or unchanged reviewed control with explicit label provenance."""

    prompt_id: str
    label: int | None
    condition: str
    pair_id: str
    prompt_text: str
    path: tuple[int, ...]
    answer_text: str
    answer_tokens: tuple[str, ...]
    concept_id: str
    model_seed: str
    source_family_id: str
    split: str
    content_sha256: str | None
    audit_status: str
    annotation_source: str | None
    mapping_kinds: tuple[str, ...]
    diagnostics: tuple[tuple[str, str], ...] = ()
    annotation_metadata: tuple[tuple[str, object], ...] = ()
    condition_index: int = 0
    base_question_index: str | None = None
    source_family_ids: tuple[str, ...] = ()
    dependency_family_id: str | None = None
    label_objective: str = LABEL_OBJECTIVE

    mapping_revision: str = MAPPING_REVISION
    response_id: str | None = None
    generation_request_id: str | None = None


@dataclass(frozen=True)
class PresenceEvaluationInput:
    """All expected responses, including missing and unresolved observations."""

    concept_id: str
    model_seed: str
    examples: tuple[PresenceExample, ...]
    blocking_reasons: tuple[str, ...]
    evaluator_version: str = EVALUATOR_VERSION
    label_objective: str = LABEL_OBJECTIVE
    response_overlap: Mapping | None = None


def _validated_answer_tokens(text: str, raw_tokens: Sequence[str]) -> tuple[str, ...]:
    from .tokenization import TokenizationConfig, tokenize_text

    if not isinstance(text, str) or not isinstance(raw_tokens, (list, tuple)) or any(
        not isinstance(token, str) for token in raw_tokens
    ):
        raise ValueError("Response text and answer_tokens must be strings and a sequence of strings.")
    tokens = tuple(raw_tokens)
    expected = tuple(tokenize_text(
        text, TokenizationConfig(mode="word", lowercase=True, max_tokens=None)
    ))
    if tokens != expected:
        raise ValueError("Response tokens do not match complete annotated text.")
    return tokens


def _validate_presence_mapping(tokens: Sequence[str], path: Sequence[int], kinds: Sequence[str]) -> None:
    if not path or len(path) != len(kinds) + 1 or len(kinds) != len(tokens):
        raise ValueError("Presence path must align with every response token.")
    if any(type(state) is not int for state in path) or any(
        kind not in {"exact", "reconstruction_exact", "global_fallback", "unknown"}
        for kind in kinds
    ):
        raise ValueError("Invalid presence mapping provenance.")
    if any(kind == "unknown" and path[i] != path[i + 1] for i, kind in enumerate(kinds)):
        raise ValueError("Unknown boundary must repeat the current state.")


def build_presence_evaluation_input(
    *,
    concept_id: str,
    model_seed: str,
    manifest_rows: Sequence[Mapping],
    response_rows: Sequence[Mapping],
    annotations: Sequence[Mapping],
    paths: Mapping[str, Sequence[int]],
    mapping_kinds: Mapping[str, Sequence[str]],
    mapping_revision: str,
    question_manifest: Mapping | None = None,
) -> PresenceEvaluationInput:
    """Bind a complete concept/model cell to reviewed response content.

    Response rows use concept_id, model_seed, prompt_id, source_family_id,
    source_family_ids, text and answer_tokens. The manifest supplies split
    and the complete reviewed source-family identity.
    Tokens must match full lowercased word tokenization without truncation.
    All supplied responses and annotations must belong to this cell. Prompt
    expected_label, polarity and question intent are deliberately ignored.
    """
    if mapping_revision != MAPPING_REVISION:
        raise ValueError("E-06-draft requires concept-presence-v1 mapping provenance.")
    automatic = any(row.get("verification_mode") == "automatic" or "automatic_check" in row
                    for row in (*manifest_rows, *annotations))
    if automatic:
        if (question_manifest is None or question_manifest.get("questions_sha256")
                != _json_sha256(question_manifest.get("questions", []))):
            raise ValueError("Automatic evaluation requires the intact frozen question manifest.")
        frozen = {row["prompt_id"]: row for row in question_manifest["questions"]}
        if len(frozen) != len(question_manifest["questions"]):
            raise ValueError("Duplicate question in frozen manifest.")
        if any(frozen.get(row["prompt_id"]) != row for row in manifest_rows):
            raise ValueError("Supplied rows differ from the frozen question manifest, including splits.")
        if {row["prompt_id"] for row in manifest_rows if row["concept_id"] == concept_id} != {
            row["prompt_id"] for row in frozen.values() if row["concept_id"] == concept_id
        }:
            raise ValueError("The complete frozen concept cell must be evaluated.")
    manifest = {}
    family_splits = defaultdict(set)
    for row in manifest_rows:
        prompt_id = _nonempty(row, "prompt_id")
        split = row.get("split")
        if split not in {"discovery", "development", "test"}:
            raise ValueError("Manifest split must be discovery, development, or test.")
        for source_family in _source_families(row):
            family_splits[source_family].add(split)
        dependency = dependency_family_id(row)
        if dependency is not None:
            family_splits[("canonical_dependency", dependency)].add(split)
        if _nonempty(row, "concept_id") == concept_id:
            if prompt_id in manifest:
                raise ValueError("Duplicate manifest prompt identity.")
            manifest[prompt_id] = row
    if not manifest:
        raise ValueError("The requested concept has no manifest rows.")

    def index_records(records: Sequence[Mapping]) -> dict:
        indexed = {}
        for row in records:
            prompt_id = _nonempty(row, "prompt_id")
            if prompt_id not in manifest:
                raise ValueError("Unexpected response or annotation prompt identity.")
            expected = {
                "concept_id": concept_id, "model_seed": model_seed,
                "prompt_id": prompt_id,
                "source_family_id": manifest[prompt_id]["source_family_id"],
            }
            for key in IDENTITY_FIELDS:
                if _nonempty(row, key) != _nonempty(expected, key):
                    raise ValueError("Response or annotation {} binding differs.".format(key))
            if _source_families(row) != _source_families(manifest[prompt_id]):
                raise ValueError("Response or annotation source_family_ids binding differs.")
            if dependency_family_id(row) != dependency_family_id(manifest[prompt_id]):
                raise ValueError("Response or annotation dependency_family_id binding differs.")
            if automatic and row.get("split") != manifest[prompt_id]["split"]:
                raise ValueError("Automatic response or annotation differs from the frozen split.")
            if prompt_id in indexed:
                raise ValueError("Duplicate response or annotation identity.")
            indexed[prompt_id] = row
        return indexed

    responses = index_records(response_rows)
    annotation_index = index_records(annotations)
    blockers = set()
    if any(len(splits) > 1 for splits in family_splits.values()):
        blockers.add("source_family_split_leakage")
    examples = []
    origin_splits = defaultdict(set)
    origin_owners = {}
    overlap_rows = []
    reviewed_labels_by_content = {}
    for prompt_id, prompt in sorted(manifest.items()):
        response = responses.get(prompt_id)
        annotation = annotation_index.get(prompt_id)
        text = ""
        tokens = ()
        digest = None
        label = None
        status = "unresolved"
        source = ""
        if annotation is not None:
            validate_presence_annotation(annotation, concept_id=concept_id)
            if automatic and annotation.get("verification_mode") != "automatic":
                raise ValueError("An automatic manifest requires automatic answer checks.")
        if response is None:
            blockers.add("missing_response")
        else:
            text = response.get("text")
            digest = content_sha256(text)
            tokens = _validated_answer_tokens(text, response.get("answer_tokens"))
            for key in response_provenance_keys(response):
                origin_splits[key].add(prompt["split"])
                if key[0] in {"response", "generation_request"}:
                    if origin_owners.setdefault(key, prompt_id) != prompt_id:
                        blockers.add("reused_response_record")
            overlap_rows.append({**response, "content_sha256": digest, "split": prompt["split"]})
            if annotation is not None:
                validate_presence_annotation(
                    annotation, concept_id=concept_id, text=text,
                    response_identity=response,
                )
                if annotation.get("verification_mode") == "automatic":
                    binding = annotation.get("construction_binding", {})
                    if (binding.get("prompt_id") != prompt_id
                            or binding.get("questions_sha256") != question_manifest["questions_sha256"]
                            or binding.get("question_content_sha256") != content_sha256(prompt["text"])
                            or any(binding.get(key) != prompt.get(key) for key in ("catalog_sha256", "plan_sha256"))
                            or annotation["automatic_check"]["definition_sha256"]
                            != prompt.get("automatic_check", {}).get("definition_sha256")):
                        raise ValueError("Automatic answer check differs from frozen question or concept binding.")
                status = annotation["audit_status"]
                source = annotation.get("annotation_source")
                if status == "reviewed":
                    label = annotation["presence_label"]
                    if label is not None:
                        disagrees, automatic_only = _observe_response_label(reviewed_labels_by_content, annotation)
                        if disagrees and not automatic_only:
                            raise ValueError("Conflicting reviewed labels for the same concept and text.")
        if annotation is None:
            blockers.add("missing_response_annotation")
        if label is None:
            blockers.add("unknown_presence_label")
        if prompt_id not in paths or prompt_id not in mapping_kinds:
            blockers.add("missing_mapping_provenance")
        path = tuple(paths.get(prompt_id, ()))
        kinds = tuple(mapping_kinds.get(prompt_id, ()))
        if response is not None and prompt_id in paths and prompt_id in mapping_kinds:
            _validate_presence_mapping(tokens, path, kinds)
        examples.append(PresenceExample(
            prompt_id=prompt_id, label=label,
            condition=str(prompt.get("condition", "unspecified")),
            pair_id=str(prompt.get("pair_id", "")),
            prompt_text=str(prompt.get("prompt_text", prompt.get("text", ""))), path=path,
            answer_text=text, answer_tokens=tokens, concept_id=concept_id,
            model_seed=model_seed, source_family_id=prompt["source_family_id"],
            split=prompt["split"], content_sha256=digest, audit_status=status,
            annotation_source=source, mapping_kinds=kinds,
            source_family_ids=_source_families(prompt),
            dependency_family_id=dependency_family_id(prompt),
            response_id=response.get("response_id") if response is not None else None,
            generation_request_id=response_generation_request_id(response) if response is not None else None,
            annotation_metadata=tuple((key, deepcopy(annotation[key])) for key in AUTOMATIC_ANNOTATION_FIELDS
                                      if annotation is not None and key in annotation),
            diagnostics=tuple((key, str(annotation[key])) for key in (
                "polarity", "style", "factual_correctness"
            ) if annotation is not None and key in annotation),
        ))
    if any(len(splits) > 1 for splits in origin_splits.values()):
        blockers.add("response_origin_split_leakage")
    for split in ("discovery", "development", "test"):
        split_examples = [item for item in examples if item.split == split]
        if not split_examples:
            blockers.add("missing_{}_split".format(split))
        elif {item.label for item in split_examples} != {0, 1}:
            blockers.add("{}_requires_two_reviewed_presence_classes".format(split))
    return PresenceEvaluationInput(concept_id, model_seed, tuple(examples), tuple(sorted(blockers)),
                                   response_overlap=response_content_overlap(overlap_rows))


def presence_assurance_status(inputs: PresenceEvaluationInput) -> dict:
    """Separate input completeness from unapproved statistical eligibility."""
    return {
        "label_objective": LABEL_OBJECTIVE,
        "evaluator_version": EVALUATOR_VERSION,
        "response_label_policy": RESPONSE_LABEL_POLICY,
        "concept_id": inputs.concept_id,
        "model_seed": inputs.model_seed,
        "expected_response_count": len(inputs.examples),
        "unknown_label_count": sum(item.label is None for item in inputs.examples),
        "input_complete": not inputs.blocking_reasons,
        "blocking_reasons": list(inputs.blocking_reasons),
        "response_content_overlap": deepcopy(inputs.response_overlap),
        "inferential_eligible": False,
        "statistical_approval": "unapproved_draft",
        "paired_mcc_inference": "unapproved",
        "finite_sample_guarantee": "unapproved",
        "runtime_dispatch": "integration_required",
        "recognition_status": "not_identifiable",
        "recognition_decision": None,
        "supported_level": None,
        "claim_scope": "annotated_response_concept_presence_only",
    }


def validate_presence_stability_inputs(
    left_rows: Sequence[Mapping], right_rows: Sequence[Mapping]
) -> dict:
    """Require common annotated answer anchors across reconstructed automata.

    model_seed identifies the answer origin, not the reconstructed automaton.
    A reconstruction_id may be carried separately. Matching prompts alone do
    not establish matching answers. This validates alignment, not independent
    sampling or preregistration of the anchor pool.
    """
    reasons = set()

    def index(rows: Sequence[Mapping]) -> dict:
        indexed = {}
        for row in rows:
            validate_presence_annotation(row, response_identity=row)
            key = tuple(row[field] for field in IDENTITY_FIELDS[:3])
            if key in indexed:
                raise ValueError("Duplicate answer anchor identity within reconstruction.")
            indexed[key] = row
            if row["audit_status"] != "reviewed" or row["presence_label"] is None:
                reasons.add("unknown_anchor_presence_label")
            if row.get("split") != "test":
                reasons.add("anchor_pool_not_held_out_test")
        return indexed

    left, right = index(left_rows), index(right_rows)
    if not left or not right:
        reasons.add("missing_answer_anchors")
    if set(left) != set(right):
        reasons.add("different_answer_anchor_identities")
    for key in set(left) & set(right):
        if left[key]["content_sha256"] != right[key]["content_sha256"]:
            reasons.add("different_answer_anchor_content")
        if left[key]["presence_label"] != right[key]["presence_label"]:
            reasons.add("different_answer_anchor_labels")
        if left[key]["source_family_id"] != right[key]["source_family_id"]:
            reasons.add("different_answer_anchor_source_families")
        if _source_families(left[key]) != _source_families(right[key]):
            reasons.add("different_answer_anchor_source_families")
        if dependency_family_id(left[key]) != dependency_family_id(right[key]):
            reasons.add("different_answer_anchor_source_families")
    return {
        "label_objective": LABEL_OBJECTIVE, "evaluator_version": EVALUATOR_VERSION,
        "status": "aligned_for_descriptive_comparison" if not reasons else "unassessable",
        "shared_anchor_count": len(set(left) & set(right)),
        "reasons": sorted(reasons), "inferential_eligible": False,
        "preregistered_anchor_pool_verified": False,
        "cross_reconstruction_independence_assumed": False,
    }


def evaluate_presence_feature_detector(inputs: PresenceEvaluationInput, family: str) -> dict:
    """Fit on discovery and select on development, with descriptive test metrics."""
    from .confirmatory_detector import fit_select_evaluate_feature_detector

    if family == "prompt_tfidf":
        raise PresenceIntegrationRequired(
            "Prompt-only baseline export requires separate presence integration."
        )
    status = presence_assurance_status(inputs)
    if inputs.blocking_reasons:
        raise PresenceIntegrationRequired(
            "Presence evaluation input is blocked: {}.".format(
                ", ".join(inputs.blocking_reasons)
            )
        )
    splits = {
        split: [item for item in inputs.examples if item.split == split]
        for split in ("discovery", "development", "test")
    }
    result = fit_select_evaluate_feature_detector(
        family, splits["discovery"], splits["development"], splits["test"],
        compute_order_controls=False,
    )
    if family == SHORT_GAP_FAMILY:
        result["fragment_policy"] = conservative_fragment_policy()
        result["cross_gap_path_claim"] = False
        result["order_gain_verified"] = False
    result.pop("feature_budget_curve", None)
    result.pop("auprc", None)
    result.update(_presence_metrics(
        [item.label for item in splits["test"]], result["_predictions"], result["_scores"]
    ))
    development = _presence_metrics(
        [item.label for item in splits["development"]],
        result["_development_predictions"], result["_development_scores"],
    )
    result["development_mcc"] = development["mcc"]
    return {
        **status, "evidence_role": "descriptive_software_evaluation",
        "detector": result,
        "observations": presence_observation_rows(
            splits["test"], result["_predictions"], result["_scores"]
        ),
    }


def _presence_metrics(labels: Sequence[int], predictions: Sequence[int], scores: Sequence[float]) -> dict:
    from .confirmatory_detector import classification_metrics

    result = classification_metrics(labels, predictions, scores)
    # The historical average-precision tie convention is not part of this API.
    result.pop("auprc")
    tp, tn, fp, fn = (result[key] for key in ("tp", "tn", "fp", "fn"))
    defined = bool((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    result["mcc_defined"] = defined
    if not defined:
        result["mcc"] = None
    return result


def score_presence_examples(result: Mapping, examples: Sequence[PresenceExample]) -> dict:
    """Apply the fitted feature rule unchanged to responses or reviewed controls."""
    from .confirmatory_detector import extract_features, score_feature_sets

    if result.get("evaluator_version") != EVALUATOR_VERSION or result.get("label_objective") != LABEL_OBJECTIVE:
        raise PresenceIntegrationRequired("Scoring requires a fitted E-06-draft presence result.")
    detector = result["detector"]
    if detector.get("family") == SHORT_GAP_FAMILY and detector.get("fragment_policy") != conservative_fragment_policy():
        raise PresenceIntegrationRequired("Saved fragment policy differs from current extraction.")
    if "_weights" not in detector:
        raise PresenceIntegrationRequired("The detector does not export a reusable feature rule.")
    if any(item.concept_id != result["concept_id"] for item in examples):
        raise ValueError("Scored controls or responses must target the fitted concept.")
    for item in examples:
        if item.label_objective != LABEL_OBJECTIVE or item.mapping_revision != MAPPING_REVISION:
            raise ValueError("Presence scoring requires the explicit presence revisions.")
        tokens = _validated_answer_tokens(item.answer_text, item.answer_tokens)
        _validate_presence_mapping(tokens, item.path, item.mapping_kinds)
        if item.content_sha256 is not None:
            validate_presence_annotation({
                "label_objective": item.label_objective, "concept_id": item.concept_id,
                "text": item.answer_text, "content_sha256": item.content_sha256,
                "presence_label": item.label, "audit_status": item.audit_status,
                "annotation_source": item.annotation_source,
                **_annotation_metadata(item),
            })
        elif item.label is not None:
            raise ValueError("Known labels require content-bound annotations.")
    scores = score_feature_sets(
        [extract_features(item, detector["family"]) for item in examples],
        detector["_weights"],
    )
    predictions = [int(score >= detector["threshold"]) for score in scores]
    return {
        "label_objective": LABEL_OBJECTIVE, "evaluator_version": EVALUATOR_VERSION,
        "predictions": predictions, "scores": scores,
        "observations": presence_observation_rows(examples, predictions, scores),
        "inferential_eligible": False,
    }


def presence_observation_rows(
    examples: Sequence[PresenceExample], predictions: Sequence[int], scores: Sequence[float]
) -> list[dict]:
    """Retain unknown labels and response identity in every scored observation."""
    if not (len(examples) == len(predictions) == len(scores)):
        raise ValueError("Examples, predictions, and scores must have equal lengths.")
    rows = []
    for item, prediction, score in zip(examples, predictions, scores, strict=True):
        if item.label_objective != LABEL_OBJECTIVE or item.mapping_revision != MAPPING_REVISION:
            raise ValueError("Presence observations require the explicit presence revisions.")
        if item.content_sha256 is not None:
            validate_presence_annotation({
                "label_objective": item.label_objective, "concept_id": item.concept_id,
                "text": item.answer_text, "content_sha256": item.content_sha256,
                "presence_label": item.label, "audit_status": item.audit_status,
                "annotation_source": item.annotation_source,
                **_annotation_metadata(item),
            })
        elif item.label is not None:
            raise ValueError("Known labels require content-bound annotations.")
        if type(prediction) is not int or prediction not in (0, 1):
            raise ValueError("Presence predictions must be binary integers.")
        if not math.isfinite(float(score)):
            raise ValueError("Presence scores must be finite.")
        rows.append({
            "label_objective": LABEL_OBJECTIVE, "evaluator_version": EVALUATOR_VERSION,
            **{key: getattr(item, key) for key in IDENTITY_FIELDS},
            "source_family_ids": list(item.source_family_ids or (item.source_family_id,)),
            "dependency_family_id": item.dependency_family_id,
            "text": item.answer_text, "content_sha256": item.content_sha256,
            "presence_label": item.label if item.audit_status == "reviewed" else None,
            "audit_status": item.audit_status,
            "annotation_source": item.annotation_source, "split": item.split,
            **{key: getattr(item, key) for key in ("response_id", "generation_request_id")
               if getattr(item, key) is not None},
            **_annotation_metadata(item),
            "prediction": prediction, "score": float(score),
            "mapping_revision": item.mapping_revision,
            "diagnostics": dict(item.diagnostics),
        })
    return rows


def build_presence_control_examples(
    concept: Mapping, transitions: Sequence[dict], root_state: int
) -> tuple[PresenceExample, ...]:
    """Map unchanged reviewed example texts, without synthesizing truth classes."""
    from .confirmatory_detector import _map_token_sequence, _transition_maps
    from .tokenization import TokenizationConfig, tokenize_text

    concept = _validate_concept(concept)
    exact, global_target = _transition_maps(transitions)
    tokenization = TokenizationConfig(mode="word", lowercase=True, max_tokens=None)
    controls = []
    for index, annotation in enumerate(concept["examples"]):
        tokens = tuple(tokenize_text(annotation["text"], tokenization))
        path, kinds = _map_token_sequence(
            tokens, root_state, exact, global_target, mapping_revision=MAPPING_REVISION
        )
        controls.append(PresenceExample(
            prompt_id="presence-control:{}:{}".format(concept["concept_id"], index),
            label=annotation["presence_label"], condition="reviewed_presence_control",
            pair_id="", prompt_text="", path=path, answer_text=annotation["text"],
            answer_tokens=tokens, concept_id=concept["concept_id"], model_seed="control",
            source_family_id="", split="control",
            content_sha256=annotation["content_sha256"], audit_status="reviewed",
            annotation_source=annotation["annotation_source"], mapping_kinds=kinds,
            annotation_metadata=tuple((key, deepcopy(annotation[key])) for key in AUTOMATIC_ANNOTATION_FIELDS
                                      if key in annotation),
            diagnostics=tuple((key, str(annotation[key])) for key in (
                "polarity", "style", "factual_correctness"
            ) if key in annotation),
        ))
    return tuple(controls)


def presence_control_summary(
    examples: Sequence[PresenceExample], predictions: Sequence[int], scores: Sequence[float]
) -> dict:
    """Summarize annotated classes, with polarity and style as diagnostics only."""
    rows = presence_observation_rows(examples, predictions, scores)
    unknown = sum(row["presence_label"] is None or row["audit_status"] != "reviewed" for row in rows)
    complete = bool(rows) and not unknown and {row["presence_label"] for row in rows} == {0, 1}
    diagnostics = defaultdict(list)
    for row in rows:
        for key, value in row["diagnostics"].items():
            diagnostics[(key, value)].append(row)
    return {
        "label_objective": LABEL_OBJECTIVE, "evaluator_version": EVALUATOR_VERSION,
        "control_count": len(rows), "unknown_label_count": unknown,
        "class_coverage_complete": complete, "inferential_eligible": False,
        "metrics": _presence_metrics(
            [row["presence_label"] for row in rows], predictions, scores
        ) if complete else None,
        "diagnostics": [
            {"dimension": key, "value": value, "count": len(group),
             "predicted_present_count": sum(row["prediction"] for row in group)}
            for (key, value), group in sorted(diagnostics.items())
        ],
        "statistical_approval": "unapproved_draft",
        "independence_assumed": False,
    }
