"""Offline model calls with content-bound, restartable single-writer journals.

Each batch is committed in one SQLite transaction. A completed response is
never regenerated because a semantic check dislikes it. Journals belong to
one fixed shard and model condition, not a shared concurrent output database.
"""

from __future__ import annotations

from contextlib import AbstractContextManager
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import sqlite3

from .checkpoint_io import _writer_lock
from .concept_presence_data import _json_sha256


def _json(value: object) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)


class ModelCallJournal(AbstractContextManager):
    """Persist complete batches and reject rebinding after an interruption."""

    def __init__(self, path: str | Path, binding: dict):
        for field in ("campaign_id", "source_sha256", "config_sha256", "model_id",
                      "model_revision", "model_manifest_sha256", "condition_id", "shard_id"):
            if not isinstance(binding.get(field), str) or not binding[field].strip():
                raise ValueError("Model-call binding is missing " + field)
        self.path = Path(path)
        self.binding = deepcopy(binding)
        self.binding_sha256 = _json_sha256(binding)
        self.connection = None
        self.lock = None
        self.generated_records = 0
        self.reused_records = 0

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = _writer_lock(self.path, blocking=False)
        self.lock.__enter__()
        try:
            self.connection = sqlite3.connect(str(self.path))
            self.connection.execute("PRAGMA journal_mode=TRUNCATE")
            self.connection.execute("PRAGMA synchronous=FULL")
            self.connection.execute("CREATE TABLE IF NOT EXISTS binding (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL)")
            self.connection.execute("CREATE TABLE IF NOT EXISTS batches (batch_id TEXT PRIMARY KEY, request TEXT NOT NULL, result TEXT NOT NULL, digest TEXT NOT NULL)")
            self.connection.execute("CREATE TABLE IF NOT EXISTS requests (request_id TEXT PRIMARY KEY, batch_id TEXT NOT NULL)")
            stored = self.connection.execute("SELECT value FROM binding WHERE id=1").fetchone()
            if stored is not None and json.loads(stored[0]) != self.binding:
                raise ValueError("Journal belongs to another source, model, shard or condition.")
            with self.connection:
                self.connection.execute("INSERT OR IGNORE INTO binding VALUES (1, ?)", (_json(self.binding),))
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, exc_type, exc, traceback):
        if self.connection is not None:
            self.connection.close()
            self.connection = None
        if self.lock is not None:
            self.lock.__exit__(exc_type, exc, traceback)
            self.lock = None

    def batch(self, requests: list[dict], backend, *, seed: int) -> list[dict]:
        """Reuse exact complete batch output, including truncated or empty text."""
        if not requests or type(seed) is not int or seed < 0:
            raise ValueError("A nonempty batch and nonnegative integer seed are required.")
        ids = [row.get("request_id") for row in requests]
        if any(not isinstance(value, str) or not value for value in ids) or len(ids) != len(set(ids)):
            raise ValueError("Batch request IDs must be unique and nonempty.")
        payload = {"binding": self.binding_sha256, "requests": requests, "seed": seed}
        batch_id = _json_sha256(payload)
        stored = self.connection.execute(
            "SELECT request, result, digest FROM batches WHERE batch_id=?", (batch_id,)
        ).fetchone()
        if stored is not None:
            result = json.loads(stored[1])
            if json.loads(stored[0]) != payload or _json_sha256(result) != stored[2]:
                raise ValueError("Cached model batch failed its content check.")
            self.reused_records += len(result)
            return result
        if any(self.connection.execute("SELECT 1 FROM requests WHERE request_id=?", (identity,)).fetchone()
               for identity in ids):
            raise ValueError("A request cannot be reused in a different batch or sampling condition.")
        result = backend(deepcopy(requests), seed=seed)
        if not isinstance(result, list) or len(result) != len(requests):
            raise ValueError("Backend must return exactly one completion per request.")
        for request, completion in zip(requests, result, strict=True):
            if (not isinstance(completion, dict) or completion.get("request_id") != request["request_id"]
                    or not isinstance(completion.get("text"), str)
                    or completion.get("finish_reason") not in ("stop", "length")
                    or type(completion.get("input_tokens")) is not int
                    or completion["input_tokens"] < 1
                    or type(completion.get("output_tokens")) is not int
                    or completion["output_tokens"] < 0):
                raise ValueError("Malformed or reordered model completion.")
        with self.connection:
            self.connection.execute("INSERT INTO batches VALUES (?, ?, ?, ?)", (
                batch_id, _json(payload), _json(result), _json_sha256(result),
            ))
            self.connection.executemany("INSERT INTO requests VALUES (?, ?)", ((identity, batch_id) for identity in ids))
        self.generated_records += len(result)
        return deepcopy(result)


def run_fixed_batches(requests: list[dict], journal: ModelCallJournal, backend, *,
                      batch_size: int, base_seed: int, stop_requested=lambda: False) -> dict:
    """Fix batch membership before cache lookup so resume cannot change sampling."""
    from .presence_parallel_batches import maybe_parallel_batches
    parallel = None if getattr(backend, "_presence_cache_only", False) else maybe_parallel_batches(
        requests, journal, backend, batch_size=batch_size, base_seed=base_seed, stop_requested=stop_requested)
    if parallel is not None:
        return parallel
    if type(batch_size) is not int or batch_size < 1 or type(base_seed) is not int or base_seed < 0:
        raise ValueError("Batch size and seed must be valid integers.")
    ids = [row.get("request_id") for row in requests]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate model request identity.")
    ordered = sorted(requests, key=lambda row: row["request_id"])
    schedule = {"requests": ordered, "batch_size": batch_size, "base_seed": base_seed}
    schedule_id = _json_sha256(schedule)
    # Binding the schedule prevents a different grouping from reusing this shard.
    existing = journal.connection.execute("SELECT value FROM binding WHERE id=1").fetchone()
    expected = json.loads(existing[0]).get("request_schedule_sha256")
    if expected != schedule_id:
        raise ValueError("Journal must bind the full fixed request schedule.")
    completions = []
    for offset in range(0, len(ordered), batch_size):
        if stop_requested():
            return {"complete": False, "completed_records": len(completions),
                    "schedule_sha256": schedule_id, "completions": completions}
        batch = ordered[offset:offset + batch_size]
        seed = int(_json_sha256([base_seed, [row["request_id"] for row in batch]])[:8], 16)
        completions.extend(journal.batch(batch, backend, seed=seed))
    return {"complete": True, "completed_records": len(completions),
            "schedule_sha256": schedule_id, "completions": completions}


def presence_check_from_completion(request: dict, completion: dict, *, checker_binding: dict) -> dict:
    """Turn JSON output into evidence without asking the model to invent provenance.

Malformed, ambiguous or truncated output is preserved as an unresolved check.
Exact evidence quotes are located in the unchanged complete answer. No fuzzy
matching repairs a quote that the model did not copy correctly.
"""
    profile = checker_binding.get("condition", {}).get("checker_profile", {})
    if ("presence_prompt_variant" in profile or "presence_evidence_binding" in checker_binding
            or "presence_evidence_request_binding" in checker_binding):
        from .presence_evidence_units import parse
        return parse(request, completion, checker_binding=checker_binding)
    if completion.get("request_id") != request.get("request_sha256"):
        raise ValueError("Checker completion belongs to another request.")
    reason = None
    try:
        if completion.get("finish_reason") != "stop":
            raise ValueError("checker_output_truncated")
        parsed = parse_model_json(completion["text"])
        if not isinstance(parsed, dict):
            raise ValueError("checker_output_not_object")
        label = parsed["presence_label"]
        if label is not None and (type(label) is not int or label not in (0, 1)):
            raise ValueError("invalid_presence_label")
        if not isinstance(parsed.get("rationale"), str) or not parsed["rationale"].strip():
            raise ValueError("missing_rationale")
        quotes = parsed.get("evidence_quotes")
        if not isinstance(quotes, list) or any(not isinstance(q, str) or not q for q in quotes):
            raise ValueError("invalid_evidence_quotes")
        spans = []
        for quote in quotes:
            start = request["text"].find(quote)
            if start < 0:
                raise ValueError("evidence_quote_not_in_text")
            spans.append({"start": start, "end": start + len(quote), "text": quote})
        if label == 1 and not spans:
            raise ValueError("missing_positive_evidence")
        if label == 0 and parsed.get("exclusion_assessed") is not True:
            raise ValueError("absence_not_assessed")
        if label == 0 and spans:
            raise ValueError("absence_with_positive_evidence")
    except (KeyError, TypeError, ValueError) as exc:
        reason, label, spans = str(exc), None, []
        parsed = {"rationale": "Automatic check unresolved: " + reason}
    return {
        "request_sha256": request["request_sha256"], "mode": "automatic",
        "checker_id": checker_binding["model_id"],
        "checker_revision": checker_binding["model_revision"],
        "checker_configuration": deepcopy(checker_binding),
        "full_text_assessed": True, "presence_label": label,
        "exclusion_assessed": label == 0, "rationale": parsed["rationale"],
        "evidence_spans": spans, "raw_completion": deepcopy(completion),
        "failure_reason": reason,
    }


def parse_model_json(text: str) -> object:
    """Reject ambiguous duplicate keys and non-JSON floating-point constants."""
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = value
        return result

    def invalid(value):
        raise ValueError("Invalid JSON constant: " + value)

    return json.loads(text, object_pairs_hook=pairs, parse_constant=invalid)


class OfflineCausalBackend:
    """One local PyTorch causal model per worker, with no hidden download path."""

    def __init__(self, model_directory: str | Path, manifest: dict[str, str], *,
                 max_new_tokens: int, max_input_tokens: int, temperature: float,
                 dtype: str = "bfloat16", device: str = "cuda"):
        directory = Path(model_directory).resolve()
        if not manifest or not directory.is_dir():
            raise ValueError("An existing local model and verified file manifest are required.")
        if (type(max_new_tokens) is not int or max_new_tokens <= 0
                or type(max_input_tokens) is not int or max_input_tokens <= 0
                or not math.isfinite(temperature) or temperature < 0
                or dtype not in ("float32", "bfloat16", "float16") or device not in ("cuda", "cpu")):
            raise ValueError("Invalid fixed model condition.")
        for relative, expected in manifest.items():
            path = (directory / relative).resolve()
            if not path.is_relative_to(directory) or not path.is_file():
                raise ValueError("Model manifest escapes its directory or names a missing file.")
            digest = hashlib.sha256()
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1 << 20), b""):
                    digest.update(chunk)
            if digest.hexdigest() != expected:
                raise ValueError("Local model file checksum mismatch: " + relative)
        required = {p.name for p in directory.iterdir() if p.is_file() and
                    (p.suffix in (".json", ".safetensors", ".model", ".bin"))}
        if not required.issubset(manifest):
            raise ValueError("Model manifest must cover every local model/tokenizer file.")
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        if device == "cuda" and (not torch.cuda.is_available() or torch.cuda.device_count() != 1):
            raise ValueError("Each GPU worker requires exactly one visible allocated GPU.")
        self.torch = torch
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(str(directory), local_files_only=True, trust_remote_code=False)
        self.tokenizer.padding_side = "left"
        if self.tokenizer.pad_token_id is None:
            self.tokenizer.pad_token_id = self.tokenizer.eos_token_id
        self.model = AutoModelForCausalLM.from_pretrained(
            str(directory), local_files_only=True, trust_remote_code=False,
            torch_dtype=getattr(torch, dtype), attn_implementation="sdpa",
        ).to(device).eval()
        self.max_new_tokens, self.max_input_tokens = max_new_tokens, max_input_tokens
        self.temperature = temperature

    def __call__(self, requests: list[dict], *, seed: int) -> list[dict]:
        prompts = [self.tokenizer.apply_chat_template(
            item["messages"], tokenize=False, add_generation_prompt=True
        ) for item in requests]
        # The chat template already emits BOS and role delimiters.
        encoded = self.tokenizer(prompts, add_special_tokens=False,
                                 padding=True, truncation=False, return_tensors="pt")
        if encoded["input_ids"].shape[1] > self.max_input_tokens:
            raise ValueError("Complete model input exceeds its fixed budget. Never truncate checked text.")
        encoded = {key: value.to(self.device) for key, value in encoded.items()}
        kwargs = {"max_new_tokens": self.max_new_tokens, "do_sample": self.temperature > 0,
                  "pad_token_id": self.tokenizer.pad_token_id}
        if self.temperature > 0:
            kwargs["temperature"] = self.temperature
        devices = [0] if self.device == "cuda" else []
        with self.torch.random.fork_rng(devices=devices), self.torch.inference_mode():
            self.torch.manual_seed(seed)
            generated = self.model.generate(**encoded, **kwargs)
        eos = self.model.generation_config.eos_token_id
        eos_ids = set(eos if isinstance(eos, list) else [eos])
        result = []
        for i, item in enumerate(requests):
            tokens = generated[i, encoded["input_ids"].shape[1]:].tolist()
            ending = next((j for j, token in enumerate(tokens) if token in eos_ids), None)
            used = tokens if ending is None else tokens[:ending + 1]
            result.append({"request_id": item["request_id"],
                           "text": self.tokenizer.decode(used, skip_special_tokens=True),
                           "input_tokens": int(encoded["attention_mask"][i].sum().item()),
                           "output_tokens": len(used),
                           "finish_reason": "stop" if ending is not None else "length"})
        return result
