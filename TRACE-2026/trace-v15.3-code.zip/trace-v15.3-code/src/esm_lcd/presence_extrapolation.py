"""Verify the V14 origin of frozen V15 working requirements.

This is provenance validation, not threshold fitting or presence calibration.
The old labels and controls do not acquire the meaning of the new objective.
"""

from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path

from .config import read_config_mapping


V14_CONFIG_SHA256 = "76074d8397fe1a603aea3cbe08bfffb5ceccb1f98fe0c6fbe632d6fa479f398c"
V14_GAP_SHA256 = "4f3b6d6b317d6e482def7bb59a4170fdb8d88adfbfe6eaaf29d0b01b5905a9fe"


def verify_v14_extrapolation(settings: dict, source_root: Path) -> dict:
    """Require the actual historical source and copied, unchanged requirements."""
    if (settings.get("source_campaign") != "V14.4"
            or settings.get("status") != "extrapolated_requirements_not_calibrated_presence_thresholds"
            or settings.get("v15_used_for_threshold_selection") is not False
            or settings.get("inherit_semantic_control_labels") is not False):
        raise ValueError("Thresholds require explicit V14-only extrapolation provenance.")
    config_path = source_root / settings["source_config"]
    gap_path = source_root / settings["gap_reference"]
    for path, expected in ((config_path, V14_CONFIG_SHA256), (gap_path, V14_GAP_SHA256)):
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError("Frozen V14 extrapolation source digest differs.")
    protocol = read_config_mapping(config_path)["protocol"]
    historical = protocol["simultaneous_nested_learning"]
    requirements = {
        "thresholds": historical["thresholds"],
        "minimum_reconstruction_count": historical["minimum_reconstruction_count"],
        "representation_mcc_tolerance": historical["representation_mcc_tolerance"],
        "total_error_budget": historical["total_error_budget"],
        "maximum_tolerable_mcc_drop": protocol["compression_policy_selection"]["maximum_tolerable_mcc_drop"],
    }
    if settings.get("requirements") != requirements:
        raise ValueError("Working requirements differ from the frozen V14 values.")
    gap = json.loads(gap_path.read_text(encoding="utf-8"))
    counts = {key: row["gap_length_histogram"] for key, row in gap["model_audits"].items()}
    if any(int(hist.get("1", 0)) != max(hist.values()) for hist in counts.values()):
        raise ValueError("The V14 reference no longer supports the stated modal gap length.")
    return {
        "source_campaign": "V14.4", "source_config_sha256": V14_CONFIG_SHA256,
        "gap_reference_sha256": V14_GAP_SHA256,
        "requirements": deepcopy(requirements),
        "source_label_objective": "intended_proposition_polarity",
        "target_label_objective": "concept_presence",
        "presence_calibrated": False, "v15_used_for_threshold_selection": False,
        "historical_rq3_assessable_cases": 0,
        "gap_reference_concepts": gap["concept_ids"],
        "gap_reference_answers": sum(row["answer_count"] for row in gap["model_audits"].values()),
        "gap_count_and_fragment_size_are_conservative_choices": True,
        "inferential_eligible": False,
    }
