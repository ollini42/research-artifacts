"""M-06 local Hoeffding compatibility.

Non-rejection permits a model proposal, but does not certify true equivalence
or supply a posterior probability of an incorrect merge.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from .automata import StateProfile


@dataclass(frozen=True)
class LocalMergeEvidence:
    status: Literal["compatible", "different", "unobserved"]
    empirical_difference: float | None
    uncertainty_radius: float
    event_count: int
    nominal_alpha: float

    @property
    def permits_proposal(self) -> bool:
        """Permit local planning only, not an unchecked recursive commit."""
        return self.status == "compatible"


def _validate_profile(profile: StateProfile) -> None:
    for count in (profile.visit_count, profile.terminal_count):
        if isinstance(count, bool) or not isinstance(count, int) or count < 0:
            raise ValueError("State counts must be nonnegative integers.")
    if profile.terminal_count > profile.visit_count:
        raise ValueError("Termination count exceeds visits.")
    probabilities = profile.next_token_probs
    if any(not isinstance(token, str) for token in (*probabilities, *profile.outgoing_labels)):
        raise ValueError("Token labels must be strings without coercion.")
    if any(not math.isfinite(p) or p < 0 or p > 1 for p in probabilities.values()):
        raise ValueError("Next-token probabilities must be finite and in [0, 1].")
    if set(probabilities) != set(profile.outgoing_labels):
        raise ValueError("Next-token events and outgoing labels do not match.")
    has_continuation = profile.visit_count > profile.terminal_count
    if has_continuation:
        if not math.isclose(math.fsum(probabilities.values()), 1.0,
                            rel_tol=1e-12, abs_tol=1e-12):
            raise ValueError("Conditional next-token probabilities must sum to one.")
    elif probabilities:
        raise ValueError("A state without continuations cannot have next-token events.")


def assess_local_compatibility(
    a: StateProfile, b: StateProfile, *, alpha: float = 0.18
) -> LocalMergeEvidence:
    """Apply the per-event ALERGIA/HyBUTLA Hoeffding compatibility rule.

    Reject if any next-event or termination difference exceeds the sum of the
    two Hoeffding radii. There is no absolute tolerance or positive-equivalence
    requirement. Alpha is the nominal per-event parameter in the published
    formula, without a multiple-comparison correction. Non-rejection does not
    establish equivalence or a bound on the probability of a wrong merge.
    """
    if isinstance(alpha, bool) or not math.isfinite(alpha) or not 0.0 < alpha < 1.0:
        raise ValueError("Hoeffding alpha must be finite and lie in (0, 1).")
    _validate_profile(a)
    _validate_profile(b)
    if min(a.visit_count, b.visit_count) == 0:
        return LocalMergeEvidence("unobserved", None, 1.0, 0, alpha)
    # Subtract logs to avoid overflow in 2/alpha for small alpha.
    factor = math.sqrt(0.5 * (math.log(2.0) - math.log(alpha)))
    radius = factor * (1.0 / math.sqrt(a.visit_count) + 1.0 / math.sqrt(b.visit_count))
    continuation_a = (a.visit_count - a.terminal_count) / a.visit_count
    continuation_b = (b.visit_count - b.terminal_count) / b.visit_count
    events = a.next_token_probs.keys() | b.next_token_probs.keys()
    difference = abs(a.terminal_count / a.visit_count - b.terminal_count / b.visit_count)
    for event in events:
        difference = max(difference, abs(
            a.next_token_probs.get(event, 0.0) * continuation_a
            - b.next_token_probs.get(event, 0.0) * continuation_b))
    if not math.isfinite(radius) or not math.isfinite(difference):
        raise ValueError("Nonfinite local evidence cannot permit a merge proposal.")
    status = "different" if difference > radius else "compatible"
    return LocalMergeEvidence(status, difference, radius, len(events) + 1, alpha)
