"""Build a concept-first draft without claiming that construction is validation."""

from __future__ import annotations

from pathlib import Path

from .config import read_config_mapping
from .concept_presence_data import content_sha256, validate_concept_presence_catalog


def load_catalog_design(path: str | Path) -> dict:
    """Read operational definitions and form unchecked automatic-check inputs."""
    spec = read_config_mapping(path)
    if spec.get("label_objective") != "concept_presence":
        raise ValueError("A concept-presence catalog design is required.")
    targets, auxiliary = spec["targets"], spec["auxiliary_controls"]
    if not isinstance(targets, list) or not targets or not isinstance(auxiliary, list) or not auxiliary:
        raise ValueError("Catalog design requires target and auxiliary concept lists.")
    records = targets + auxiliary
    if any(not isinstance(item, list) or len(item) != 4
           or any(not isinstance(value, str) or not value.strip() for value in item) for item in records):
        raise ValueError("Each concept needs ID, name, description and nearby control.")
    ids = [item[0] for item in records]
    if len(ids) != len(set(ids)) or len(targets) != spec["target_count"]:
        raise ValueError("Catalog design has duplicate IDs or an incorrect target count.")
    by_id = {item[0]: item for item in records}
    catalog, assignments = [], {}
    for index, item in enumerate(records):
        cid, name, description, nearby = item
        unrelated = auxiliary[index % len(auxiliary)][0] if index < len(targets) else targets[0][0]
        if nearby not in by_id or cid in (nearby, unrelated) or nearby == unrelated:
            raise ValueError("Concept contrast IDs are missing or inconsistent.")
        examples = []
        for text, label in (
            ("The text discusses " + name + ".", 1),
            ("This meal contains no " + name + "." if index < len(targets)
             else "This text is not about " + name + ".", 1),
            ("The text discusses " + by_id[nearby][1] + ".", 0),
            ("The text discusses " + by_id[unrelated][1] + ".", 0),
        ):
            examples.append({
                "label_objective": "concept_presence", "concept_id": cid,
                "text": text, "content_sha256": content_sha256(text),
                "presence_label": label, "audit_status": "constructed",
                "annotation_source": "concept-first-draft-construction-not-checked",
            })
        catalog.append({
            "concept_id": cid, "name": name,
            "inclusion_definition": (
                "Presence of the following concept: " + description + ". "
                "Count explicit names, synonyms and unambiguous descriptions, including "
                "negation, quotations, questions and factual mistakes. Do not require "
                "the concept name to occur literally."
            ),
            "exclusion_definition": (
                "Related food, ingredients, places or activities alone do not establish "
                "this concept. In particular, the distinct nearby concept '" + by_id[nearby][1]
                + "' means " + by_id[nearby][2] + ". That referent alone, including "
                "a negated mention, is not the target concept or its synonym. "
                "Do not infer ingredients from a dish name without a "
                "textual mention or unambiguous description. An ambiguous description "
                "is unresolved, not absent. Check the whole text."
            ),
            "definition_status": "draft", "examples": examples,
            "verified_absent_contrast_ids": [nearby, unrelated],
            "contrast_verification_status": "pending_automatic_check",
            "experiment_role": "target" if index < len(targets) else "auxiliary_control",
        })
        if index < len(targets):
            assignments[cid] = {"nearby": nearby, "unrelated": unrelated}
    validate_concept_presence_catalog(catalog, require_reviewed=False)
    return {
        "catalog": catalog, "target_concept_ids": [item[0] for item in targets],
        "contrast_assignments": assignments,
        "scientific_checks_complete": False, "human_annotation_used": False,
        "theme": spec["theme"], "target_count": len(targets),
        "auxiliary_control_count": len(auxiliary),
    }
