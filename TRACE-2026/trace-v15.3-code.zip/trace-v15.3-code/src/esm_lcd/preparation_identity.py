"""Read historical preparation identities without restoring retired mergers."""

from dataclasses import asdict
from collections.abc import Mapping
import hashlib
import json

from .config import ReconstructionConfig


def policy_mapping(config):
    if isinstance(config, ReconstructionConfig):
        return asdict(config)
    if isinstance(config, Mapping):
        return dict(config)
    raise ValueError("Preparation import requires the original configuration mapping.")


def profile_config(config):
    """Only preparation settings are needed to validate an unmerged tree."""
    raw = policy_mapping(config)
    return ReconstructionConfig(
        suffix_length=raw["suffix_length"],
        max_suffixes_per_state=raw["max_suffixes_per_state"],
    )


def source_fingerprint(traces, config):
    identity = policy_mapping(config)
    if identity.get("implementation_revision") == "M-06-r3":
        identity.pop("priority_retrieval_batch_pairs", None)
    if "method_version" not in identity:
        # Reproduce historical serialization solely to verify unmerged caches.
        if not identity.get("hoeffding_compatibility_enabled", False):
            identity.pop("hoeffding_compatibility_enabled", None)
            identity.pop("hoeffding_compatibility_alpha", None)
        if not identity.get("local_equivalence_enabled", False):
            for key in ("local_equivalence_enabled", "local_equivalence_tolerance", "local_equivalence_alpha"):
                identity.pop(key, None)
        if identity.get("candidate_search_mode") != "priority":
            for key in ("priority_candidate_scope", "priority_refresh_interval_merges", "priority_max_candidate_pairs"):
                identity.pop(key, None)
    digest = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode())
    for trace in traces:
        digest.update(trace.prompt.prompt_id.encode() + b"\0")
        for token in trace.answer_tokens:
            digest.update(token.encode() + b"\0")
        digest.update(b"\n")
    return digest.hexdigest()
