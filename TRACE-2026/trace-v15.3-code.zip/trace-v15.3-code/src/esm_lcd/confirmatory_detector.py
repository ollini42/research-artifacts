"""Leakage-controlled concept detectors for the confirmatory campaign."""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
import os
import random
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, Sequence

from .concept_assurance import (
    assurance_metrics,
    bootstrap_binary_learning_metrics,
    bootstrap_assurance_metrics,
    path_evidence,
    select_conditional_representation,
    select_learning_representation,
)
from .config import DatabaseConfig
from .confirmatory_plan import load_confirmatory_config, verify_evaluation_release
from .data import ResponseTrace, load_response_traces
from .simultaneous_assurance import observation_rows
from .audited_assurance import (
    EVALUATOR_IMPLEMENTATION_REVISION,
    RETROSPECTIVE_EVIDENCE_ROLE,
    observation_rows as audited_observation_rows,
    semantic_control_rows,
)
from .tokenization import TokenizationConfig, tokenize_text
from .concept_presence_evaluation import reject_presence_in_legacy


WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9]+")
LEGACY_MAPPING_REVISION = "legacy-v1"
PRESENCE_MAPPING_REVISION = "concept-presence-v1"
MODEL_SEEDS = (
    "3B_seed17",
    "3B_seed43",
    "3B_seed89",
    "8B_seed113",
)


@dataclass(frozen=True)
class ManifestRow:
    prompt_id: str
    concept_id: str
    split: str
    condition: str
    pair_id: str
    expected_label: int
    prompt_text: str
    condition_index: int = 0
    base_question_index: str | None = None


@dataclass(frozen=True)
class Example:
    prompt_id: str
    label: int
    condition: str
    pair_id: str
    prompt_text: str
    path: tuple[int, ...]
    answer_text: str
    answer_tokens: tuple[str, ...]
    condition_index: int = 0
    mapping_kinds: tuple[str, ...] = ()
    base_question_index: str | None = None


class _ResponseObservationWriter:
    """Write response-level assurance evidence incrementally and atomically."""

    def __init__(self, path: Path):
        self.path = path
        self.temporary_path = path.with_name(path.name + ".tmp")
        self.handle = None
        self.count = 0

    def write_result(self, result: dict) -> None:
        evidence = result.get("simultaneous_nested_learning", {})
        observations = evidence.pop("observations", [])
        if not observations:
            return
        if self.handle is None:
            self.handle = gzip.open(self.temporary_path, "wt", encoding="utf-8")
        identity = {
            "concept_id": str(result["concept_id"]),
            "model_seed": str(result["model_seed"]),
            "policy_id": str(result["policy_id"]),
        }
        for observation in observations:
            self.handle.write(json.dumps({**identity, **observation}, sort_keys=True))
            self.handle.write("\n")
            self.count += 1
        evidence["observation_count"] = len(observations)
        evidence["observation_artifact"] = self.path.name

    def commit(self) -> None:
        if self.handle is None:
            if self.path.exists():
                self.path.unlink()
            return
        self.handle.close()
        os.replace(self.temporary_path, self.path)


class _MappingProvenanceWriter:
    """Write per-token mapping provenance once per model and reconstruction."""

    def __init__(self, path: Path):
        self.path = path
        self.temporary_path = path.with_name(path.name + ".tmp")
        self.handle = None
        self.count = 0

    def write(
        self,
        model_seed: str,
        policy_id: str,
        rows: Sequence[dict],
        manifest: Dict[str, ManifestRow],
        selected_concepts: set[str],
    ) -> None:
        selected_rows = [
            row
            for row in rows
            if row["prompt_id"] in manifest
            and manifest[row["prompt_id"]].concept_id in selected_concepts
        ]
        if not selected_rows:
            return
        if self.handle is None:
            self.handle = gzip.open(self.temporary_path, "wt", encoding="utf-8")
        for row in selected_rows:
            prompt = manifest[row["prompt_id"]]
            payload = {
                "model_seed": model_seed,
                "policy_id": policy_id,
                "concept_id": prompt.concept_id,
                "split": prompt.split,
                "condition": prompt.condition,
                **row,
            }
            self.handle.write(json.dumps(payload, sort_keys=True) + "\n")
            self.count += 1

    def commit(self) -> None:
        if self.handle is None:
            if self.path.exists():
                self.path.unlink()
            return
        self.handle.close()
        os.replace(self.temporary_path, self.path)


def run_detector_task(
    config_path: str | Path,
    lock_path: str | Path,
    campaign_root: str | Path,
    task_index: int,
) -> Dict[str, object]:
    """Evaluate one deterministic concept shard for every model and policy."""

    raw = load_confirmatory_config(config_path)
    reject_presence_in_legacy(raw)
    verification = verify_evaluation_release(config_path, lock_path, campaign_root)
    if not verification["valid"]:
        raise RuntimeError(
            "Protocol lock verification failed: {}".format(
                ", ".join(verification["mismatches"])
            )
        )
    settings = raw["protocol"].get("simultaneous_nested_learning", {})
    retrospective = settings.get("evidence_role") == RETROSPECTIVE_EVIDENCE_ROLE
    if retrospective and verification["lock_stage"] != "retrospective_evaluation":
        raise RuntimeError("Retrospective E-05 requires its separate evaluator lock.")
    retrospective_audits = {
        item["concept_id"]: item
        for item in (verification["validation"].get("prompt_manifest", {})
                     .get("retrospective_input_audit") or {}).get("concept_reports", [])
    }
    root = Path(config_path).resolve().parent.parent
    manifest_path = _resolve(root, raw["protocol"]["prompt_manifest"])
    manifest = load_manifest(manifest_path, allow_missing_metadata=retrospective)
    evaluator_version = str(
        raw["protocol"].get("simultaneous_nested_learning", {}).get(
            "version", "E-04"
        )
    )
    concept_semantics = (
        load_concept_semantics(
            _resolve(root, raw["protocol"]["concept_catalog"]), allow_missing=retrospective
        )
        if evaluator_version == "E-05"
        else {}
    )
    concept_ids = sorted({row.concept_id for row in manifest.values()})
    task_count = int(raw["protocol"].get("detector_task_count", 6))
    if task_index < 0 or task_index >= task_count:
        raise ValueError(
            "Detector task index must satisfy 0 <= index < {}.".format(task_count)
        )
    concepts_per_task = int(math.ceil(len(concept_ids) / task_count))
    selected = concept_ids[
        task_index * concepts_per_task : (task_index + 1) * concepts_per_task
    ]
    if not selected:
        raise RuntimeError("Detector task {} has no assigned concepts.".format(task_index))

    campaign = Path(campaign_root)
    output_dir = campaign / "detectors" / "task_{:02d}".format(task_index)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    examples = []
    observation_writer = _ResponseObservationWriter(
        output_dir / "simultaneous_response_observations.jsonl.gz"
    )
    mapping_writer = _MappingProvenanceWriter(
        output_dir / "mapping_position_provenance.jsonl.gz"
    )
    model_seeds = tuple(raw["protocol"].get("model_seed_labels", MODEL_SEEDS))
    question_run_id = str(
        raw["protocol"].get("question_run_id", "confirmatory-scap7d-proxy-2026")
    )
    for model_seed in model_seeds:
        train_label = model_seed + "_discovery_development"
        test_label = model_seed + "_test"
        train_db = campaign / "response_databases" / (train_label + ".db")
        test_db = campaign / "response_databases" / (test_label + ".db")
        train_traces = load_response_traces(
            DatabaseConfig(
                path=str(train_db),
                question_run_id=question_run_id,
            ),
            TokenizationConfig(mode="word", lowercase=True, max_tokens=192),
        )
        test_traces = load_response_traces(
            DatabaseConfig(
                path=str(test_db),
                question_run_id=question_run_id,
            ),
            TokenizationConfig(mode="word", lowercase=True, max_tokens=192),
        )
        train_by_id = {trace.prompt.prompt_id: trace for trace in train_traces}
        test_by_id = {trace.prompt.prompt_id: trace for trace in test_traces}

        for policy in raw["locked_reconstructions"]:
            policy_id = str(policy["id"])
            policy_dir = campaign / "reconstructions" / train_label / policy_id
            train_paths = load_state_paths(
                policy_dir / "prompt_state_paths.jsonl.gz"
            )
            transitions = load_json_lines(policy_dir / "transitions.jsonl.gz")
            audit = json.loads(
                (policy_dir / "merge_audit.json").read_text(encoding="utf-8")
            )
            root_state = int(audit["diagnostics"]["root_state_id"])
            missing_train_traces = [
                trace
                for trace in train_traces
                if trace.prompt.prompt_id not in train_paths
            ]
            mapped_train_paths, train_mapping_audit = map_traces_inductively(
                missing_train_traces, transitions, root_state
            )
            train_mapping_kinds = train_mapping_audit.pop("_path_mapping_kinds")
            mapping_writer.write(
                model_seed,
                policy_id,
                train_mapping_audit.pop("_position_provenance"),
                manifest,
                set(selected),
            )
            train_paths.update(mapped_train_paths)
            test_paths, test_mapping_audit = map_traces_inductively(
                test_traces, transitions, root_state
            )
            test_mapping_kinds = test_mapping_audit.pop("_path_mapping_kinds")
            mapping_writer.write(
                model_seed,
                policy_id,
                test_mapping_audit.pop("_position_provenance"),
                manifest,
                set(selected),
            )
            mapping_audit = {
                **test_mapping_audit,
                "reconstruction_path_count": len(train_paths) - len(mapped_train_paths),
                "inductively_mapped_train_path_count": len(mapped_train_paths),
                "train_total_tokens": train_mapping_audit["total_tokens"],
                "train_exact_transition_rate": train_mapping_audit[
                    "exact_transition_rate"
                ],
                "train_global_label_fallback_rate": train_mapping_audit[
                    "global_label_fallback_rate"
                ],
                "train_unknown_token_rate": train_mapping_audit[
                    "unknown_token_rate"
                ],
            }
            for concept_id in selected:
                result, result_examples = evaluate_concept(
                    evaluator_implementation_revision=raw["protocol"].get(
                        "method_versions", {}
                    ).get("evaluator_implementation_revision", EVALUATOR_IMPLEMENTATION_REVISION),
                    concept_id=concept_id,
                    model_seed=model_seed,
                    policy_id=policy_id,
                    manifest=manifest,
                    train_by_id=train_by_id,
                    test_by_id=test_by_id,
                    train_paths=train_paths,
                    test_paths=test_paths,
                    mapping_audit=mapping_audit,
                    bootstrap_repetitions=int(
                        raw["protocol"]["bootstrap"]["repetitions"]
                    ),
                    bootstrap_seed=int(
                        raw["protocol"].get("bootstrap", {}).get("seed", 17017)
                    ),
                    concept_assurance_config=raw["protocol"].get(
                        "conditional_concept_assurance", {}
                    ),
                    binary_learning_config=raw["protocol"].get(
                        "binary_concept_learning", {}
                    ),
                    simultaneous_learning_config=raw["protocol"].get(
                        "simultaneous_nested_learning", {}
                    ),
                    rq1_config=raw["protocol"].get("rq1_evaluation", {}),
                    train_mapping_kinds=train_mapping_kinds,
                    test_mapping_kinds=test_mapping_kinds,
                    semantic_control_examples=(
                        build_semantic_control_examples(
                            concept_id,
                            concept_semantics.get(concept_id, {}),
                            manifest,
                            transitions,
                            root_state,
                        )
                        if evaluator_version == "E-05"
                        else ()
                    ),
                    retrospective_audit=retrospective_audits.get(concept_id),
                )
                observation_writer.write_result(result)
                rows.append(result)
                examples.extend(result_examples)

    observation_writer.commit()
    mapping_writer.commit()

    output = {
        "schema_version": 1,
        "task_index": task_index,
        "concept_ids": selected,
        "approval_mode": raw["protocol"].get("approval_mode", "human_expert"),
        "human_expert_gate_available": raw["protocol"].get("approval_mode") == "human_expert",
        "result_count": len(rows),
        "simultaneous_evaluator_version": evaluator_version,
        "simultaneous_response_observation_count": observation_writer.count,
        "mapping_position_provenance_count": mapping_writer.count,
        "analysis_tokenizer": {
            "kind": "regex_symbolic_word_tokenizer",
            "lowercase": True,
            "maximum_tokens": 192,
            "is_language_model_tokenizer": False,
        },
        "results": rows,
        "examples": examples,
    }
    _atomic_json(output_dir / "detector_results.json", output)
    _write_flat_csv(output_dir / "detector_metrics.csv", rows)
    _atomic_json(output_dir / "COMPLETE.json", {
        "task_index": task_index,
        "concept_ids": selected,
        "result_count": len(rows),
        "simultaneous_evaluator_version": evaluator_version,
        "mapping_position_provenance_count": mapping_writer.count,
        "complete": True,
    })
    return {
        "task_index": task_index,
        "concept_ids": selected,
        "result_count": len(rows),
        "complete": True,
    }


def load_manifest(
    path: Path, *, allow_missing_metadata: bool = False
) -> Dict[str, ManifestRow]:
    def condition_index(row: dict) -> int:
        try:
            return int(row.get("condition_index") or 0)
        except (TypeError, ValueError):
            if allow_missing_metadata:
                return 0
            raise

    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
        reject_presence_in_legacy(rows)
        return {
            row["prompt_id"]: ManifestRow(
                prompt_id=row["prompt_id"],
                concept_id=row["concept_id"],
                split=row["split"],
                condition=row["condition"],
                condition_index=condition_index(row),
                base_question_index=row.get("base_question_index") or None,
                pair_id=row.get("pair_id", ""),
                expected_label=int(row["expected_label"]),
                prompt_text=row["prompt_text"],
            )
            for row in rows
        }


def load_concept_semantics(
    path: Path, *, allow_missing: bool = False
) -> Dict[str, dict[str, str]]:
    """Load the locked semantic statements used only for construct controls."""

    if path.suffix.lower() == ".csv":
        with path.open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
    else:
        payload = json.loads(path.read_text(encoding="utf-8"))
        reject_presence_in_legacy(payload)
        rows = payload.get("concepts", payload) if isinstance(payload, dict) else payload
        if not isinstance(rows, list):
            raise ValueError("The concept catalog must contain a concept list.")
    result = {}
    reject_presence_in_legacy(rows)
    for row in rows:
        concept_id = str(row["concept_id"])
        if concept_id in result:
            raise ValueError("Duplicate concept identifier: {}.".format(concept_id))
        canonical = str(row.get("canonical_statement") or "").strip()
        negation = str(row.get("logical_negation") or "").strip()
        if (not canonical or not negation) and not allow_missing:
            raise ValueError(
                "Concept {} lacks canonical_statement or logical_negation.".format(
                    concept_id
                )
            )
        result[concept_id] = {
            "canonical_statement": canonical,
            "logical_negation": negation,
        }
    return result


def build_semantic_control_examples(
    concept_id: str,
    semantics: dict[str, str],
    manifest: Dict[str, ManifestRow],
    transitions: Sequence[dict],
    root_state: int,
) -> tuple[Example, ...]:
    """Construct preregistered response controls for empirical construct validity."""

    reject_presence_in_legacy(semantics, tuple(manifest.values()))
    canonical = str(semantics.get("canonical_statement") or "").strip()
    negation = str(semantics.get("logical_negation") or "").strip()
    if not canonical or not negation:
        return ()
    concept_prompts = sorted(
        row.prompt_text
        for row in manifest.values()
        if row.concept_id == concept_id and row.split == "test"
    )
    if not concept_prompts:
        raise ValueError("No test prompts are available for {}.".format(concept_id))
    templates = {
        "known_correct": (
            canonical,
            "It is correct that {}".format(canonical),
            "The relevant fact is: {}".format(canonical),
            "According to the stated relation, {}".format(canonical),
        ),
        "systematically_wrong": (
            negation,
            "It is correct that {}".format(negation),
            "The relevant fact is: {}".format(negation),
            "According to the stated relation, {}".format(negation),
        ),
        "prompt_echo": tuple(
            concept_prompts[index % len(concept_prompts)] for index in range(4)
        ),
        "template_only": (
            "The answer follows from the information provided.",
            "This statement is correct.",
            "The requested relation applies here.",
            "Therefore, this is the answer.",
        ),
    }
    exact, global_target = _transition_maps(transitions)
    tokenization = TokenizationConfig(mode="word", lowercase=True, max_tokens=192)
    examples = []
    for control_type, texts in templates.items():
        for index, answer_text in enumerate(texts):
            tokens = tuple(tokenize_text(answer_text, tokenization))
            path, mapping_kinds = _map_token_sequence(
                tokens, root_state, exact, global_target
            )
            examples.append(
                Example(
                    prompt_id="control:{}:{}:{:02d}".format(
                        concept_id, control_type, index
                    ),
                    label=int(control_type == "known_correct"),
                    condition=control_type,
                    pair_id="control:{}:{:02d}".format(concept_id, index),
                    prompt_text=concept_prompts[index % len(concept_prompts)],
                    path=path,
                    answer_text=answer_text,
                    answer_tokens=tokens,
                    condition_index=index + 1,
                    mapping_kinds=mapping_kinds,
                )
            )
    return tuple(examples)


def load_state_paths(path: Path) -> Dict[str, tuple[int, ...]]:
    return {
        str(row["prompt_id"]): tuple(int(value) for value in row["state_path"])
        for row in load_json_lines(path)
    }


def load_json_lines(path: Path) -> list[dict]:
    opener = gzip.open if path.suffix == ".gz" else Path.open
    kwargs = {"mode": "rt", "encoding": "utf-8"} if path.suffix == ".gz" else {
        "mode": "r", "encoding": "utf-8"
    }
    with opener(path, **kwargs) as handle:
        return [json.loads(line) for line in handle if line.strip()]


def map_traces_inductively(
    traces: Sequence[ResponseTrace],
    transitions: Sequence[dict],
    root_state: int,
    *,
    mapping_revision: str = LEGACY_MAPPING_REVISION,
) -> tuple[Dict[str, tuple[int, ...]], Dict[str, object]]:
    _validate_mapping_revision(mapping_revision)
    exact, global_target = _transition_maps(transitions)
    paths: Dict[str, tuple[int, ...]] = {}
    path_mapping_kinds: Dict[str, tuple[str, ...]] = {}
    position_provenance = []
    exact_segment_lengths = []
    exact_hits = 0
    fallback_hits = 0
    unknown_tokens = 0
    total_tokens = 0
    for trace in traces:
        if mapping_revision == PRESENCE_MAPPING_REVISION and trace.prompt.prompt_id in paths:
            raise ValueError("Duplicate prompt identity in presence mapping. Map answer origins separately.")
        state = root_state
        path = [state]
        mapping_kinds = []
        exact_segment_length = 0
        for position, token in enumerate(trace.answer_tokens):
            total_tokens += 1
            source_state = state
            target = exact.get((state, token))
            if target is not None:
                exact_hits += 1
                mapping_kind = "exact"
                exact_segment_length += 1
            else:
                target = global_target.get(token)
                if target is None:
                    unknown_tokens += 1
                    mapping_kind = "unknown"
                    if exact_segment_length:
                        exact_segment_lengths.append(exact_segment_length)
                    exact_segment_length = 0
                    position_provenance.append(
                        {
                            "prompt_id": str(trace.prompt.prompt_id),
                            "token_position": position,
                            "token": str(token),
                            "source_state": source_state,
                            "target_state": None,
                            "mapping_kind": mapping_kind,
                            "graph_edge_verified": False,
                        }
                    )
                    if mapping_revision == PRESENCE_MAPPING_REVISION:
                        # A repeated state marks a gap, never an asserted self-edge.
                        path.append(state)
                        mapping_kinds.append("unknown")
                    continue
                fallback_hits += 1
                mapping_kind = "global_fallback"
                if exact_segment_length:
                    exact_segment_lengths.append(exact_segment_length)
                exact_segment_length = 0
            state = target
            path.append(state)
            mapping_kinds.append(mapping_kind)
            position_provenance.append(
                {
                    "prompt_id": str(trace.prompt.prompt_id),
                    "token_position": position,
                    "token": str(token),
                    "source_state": source_state,
                    "target_state": target,
                    "mapping_kind": mapping_kind,
                    "graph_edge_verified": mapping_kind == "exact",
                }
            )
        if exact_segment_length:
            exact_segment_lengths.append(exact_segment_length)
        paths[trace.prompt.prompt_id] = tuple(path)
        path_mapping_kinds[trace.prompt.prompt_id] = tuple(mapping_kinds)
    audit = {
        "total_tokens": total_tokens,
        "exact_transition_rate": exact_hits / total_tokens if total_tokens else 0.0,
        "global_label_fallback_rate": fallback_hits / total_tokens if total_tokens else 0.0,
        "unknown_token_rate": unknown_tokens / total_tokens if total_tokens else 0.0,
        "exact_contiguous_segment_count": len(exact_segment_lengths),
        "mean_exact_contiguous_segment_length": (
            sum(exact_segment_lengths) / len(exact_segment_lengths)
            if exact_segment_lengths
            else 0.0
        ),
        "maximum_exact_contiguous_segment_length": max(
            exact_segment_lengths, default=0
        ),
        "_path_mapping_kinds": path_mapping_kinds,
        "_position_provenance": position_provenance,
    }
    if mapping_revision == PRESENCE_MAPPING_REVISION:
        audit["mapping_revision"] = mapping_revision
    return paths, audit


def _transition_maps(
    transitions: Sequence[dict],
) -> tuple[dict[tuple[int, str], int], dict[str, int]]:
    exact_counts: dict[tuple[int, str], Counter[int]] = defaultdict(Counter)
    global_counts: dict[str, Counter[int]] = defaultdict(Counter)
    for row in transitions:
        source = int(row["source"])
        label = str(row["label"])
        target = int(row["target"])
        count = int(row.get("count", 1))
        exact_counts[(source, label)][target] += count
        global_counts[label][target] += count
    exact = {key: _most_common(counter) for key, counter in exact_counts.items()}
    global_target = {
        label: _most_common(counter) for label, counter in global_counts.items()
    }
    return exact, global_target


def _map_token_sequence(
    tokens: Sequence[str],
    root_state: int,
    exact: Dict[tuple[int, str], int],
    global_target: Dict[str, int],
    *,
    mapping_revision: str = LEGACY_MAPPING_REVISION,
) -> tuple[tuple[int, ...], tuple[str, ...]]:
    _validate_mapping_revision(mapping_revision)
    state = root_state
    path = [state]
    mapping_kinds = []
    for token in tokens:
        target = exact.get((state, token))
        mapping_kind = "exact"
        if target is None:
            target = global_target.get(token)
            mapping_kind = "global_fallback" if target is not None else "unknown"
        if target is None:
            if mapping_revision == PRESENCE_MAPPING_REVISION:
                path.append(state)
                mapping_kinds.append("unknown")
            continue
        state = target
        path.append(state)
        mapping_kinds.append(mapping_kind)
    return tuple(path), tuple(mapping_kinds)


def _validate_mapping_revision(mapping_revision: str) -> None:
    if mapping_revision not in {LEGACY_MAPPING_REVISION, PRESENCE_MAPPING_REVISION}:
        raise ValueError("Unsupported trace mapping revision.")


def evaluate_concept(
    concept_id: str,
    model_seed: str,
    policy_id: str,
    manifest: Dict[str, ManifestRow],
    train_by_id: Dict[str, ResponseTrace],
    test_by_id: Dict[str, ResponseTrace],
    train_paths: Dict[str, tuple[int, ...]],
    test_paths: Dict[str, tuple[int, ...]],
    mapping_audit: Dict[str, float],
    bootstrap_repetitions: int,
    bootstrap_seed: int,
    concept_assurance_config: dict | None = None,
    binary_learning_config: dict | None = None,
    simultaneous_learning_config: dict | None = None,
    rq1_config: dict | None = None,
    train_mapping_kinds: Dict[str, tuple[str, ...]] | None = None,
    test_mapping_kinds: Dict[str, tuple[str, ...]] | None = None,
    semantic_control_examples: Sequence[Example] = (),
    retrospective_audit: dict | None = None,
    evaluator_implementation_revision: str = EVALUATOR_IMPLEMENTATION_REVISION,
) -> tuple[dict, list[dict]]:
    reject_presence_in_legacy(
        simultaneous_learning_config, concept_assurance_config,
        binary_learning_config, rq1_config, tuple(manifest.values()),
        semantic_control_examples,
        {"evaluator_implementation_revision": evaluator_implementation_revision},
    )
    if evaluator_implementation_revision not in ("E-05-r1", "E-05-r2"):
        raise ValueError("Unsupported evaluator implementation revision.")
    discovery = _examples(
        manifest,
        concept_id,
        "discovery",
        train_by_id,
        train_paths,
        train_mapping_kinds,
    )
    development = _examples(
        manifest,
        concept_id,
        "development",
        train_by_id,
        train_paths,
        train_mapping_kinds,
    )
    test = _examples(
        manifest,
        concept_id,
        "test",
        test_by_id,
        test_paths,
        test_mapping_kinds,
    )
    if not discovery or not development or not test:
        raise RuntimeError("Missing split examples for {}.".format(concept_id))

    family_results = []
    for family in (
        "terminal_state",
        "best_interior_state",
        "unordered_state_set",
        "transition_edge_set",
        "contiguous_state_motif",
        "gapped_state_motif",
    ):
        family_results.append(
            fit_select_evaluate_feature_detector(
                family, discovery, development, test
            )
        )
    surface_results = []
    for family in (
        "answer_token_ngram",
        "answer_position",
        "answer_template",
        "answer_length",
        "prompt_tfidf",
    ):
        surface_results.append(
            fit_select_evaluate_feature_detector(
                family, discovery, development, test
            )
        )

    assurance_settings = concept_assurance_config or {}
    representation_selection = select_conditional_representation(
        family_results,
        surface_results,
        assurance_settings.get("selection", {}),
    )
    selected_detector = next(
        row.copy()
        for row in family_results
        if row["family"] == representation_selection["selected_family"]
    )
    binary_settings = binary_learning_config or {}
    simultaneous_settings = simultaneous_learning_config or {}
    simultaneous_enabled = bool(simultaneous_settings.get("enabled", False))
    learning_selection = select_learning_representation(
        family_results,
        tolerance=float(
            simultaneous_settings.get(
                "representation_mcc_tolerance",
                binary_settings.get("representation_mcc_tolerance", 0.02),
            )
        ),
    )
    learning_detector = next(
        row.copy()
        for row in family_results
        if row["family"] == learning_selection["selected_family"]
    )

    best_state = _best_result(
        [
            row
            for row in family_results
            if row["family"] in {"terminal_state", "best_interior_state"}
        ]
    )
    best_path = _best_result(
        [
            row
            for row in family_results
            if row["family"] not in {"terminal_state", "best_interior_state"}
        ]
    )
    best_overall = _best_result(family_results)
    rq1_settings = rq1_config or {}
    rq1_maximum = int(
        rq1_settings.get(
            "maximum_state_features",
            rq1_settings.get("maximum_feature_count", 32),
        )
    )
    rq1_detector = fit_select_evaluate_feature_detector(
        str(rq1_settings.get("family", "unordered_state_set")),
        discovery,
        development,
        test,
        max_feature_count=rq1_maximum,
    )
    best_surface = _best_result(surface_results)
    matched_surface_results = [
        fit_select_evaluate_feature_detector(
            family,
            discovery,
            development,
            test,
            fixed_feature_count=max(
                1, int(representation_selection["selected_feature_count"])
            ),
        )
        for family in (
            "answer_token_ngram",
            "answer_position",
            "answer_template",
            "answer_length",
            "prompt_tfidf",
        )
    ]
    best_matched_surface = _best_result(matched_surface_results)
    rq1_matched_surface_results = [
        fit_select_evaluate_feature_detector(
            family,
            discovery,
            development,
            test,
            fixed_feature_count=max(1, int(rq1_detector["feature_count"])),
        )
        for family in rq1_settings.get(
            "matched_text_baseline_families",
            (
                "answer_token_ngram",
                "answer_position",
                "answer_template",
                "answer_length",
                "prompt_tfidf",
            ),
        )
    ]
    rq1_matched_surface = _best_result(rq1_matched_surface_results)
    simultaneous_surface_results = []
    refit_order_controls = []
    if simultaneous_enabled:
        simultaneous_surface_results = [
            fit_select_evaluate_feature_detector(
                family,
                discovery,
                development,
                test,
                fixed_feature_count=max(1, int(best_path["feature_count"])),
            )
            for family in simultaneous_settings["visible_text_families"]
        ]
        visible_text = _best_result(simultaneous_surface_results)
        evaluator_version = str(simultaneous_settings.get("version", "E-04"))
        row_factory = (
            audited_observation_rows
            if evaluator_version == "E-05"
            else observation_rows
        )
        simultaneous_observations = []
        for role, detector in (
            ("selected_rule", learning_detector),
            ("individual_state_rule", best_state),
            ("path_rule", best_path),
            ("visible_text_rule", visible_text),
        ):
            simultaneous_observations.extend(
                row_factory(
                    test,
                    role,
                    str(detector["family"]),
                    detector["_predictions"],
                    detector["_scores"],
                )
            )
        if evaluator_version == "E-05":
            simultaneous_observations.extend(
                audited_observation_rows(
                    development,
                    "compression_development_rule",
                    str(learning_detector["family"]),
                    learning_detector["_development_predictions"],
                    learning_detector["_development_scores"],
                )
            )
            refit_order_controls = refit_order_control_outputs(
                str(best_path["family"]),
                discovery,
                development,
                test,
                max(1, int(best_path["feature_count"])),
            )
            for control in refit_order_controls:
                simultaneous_observations.extend(
                    audited_observation_rows(
                        test,
                        control["role"],
                        str(best_path["family"]),
                        control["predictions"],
                        control["scores"],
                    )
                )
            control_scores = score_feature_sets(
                [
                    extract_features(item, str(learning_detector["family"]))
                    for item in semantic_control_examples
                ],
                learning_detector.get("_weights", {}),
            )
            control_predictions = [
                int(score >= float(learning_detector["threshold"]))
                for score in control_scores
            ]
            simultaneous_observations.extend(
                semantic_control_rows(
                    semantic_control_examples,
                    str(learning_detector["family"]),
                    control_predictions,
                    control_scores,
                )
            )
        else:
            for control in order_control_outputs(
                str(best_path["family"]),
                test,
                best_path.get("_weights", {}),
                float(best_path["threshold"]),
            ):
                simultaneous_observations.extend(
                    observation_rows(
                        test,
                        control["role"],
                        str(best_path["family"]),
                        control["predictions"],
                        control["scores"],
                    )
                )
        simultaneous_evidence = {
            "enabled": True,
            "evaluated": True,
            "evaluator_version": evaluator_version,
            "evaluator_implementation_revision": (
                evaluator_implementation_revision
            ),
            "evidence_role": str(
                simultaneous_settings.get(
                    "evidence_role", "confirmatory_model_outcome"
                )
            ),
            "development_selection": {
                "selection_split": "development",
                "admissible_rule": all(
                    int(detector["feature_count"]) > 0
                    for detector in (
                        learning_detector,
                        best_state,
                        best_path,
                        visible_text,
                    )
                ),
                "selected_family": str(learning_detector["family"]),
                "selected_feature_count": int(learning_detector["feature_count"]),
                "selected_threshold": float(learning_detector["threshold"]),
                "selected_development_mcc": float(
                    learning_detector["development_mcc"]
                ),
                "individual_state_family": str(best_state["family"]),
                "individual_state_development_mcc": float(
                    best_state["development_mcc"]
                ),
                "path_family": str(best_path["family"]),
                "path_development_mcc": float(best_path["development_mcc"]),
                "visible_text_family": str(visible_text["family"]),
                "visible_text_development_mcc": float(
                    visible_text["development_mcc"]
                ),
                "feature_budget_match": int(best_path["feature_count"]),
                "simplicity_tolerance": float(
                    simultaneous_settings["representation_mcc_tolerance"]
                ),
            },
            "observations": simultaneous_observations,
        }
        if evaluator_version == "E-05":
            reasons = []
            if not semantic_control_examples:
                reasons.append("missing_semantic_control_evidence")
            if simultaneous_settings.get("evidence_role") == RETROSPECTIVE_EVIDENCE_ROLE:
                audit = retrospective_audit or {
                    "status": "not_identifiable", "reasons": ["missing_retrospective_input_audit"]
                }
                simultaneous_evidence["retrospective_input_audit"] = audit
                reasons.extend(audit.get("reasons", []))
                if any(item.condition_index <= 0 for item in test):
                    reasons.append("missing_or_invalid_condition_index")
            simultaneous_evidence["not_identifiable_reasons"] = sorted(set(reasons))
            simultaneous_evidence["assessment_status"] = (
                "not_identifiable" if reasons else "requires_aggregate_evaluation"
            )
    else:
        simultaneous_evidence = {
            "enabled": False,
            "evaluated": False,
            "evaluator_version": str(simultaneous_settings.get("version", "E-04")),
            "evaluator_implementation_revision": None,
        }
    primary_predictions = best_overall.pop("_predictions")
    primary_scores = best_overall.pop("_scores")
    best_overall.pop("_weights", None)
    rq1_predictions = rq1_detector.pop("_predictions")
    rq1_scores = rq1_detector.pop("_scores")
    rq1_detector.pop("_weights", None)
    selected_predictions = selected_detector.pop("_predictions")
    selected_scores = selected_detector.pop("_scores")
    selected_weights = selected_detector.pop("_weights")

    shared_seed = _shared_bootstrap_seed(bootstrap_seed, concept_id)
    ci = bootstrap_metrics(
        test,
        primary_predictions,
        primary_scores,
        repetitions=bootstrap_repetitions,
        seed=shared_seed,
    )
    conditions = condition_metrics(test, primary_predictions)
    if best_overall["family"] == rq1_detector["family"]:
        rq1_ci = ci
        rq1_conditions = conditions
    else:
        rq1_ci = bootstrap_metrics(
            test,
            rq1_predictions,
            rq1_scores,
            repetitions=bootstrap_repetitions,
            seed=shared_seed,
        )
        rq1_conditions = condition_metrics(test, rq1_predictions)

    if selected_detector["family"] == best_overall["family"]:
        selected_ci = ci
        selected_conditions = conditions
    elif selected_detector["family"] == rq1_detector["family"]:
        selected_ci = rq1_ci
        selected_conditions = rq1_conditions
    else:
        selected_ci = bootstrap_metrics(
            test,
            selected_predictions,
            selected_scores,
            repetitions=bootstrap_repetitions,
            seed=shared_seed,
        )
        selected_conditions = condition_metrics(test, selected_predictions)

    learning_predictions = learning_detector.pop("_predictions")
    learning_scores = learning_detector.pop("_scores")
    learning_detector.pop("_weights", None)
    binary_enabled = bool(binary_settings.get("enabled", False))
    learning_bootstrap = (
        bootstrap_binary_learning_metrics(
            [item.label for item in test],
            learning_predictions,
            learning_scores,
            [item.pair_id or item.prompt_id for item in test],
            repetitions=int(
                binary_settings.get("bootstrap_repetitions", bootstrap_repetitions)
            ),
            seed=shared_seed,
            conditions=[item.condition for item in test],
        )
        if binary_enabled
        else {}
    )

    assurance_enabled = bool(assurance_settings.get("enabled", False))
    evidence = [
        path_evidence(item.path, selected_detector["family"], selected_weights)
        for item in test
    ]
    evidence_fractions = [item[0] for item in evidence]
    evidence_token_counts = [item[1] for item in evidence]
    evidence_features = [item[2] for item in evidence]
    assurance_test_metrics = (
        assurance_metrics(
            [item.label for item in test],
            selected_predictions,
            selected_scores,
            evidence_fractions,
            evidence_token_counts,
            evidence_features,
            [item.condition for item in test],
        )
        if assurance_enabled
        else {}
    )
    assurance_bootstrap = (
        bootstrap_assurance_metrics(
            [item.label for item in test],
            selected_predictions,
            selected_scores,
            evidence_fractions,
            evidence_token_counts,
            evidence_features,
            [item.pair_id or item.prompt_id for item in test],
            repetitions=bootstrap_repetitions,
            seed=shared_seed,
            conditions=[item.condition for item in test],
        )
        if assurance_enabled
        else {}
    )
    selected_surface_margin = (
        float(selected_detector["mcc"]) - float(best_matched_surface["mcc"])
    )
    gate_values = {
        **{
            name: value
            for name, value in selected_ci.items()
            if name.endswith("_lower_95")
        },
        **{
            name: value
            for name, value in assurance_bootstrap.items()
            if name.endswith("_lower_95")
        },
        "matched_surface_mcc_margin": selected_surface_margin,
    }
    gate_thresholds = {
        str(name): float(value)
        for name, value in assurance_settings.get("gates", {}).items()
    }
    gate_decisions = {
        name: gate_values.get(name) is not None
        and float(gate_values[name]) >= threshold
        for name, threshold in gate_thresholds.items()
    }
    assurance_eligible = bool(
        assurance_enabled and representation_selection["eligible"]
    )
    if not assurance_enabled:
        assurance_decision = "disabled"
    elif not assurance_eligible:
        assurance_decision = "not_identifiable"
    elif gate_decisions and all(gate_decisions.values()):
        assurance_decision = "assured_before_seed_stability"
    else:
        assurance_decision = "not_assured"

    for row in (
        family_results
        + surface_results
        + matched_surface_results
        + rq1_matched_surface_results
        + simultaneous_surface_results
    ):
        row.pop("_predictions", None)
        row.pop("_scores", None)
        row.pop("_weights", None)
        row.pop("_development_predictions", None)
        row.pop("_development_scores", None)
    for row in (
        best_overall,
        rq1_detector,
        selected_detector,
        learning_detector,
        best_state,
        best_path,
        best_surface,
        best_matched_surface,
        rq1_matched_surface,
    ):
        row.pop("_development_predictions", None)
        row.pop("_development_scores", None)
    full_scap_available = False
    computational_gates = [
        conditions.get("lexical_disjoint_balanced_accuracy"),
        conditions.get("hard_negative_true_negative_rate"),
        conditions.get("counterfactual_score"),
        conditions.get("unseen_composition_balanced_accuracy"),
        conditions.get("surface_control_balanced_accuracy"),
    ]
    computational_minimum = min(
        value for value in computational_gates if value is not None
    )
    automatic_gates = [
        conditions.get("lexical_disjoint_balanced_accuracy"),
        conditions.get("hard_negative_three_mode_minimum_tnr"),
        conditions.get("counterfactual_score"),
        conditions.get("unseen_composition_balanced_accuracy"),
        conditions.get("entity_renamed_balanced_accuracy"),
        conditions.get("lexical_decoy_balanced_accuracy"),
        conditions.get("adversarial_paraphrase_balanced_accuracy"),
        conditions.get("surface_control_balanced_accuracy"),
    ]
    automatic_minimum = min(
        (value for value in automatic_gates if value is not None),
        default=None,
    )
    localization = localization_summary(
        next(row for row in family_results if row["family"] == "unordered_state_set")
    )
    inferential_order_controls = [
        row for row in refit_order_controls
        if evaluator_implementation_revision == "E-05-r1"
        or row["role"] == "order_shuffled_refit_rule"
    ]
    result = {
        "concept_id": concept_id,
        "model_seed": model_seed,
        "policy_id": policy_id,
        "discovery_count": len(discovery),
        "development_count": len(development),
        "test_count": len(test),
        "inductive_mapping": mapping_audit,
        "best_state_family": best_state["family"],
        "best_state_mcc": best_state["mcc"],
        "best_path_family": best_path["family"],
        "best_path_mcc": best_path["mcc"],
        "delta_path_mcc": best_path["mcc"] - best_state["mcc"],
        "best_path_shuffled_order_mcc": best_path.get("shuffled_order_mcc"),
        "best_path_reversed_order_mcc": best_path.get("reversed_order_mcc"),
        "delta_order_mcc": best_path.get("delta_order_mcc", 0.0),
        "best_path_refit_order_control_mcc": max(
            (float(row["mcc"]) for row in inferential_order_controls),
            default=None,
        ),
        "delta_order_refit_mcc": (
            float(best_path["mcc"])
            - max(float(row["mcc"]) for row in inferential_order_controls)
            if inferential_order_controls
            else None
        ),
        "fixed_rule_order_control_role": "diagnostic_only",
        "refit_order_control_role": (
            "confirmatory" if refit_order_controls else "not_applicable"
        ),
        "reversal_refit_role": (
            "equivalence_diagnostic" if evaluator_implementation_revision == "E-05-r2"
            else "confirmatory"
        ),
        "selected_family": best_overall["family"],
        "selected_feature_count": best_overall["feature_count"],
        "held_out_mcc": best_overall["mcc"],
        "held_out_balanced_accuracy": best_overall["balanced_accuracy"],
        "held_out_auprc": best_overall["auprc"],
        "strongest_surface_baseline": best_surface["family"],
        "strongest_surface_baseline_mcc": best_surface["mcc"],
        "budget_matched_surface_baseline": best_matched_surface["family"],
        "budget_matched_surface_baseline_mcc": best_matched_surface["mcc"],
        "matched_baseline_mcc_margin": best_overall["mcc"] - best_matched_surface["mcc"],
        "bootstrap": ci,
        "condition_metrics": conditions,
        "computational_scap_minimum": computational_minimum,
        "automatic_scap_minimum": automatic_minimum,
        "localization": localization,
        "blinded_expert_identification_accuracy": None,
        "human_expert_gate_available": full_scap_available,
        "full_scap_pass": False,
        "counterfactual_deletion_auc": best_overall.get(
            "counterfactual_deletion_auc"
        ),
        "counterfactual_insertion_auc": best_overall.get(
            "counterfactual_insertion_auc"
        ),
        "selected_positive_prompt_ids": [
            item.prompt_id
            for item, prediction in zip(test, primary_predictions, strict=True)
            if prediction == 1
        ],
        "rq1_detector": {
            "family": rq1_detector["family"],
            "maximum_feature_count": rq1_maximum,
            "selection_split": rq1_detector["selection_split"],
            "feature_count": rq1_detector["feature_count"],
            "threshold": rq1_detector["threshold"],
            "development_mcc": rq1_detector["development_mcc"],
            "development_balanced_accuracy": rq1_detector[
                "development_balanced_accuracy"
            ],
            "held_out_mcc": rq1_detector["mcc"],
            "held_out_balanced_accuracy": rq1_detector["balanced_accuracy"],
            "held_out_auprc": rq1_detector["auprc"],
            "bootstrap": rq1_ci,
            "condition_metrics": rq1_conditions,
            "evaluated_prompt_ids": [item.prompt_id for item in test],
            "budget_matched_surface_baseline": rq1_matched_surface["family"],
            "budget_matched_surface_baseline_mcc": rq1_matched_surface["mcc"],
            "matched_surface_mcc_margin": (
                float(rq1_detector["mcc"]) - float(rq1_matched_surface["mcc"])
            ),
            "selected_positive_prompt_ids": [
                item.prompt_id
                for item, prediction in zip(test, rq1_predictions, strict=True)
                if prediction == 1
            ],
            "selected_features": rq1_detector["selected_features"],
        },
        "conditional_concept_assurance": {
            **representation_selection,
            "enabled": assurance_enabled,
            "eligible": assurance_eligible,
            "decision_before_seed_stability": assurance_decision,
            "selected_family": selected_detector["family"],
            "selected_feature_count": selected_detector["feature_count"],
            "held_out_mcc": selected_detector["mcc"],
            "held_out_balanced_accuracy": selected_detector["balanced_accuracy"],
            "held_out_auprc": selected_detector["auprc"],
            "selected_test_bootstrap": selected_ci,
            "condition_metrics": selected_conditions,
            "assurance_metrics": assurance_test_metrics,
            "assurance_bootstrap": assurance_bootstrap,
            "matched_surface_baseline": best_matched_surface["family"],
            "matched_surface_baseline_mcc": best_matched_surface["mcc"],
            "matched_surface_mcc_margin": selected_surface_margin,
            "gate_values": gate_values,
            "gate_thresholds": gate_thresholds,
            "gate_decisions": gate_decisions,
            "selected_positive_prompt_ids": [
                item.prompt_id
                for item, prediction in zip(test, selected_predictions, strict=True)
                if prediction == 1
            ],
            "selected_features": selected_detector["selected_features"],
        },
        "binary_concept_learning": {
            **learning_selection,
            "enabled": binary_enabled,
            "evaluated": binary_enabled,
            "held_out_mcc": learning_detector["mcc"],
            "held_out_balanced_accuracy": learning_detector["balanced_accuracy"],
            "held_out_auprc": learning_detector["auprc"],
            "bootstrap": learning_bootstrap,
            "test_count": len(test),
            "selected_positive_prompt_ids": [
                item.prompt_id
                for item, prediction in zip(test, learning_predictions, strict=True)
                if prediction == 1
            ],
            "selected_features": learning_detector["selected_features"],
        },
        "simultaneous_nested_learning": simultaneous_evidence,
        "family_results": family_results,
        "surface_baselines": surface_results,
        "budget_matched_surface_baselines": matched_surface_results,
        "selected_features": best_overall["selected_features"],
    }
    examples = evidence_examples(
        concept_id,
        model_seed,
        policy_id,
        selected_detector,
        test,
        selected_predictions,
        selected_scores,
    )
    return result, examples


def fit_select_evaluate_feature_detector(
    family: str,
    discovery: Sequence[Example],
    development: Sequence[Example],
    test: Sequence[Example],
    fixed_feature_count: int | None = None,
    max_feature_count: int | None = None,
    compute_order_controls: bool = True,
) -> dict:
    if family == "prompt_tfidf":
        return fit_tfidf_detector(
            discovery,
            development,
            test,
            fixed_feature_count=fixed_feature_count,
        )
    discovery_features = [extract_features(item, family) for item in discovery]
    development_features = [extract_features(item, family) for item in development]
    test_features = [extract_features(item, family) for item in test]
    labels = [item.label for item in discovery]
    weights = feature_log_odds(discovery_features, labels)
    if fixed_feature_count is not None:
        candidate_sizes = (max(1, int(fixed_feature_count)),)
    elif family in {"terminal_state", "best_interior_state"}:
        candidate_sizes = (1,)
    elif family == "unordered_state_set":
        candidate_sizes = (1, 2, 4, 8, 16, 32)
    elif family == "answer_length":
        candidate_sizes = (1, 2, 4, 8, 16)
    else:
        candidate_sizes = (2, 4, 8, 16, 32, 64)
    if max_feature_count is not None and fixed_feature_count is None:
        maximum = max(1, int(max_feature_count))
        candidate_sizes = tuple(size for size in candidate_sizes if size <= maximum)
        if maximum not in candidate_sizes:
            candidate_sizes = tuple(sorted(set(candidate_sizes + (maximum,))))
    best = None
    budget_curve = []
    for size in candidate_sizes:
        selected = sorted(
            weights,
            key=lambda feature: (-abs(weights[feature]), repr(feature)),
        )[:size]
        selected_weights = {feature: weights[feature] for feature in selected}
        dev_scores = score_feature_sets(development_features, selected_weights)
        threshold, dev_metrics = select_threshold(
            dev_scores, [item.label for item in development]
        )
        test_scores_for_budget = score_feature_sets(test_features, selected_weights)
        test_predictions_for_budget = [
            int(score >= threshold) for score in test_scores_for_budget
        ]
        test_metrics_for_budget = classification_metrics(
            [item.label for item in test],
            test_predictions_for_budget,
            test_scores_for_budget,
        )
        budget_curve.append(
            {
                "requested_feature_count": int(size),
                "feature_count": len(selected_weights),
                "development_mcc": dev_metrics["mcc"],
                "development_balanced_accuracy": dev_metrics["balanced_accuracy"],
                "test_mcc": test_metrics_for_budget["mcc"],
                "test_balanced_accuracy": test_metrics_for_budget["balanced_accuracy"],
            }
        )
        candidate = {
            "selection_key": (
                dev_metrics["mcc"],
                dev_metrics["balanced_accuracy"],
                -len(selected),
            ),
            "threshold": threshold,
            "weights": selected_weights,
            "development_metrics": dev_metrics,
        }
        if best is None or candidate["selection_key"] > best["selection_key"]:
            best = candidate
    assert best is not None
    threshold = best["threshold"]
    selected_weights = best["weights"]
    test_scores = score_feature_sets(test_features, selected_weights)
    predictions = [int(score >= threshold) for score in test_scores]
    metrics = classification_metrics(
        [item.label for item in test], predictions, test_scores
    )
    result = {
        "family": family,
        "feature_count": len(selected_weights),
        "threshold": threshold,
        "development_mcc": best["development_metrics"]["mcc"],
        "development_balanced_accuracy": best["development_metrics"]["balanced_accuracy"],
        "selection_split": "development",
        "feature_budget_curve": budget_curve,
        "selected_features": [
            {"feature": repr(feature), "weight": selected_weights[feature]}
            for feature in sorted(
                selected_weights,
                key=lambda feature: (-abs(selected_weights[feature]), repr(feature)),
            )
        ],
        **metrics,
        "_predictions": predictions,
        "_scores": test_scores,
        "_weights": selected_weights,
        "_development_scores": score_feature_sets(
            development_features, selected_weights
        ),
    }
    result["_development_predictions"] = [
        int(score >= threshold) for score in result["_development_scores"]
    ]
    if compute_order_controls:
        result.update(
            {
                "development_" + name: value
                for name, value in order_control_metrics(
                    family,
                    development,
                    selected_weights,
                    threshold,
                    best["development_metrics"]["mcc"],
                ).items()
            }
        )
        result.update(
            order_control_metrics(
                family,
                test,
                selected_weights,
                threshold,
                metrics["mcc"],
            )
        )
    result.update(
        explanation_perturbation_metrics(test_features, selected_weights)
    )
    return result


def extract_features(item: Example, family: str) -> set[object]:
    if family == "short_gap_fragment_pair":
        from .trace_coverage import short_gap_fragment_features

        if getattr(item, "mapping_revision", LEGACY_MAPPING_REVISION) != PRESENCE_MAPPING_REVISION:
            raise ValueError("Short-gap fragments require concept-presence mapping.")
        return short_gap_fragment_features(item.path, item.mapping_kinds)
    path = tuple(item.path[1:]) if len(item.path) > 1 else tuple(item.path)
    if getattr(item, "mapping_revision", LEGACY_MAPPING_REVISION) == PRESENCE_MAPPING_REVISION:
        _exact_path_segments(item)
        # Boundary placeholders are neither visits caused by tokens nor endpoints.
        path = tuple(
            state for state, kind in zip(item.path[1:], item.mapping_kinds, strict=True)
            if kind != "unknown"
        )
        if family == "terminal_state" and (
            not item.mapping_kinds or item.mapping_kinds[-1] == "unknown"
        ):
            return set()
    if family == "terminal_state":
        return {("terminal", path[-1])} if path else set()
    if family in {"best_interior_state", "unordered_state_set"}:
        return {("state", state) for state in path}
    if family == "transition_edge_set":
        return {
            ("edge", left, right)
            for segment in _exact_path_segments(item)
            for left, right in zip(segment, segment[1:], strict=False)
        }
    if family == "contiguous_state_motif":
        return {
            ("motif", length, *segment[index : index + length])
            for segment in _exact_path_segments(item)
            for length in (2, 3, 4, 5)
            for index in range(max(0, len(segment) - length + 1))
        }
    if family == "gapped_state_motif":
        features = set()
        for segment in _exact_path_segments(item):
            for gap in (1, 2, 4):
                step = gap + 1
                for length in (2, 3, 4, 5):
                    span = (length - 1) * step + 1
                    for index in range(max(0, len(segment) - span + 1)):
                        motif = tuple(
                            segment[index + offset * step]
                            for offset in range(length)
                        )
                        features.add(("gapped", gap, length, *motif))
        return features
    tokens = item.answer_tokens
    if family == "answer_token_ngram":
        return {("token", token) for token in tokens} | {
            ("bigram", left, right)
            for left, right in zip(tokens, tokens[1:], strict=False)
        }
    if family == "answer_position":
        features = set()
        for index, token in enumerate(tokens[:8]):
            features.add(("absolute", index, token))
        for index, token in enumerate(tokens[-4:]):
            features.add(("relative_end", index - min(4, len(tokens)), token))
        return features
    if family == "answer_template":
        return {("template", *tokens[:4])} if tokens else set()
    if family == "answer_length":
        return {("length_bin", min(12, len(tokens) // 16))}
    raise ValueError("Unknown detector family: {}".format(family))


def _exact_path_segments(item: Example) -> tuple[tuple[int, ...], ...]:
    """Return graph-verified state segments without crossing fallback positions."""

    presence_mapping = getattr(item, "mapping_revision", LEGACY_MAPPING_REVISION) == PRESENCE_MAPPING_REVISION
    if presence_mapping and (
        len(item.mapping_kinds) != max(0, len(item.path) - 1)
        or any(kind not in {"exact", "reconstruction_exact", "global_fallback", "unknown"}
               for kind in item.mapping_kinds)
    ):
        raise ValueError("Presence mapping requires complete token-bound provenance.")
    if len(item.path) < 2:
        return ()
    kinds = item.mapping_kinds
    if not kinds:
        return (tuple(item.path),)
    if len(kinds) != len(item.path) - 1:
        raise ValueError("Mapping provenance does not align with the state path.")
    accepted = {"exact", "reconstruction_exact"}
    segments = []
    current = [item.path[0]]
    for index, kind in enumerate(kinds):
        if kind in accepted:
            current.append(item.path[index + 1])
            continue
        if len(current) > 1:
            segments.append(tuple(current))
        current = [item.path[index + 1]]
    if len(current) > 1:
        segments.append(tuple(current))
    return tuple(segments)


def fit_tfidf_detector(
    discovery: Sequence[Example],
    development: Sequence[Example],
    test: Sequence[Example],
    fixed_feature_count: int | None = None,
) -> dict:
    documents = [text_terms(item.prompt_text) for item in discovery]
    document_frequency: Counter[str] = Counter()
    for terms in documents:
        document_frequency.update(set(terms))
    count = len(documents)
    idf = {
        term: math.log((count + 1.0) / (frequency + 1.0)) + 1.0
        for term, frequency in document_frequency.items()
    }
    vectors = [tfidf_vector(terms, idf) for terms in documents]
    positive = centroid(
        [
            vector
            for vector, item in zip(vectors, discovery, strict=True)
            if item.label == 1
        ]
    )
    negative = centroid(
        [
            vector
            for vector, item in zip(vectors, discovery, strict=True)
            if item.label == 0
        ]
    )

    feature_limit = max(1, int(fixed_feature_count)) if fixed_feature_count is not None else 64
    discriminative_terms = sorted(
        set(positive) | set(negative),
        key=lambda term: (-abs(positive.get(term, 0.0) - negative.get(term, 0.0)), term),
    )[:feature_limit]
    selected_terms = set(discriminative_terms)
    selected_positive = {term: value for term, value in positive.items() if term in selected_terms}
    selected_negative = {term: value for term, value in negative.items() if term in selected_terms}

    def scores(items: Sequence[Example]) -> list[float]:
        return [
            cosine(tfidf_vector(text_terms(item.prompt_text), idf), selected_positive)
            - cosine(tfidf_vector(text_terms(item.prompt_text), idf), selected_negative)
            for item in items
        ]

    development_scores = scores(development)
    threshold, _ = select_threshold(
        development_scores, [item.label for item in development]
    )
    test_scores = scores(test)
    predictions = [int(score >= threshold) for score in test_scores]
    metrics = classification_metrics(
        [item.label for item in test], predictions, test_scores
    )
    _, development_metrics = select_threshold(
        development_scores, [item.label for item in development]
    )
    return {
        "family": "prompt_tfidf",
        "feature_count": len(discriminative_terms),
        "threshold": threshold,
        "development_mcc": development_metrics["mcc"],
        "development_balanced_accuracy": development_metrics["balanced_accuracy"],
        "selection_split": "development",
        "feature_budget_curve": [],
        "selected_features": [
            {
                "feature": repr(("tfidf", term)),
                "weight": positive.get(term, 0.0) - negative.get(term, 0.0),
            }
            for term in discriminative_terms
        ],
        **metrics,
        "_predictions": predictions,
        "_scores": test_scores,
        "shuffled_order_mcc": metrics["mcc"],
        "reversed_order_mcc": metrics["mcc"],
        "delta_order_mcc": 0.0,
        **explanation_perturbation_metrics(
            [extract_features(item, "answer_token_ngram") for item in test], {}
        ),
    }


def order_control_metrics(
    family: str,
    examples: Sequence[Example],
    weights: Dict[object, float],
    threshold: float,
    observed_mcc: float,
) -> dict:
    controls = order_control_outputs(family, examples, weights, threshold)
    if not controls:
        return {
            "shuffled_order_mcc": observed_mcc,
            "reversed_order_mcc": observed_mcc,
            "delta_order_mcc": 0.0,
        }
    by_role = {row["role"]: row for row in controls}
    shuffled_mcc = float(by_role["order_shuffled_rule"]["mcc"])
    reversed_mcc = float(by_role["order_reversed_rule"]["mcc"])
    return {
        "shuffled_order_mcc": shuffled_mcc,
        "reversed_order_mcc": reversed_mcc,
        "delta_order_mcc": observed_mcc - max(shuffled_mcc, reversed_mcc),
    }


def order_control_outputs(
    family: str,
    examples: Sequence[Example],
    weights: Dict[object, float],
    threshold: float,
) -> list[dict]:
    """Return deterministic order-control predictions for response-level audits."""

    if family not in {
        "transition_edge_set",
        "contiguous_state_motif",
        "gapped_state_motif",
    }:
        return []
    shuffled = _transform_order(examples, "shuffled")
    reversed_items = _transform_order(examples, "reversed")

    def controlled(role: str, items: Sequence[Example]) -> dict:
        scores = score_feature_sets(
            [extract_features(item, family) for item in items], weights
        )
        predictions = [int(score >= threshold) for score in scores]
        metrics = classification_metrics(
            [item.label for item in items], predictions, scores
        )
        return {
            "role": role,
            "mcc": metrics["mcc"],
            "scores": scores,
            "predictions": predictions,
        }

    return [
        controlled("order_shuffled_rule", shuffled),
        controlled("order_reversed_rule", reversed_items),
    ]


def refit_order_control_outputs(
    family: str,
    discovery: Sequence[Example],
    development: Sequence[Example],
    test: Sequence[Example],
    feature_count: int,
) -> list[dict]:
    """Refit transformed controls at the same capacity as the path detector."""

    if family not in {
        "transition_edge_set",
        "contiguous_state_motif",
        "gapped_state_motif",
    }:
        return []
    results = []
    for transformation, role in (
        ("shuffled", "order_shuffled_refit_rule"),
        ("reversed", "order_reversed_refit_rule"),
    ):
        fitted = fit_select_evaluate_feature_detector(
            family,
            _transform_order(discovery, transformation),
            _transform_order(development, transformation),
            _transform_order(test, transformation),
            fixed_feature_count=feature_count,
            compute_order_controls=False,
        )
        results.append(
            {
                "role": role,
                "mcc": fitted["mcc"],
                "scores": fitted["_scores"],
                "predictions": fitted["_predictions"],
            }
        )
    return results


def _order_control_seed(prompt_id: str) -> int:
    digest = hashlib.sha256(prompt_id.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") ^ 31013


def _transform_order(
    examples: Sequence[Example], transformation: str
) -> tuple[Example, ...]:
    transformed = []
    for item in examples:
        path = list(item.path)
        if transformation not in {"shuffled", "reversed"}:
            raise ValueError("Unknown order transformation: {}.".format(transformation))
        kinds = item.mapping_kinds
        if kinds and len(kinds) != len(path) - 1:
            raise ValueError("Mapping provenance does not align with the state path.")
        accepted = {"exact", "reconstruction_exact"}
        ranges = []
        start = None
        for edge_index, kind in enumerate(kinds):
            if kind in accepted and start is None:
                start = edge_index
            elif kind not in accepted and start is not None:
                ranges.append((start, edge_index + 1))
                start = None
        if start is not None:
            ranges.append((start, len(path)))
        if not kinds and len(path) > 1:
            ranges.append((0, len(path)))

        rng = random.Random(_order_control_seed(item.prompt_id))
        for start, stop in ranges:
            segment = path[start:stop]
            if transformation == "shuffled":
                rng.shuffle(segment)
            else:
                segment.reverse()
            path[start:stop] = segment
        transformed.append(replace(item, path=tuple(path)))
    return tuple(transformed)


def explanation_perturbation_metrics(
    feature_sets: Sequence[set[object]],
    weights: Dict[object, float],
) -> dict:
    deletion_values = []
    insertion_values = []
    for features in feature_sets:
        ranked = sorted(
            (feature for feature in features if feature in weights),
            key=lambda feature: -abs(weights[feature]),
        )
        if not ranked:
            continue
        full = sum(weights[feature] for feature in ranked)
        full_probability = logistic(full)
        deletion_curve = []
        insertion_curve = []
        for fraction in (0.0, 0.25, 0.50, 0.75, 1.0):
            count = round(len(ranked) * fraction)
            deleted = sum(weights[feature] for feature in ranked[count:])
            inserted = sum(weights[feature] for feature in ranked[:count])
            deletion_curve.append(max(0.0, full_probability - logistic(deleted)))
            insertion_curve.append(logistic(inserted))
        deletion_values.append(sum(deletion_curve) / len(deletion_curve))
        insertion_values.append(sum(insertion_curve) / len(insertion_curve))
    return {
        "counterfactual_deletion_auc": _mean(deletion_values),
        "counterfactual_insertion_auc": _mean(insertion_values),
    }


def logistic(value: float) -> float:
    bounded = max(-40.0, min(40.0, value))
    return 1.0 / (1.0 + math.exp(-bounded))


def text_terms(text: str) -> tuple[str, ...]:
    words = tuple(WORD_RE.findall(text.lower()))
    return words + tuple(
        "{} {}".format(a, b) for a, b in zip(words, words[1:], strict=False)
    )


def tfidf_vector(terms: Sequence[str], idf: Dict[str, float]) -> Dict[str, float]:
    counts = Counter(term for term in terms if term in idf)
    total = sum(counts.values())
    if not total:
        return {}
    vector = {term: count / total * idf[term] for term, count in counts.items()}
    norm = math.sqrt(sum(value * value for value in vector.values()))
    return {term: value / norm for term, value in vector.items()} if norm else {}


def centroid(vectors: Sequence[Dict[str, float]]) -> Dict[str, float]:
    result: Counter[str] = Counter()
    for vector in vectors:
        result.update(vector)
    if not vectors:
        return {}
    averaged = {term: value / len(vectors) for term, value in result.items()}
    norm = math.sqrt(sum(value * value for value in averaged.values()))
    return {term: value / norm for term, value in averaged.items()} if norm else {}


def cosine(left: Dict[str, float], right: Dict[str, float]) -> float:
    if len(left) > len(right):
        left, right = right, left
    return sum(value * right.get(term, 0.0) for term, value in left.items())


def feature_log_odds(
    feature_sets: Sequence[set[object]], labels: Sequence[int]
) -> Dict[object, float]:
    if len(feature_sets) != len(labels):
        raise ValueError("Feature sets and labels must have equal lengths.")
    positive_docs = sum(labels)
    negative_docs = len(labels) - positive_docs
    positive_counts: Counter[object] = Counter()
    negative_counts: Counter[object] = Counter()
    for features, label in zip(feature_sets, labels, strict=True):
        (positive_counts if label else negative_counts).update(features)
    weights = {}
    for feature in set(positive_counts) | set(negative_counts):
        support = positive_counts[feature] + negative_counts[feature]
        if support < 3:
            continue
        pos_odds = (positive_counts[feature] + 1.0) / (
            positive_docs - positive_counts[feature] + 1.0
        )
        neg_odds = (negative_counts[feature] + 1.0) / (
            negative_docs - negative_counts[feature] + 1.0
        )
        weights[feature] = math.log(pos_odds / neg_odds)
    return weights


def score_feature_sets(
    feature_sets: Sequence[set[object]], weights: Dict[object, float]
) -> list[float]:
    return [sum(weights.get(feature, 0.0) for feature in features) for features in feature_sets]


def select_threshold(scores: Sequence[float], labels: Sequence[int]) -> tuple[float, dict]:
    values = sorted(set(float(score) for score in scores))
    if len(values) > 200:
        values = [values[round(index * (len(values) - 1) / 199)] for index in range(200)]
    candidates = [values[0] - 1e-9] + values + [values[-1] + 1e-9]
    best = None
    for threshold in candidates:
        predictions = [int(score >= threshold) for score in scores]
        metrics = classification_metrics(labels, predictions, scores)
        key = (metrics["mcc"], metrics["balanced_accuracy"], -abs(threshold))
        if best is None or key > best[0]:
            best = (key, threshold, metrics)
    assert best is not None
    return best[1], best[2]


def classification_metrics(
    labels: Sequence[int], predictions: Sequence[int], scores: Sequence[float]
) -> dict:
    if not (len(labels) == len(predictions) == len(scores)):
        raise ValueError("Labels, predictions, and scores must have equal lengths.")
    paired = tuple(zip(labels, predictions, strict=True))
    tp = sum(label == 1 and pred == 1 for label, pred in paired)
    tn = sum(label == 0 and pred == 0 for label, pred in paired)
    fp = sum(label == 0 and pred == 1 for label, pred in paired)
    fn = sum(label == 1 and pred == 0 for label, pred in paired)
    tpr = tp / (tp + fn) if tp + fn else 0.0
    tnr = tn / (tn + fp) if tn + fp else 0.0
    denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    mcc = (tp * tn - fp * fn) / denominator if denominator else 0.0
    return {
        "mcc": mcc,
        "balanced_accuracy": 0.5 * (tpr + tnr),
        "auprc": average_precision(labels, scores),
        "true_positive_rate": tpr,
        "true_negative_rate": tnr,
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
    }


def average_precision(labels: Sequence[int], scores: Sequence[float]) -> float:
    if len(labels) != len(scores):
        raise ValueError("Labels and scores must have equal lengths.")
    positives = sum(labels)
    if not positives:
        return 0.0
    ranked = sorted(zip(scores, labels, strict=True), key=lambda item: -item[0])
    true_positives = 0
    precision_sum = 0.0
    for rank, (_, label) in enumerate(ranked, 1):
        if label:
            true_positives += 1
            precision_sum += true_positives / rank
    return precision_sum / positives


def condition_metrics(examples: Sequence[Example], predictions: Sequence[int]) -> dict:
    reject_presence_in_legacy(examples)
    by_condition: dict[str, list[int]] = defaultdict(list)
    for index, item in enumerate(examples):
        by_condition[item.condition].append(index)

    def balanced(positive: str, negative: str) -> float | None:
        indices = by_condition.get(positive, []) + by_condition.get(negative, [])
        if not indices:
            return None
        labels = [examples[index].label for index in indices]
        preds = [predictions[index] for index in indices]
        return classification_metrics(labels, preds, preds)["balanced_accuracy"]

    hard = by_condition.get("hard_negative", [])
    hard_tnr = (
        sum(predictions[index] == 0 for index in hard) / len(hard) if hard else None
    )
    irrelevant = paired_consistency(
        examples, predictions, "irrelevant_original", "irrelevant_perturbation", False
    )
    relevant = paired_consistency(
        examples, predictions, "relevant_original", "relevant_toggle", True
    )
    surface_values = [
        balanced("token_control_positive", "token_control_negative"),
        balanced("position_control_positive", "position_control_negative"),
        balanced("template_control_positive", "template_control_negative"),
        balanced("style_control_positive", "style_control_negative"),
    ]
    hard_by_mode = {
        mode: true_negative_rate(
            by_condition.get("hard_negative_{}".format(mode), []), predictions
        )
        for mode in ("keyword_topic", "llm_topic_relation", "combined")
    }
    return {
        "lexical_disjoint_balanced_accuracy": balanced(
            "lexical_disjoint_positive", "lexical_disjoint_negative"
        ),
        "hard_negative_true_negative_rate": hard_tnr,
        "hard_negative_keyword_topic_tnr": hard_by_mode["keyword_topic"],
        "hard_negative_llm_topic_relation_tnr": hard_by_mode["llm_topic_relation"],
        "hard_negative_combined_tnr": hard_by_mode["combined"],
        "hard_negative_three_mode_minimum_tnr": min(
            (value for value in hard_by_mode.values() if value is not None),
            default=hard_tnr,
        ),
        "irrelevant_invariance": irrelevant,
        "relevant_counterfactual_sensitivity": relevant,
        "counterfactual_score": _mean([irrelevant, relevant]),
        "unseen_composition_balanced_accuracy": balanced(
            "unseen_composition_positive", "unseen_composition_negative"
        ),
        "token_control_balanced_accuracy": surface_values[0],
        "position_control_balanced_accuracy": surface_values[1],
        "template_control_balanced_accuracy": surface_values[2],
        "style_control_balanced_accuracy": surface_values[3],
        "surface_control_balanced_accuracy": _mean(surface_values),
        "entity_renamed_balanced_accuracy": balanced(
            "entity_renamed_positive", "entity_renamed_negative"
        ),
        "lexical_decoy_balanced_accuracy": balanced(
            "lexical_decoy_positive", "lexical_decoy_negative"
        ),
        "adversarial_paraphrase_balanced_accuracy": balanced(
            "adversarial_paraphrase_positive", "adversarial_paraphrase_negative"
        ),
    }


def true_negative_rate(indices: Sequence[int], predictions: Sequence[int]) -> float | None:
    return (
        sum(predictions[index] == 0 for index in indices) / len(indices)
        if indices
        else None
    )


def paired_consistency(
    examples: Sequence[Example],
    predictions: Sequence[int],
    condition_a: str,
    condition_b: str,
    require_change: bool,
) -> float | None:
    if len(examples) != len(predictions):
        raise ValueError("Examples and predictions must have equal lengths.")
    pairs: dict[str, dict[str, int]] = defaultdict(dict)
    for item, prediction in zip(examples, predictions, strict=True):
        if item.condition in {condition_a, condition_b} and item.pair_id:
            pairs[item.pair_id][item.condition] = prediction
    values = []
    for pair in pairs.values():
        if condition_a not in pair or condition_b not in pair:
            continue
        if require_change:
            values.append(int(pair[condition_a] == 1 and pair[condition_b] == 0))
        else:
            values.append(int(pair[condition_a] == pair[condition_b]))
    return _mean(values)


def bootstrap_metrics(
    examples: Sequence[Example],
    predictions: Sequence[int],
    scores: Sequence[float],
    repetitions: int,
    seed: int,
) -> dict:
    families: dict[str, list[int]] = defaultdict(list)
    for index, item in enumerate(examples):
        families[item.pair_id or item.prompt_id].append(index)
    family_ids = sorted(families)
    rng = random.Random(seed)
    metrics_by_name: dict[str, list[float]] = defaultdict(list)
    for _ in range(repetitions):
        sampled = [rng.choice(family_ids) for _ in family_ids]
        sampled_examples = []
        sampled_predictions = []
        sampled_scores = []
        for draw_index, family in enumerate(sampled):
            for index in families[family]:
                sampled_examples.append(
                    replace(
                        examples[index],
                        pair_id="{}#{}".format(
                            examples[index].pair_id or examples[index].prompt_id,
                            draw_index,
                        ),
                    )
                )
                sampled_predictions.append(predictions[index])
                sampled_scores.append(scores[index])
        metrics = classification_metrics(
            [item.label for item in sampled_examples],
            sampled_predictions,
            sampled_scores,
        )
        metrics_by_name["held_out_mcc"].append(metrics["mcc"])
        for name, value in condition_metrics(
            sampled_examples, sampled_predictions
        ).items():
            if value is not None:
                metrics_by_name[name].append(value)
    result = {
        "resampling_unit": "prompt_family",
        "repetitions": repetitions,
        "seed": int(seed),
    }
    for name, values in metrics_by_name.items():
        values.sort()
        result[name + "_lower_95"] = percentile(values, 0.025)
        result[name + "_upper_95"] = percentile(values, 0.975)
    return result


def evidence_examples(
    concept_id: str,
    model_seed: str,
    policy_id: str,
    detector: dict,
    examples: Sequence[Example],
    predictions: Sequence[int],
    scores: Sequence[float],
) -> list[dict]:
    priority_conditions = (
        "lexical_disjoint_positive",
        "entity_renamed_positive",
        "unseen_composition_positive",
        "lexical_decoy_positive",
        "adversarial_paraphrase_positive",
        "relevant_toggle",
    )
    selected_indices = []
    for condition in priority_conditions:
        candidates = [
            index
            for index, item in enumerate(examples)
            if item.condition == condition
            and predictions[index] == item.label
        ]
        if candidates:
            selected_indices.append(max(candidates, key=lambda index: abs(scores[index])))
    ranked = selected_indices + [
        index
        for index in sorted(
            range(len(examples)),
            key=lambda index: (
                predictions[index] == examples[index].label,
                abs(scores[index]),
            ),
            reverse=True,
        )
        if index not in selected_indices
    ]
    result = []
    for index in ranked[:8]:
        item = examples[index]
        result.append(
            {
                "concept_id": concept_id,
                "model_seed": model_seed,
                "policy_id": policy_id,
                "detector_family": detector["family"],
                "prompt_id": item.prompt_id,
                "condition": item.condition,
                "expected_label": item.label,
                "predicted_label": predictions[index],
                "score": scores[index],
                "state_path_context": list(item.path[:24]),
                "prompt_excerpt": item.prompt_text[:500],
                "answer_excerpt": item.answer_text[:500],
                "selected_features": detector["selected_features"][:8],
            }
        )
    return result


def _examples(
    manifest: Dict[str, ManifestRow],
    concept_id: str,
    split: str,
    traces: Dict[str, ResponseTrace],
    paths: Dict[str, tuple[int, ...]],
    mapping_kinds: Dict[str, tuple[str, ...]] | None = None,
) -> list[Example]:
    reject_presence_in_legacy(tuple(manifest.values()))
    result = []
    for prompt_id, row in manifest.items():
        if row.concept_id != concept_id or row.split != split:
            continue
        trace = traces.get(prompt_id)
        path = paths.get(prompt_id)
        if trace is None or path is None:
            continue
        result.append(
            Example(
                prompt_id=prompt_id,
                label=row.expected_label,
                condition=row.condition,
                pair_id=row.pair_id,
                prompt_text=row.prompt_text,
                path=path,
                answer_text=trace.answer_text,
                answer_tokens=trace.answer_tokens,
                condition_index=row.condition_index,
                base_question_index=row.base_question_index,
                mapping_kinds=(
                    mapping_kinds[prompt_id]
                    if mapping_kinds is not None and prompt_id in mapping_kinds
                    else tuple("reconstruction_exact" for _ in range(len(path) - 1))
                ),
            )
        )
    return result


def _best_result(rows: Sequence[dict]) -> dict:
    return max(
        rows,
        key=lambda row: (
            row.get("development_mcc", row["mcc"]),
            row.get("development_balanced_accuracy", row["balanced_accuracy"]),
            -row["feature_count"],
            row["family"],
        ),
    ).copy()


def localization_summary(unordered_result: dict) -> dict:
    """Summarize the preregistered sparse-state localization frontier."""

    curve = list(unordered_result.get("feature_budget_curve", []))
    if not curve:
        return {
            "selected_k": unordered_result.get("feature_count", 0),
            "minimum_k_within_0_02_development_mcc": None,
            "effective_positive_state_count": None,
            "top_state_weight_concentration": None,
            "curve": [],
        }
    best_development = max(float(row["development_mcc"]) for row in curve)
    near_best = [
        int(row["feature_count"])
        for row in curve
        if float(row["development_mcc"]) >= best_development - 0.02
    ]
    positive_weights = [
        max(0.0, float(item["weight"]))
        for item in unordered_result.get("selected_features", [])
    ]
    total = sum(positive_weights)
    probabilities = [value / total for value in positive_weights if value > 0.0] if total else []
    entropy = -sum(value * math.log(value) for value in probabilities)
    return {
        "selected_k": int(unordered_result.get("feature_count", 0)),
        "minimum_k_within_0_02_development_mcc": min(near_best) if near_best else None,
        "effective_positive_state_count": math.exp(entropy) if probabilities else None,
        "top_state_weight_concentration": max(probabilities) if probabilities else None,
        "curve": curve,
    }


def _most_common(counter: Counter[int]) -> int:
    return min(counter, key=lambda value: (-counter[value], value))


def percentile(values: Sequence[float], quantile: float) -> float | None:
    if not values:
        return None
    index = min(len(values) - 1, max(0, round((len(values) - 1) * quantile)))
    return float(values[index])


def _shared_bootstrap_seed(base_seed: int, concept_id: str) -> int:
    material = "{}|{}|prompt-family-bootstrap-v1".format(base_seed, concept_id)
    return int(hashlib.sha256(material.encode("utf-8")).hexdigest()[:16], 16)


def _mean(values: Iterable[float | int | None]) -> float | None:
    clean = [float(value) for value in values if value is not None]
    return sum(clean) / len(clean) if clean else None


def _resolve(root: Path, raw: str) -> Path:
    path = Path(raw)
    return path if path.is_absolute() else (root / path).resolve()


def _write_flat_csv(path: Path, rows: Sequence[dict]) -> None:
    flattened = []
    for row in rows:
        flat = {
            key: value
            for key, value in row.items()
            if not isinstance(value, (dict, list))
        }
        for key, value in row.get("condition_metrics", {}).items():
            flat[key] = value
        flattened.append(flat)
    fields = sorted({key for row in flattened for key in row})
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(flattened)
    os.replace(temporary, path)


def _atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    os.replace(temporary, path)
