"""Conditional, label-controlled semantic concept assurance."""

from __future__ import annotations

import bisect
import hashlib
import math
import random
from collections import Counter, defaultdict
from typing import Dict, Sequence


INDIVIDUAL_STATE_FAMILIES = {"terminal_state", "best_interior_state"}
UNORDERED_STATE_FAMILY = "unordered_state_set"
TRANSITION_FAMILY = "transition_edge_set"
ORDERED_MOTIF_FAMILIES = {"contiguous_state_motif", "gapped_state_motif"}
CONTRAST_NEGATIVE_CONDITIONS = {
    "natural_negative",
    "lexical_disjoint_negative",
    "hard_negative_keyword_topic",
    "hard_negative_llm_topic_relation",
    "hard_negative_combined",
    "relevant_toggle",
    "unseen_composition_negative",
    "entity_renamed_negative",
    "lexical_decoy_negative",
    "adversarial_paraphrase_negative",
}

BINARY_LEARNING_CRITERIA = (
    "mean_development_mcc",
    "minimum_development_mcc",
    "minimum_test_mcc_lower_95",
    "minimum_positive_sensitivity_lower_95",
    "minimum_contrastive_auc_lower_95",
    "seed_prediction_jaccard",
)


def select_learning_representation(
    family_results: Sequence[dict],
    tolerance: float = 0.02,
) -> dict:
    """Select the simplest structural family within a development-MCC tolerance."""

    by_family = {str(row["family"]): row for row in family_results}
    missing = (
        INDIVIDUAL_STATE_FAMILIES
        | {UNORDERED_STATE_FAMILY, TRANSITION_FAMILY}
        | ORDERED_MOTIF_FAMILIES
    ) - set(by_family)
    if missing:
        raise ValueError(
            "Binary learning selection lacks families: {}.".format(
                ", ".join(sorted(missing))
            )
        )
    if float(tolerance) < 0.0:
        raise ValueError("Representation-selection tolerance must be non-negative.")

    best_individual = _development_best(
        [by_family[name] for name in INDIVIDUAL_STATE_FAMILIES]
    )
    best_motif = _development_best(
        [by_family[name] for name in ORDERED_MOTIF_FAMILIES]
    )
    ordered = (
        ("individual_state", best_individual),
        ("unordered_state_set", by_family[UNORDERED_STATE_FAMILY]),
        ("transition_set", by_family[TRANSITION_FAMILY]),
        ("ordered_motif", best_motif),
    )
    best_mcc = max(_development_mcc(row) for _, row in ordered)
    selected_class, selected = next(
        (family_class, row)
        for family_class, row in ordered
        if _development_mcc(row) >= best_mcc - float(tolerance)
    )
    return {
        "selection_split": "development",
        "selected_family": str(selected["family"]),
        "representation_class": selected_class,
        "selected_feature_count": int(selected["feature_count"]),
        "development_mcc": _development_mcc(selected),
        "best_development_mcc": best_mcc,
        "development_mcc_gap": best_mcc - _development_mcc(selected),
        "simplicity_tolerance": float(tolerance),
    }


def select_conditional_representation(
    family_results: Sequence[dict],
    surface_results: Sequence[dict],
    config: dict | None = None,
) -> dict:
    """Select the simplest adequate representation using development data only."""

    settings = config or {}
    minimum_mcc = float(settings.get("minimum_development_mcc", 0.20))
    minimum_surface_margin = float(
        settings.get("minimum_development_surface_margin", 0.02)
    )
    minimum_set_gain = float(settings.get("minimum_state_set_mcc_gain", 0.03))
    minimum_path_gain = float(settings.get("minimum_path_mcc_gain", 0.03))
    minimum_order_gain = float(settings.get("minimum_order_mcc_gain", 0.03))
    sparse_max_features = int(settings.get("sparse_state_max_features", 4))

    by_family = {str(row["family"]): row for row in family_results}
    missing = (
        INDIVIDUAL_STATE_FAMILIES
        | {UNORDERED_STATE_FAMILY, TRANSITION_FAMILY}
        | ORDERED_MOTIF_FAMILIES
    ) - set(by_family)
    if missing:
        raise ValueError(
            "Conditional representation selection lacks families: {}.".format(
                ", ".join(sorted(missing))
            )
        )

    best_individual = _development_best(
        [by_family[name] for name in INDIVIDUAL_STATE_FAMILIES]
    )
    unordered = by_family[UNORDERED_STATE_FAMILY]
    selected = best_individual
    representation_kind = "localized_single_state"

    state_set_gain = _development_mcc(unordered) - _development_mcc(best_individual)
    if state_set_gain >= minimum_set_gain:
        selected = unordered
        representation_kind = (
            "localized_state_set"
            if int(unordered["feature_count"]) <= sparse_max_features
            else "distributed_state_set"
        )

    transition = by_family[TRANSITION_FAMILY]
    transition_gain = _development_mcc(transition) - _development_mcc(selected)
    if transition_gain >= minimum_path_gain:
        selected = transition
        representation_kind = "distributed_transition_set"

    best_motif = _development_best(
        [by_family[name] for name in ORDERED_MOTIF_FAMILIES]
    )
    motif_gain = _development_mcc(best_motif) - _development_mcc(selected)
    motif_order_gain = float(best_motif.get("development_delta_order_mcc", 0.0))
    if motif_gain >= minimum_path_gain and motif_order_gain >= minimum_order_gain:
        selected = best_motif
        representation_kind = "ordered_path_motif"

    best_surface_mcc = max(
        (_development_mcc(row) for row in surface_results),
        default=0.0,
    )
    selected_mcc = _development_mcc(selected)
    surface_margin = selected_mcc - best_surface_mcc
    eligible = selected_mcc >= minimum_mcc and surface_margin >= minimum_surface_margin

    if not eligible:
        rq1_status = "not_identifiable"
        rq2_status = "not_identifiable"
        order_status = "not_identifiable"
    else:
        rq1_status = (
            "supported"
            if representation_kind in {
                "localized_single_state",
                "localized_state_set",
            }
            else "not_supported"
        )
        rq2_status = (
            "supported"
            if representation_kind in {
                "distributed_state_set",
                "distributed_transition_set",
                "ordered_path_motif",
            }
            else "not_supported"
        )
        order_status = (
            "supported"
            if representation_kind == "ordered_path_motif"
            else "not_supported"
        )

    return {
        "eligible": eligible,
        "selection_split": "development",
        "selected_family": selected["family"],
        "selected_feature_count": int(selected["feature_count"]),
        "representation_kind": representation_kind,
        "development_mcc": selected_mcc,
        "development_surface_baseline_mcc": best_surface_mcc,
        "development_surface_margin": surface_margin,
        "best_individual_state_mcc": _development_mcc(best_individual),
        "unordered_state_set_mcc": _development_mcc(unordered),
        "state_set_mcc_gain": state_set_gain,
        "transition_mcc_gain": transition_gain,
        "ordered_motif_mcc_gain": motif_gain,
        "ordered_motif_order_gain": motif_order_gain,
        "rq1_status": rq1_status,
        "rq2_status": rq2_status,
        "order_status": order_status,
        "thresholds": {
            "minimum_development_mcc": minimum_mcc,
            "minimum_development_surface_margin": minimum_surface_margin,
            "minimum_state_set_mcc_gain": minimum_set_gain,
            "minimum_path_mcc_gain": minimum_path_gain,
            "minimum_order_mcc_gain": minimum_order_gain,
            "sparse_state_max_features": sparse_max_features,
        },
    }


def path_evidence(
    path: Sequence[int],
    family: str,
    weights: Dict[object, float],
) -> tuple[float, int, set[object]]:
    """Measure how much of a response path is covered by positive concept evidence."""

    body = tuple(path[1:]) if len(path) > 1 else tuple(path)
    if not body:
        return 0.0, 0, set()
    positive = {feature for feature, weight in weights.items() if weight > 0.0}
    covered: set[int] = set()
    matched: set[object] = set()

    if family == "terminal_state":
        feature = ("terminal", body[-1])
        if feature in positive:
            covered.add(len(body) - 1)
            matched.add(feature)
    elif family in {"best_interior_state", UNORDERED_STATE_FAMILY}:
        for index, state in enumerate(body):
            feature = ("state", state)
            if feature in positive:
                covered.add(index)
                matched.add(feature)
    elif family == TRANSITION_FAMILY:
        for index, (left, right) in enumerate(zip(body, body[1:], strict=False)):
            feature = ("edge", left, right)
            if feature in positive:
                covered.update((index, index + 1))
                matched.add(feature)
    elif family == "contiguous_state_motif":
        for feature in positive:
            if not isinstance(feature, tuple) or not feature or feature[0] != "motif":
                continue
            states = tuple(int(value) for value in feature[2:])
            for index in range(max(0, len(body) - len(states) + 1)):
                if body[index : index + len(states)] == states:
                    covered.update(range(index, index + len(states)))
                    matched.add(feature)
    elif family == "gapped_state_motif":
        for feature in positive:
            if not isinstance(feature, tuple) or not feature or feature[0] != "gapped":
                continue
            gap = int(feature[1])
            states = tuple(int(value) for value in feature[3:])
            step = gap + 1
            span = (len(states) - 1) * step + 1
            for index in range(max(0, len(body) - span + 1)):
                indices = tuple(index + offset * step for offset in range(len(states)))
                if tuple(body[position] for position in indices) == states:
                    covered.update(indices)
                    matched.add(feature)
    else:
        raise ValueError("Unsupported structural detector family: {}.".format(family))

    return len(covered) / len(body), len(covered), matched


def assurance_metrics(
    labels: Sequence[int],
    predictions: Sequence[int],
    scores: Sequence[float],
    evidence_fractions: Sequence[float],
    evidence_token_counts: Sequence[int],
    evidence_features: Sequence[set[object]],
    conditions: Sequence[str] | None = None,
) -> dict:
    """Compute bounded concept assurance metrics for one held-out sample."""

    if not (
        len(labels)
        == len(predictions)
        == len(scores)
        == len(evidence_fractions)
        == len(evidence_token_counts)
        == len(evidence_features)
    ):
        raise ValueError("Assurance metric inputs must have equal lengths.")
    positive = [index for index, label in enumerate(labels) if int(label) == 1]
    negative = [index for index, label in enumerate(labels) if int(label) == 0]
    if conditions is not None and len(conditions) != len(labels):
        raise ValueError("conditions must align with labels.")
    contrast_negative = (
        [
            index
            for index in negative
            if str(conditions[index]) in CONTRAST_NEGATIVE_CONDITIONS
        ]
        if conditions is not None
        else negative
    )
    if not contrast_negative:
        raise ValueError("Assurance metrics require locked contrast examples.")
    if not positive or not negative:
        raise ValueError("Assurance metrics require positive and negative examples.")

    feature_counts: Counter[object] = Counter()
    for index in positive:
        feature_counts.update(evidence_features[index])
    effective_feature_count = _effective_count(feature_counts.values())
    positive_scores = [float(scores[index]) for index in positive]
    negative_scores = [float(scores[index]) for index in contrast_negative]
    positive_probabilities = [_logistic(value) for value in positive_scores]
    negative_probabilities = [_logistic(value) for value in negative_scores]

    return {
        "response_coverage": _mean(predictions[index] == 1 for index in positive),
        "evidence_response_coverage": _mean(
            evidence_token_counts[index] > 0 for index in positive
        ),
        "mean_evidence_path_fraction": _mean(
            evidence_fractions[index] for index in positive
        ),
        "mean_evidence_token_count": _mean(
            evidence_token_counts[index] for index in positive
        ),
        "effective_positive_feature_count": effective_feature_count,
        "contrastive_auc": _rank_auc(positive_scores, negative_scores),
        "contrastive_probability_margin": (
            _mean(positive_probabilities) - _mean(negative_probabilities)
        ),
        "contrast_negative_count": float(len(contrast_negative)),
    }


def bootstrap_assurance_metrics(
    labels: Sequence[int],
    predictions: Sequence[int],
    scores: Sequence[float],
    evidence_fractions: Sequence[float],
    evidence_token_counts: Sequence[int],
    evidence_features: Sequence[set[object]],
    pair_ids: Sequence[str],
    repetitions: int,
    seed: int,
    conditions: Sequence[str] | None = None,
) -> dict:
    """Bootstrap concept metrics with prompt families as resampling units."""

    if len(pair_ids) != len(labels):
        raise ValueError("pair_ids must align with labels.")
    families: dict[str, list[int]] = defaultdict(list)
    for index, pair_id in enumerate(pair_ids):
        families[str(pair_id)].append(index)
    family_ids = sorted(families)
    if not family_ids:
        raise ValueError("At least one prompt family is required.")

    rng = random.Random(seed)
    samples: dict[str, list[float]] = defaultdict(list)
    for _ in range(int(repetitions)):
        sampled_indices = [
            index
            for _draw in range(len(family_ids))
            for index in families[rng.choice(family_ids)]
        ]
        sampled_labels = [labels[index] for index in sampled_indices]
        if not any(sampled_labels) or all(sampled_labels):
            continue
        metrics = assurance_metrics(
            sampled_labels,
            [predictions[index] for index in sampled_indices],
            [scores[index] for index in sampled_indices],
            [evidence_fractions[index] for index in sampled_indices],
            [evidence_token_counts[index] for index in sampled_indices],
            [evidence_features[index] for index in sampled_indices],
            (
                [conditions[index] for index in sampled_indices]
                if conditions is not None
                else None
            ),
        )
        for name, value in metrics.items():
            samples[name].append(float(value))

    result = {
        "resampling_unit": "prompt_family",
        "repetitions": int(repetitions),
    }
    for name, values in samples.items():
        values.sort()
        result[name + "_lower_95"] = _percentile(values, 0.025)
        result[name + "_upper_95"] = _percentile(values, 0.975)
    return result


def bootstrap_binary_learning_metrics(
    labels: Sequence[int],
    predictions: Sequence[int],
    scores: Sequence[float],
    pair_ids: Sequence[str],
    repetitions: int,
    seed: int,
    conditions: Sequence[str] | None = None,
) -> dict:
    """Bootstrap the three held-out learning metrics by prompt family."""

    size = len(labels)
    if not (size == len(predictions) == len(scores) == len(pair_ids)):
        raise ValueError("Binary learning metric inputs must have equal lengths.")
    if conditions is not None and len(conditions) != size:
        raise ValueError("conditions must align with labels.")
    if int(repetitions) < 1:
        raise ValueError("Bootstrap repetitions must be positive.")

    families: dict[str, list[int]] = defaultdict(list)
    for index, pair_id in enumerate(pair_ids):
        families[str(pair_id)].append(index)
    family_ids = sorted(families)
    if not family_ids:
        raise ValueError("At least one prompt family is required.")
    family_index = {family_id: index for index, family_id in enumerate(family_ids)}
    row_family = [family_index[str(pair_id)] for pair_id in pair_ids]

    confusion_by_family = [[0, 0, 0, 0] for _ in family_ids]
    for index, (label, prediction) in enumerate(
        zip(labels, predictions, strict=True)
    ):
        counts = confusion_by_family[row_family[index]]
        if int(label) == 1 and int(prediction) == 1:
            counts[0] += 1
        elif int(label) == 0 and int(prediction) == 0:
            counts[1] += 1
        elif int(label) == 0 and int(prediction) == 1:
            counts[2] += 1
        else:
            counts[3] += 1

    contrast_negative = [
        int(label) == 0
        and (
            conditions is None
            or str(conditions[index]) in CONTRAST_NEGATIVE_CONDITIONS
        )
        for index, label in enumerate(labels)
    ]
    score_rows = sorted(
        (
            float(scores[index]),
            row_family[index],
            int(labels[index]) == 1,
            contrast_negative[index],
        )
        for index in range(size)
        if int(labels[index]) == 1 or contrast_negative[index]
    )

    rng = random.Random(int(seed))
    family_range = range(len(family_ids))
    mcc_samples = []
    sensitivity_samples = []
    auc_samples = []
    for _ in range(int(repetitions)):
        multiplicities = [0] * len(family_ids)
        for family in rng.choices(family_range, k=len(family_ids)):
            multiplicities[family] += 1

        tp = tn = fp = fn = 0
        for family, multiplier in enumerate(multiplicities):
            if multiplier:
                counts = confusion_by_family[family]
                tp += multiplier * counts[0]
                tn += multiplier * counts[1]
                fp += multiplier * counts[2]
                fn += multiplier * counts[3]
        if tp + fn == 0 or tn + fp == 0:
            continue

        mcc_samples.append(_mcc_from_counts(tp, tn, fp, fn))
        sensitivity_samples.append(tp / (tp + fn))

        positive_total = sum(
            multiplicities[family]
            for _, family, positive, _ in score_rows
            if positive
        )
        negative_total = sum(
            multiplicities[family]
            for _, family, _, negative in score_rows
            if negative
        )
        if positive_total == 0 or negative_total == 0:
            continue
        wins = 0.0
        lower_negative = 0
        cursor = 0
        while cursor < len(score_rows):
            score = score_rows[cursor][0]
            group_positive = 0
            group_negative = 0
            while cursor < len(score_rows) and score_rows[cursor][0] == score:
                _, family, positive, negative = score_rows[cursor]
                multiplier = multiplicities[family]
                if positive:
                    group_positive += multiplier
                if negative:
                    group_negative += multiplier
                cursor += 1
            wins += group_positive * (lower_negative + 0.5 * group_negative)
            lower_negative += group_negative
        auc_samples.append(wins / (positive_total * negative_total))

    result = {
        "resampling_unit": "prompt_family",
        "repetitions": int(repetitions),
        "effective_repetitions": len(mcc_samples),
        "seed": int(seed),
        "shared_resample_plan_id": _resample_plan_id(
            family_ids, int(repetitions), int(seed)
        ),
    }
    for name, values in (
        ("held_out_mcc", mcc_samples),
        ("positive_sensitivity", sensitivity_samples),
        ("contrastive_auc", auc_samples),
    ):
        values.sort()
        result[name + "_lower_95"] = _percentile(values, 0.025)
        result[name + "_upper_95"] = _percentile(values, 0.975)
    return result


def aggregate_binary_learning(
    rows: Sequence[dict],
    protocol: dict,
) -> dict:
    """Apply the model-neutral noncompensatory learning decision per concept."""

    settings = protocol.get("binary_concept_learning", {})
    primary_policy = str(protocol["primary_policy_id"])
    minimum_reconstructions = int(settings.get("minimum_reconstruction_count", 3))
    thresholds = _learning_thresholds(settings, "thresholds")
    strict_thresholds = _learning_thresholds(settings, "strict_thresholds")
    lenient_thresholds = _learning_thresholds(settings, "lenient_thresholds")
    model_groups = _resolve_model_groups(rows, settings)

    outcomes = []
    for model_name, model_seed_labels in model_groups.items():
        model_rows = [
            row
            for row in rows
            if str(row["policy_id"]) == primary_policy
            and str(row["model_seed"]) in model_seed_labels
        ]
        concept_ids = sorted({str(row["concept_id"]) for row in model_rows})
        for concept_id in concept_ids:
            group = [
                row for row in model_rows if str(row["concept_id"]) == concept_id
            ]
            learning = [row.get("binary_concept_learning", {}) for row in group]
            seed_count = len(group)
            complete = all(bool(item.get("evaluated")) for item in learning)
            values = _aggregate_learning_values(learning) if learning else {}
            nominal = _threshold_decisions(values, thresholds)
            strict = _threshold_decisions(values, strict_thresholds)
            lenient = _threshold_decisions(values, lenient_thresholds)

            representations = [
                str(item.get("representation_class", "unavailable"))
                for item in learning
            ]
            representation_counts = Counter(representations)
            modal_representation, modal_count = representation_counts.most_common(1)[0]
            representation_agreement = modal_count / len(representations)
            prediction_sets = [
                set(item.get("selected_positive_prompt_ids", [])) for item in learning
            ]
            test_counts = {int(item.get("test_count", 0)) for item in learning}
            jaccards = []
            kappas = []
            for index, left in enumerate(prediction_sets):
                for right in prediction_sets[index + 1 :]:
                    union = left | right
                    jaccards.append(len(left & right) / len(union) if union else 0.0)
                    if len(test_counts) == 1:
                        kappas.append(
                            _binary_prediction_kappa(left, right, next(iter(test_counts)))
                        )
            values["seed_prediction_jaccard"] = _mean(jaccards)
            for decisions, limits in (
                (nominal, thresholds),
                (strict, strict_thresholds),
                (lenient, lenient_thresholds),
            ):
                decisions["seed_prediction_jaccard"] = (
                    values["seed_prediction_jaccard"]
                    >= limits["seed_prediction_jaccard"]
                )

            sufficient = seed_count >= minimum_reconstructions and complete
            learned = sufficient and all(nominal.values())
            if not sufficient:
                status = "insufficient_replicates"
            elif all(strict.values()):
                status = "robust"
            elif learned:
                status = "nominal"
            elif all(lenient.values()):
                status = "borderline"
            else:
                status = "failed"
            outcomes.append(
                {
                    "concept_id": concept_id,
                    "model": model_name,
                    "policy_id": primary_policy,
                    "decision": "learned" if learned else "not_learned",
                    "robustness_status": status,
                    "reconstruction_count": seed_count,
                    "criterion_values": values,
                    "criterion_thresholds": thresholds,
                    "criterion_decisions": nominal,
                    "strict_criterion_decisions": strict,
                    "lenient_criterion_decisions": lenient,
                    "failed_criteria": sorted(
                        name for name, passed in nominal.items() if not passed
                    ),
                    "representation_class": modal_representation,
                    "representation_agreement": representation_agreement,
                    "representation_agreement_role": "diagnostic_only",
                    "seed_prediction_kappa": _mean(kappas),
                    "seed_prediction_kappa_role": "diagnostic_only",
                }
            )

    model_summaries = []
    for model_name in model_groups:
        model_outcomes = [row for row in outcomes if row["model"] == model_name]
        evaluated = [
            row
            for row in model_outcomes
            if row["robustness_status"] != "insufficient_replicates"
        ]
        learned = [row for row in evaluated if row["decision"] == "learned"]
        model_summaries.append(
            {
                "model": model_name,
                "concept_count": len(model_outcomes),
                "evaluated_concept_count": len(evaluated),
                "learned_concept_count": len(learned),
                "learned_concept_fraction": (
                    len(learned) / len(evaluated) if evaluated else 0.0
                ),
                "robust_count": sum(
                    row["robustness_status"] == "robust" for row in evaluated
                ),
                "nominal_count": sum(
                    row["robustness_status"] == "nominal" for row in evaluated
                ),
                "borderline_count": sum(
                    row["robustness_status"] == "borderline" for row in evaluated
                ),
                "failed_count": sum(
                    row["robustness_status"] == "failed" for row in evaluated
                ),
            }
        )
    operational = bool(outcomes) and all(
        row["robustness_status"] != "insufficient_replicates" for row in outcomes
    )
    return {
        "method_decision": "operational" if operational else "not_operational",
        "primary_policy_id": primary_policy,
        "criteria": list(BINARY_LEARNING_CRITERIA),
        "criterion_count": len(BINARY_LEARNING_CRITERIA),
        "representation_agreement_is_gate": False,
        "model_summaries": model_summaries,
        "outcomes": outcomes,
        "decision_rule": "all six nominal criteria must pass",
    }


def aggregate_concept_assurance(
    rows: Sequence[dict],
    protocol: dict,
) -> dict:
    """Create non-compensatory decisions for every primary-model concept."""

    settings = protocol.get("conditional_concept_assurance", {})
    primary_policy = str(protocol["primary_policy_id"])
    primary_model_prefix = str(settings.get("primary_model_prefix", "3B"))
    minimum_seed_count = int(settings.get("minimum_seed_count", 3))
    minimum_jaccard = float(
        settings.get("minimum_seed_prediction_jaccard", 0.60)
    )
    minimum_representation_agreement = float(
        settings.get("minimum_representation_agreement", 2.0 / 3.0)
    )

    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        model_prefix = str(row["model_seed"]).split("_seed", 1)[0]
        if row["policy_id"] != primary_policy or model_prefix != primary_model_prefix:
            continue
        grouped[str(row["concept_id"])].append(row)

    outcomes = []
    for concept_id, group in sorted(grouped.items()):
        assurances = [row.get("conditional_concept_assurance", {}) for row in group]
        seed_count = len(group)
        eligible = all(bool(item.get("eligible")) for item in assurances)
        representations = [
            str(item.get("representation_kind", "not_identifiable"))
            for item in assurances
        ]
        representation_counts = Counter(representations)
        modal_representation, modal_count = representation_counts.most_common(1)[0]
        representation_agreement = modal_count / len(representations)
        prediction_sets = [
            set(item.get("selected_positive_prompt_ids", [])) for item in assurances
        ]
        jaccards = []
        for index, left in enumerate(prediction_sets):
            for right in prediction_sets[index + 1 :]:
                union = left | right
                jaccards.append(len(left & right) / len(union) if union else 0.0)
        seed_jaccard = _mean(jaccards)

        gate_names = sorted(
            {
                name
                for item in assurances
                for name in item.get("gate_decisions", {})
            }
        )
        gate_decisions = {
            name: all(
                item.get("gate_decisions", {}).get(name) is True
                for item in assurances
            )
            for name in gate_names
        }
        gates_pass = bool(gate_decisions) and all(gate_decisions.values())
        gate_minimum_values = {}
        gate_thresholds = {}
        for name in gate_names:
            observed = [item.get("gate_values", {}).get(name) for item in assurances]
            thresholds = [
                item.get("gate_thresholds", {}).get(name) for item in assurances
            ]
            gate_minimum_values[name] = (
                min(float(value) for value in observed)
                if all(value is not None for value in observed)
                else None
            )
            gate_thresholds[name] = (
                max(float(value) for value in thresholds)
                if all(value is not None for value in thresholds)
                else None
            )

        if seed_count < minimum_seed_count:
            decision = "insufficient_replicates"
        elif not eligible:
            decision = "not_identifiable"
        elif (
            gates_pass
            and seed_jaccard >= minimum_jaccard
            and representation_agreement >= minimum_representation_agreement
        ):
            decision = "assured"
        else:
            decision = "not_assured"

        outcomes.append(
            {
                "concept_id": concept_id,
                "model": primary_model_prefix,
                "policy_id": primary_policy,
                "decision": decision,
                "seed_count": seed_count,
                "eligible_for_rq3": eligible,
                "representation_kind": modal_representation,
                "representation_agreement": representation_agreement,
                "seed_prediction_jaccard": seed_jaccard,
                "gate_decisions": gate_decisions,
                "gate_minimum_values": gate_minimum_values,
                "gate_thresholds": gate_thresholds,
                "failed_gates": sorted(
                    name for name, passed in gate_decisions.items() if not passed
                ),
            }
        )

    evaluated = [
        row for row in outcomes if row["decision"] in {"assured", "not_assured"}
    ]
    assured = [row for row in outcomes if row["decision"] == "assured"]
    method_operational = bool(outcomes) and len(evaluated) == len(outcomes)
    return {
        "method_decision": "operational" if method_operational else "not_operational",
        "primary_model": primary_model_prefix,
        "primary_policy_id": primary_policy,
        "concept_count": len(outcomes),
        "evaluated_concept_count": len(evaluated),
        "assured_concept_count": len(assured),
        "assured_concept_fraction": (
            len(assured) / len(evaluated) if evaluated else 0.0
        ),
        "outcomes": outcomes,
        "decision_rule": "all per-seed gates and both stability gates must pass",
    }


def _development_best(rows: Sequence[dict]) -> dict:
    return max(
        rows,
        key=lambda row: (
            _development_mcc(row),
            float(row.get("development_balanced_accuracy", 0.0)),
            -int(row.get("feature_count", 0)),
            str(row.get("family", "")),
        ),
    )


def _development_mcc(row: dict) -> float:
    return float(row.get("development_mcc", row.get("mcc", 0.0)))


def _rank_auc(positive_scores: Sequence[float], negative_scores: Sequence[float]) -> float:
    ordered_negative = sorted(float(value) for value in negative_scores)
    wins = 0.0
    for score in positive_scores:
        left = bisect.bisect_left(ordered_negative, float(score))
        right = bisect.bisect_right(ordered_negative, float(score))
        wins += left + 0.5 * (right - left)
    return wins / (len(positive_scores) * len(negative_scores))


def _mcc_from_counts(tp: int, tn: int, fp: int, fn: int) -> float:
    denominator = math.sqrt(
        (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    )
    return ((tp * tn - fp * fn) / denominator) if denominator else 0.0


def _resample_plan_id(
    family_ids: Sequence[str], repetitions: int, seed: int
) -> str:
    material = "{}|{}|{}".format(seed, repetitions, "\n".join(family_ids))
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def _resolve_model_groups(rows: Sequence[dict], settings: dict) -> dict[str, set[str]]:
    configured = settings.get("model_groups")
    if configured is not None:
        if not isinstance(configured, dict) or not configured:
            raise ValueError("binary_concept_learning.model_groups must be a mapping.")
        groups = {
            str(name): {str(label) for label in labels}
            for name, labels in configured.items()
        }
    else:
        inferred: dict[str, set[str]] = defaultdict(set)
        for row in rows:
            label = str(row["model_seed"])
            inferred[label.split("_seed", 1)[0]].add(label)
        groups = dict(inferred)
    flattened = [label for labels in groups.values() for label in labels]
    if len(flattened) != len(set(flattened)):
        raise ValueError("Model-group reconstruction labels must be disjoint.")
    return groups


def _learning_thresholds(settings: dict, name: str) -> dict[str, float]:
    raw = settings.get(name)
    if not isinstance(raw, dict):
        raise ValueError("binary_concept_learning.{} must be a mapping.".format(name))
    missing = set(BINARY_LEARNING_CRITERIA) - set(raw)
    if missing:
        raise ValueError(
            "Binary learning thresholds lack criteria: {}.".format(
                ", ".join(sorted(missing))
            )
        )
    return {criterion: float(raw[criterion]) for criterion in BINARY_LEARNING_CRITERIA}


def _aggregate_learning_values(learning: Sequence[dict]) -> dict[str, float]:
    development = [float(item["development_mcc"]) for item in learning]
    bootstrap = [item["bootstrap"] for item in learning]
    return {
        "mean_development_mcc": _mean(development),
        "minimum_development_mcc": min(development),
        "minimum_test_mcc_lower_95": min(
            float(item["held_out_mcc_lower_95"]) for item in bootstrap
        ),
        "minimum_positive_sensitivity_lower_95": min(
            float(item["positive_sensitivity_lower_95"]) for item in bootstrap
        ),
        "minimum_contrastive_auc_lower_95": min(
            float(item["contrastive_auc_lower_95"]) for item in bootstrap
        ),
    }


def _threshold_decisions(
    values: dict[str, float], thresholds: dict[str, float]
) -> dict[str, bool]:
    return {
        name: name in values and float(values[name]) >= threshold
        for name, threshold in thresholds.items()
        if name != "seed_prediction_jaccard"
    }


def _binary_prediction_kappa(
    left: set[str], right: set[str], total_count: int
) -> float:
    if total_count <= 0 or len(left | right) > total_count:
        return 0.0
    both_positive = len(left & right)
    both_negative = total_count - len(left | right)
    observed = (both_positive + both_negative) / total_count
    left_rate = len(left) / total_count
    right_rate = len(right) / total_count
    expected = left_rate * right_rate + (1.0 - left_rate) * (1.0 - right_rate)
    return (observed - expected) / (1.0 - expected) if expected < 1.0 else 0.0


def _effective_count(values: Sequence[int]) -> float:
    total = float(sum(values))
    if total <= 0.0:
        return 0.0
    entropy = -sum(
        (float(value) / total) * math.log(float(value) / total)
        for value in values
        if value > 0
    )
    return math.exp(entropy)


def _logistic(value: float) -> float:
    bounded = max(-40.0, min(40.0, float(value)))
    return 1.0 / (1.0 + math.exp(-bounded))


def _mean(values: Sequence[float]) -> float:
    materialized = [float(value) for value in values]
    return sum(materialized) / len(materialized) if materialized else 0.0


def _percentile(values: Sequence[float], fraction: float) -> float:
    if not values:
        return 0.0
    position = max(0.0, min(1.0, fraction)) * (len(values) - 1)
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return float(values[lower])
    weight = position - lower
    return float(values[lower]) * (1.0 - weight) + float(values[upper]) * weight
