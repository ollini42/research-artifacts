"""Audited, model-neutral concept-learning assurance (E-05).

E-05 keeps four questions separate.  It first checks whether the locked design
can support a positive decision.  It then validates the complete planned
model-concept matrix.  Held-out behavioral evidence and controlled semantic
stress tests are evaluated independently.  Finally, the result schema reports
technical, statistical, construct-validity, and model-outcome status without
using technical operability as evidence that a concept was learned.

Explicit r2 adds development eligibility, shuffle-only order inference, and
source-family AUC dependencies. It retains the thresholds, interval method,
and conservative error allocation. Historical calls default to r1.
"""

from __future__ import annotations

import itertools
import math
from collections import defaultdict
from collections.abc import Iterable, Mapping, Sequence
from statistics import mean
from .concept_presence_evaluation import reject_presence_in_legacy

from .simultaneous_assurance import (
    L1_THRESHOLDS,
    L2_THRESHOLDS,
    L3_THRESHOLDS,
    ORDERED_PATH_FAMILIES,
    decide_level,
    nested_decision,
    subtract_intervals,
)

EVALUATOR_VERSION = "E-05"
EVALUATOR_IMPLEMENTATION_REVISION = "E-05-r1"
EVALUATOR_IMPLEMENTATION_REVISION_R2 = "E-05-r2"
SUPPORTED_EVALUATOR_IMPLEMENTATION_REVISIONS = frozenset({
    EVALUATOR_IMPLEMENTATION_REVISION, EVALUATOR_IMPLEMENTATION_REVISION_R2
})
RETROSPECTIVE_EVIDENCE_ROLE = "retrospective_reanalysis"
REQUIRED_BASE_ROLES = {
    "selected_rule",
    "individual_state_rule",
    "path_rule",
    "visible_text_rule",
}
REQUIRED_ORDER_ROLES = {
    "order_shuffled_refit_rule",
    "order_reversed_refit_rule",
}
REQUIRED_ORDER_ROLES_R2 = {"order_shuffled_refit_rule"}
REQUIRED_CONTROL_TYPES = {
    "known_correct",
    "systematically_wrong",
    "prompt_echo",
    "template_only",
}


def retrospective_input_audit(
    catalog_rows: Sequence[Mapping[str, object]],
    prompt_rows: Sequence[Mapping[str, object]],
    settings: Mapping[str, object],
) -> dict:
    """Record absent contracts without deriving labels or independent units."""
    reject_presence_in_legacy(catalog_rows, prompt_rows, settings)
    catalog = {str(row["concept_id"]): row for row in catalog_rows}
    reports = []
    for concept_id in sorted(settings["concept_error_budgets"]):
        semantics = catalog.get(concept_id, {})
        prompts = [row for row in prompt_rows if str(row.get("concept_id")) == concept_id]
        reasons = []
        if any(not str(semantics.get(key) or "").strip() for key in (
            "canonical_statement", "logical_negation"
        )):
            reasons.append("missing_semantic_metadata")
        if not prompts:
            reasons.append("missing_prompt_metadata")
        invalid_index = False
        for row in prompts:
            try:
                invalid_index |= int(row.get("condition_index") or 0) <= 0
            except (TypeError, ValueError):
                invalid_index = True
        if invalid_index:
            reasons.append("missing_or_invalid_condition_index")
        if any(not str(row.get("pair_id") or "").strip() for row in prompts):
            reasons.append("unverified_prompt_family_metadata")
        reports.append({
            "concept_id": concept_id,
            "status": "not_identifiable" if reasons else "available",
            "reasons": reasons,
            "base_question_index_available": any(
                row.get("base_question_index") not in (None, "") for row in prompts
            ),
            "base_question_index_used_as_condition_index": False,
            "independent_units_inferred": False,
        })
    return {
        "evidence_role": RETROSPECTIVE_EVIDENCE_ROLE,
        "status": "not_identifiable" if any(row["reasons"] for row in reports) else "available",
        "concept_reports": reports,
        "insufficient_model_groups": [
            name for name, labels in settings["model_groups"].items()
            if len(labels) < max(3, int(settings.get("minimum_reconstruction_count", 3)))
        ],
        "independent_confirmatory_evidence": False,
    }


def observation_rows(
    examples: Sequence[object],
    role: str,
    family: str,
    predictions: Sequence[int],
    scores: Sequence[float],
) -> list[dict]:
    """Create response-level rows with locked family and provenance metadata."""

    reject_presence_in_legacy(examples)
    if not (len(examples) == len(predictions) == len(scores)):
        raise ValueError("Examples, predictions, and scores must have equal lengths.")
    rows = []
    for item, prediction, score in zip(
        examples, predictions, scores, strict=True
    ):
        rows.append(
            {
                "role": str(role),
                "detector_family": str(family),
                "prompt_id": str(item.prompt_id),
                "family_id": str(item.pair_id or item.prompt_id),
                "condition_index": int(getattr(item, "condition_index", 0)),
                "base_question_index": getattr(item, "base_question_index", None),
                "condition": str(item.condition),
                "label": int(item.label),
                "score": float(score),
                "prediction": int(prediction),
            }
        )
    return rows


def semantic_control_rows(
    examples: Sequence[object],
    family: str,
    predictions: Sequence[int],
    scores: Sequence[float],
) -> list[dict]:
    """Create rows for preregistered correct, wrong, echo, and template controls."""

    rows = observation_rows(
        examples, "semantic_control", family, predictions, scores
    )
    for row, item in zip(rows, examples, strict=True):
        row["control_type"] = str(item.condition)
    return rows


def aggregate_audited_learning(rows: Sequence[dict], protocol: dict) -> dict:
    """Evaluate the complete configured model-concept matrix under E-05."""

    reject_presence_in_legacy(rows, protocol)
    settings = protocol.get("simultaneous_nested_learning", {})
    if not settings.get("enabled", False):
        return {}
    if str(settings.get("version")) != EVALUATOR_VERSION:
        raise ValueError("aggregate_audited_learning requires E-05 settings.")

    implementation_revision = str(protocol.get("method_versions", {}).get(
        "evaluator_implementation_revision", EVALUATOR_IMPLEMENTATION_REVISION
    ))
    concept_budgets = {
        str(name): float(value)
        for name, value in settings["concept_error_budgets"].items()
    }
    model_groups = {
        str(name): tuple(str(label) for label in labels)
        for name, labels in settings["model_groups"].items()
    }
    primary_policy = str(protocol["primary_policy_id"])
    model_count = len(model_groups)
    outcomes = []
    criterion_rows = []
    sample_audits = []

    scoped_rows = [
        row for row in rows if str(row.get("policy_id")) == primary_policy
    ]
    allowed_concepts = set(concept_budgets)
    allowed_reconstructions = {
        label for labels in model_groups.values() for label in labels
    }
    unexpected = [
        row
        for row in scoped_rows
        if str(row.get("concept_id")) not in allowed_concepts
        or str(row.get("model_seed")) not in allowed_reconstructions
    ]
    if unexpected:
        raise ValueError("Detector results contain unregistered E-05 matrix cells.")

    for concept_id in sorted(concept_budgets):
        for model_name, labels in model_groups.items():
            group = [
                row
                for row in scoped_rows
                if str(row.get("concept_id")) == concept_id
                and str(row.get("model_seed")) in labels
            ]
            outcome, criteria, audit = evaluate_concept_group(
                concept_id=concept_id,
                model_name=model_name,
                policy_id=primary_policy,
                rows=group,
                error_budget=concept_budgets[concept_id] / model_count,
                expected_reconstruction_ids=labels,
                contrast_families=settings["contrast_families"],
                thresholds=settings.get("thresholds", {}),
                strict_l1_thresholds=settings.get("strict_l1_thresholds", {}),
                construct_thresholds=settings["construct_validity"]["thresholds"],
                minimum_reconstruction_count=max(
                    3, int(settings.get("minimum_reconstruction_count", 3))
                ),
                evidence_role=str(settings.get("evidence_role", "independent_confirmatory_evaluation")),
                evaluator_implementation_revision=implementation_revision,
            )
            outcomes.append(outcome)
            criterion_rows.extend(criteria)
            sample_audits.append(audit)

    identifiable = [
        row for row in outcomes if row["l1_decision"] != "not_identifiable"
    ]
    construct_passed = [
        row for row in identifiable if row["construct_validity_status"] == "passed"
    ]
    supported = [row for row in identifiable if row["l1_decision"] == "supported"]
    return {
        "evaluator_version": EVALUATOR_VERSION,
        "evaluator_implementation_revision": implementation_revision,
        "evidence_role": str(
            settings.get("evidence_role", "independent_confirmatory_evaluation")
        ),
        "technical_operability": {
            "status": "complete" if outcomes else "incomplete",
            "expected_model_concept_pair_count": len(concept_budgets) * model_count,
            "observed_model_concept_pair_count": len(outcomes),
        },
        "statistical_assumptions": {
            "status": (
                "retrospective_no_confirmatory_error_guarantee"
                if settings.get("evidence_role") == RETROSPECTIVE_EVIDENCE_ROLE
                else
                "verified_for_all_identifiable_cells"
                if len(identifiable) == len(outcomes)
                else "not_verified_for_all_cells"
            ),
            "independent_sampling_unit": "locked_prompt_family",
            "missing_cells_reallocate_error_budget": False,
        },
        "empirical_construct_validity": {
            "status": (
                "passed_for_all_identifiable_cells"
                if identifiable and len(construct_passed) == len(identifiable)
                else "not_passed_for_all_identifiable_cells"
            ),
            "required_control_types": sorted(REQUIRED_CONTROL_TYPES),
        },
        "model_concept_outcomes": {
            "unique_concept_count": len(concept_budgets),
            "model_group_count": model_count,
            "model_concept_pair_count": len(outcomes),
            "identifiable_pair_count": len(identifiable),
            "supported_pair_count": len(supported),
        },
        "method_decision": (
            "applicable_to_complete_matrix"
            if outcomes and len(identifiable) == len(outcomes)
            else "not_applicable_to_complete_matrix"
        ),
        "scientific_rq3_decision": (
            "supported_for_all_model_concept_pairs"
            if outcomes and len(supported) == len(outcomes)
            else "not_supported_for_all_model_concept_pairs"
        ),
        "primary_policy_id": primary_policy,
        "total_error_budget": float(settings["total_error_budget"]),
        "allocated_error_budget": sum(concept_budgets.values()),
        "interval_method": str(settings["interval_method"]),
        "auc_aggregation": (
            "equal_weight_over_source_family_and_response_dependency_clusters_with_per_contrast_coverage"
            if implementation_revision == EVALUATOR_IMPLEMENTATION_REVISION_R2
            else "equal_weight_over_response_dependency_clusters_with_per_contrast_coverage"
        ),
        "outcomes": outcomes,
        "criteria": criterion_rows,
        "sample_size_audit": sample_audits,
        "evaluated_concept_count": len({row["concept_id"] for row in identifiable}),
        "evaluated_model_concept_pair_count": len(identifiable),
        "supported_concept_count": len({row["concept_id"] for row in supported}),
        "supported_model_concept_pair_count": len(supported),
        "decision_rule": (
            "development eligibility precedes test inference. Behavioral support "
            "requires every simultaneous lower bound to reach its threshold. "
            "Semantic support also requires every preregistered control gate."
        ),
        "claim_boundary": (
            "controlled black-box semantic behavior represented by audited "
            "automaton-derived traces, not internal neural state identity"
        ),
    }


def evaluate_concept_group(
    *,
    concept_id: str,
    model_name: str,
    policy_id: str,
    rows: Sequence[dict],
    error_budget: float,
    expected_reconstruction_ids: Sequence[str],
    contrast_families: Mapping[str, Mapping[str, object]],
    thresholds: Mapping[str, object],
    strict_l1_thresholds: Mapping[str, object],
    construct_thresholds: Mapping[str, object],
    minimum_reconstruction_count: int = 3,
    evidence_role: str = "independent_confirmatory_evaluation",
    evaluator_implementation_revision: str = EVALUATOR_IMPLEMENTATION_REVISION,
) -> tuple[dict, list[dict], dict]:
    """Evaluate one preregistered model-concept cell."""

    reject_presence_in_legacy(
        rows, {"evaluator_implementation_revision": evaluator_implementation_revision}
    )
    base = {
        "concept_id": concept_id,
        "model": model_name,
        "policy_id": policy_id,
        "evaluator_version": EVALUATOR_VERSION,
        "evaluator_implementation_revision": evaluator_implementation_revision,
        "reconstruction_count": len(rows),
        "error_budget": float(error_budget),
        "evidence_role": evidence_role,
        "minimum_reconstruction_count": max(3, minimum_reconstruction_count),
    }
    evidence = [row.get("simultaneous_nested_learning", {}) for row in rows]
    reason = None
    if evaluator_implementation_revision == EVALUATOR_IMPLEMENTATION_REVISION_R2:
        reason = _development_eligibility_reason(
            evidence, _thresholds(L1_THRESHOLDS, thresholds.get("l1", {}))
        )
    if reason is None:
        reason = _identifiability_reason(
            rows,
            evidence,
            expected_reconstruction_ids,
            contrast_families,
            minimum_reconstruction_count=max(3, minimum_reconstruction_count),
            evidence_role=evidence_role,
            evaluator_implementation_revision=evaluator_implementation_revision,
        )
    if reason:
        outcome = {
            **base,
            "l1_decision": "not_identifiable",
            "l2_decision": "not_identifiable",
            "l3_decision": "not_identifiable",
            "highest_supported_level": None,
            "LEARNED": "?",
            "strict_l1_robustness": False,
            "construct_validity_status": "not_identifiable",
            "not_identifiable_reason": reason,
        }
        return outcome, [], {
            **base,
            "identifiable": False,
            "reason": reason,
            "primitive_bound_count": 0,
        }

    ordered_required = any(
        str(item["development_selection"]["path_family"])
        in ORDERED_PATH_FAMILIES
        for item in evidence
    )
    primitive_count = len(evidence) * 18 + len(evidence) * (len(evidence) - 1) // 2
    alpha = float(error_budget) / primitive_count
    l1_limits = _thresholds(L1_THRESHOLDS, thresholds.get("l1", {}))
    l2_limits = _thresholds(L2_THRESHOLDS, thresholds.get("l2", {}))
    l3_limits = _thresholds(L3_THRESHOLDS, thresholds.get("l3", {}))
    strict_limits = _thresholds(L1_THRESHOLDS, strict_l1_thresholds)

    per_reconstruction = []
    construct_rows = []
    for row, item in zip(rows, evidence, strict=True):
        by_role = _by_role(item["observations"])
        selected = metric_intervals(
            by_role["selected_rule"], alpha, contrast_families,
            evaluator_implementation_revision=evaluator_implementation_revision,
        )
        individual = metric_intervals(
            by_role["individual_state_rule"], alpha, contrast_families,
            evaluator_implementation_revision=evaluator_implementation_revision,
        )
        path = metric_intervals(
            by_role["path_rule"], alpha, contrast_families,
            evaluator_implementation_revision=evaluator_implementation_revision,
        )
        visible = metric_intervals(
            by_role["visible_text_rule"], alpha, contrast_families,
            evaluator_implementation_revision=evaluator_implementation_revision,
        )
        selection = item["development_selection"]
        record = {
            "reconstruction": str(row["model_seed"]),
            "development_mcc": float(selection["selected_development_mcc"]),
            "selected": selected,
            "path_gain": subtract_intervals(path["mcc"], individual["mcc"]),
            "visible_text_margin": subtract_intervals(path["mcc"], visible["mcc"]),
            "path_family": str(selection["path_family"]),
        }
        if record["path_family"] in ORDERED_PATH_FAMILIES:
            shuffled = metric_intervals(
                by_role["order_shuffled_refit_rule"], alpha, contrast_families,
                evaluator_implementation_revision=evaluator_implementation_revision,
            )
            if evaluator_implementation_revision == EVALUATOR_IMPLEMENTATION_REVISION_R2:
                # Reversal is an invertible diagnostic, not an inferential gate.
                control = shuffled["mcc"]
            else:
                reversed_rule = metric_intervals(
                    by_role["order_reversed_refit_rule"], alpha, contrast_families,
                    evaluator_implementation_revision=evaluator_implementation_revision,
                )
                control = {
                    "lower": max(shuffled["mcc"]["lower"], reversed_rule["mcc"]["lower"]),
                    "upper": max(shuffled["mcc"]["upper"], reversed_rule["mcc"]["upper"]),
                    "estimate": max(
                        shuffled["mcc"]["estimate"], reversed_rule["mcc"]["estimate"]
                    ),
                }
            record["order_gain"] = subtract_intervals(path["mcc"], control)
        control = construct_validity_summary(
            by_role["semantic_control"], construct_thresholds
        )
        construct_rows.append(control)
        per_reconstruction.append(record)

    jaccard_intervals = [
        prediction_jaccard_interval(
            _by_role(left["observations"])["selected_rule"],
            _by_role(right["observations"])["selected_rule"],
            alpha,
        )
        for left, right in itertools.combinations(evidence, 2)
    ]
    # Preserve r1 arithmetic and avoid rounding an exact r2 eligibility boundary down.
    development_mean = (
        mean
        if evaluator_implementation_revision == EVALUATOR_IMPLEMENTATION_REVISION_R2
        else _mean
    )
    l1 = {
        "mean_development_mcc": _point_interval(
            development_mean(
                item["development_mcc"] for item in per_reconstruction
            )
        ),
        "minimum_development_mcc": _point_interval(
            min(item["development_mcc"] for item in per_reconstruction)
        ),
        "minimum_test_mcc": _minimum_interval(
            item["selected"]["mcc"] for item in per_reconstruction
        ),
        "minimum_positive_sensitivity": _minimum_interval(
            item["selected"]["sensitivity"] for item in per_reconstruction
        ),
        "minimum_family_balanced_auc": _minimum_interval(
            item["selected"]["family_balanced_auc"] for item in per_reconstruction
        ),
        "minimum_prediction_jaccard": _minimum_interval(jaccard_intervals),
    }
    l2 = {
        "minimum_path_gain": _minimum_interval(
            item["path_gain"] for item in per_reconstruction
        )
    }
    order_gains = [
        item["order_gain"] for item in per_reconstruction if "order_gain" in item
    ]
    if order_gains:
        l2["minimum_order_gain"] = _minimum_interval(order_gains)
    l3 = {
        "minimum_visible_text_margin": _minimum_interval(
            item["visible_text_margin"] for item in per_reconstruction
        )
    }

    behavioral_l1 = decide_level(l1, l1_limits)
    construct_status = (
        "passed" if all(row["passed"] for row in construct_rows) else "failed"
    )
    l1_decision = (
        "not_supported" if construct_status == "failed" else behavioral_l1
    )
    l2_decision = nested_decision(
        l1_decision,
        decide_level(l2, {name: l2_limits[name] for name in l2}),
    )
    l3_decision = nested_decision(l2_decision, decide_level(l3, l3_limits))
    highest = _highest_supported_level(l1_decision, l2_decision, l3_decision)
    strict_pass = all(l1[name]["lower"] >= strict_limits[name] for name in l1)
    criteria = _criterion_rows(base, "L1", l1, l1_limits)
    criteria += _criterion_rows(
        base, "L2", l2, {name: l2_limits[name] for name in l2}
    )
    criteria += _criterion_rows(base, "L3", l3, l3_limits)
    criteria.extend(
        {
            **base,
            "level": "construct_validity",
            "criterion": name,
            "estimate": min(float(row[name]) for row in construct_rows),
            "lower": None,
            "upper": None,
            "threshold": float(construct_thresholds[name]),
            "decision": (
                "supported"
                if min(float(row[name]) for row in construct_rows)
                >= float(construct_thresholds[name])
                else "not_supported"
            ),
        }
        for name in construct_thresholds
    )
    outcome = {
        **base,
        "behavioral_l1_decision": behavioral_l1,
        "l1_decision": l1_decision,
        "l2_decision": l2_decision,
        "l3_decision": l3_decision,
        "highest_supported_level": highest,
        "LEARNED": {"supported": 1, "not_supported": 0}.get(l1_decision, "?"),
        "strict_l1_robustness": strict_pass,
        "construct_validity_status": construct_status,
        "construct_validity": construct_rows,
        "ordered_path_evidence_required": ordered_required,
        "not_identifiable_reason": None,
    }
    coverage = [
        item["selected"]["contrast_coverage"] for item in per_reconstruction
    ]
    audit = {
        **base,
        "identifiable": True,
        "primitive_bound_count": primitive_count,
        "alpha_per_primitive_bound": alpha,
        "minimum_prompt_family_count": min(
            item["selected"]["family_count"] for item in per_reconstruction
        ),
        "minimum_complete_auc_family_count": min(
            item["selected"]["complete_auc_family_count"]
            for item in per_reconstruction
        ),
        "minimum_independent_auc_cluster_count": min(
            item["selected"]["independent_auc_cluster_count"]
            for item in per_reconstruction
        ),
        "maximum_hoeffding_radius": max(
            item["selected"]["hoeffding_radius"] for item in per_reconstruction
        ),
        "contrast_coverage": coverage,
        "undefined_metric_count": sum(
            bool(item["selected"]["mcc"].get("undefined_reason"))
            for item in per_reconstruction
        ),
        "prelock_feasibility_required": True,
    }
    return outcome, criteria, audit


def metric_intervals(
    observations: Sequence[dict],
    alpha: float,
    contrast_families: Mapping[str, Mapping[str, object]],
    *,
    evaluator_implementation_revision: str = EVALUATOR_IMPLEMENTATION_REVISION,
) -> dict:
    """Bound class-conditioned rates, MCC, and preregistered contrast AUC."""

    reject_presence_in_legacy(
        observations, {"evaluator_implementation_revision": evaluator_implementation_revision}
    )
    _validate_observations(observations)
    families = _families(observations)
    if not families:
        raise ValueError("At least one prompt family is required.")
    positive_values = [
        _mean(int(row["prediction"]) == 1 for row in family if int(row["label"]) == 1)
        for family in families.values()
        if any(int(row["label"]) == 1 for row in family)
    ]
    negative_values = [
        _mean(int(row["prediction"]) == 0 for row in family if int(row["label"]) == 0)
        for family in families.values()
        if any(int(row["label"]) == 0 for row in family)
    ]
    if not positive_values or not negative_values:
        raise ValueError("E-05 requires both positive and negative prompt families.")
    sensitivity_radius = _hoeffding_radius(len(positive_values), alpha)
    specificity_radius = _hoeffding_radius(len(negative_values), alpha)
    sensitivity = _bounded_mean_interval(positive_values, sensitivity_radius)
    specificity = _bounded_mean_interval(negative_values, specificity_radius)
    positive_count = sum(int(row["label"]) == 1 for row in observations)
    prevalence = positive_count / len(observations)
    mcc = _mcc_from_class_rate_intervals(sensitivity, specificity, prevalence)

    coverage, auc_values = contrast_coverage(
        observations, contrast_families,
        evaluator_implementation_revision=evaluator_implementation_revision,
    )
    if not auc_values:
        auc = _undefined_interval(0.0, 1.0, "no_complete_contrast_family")
        auc_radius = 1.0
    else:
        auc_radius = _hoeffding_radius(len(auc_values), alpha)
        auc = _bounded_mean_interval(auc_values, auc_radius)
    return {
        "mcc": mcc,
        "sensitivity": sensitivity,
        "specificity": specificity,
        "family_balanced_auc": auc,
        "family_count": len(families),
        "complete_auc_family_count": sum(
            int(item["complete_family_count"]) for item in coverage.values()
        ),
        "independent_auc_cluster_count": len(auc_values),
        "contrast_coverage": coverage,
        "hoeffding_radius": max(sensitivity_radius, specificity_radius, auc_radius),
        "null_denominator": bool(mcc.get("undefined_reason")),
    }


def contrast_coverage(
    observations: Sequence[dict],
    contrast_families: Mapping[str, Mapping[str, object]],
    *,
    evaluator_implementation_revision: str = EVALUATOR_IMPLEMENTATION_REVISION,
) -> tuple[dict[str, dict], list[float]]:
    """Return complete design-based families for each preregistered contrast."""

    by_condition_index: dict[tuple[str, int], list[dict]] = defaultdict(list)
    for row in observations:
        by_condition_index[
            (str(row["condition"]), int(row.get("condition_index", 0)))
        ].append(row)
    coverage = {}
    comparisons: list[tuple[frozenset[str], float]] = []
    for name, spec in sorted(contrast_families.items()):
        positive_conditions = {str(value) for value in spec["positive_conditions"]}
        negative_conditions = {str(value) for value in spec["negative_conditions"]}
        indices = {
            index
            for condition, index in by_condition_index
            if condition in positive_conditions | negative_conditions
        }
        complete = 0
        incomplete = 0
        for index in sorted(indices):
            positive_rows = [
                row
                for condition in positive_conditions
                for row in by_condition_index.get((condition, index), [])
                if int(row["label"]) == 1
            ]
            negative_rows = [
                row
                for condition in negative_conditions
                for row in by_condition_index.get((condition, index), [])
                if int(row["label"]) == 0
            ]
            if positive_rows and negative_rows:
                dependency_ids = frozenset(
                    str(row["prompt_id"])
                    for row in positive_rows + negative_rows
                )
                if evaluator_implementation_revision == EVALUATOR_IMPLEMENTATION_REVISION_R2:
                    dependency_ids = frozenset(
                        "{}:{}".format(kind, row[field])
                        for row in positive_rows + negative_rows
                        for kind, field in (("prompt", "prompt_id"), ("family", "family_id"))
                    )
                comparisons.append(
                    (
                        dependency_ids,
                        _rank_auc(
                            [float(row["score"]) for row in positive_rows],
                            [float(row["score"]) for row in negative_rows],
                        ),
                    )
                )
                complete += 1
            elif positive_rows or negative_rows:
                incomplete += 1
        minimum = int(spec.get("minimum_complete_families", 1))
        required = bool(spec.get("required", True))
        coverage[str(name)] = {
            "required": required,
            "minimum_complete_families": minimum,
            "complete_family_count": complete,
            "incomplete_family_count": incomplete,
            "status": "covered" if complete >= minimum else "insufficient",
        }
    return coverage, _cluster_dependent_auc_comparisons(comparisons)


def prediction_jaccard_interval(
    left: Sequence[dict], right: Sequence[dict], alpha: float
) -> dict:
    """Bound family-level Jaccard and reject any silent prompt intersection."""

    left_by_id = _unique_by_prompt(left)
    right_by_id = _unique_by_prompt(right)
    if set(left_by_id) != set(right_by_id):
        raise ValueError("Jaccard inputs have different prompt ID sets.")
    for prompt_id in left_by_id:
        lrow = left_by_id[prompt_id]
        rrow = right_by_id[prompt_id]
        if (
            str(lrow["family_id"]) != str(rrow["family_id"])
            or int(lrow["label"]) != int(rrow["label"])
        ):
            raise ValueError("Jaccard inputs disagree on family IDs or labels.")
    grouped: dict[str, list[str]] = defaultdict(list)
    for prompt_id, row in left_by_id.items():
        grouped[str(row["family_id"])].append(prompt_id)
    values = []
    for prompt_ids in grouped.values():
        left_positive = {
            prompt_id
            for prompt_id in prompt_ids
            if int(left_by_id[prompt_id]["prediction"]) == 1
        }
        right_positive = {
            prompt_id
            for prompt_id in prompt_ids
            if int(right_by_id[prompt_id]["prediction"]) == 1
        }
        union = left_positive | right_positive
        values.append(len(left_positive & right_positive) / len(union) if union else 1.0)
    radius = _hoeffding_radius(len(values), alpha)
    return _bounded_mean_interval(values, radius)


def construct_validity_summary(
    observations: Sequence[dict], thresholds: Mapping[str, object]
) -> dict:
    """Evaluate controlled semantic behavior separately from statistical gates."""

    _validate_observations(observations, require_family=False)
    by_type: dict[str, list[dict]] = defaultdict(list)
    for row in observations:
        by_type[str(row.get("control_type", row.get("condition", "")))].append(row)
    missing = sorted(REQUIRED_CONTROL_TYPES - set(by_type))
    if missing:
        raise ValueError("Semantic control rows are missing: {}.".format(", ".join(missing)))
    values = {
        "minimum_correct_sensitivity": _mean(
            int(row["prediction"]) == 1 for row in by_type["known_correct"]
        ),
        "minimum_wrong_specificity": _mean(
            int(row["prediction"]) == 0
            for row in by_type["systematically_wrong"]
        ),
        "minimum_echo_specificity": _mean(
            int(row["prediction"]) == 0 for row in by_type["prompt_echo"]
        ),
        "minimum_template_specificity": _mean(
            int(row["prediction"]) == 0 for row in by_type["template_only"]
        ),
    }
    return {
        **values,
        "control_counts": {name: len(by_type[name]) for name in sorted(by_type)},
        "passed": all(
            float(values[name]) >= float(threshold)
            for name, threshold in thresholds.items()
        ),
        "interpretation": "controlled_stress_test_not_population_interval",
    }


def assess_prelock_feasibility(
    prompt_rows: Sequence[Mapping[str, object]],
    concept_ids: Sequence[str],
    settings: Mapping[str, object],
    *,
    evaluator_implementation_revision: str = EVALUATOR_IMPLEMENTATION_REVISION,
) -> dict:
    """Check the materialized design under the explicitly supplied revision."""

    reject_presence_in_legacy(
        prompt_rows, settings,
        {"evaluator_implementation_revision": evaluator_implementation_revision},
    )
    groups = settings["model_groups"]
    reconstruction_count = max(
        3, int(settings.get("minimum_reconstruction_count", 3)),
        max(len(labels) for labels in groups.values()),
    )
    primitive_count = reconstruction_count * 18 + (
        reconstruction_count * (reconstruction_count - 1) // 2
    )
    limits = _thresholds(
        L1_THRESHOLDS, settings.get("thresholds", {}).get("l1", {})
    )
    reports = []
    for concept_id in sorted(str(value) for value in concept_ids):
        rows = [
            dict(row)
            for row in prompt_rows
            if str(row.get("concept_id")) == concept_id
            and str(row.get("split")) == "test"
        ]
        budget = float(settings["concept_error_budgets"][concept_id]) / len(groups)
        alpha = budget / primitive_count
        positive_families = len(
            {
                str(row.get("pair_id") or row.get("prompt_id"))
                for row in rows
                if int(row["expected_label"]) == 1
            }
        )
        negative_families = len(
            {
                str(row.get("pair_id") or row.get("prompt_id"))
                for row in rows
                if int(row["expected_label"]) == 0
            }
        )
        synthetic = [
            {
                "prompt_id": str(row["prompt_id"]),
                "family_id": str(row.get("pair_id") or row["prompt_id"]),
                "condition": str(row["condition"]),
                "condition_index": int(row.get("condition_index", 0)),
                "label": int(row["expected_label"]),
                "score": 1.0 if int(row["expected_label"]) else 0.0,
            }
            for row in rows
        ]
        coverage, auc_values = contrast_coverage(
            synthetic, settings["contrast_families"],
            evaluator_implementation_revision=evaluator_implementation_revision,
        )
        sensitivity_lower = (
            1.0 - _hoeffding_radius(positive_families, alpha)
            if positive_families
            else 0.0
        )
        specificity_lower = (
            1.0 - _hoeffding_radius(negative_families, alpha)
            if negative_families
            else 0.0
        )
        prevalence = (
            sum(int(row["expected_label"]) for row in rows) / len(rows)
            if rows
            else 0.0
        )
        mcc_lower = _mcc_from_sensitivity_specificity(
            max(0.0, sensitivity_lower),
            max(0.0, specificity_lower),
            prevalence,
        )
        auc_lower = 1.0 - _hoeffding_radius(len(auc_values), alpha) if auc_values else 0.0
        family_count = len(
            {str(row.get("pair_id") or row.get("prompt_id")) for row in rows}
        )
        jaccard_lower = 1.0 - _hoeffding_radius(family_count, alpha)
        bounds = {
            "minimum_test_mcc": max(-1.0, mcc_lower if mcc_lower is not None else -1.0),
            "minimum_positive_sensitivity": max(0.0, sensitivity_lower),
            "minimum_family_balanced_auc": max(0.0, auc_lower),
            "minimum_prediction_jaccard": max(0.0, jaccard_lower),
        }
        coverage_pass = all(
            not row["required"] or row["status"] == "covered"
            for row in coverage.values()
        )
        bound_pass = all(bounds[name] >= limits[name] for name in bounds)
        reports.append(
            {
                "concept_id": concept_id,
                "unit_error_budget": budget,
                "primitive_bound_count": primitive_count,
                "alpha_per_primitive_bound": alpha,
                "positive_family_count": positive_families,
                "negative_family_count": negative_families,
                "complete_auc_family_count": sum(
                    int(item["complete_family_count"])
                    for item in coverage.values()
                ),
                "independent_auc_cluster_count": len(auc_values),
                "best_case_lower_bounds": bounds,
                "contrast_coverage": coverage,
                "perfect_case_can_support_l1": bool(coverage_pass and bound_pass),
            }
        )
    passed = bool(reports) and all(
        row["perfect_case_can_support_l1"] for row in reports
    )
    return {
        "evaluator_version": EVALUATOR_VERSION,
        "evaluator_implementation_revision": evaluator_implementation_revision,
        "status": "passed" if passed else "failed",
        "uses_materialized_family_structure": True,
        "full_error_budget_used": True,
        "concept_reports": reports,
    }


def _development_eligibility_reason(
    evidence: Sequence[dict], limits: Mapping[str, float]
) -> str | None:
    try:
        values = [
            float(item["development_selection"]["selected_development_mcc"])
            for item in evidence
        ]
    except (KeyError, TypeError, ValueError, OverflowError):
        return "no_admissible_development_rule"
    if not values or any(not math.isfinite(value) for value in values):
        return "no_admissible_development_rule"
    if (
        mean(values) < limits["mean_development_mcc"]
        or min(values) < limits["minimum_development_mcc"]
    ):
        return "no_admissible_development_rule"
    return None


def _identifiability_reason(
    rows: Sequence[dict],
    evidence: Sequence[dict],
    expected_reconstruction_ids: Sequence[str],
    contrast_families: Mapping[str, Mapping[str, object]],
    *,
    minimum_reconstruction_count: int = 3,
    evidence_role: str = "independent_confirmatory_evaluation",
    evaluator_implementation_revision: str = EVALUATOR_IMPLEMENTATION_REVISION,
) -> str | None:
    expected = tuple(str(value) for value in expected_reconstruction_ids)
    observed = [str(row.get("model_seed")) for row in rows]
    if sorted(observed) != sorted(expected):
        return "incomplete_reconstruction_matrix"
    if len(observed) != len(set(observed)):
        return "duplicate_reconstruction_identifiers"
    if len(expected) < max(3, minimum_reconstruction_count):
        return "insufficient_reconstruction_count"
    required_order_roles = (
        REQUIRED_ORDER_ROLES_R2
        if evaluator_implementation_revision == EVALUATOR_IMPLEMENTATION_REVISION_R2
        else REQUIRED_ORDER_ROLES
    )
    reference_ids = None
    for item in evidence:
        if (
            not item.get("enabled")
            or not item.get("evaluated")
            or str(item.get("evaluator_version")) != EVALUATOR_VERSION
            or str(item.get("evaluator_implementation_revision"))
            != evaluator_implementation_revision
        ):
            return "missing_e05_evidence"
        if evidence_role == RETROSPECTIVE_EVIDENCE_ROLE:
            if item.get("evidence_role") != RETROSPECTIVE_EVIDENCE_ROLE:
                return "missing_retrospective_evidence_provenance"
            audit = item.get("retrospective_input_audit", {})
            if audit.get("status") != "available":
                reasons = audit.get("reasons", [])
                return str(reasons[0]) if reasons else "missing_retrospective_input_audit"
        if item.get("not_identifiable_reasons"):
            return str(item["not_identifiable_reasons"][0])
        selection = item.get("development_selection", {})
        if not selection.get("admissible_rule", False):
            return "no_admissible_development_rule"
        by_role = _by_role(item.get("observations", []))
        required = set(REQUIRED_BASE_ROLES) | {"semantic_control"}
        if str(selection.get("path_family")) in ORDERED_PATH_FAMILIES:
            required |= required_order_roles
        if not required <= set(by_role):
            return "missing_required_response_level_roles"
        try:
            role_ids = None
            aligned_roles = set(REQUIRED_BASE_ROLES)
            if str(selection.get("path_family")) in ORDERED_PATH_FAMILIES:
                aligned_roles |= required_order_roles
            for role in sorted(aligned_roles):
                _validate_observations(by_role[role])
                ids = {
                    (
                        str(row["prompt_id"]),
                        str(row["family_id"]),
                        int(row["label"]),
                    )
                    for row in by_role[role]
                }
                if role_ids is None:
                    role_ids = ids
                elif ids != role_ids:
                    return "unaligned_role_observations"
            if reference_ids is None:
                reference_ids = role_ids
            elif role_ids != reference_ids:
                return "unaligned_reconstruction_observations"
            coverage, _ = contrast_coverage(
                by_role["selected_rule"], contrast_families,
                evaluator_implementation_revision=evaluator_implementation_revision,
            )
            if any(
                row["required"] and row["status"] != "covered"
                for row in coverage.values()
            ):
                return "incomplete_required_contrast_coverage"
            construct_validity_summary(
                by_role["semantic_control"],
                {
                    "minimum_correct_sensitivity": 0.0,
                    "minimum_wrong_specificity": 0.0,
                    "minimum_echo_specificity": 0.0,
                    "minimum_template_specificity": 0.0,
                },
            )
        except (KeyError, TypeError, ValueError):
            return "invalid_response_level_evidence"
    return None


def _validate_observations(
    observations: Sequence[dict], *, require_family: bool = True
) -> None:
    reject_presence_in_legacy(observations)
    if not observations:
        raise ValueError("Observation rows must not be empty.")
    seen = set()
    for row in observations:
        required = {"prompt_id", "label", "score", "prediction"}
        if require_family:
            required |= {"family_id", "condition", "condition_index"}
        if not required <= set(row):
            raise ValueError("Observation row lacks required fields.")
        key = str(row["prompt_id"])
        if key in seen:
            raise ValueError("Observation prompt IDs must be unique within a role.")
        seen.add(key)
        if int(row["label"]) not in {0, 1} or int(row["prediction"]) not in {0, 1}:
            raise ValueError("Labels and predictions must be binary.")
        if not math.isfinite(float(row["score"])):
            raise ValueError("Observation scores must be finite.")


def _unique_by_prompt(rows: Sequence[dict]) -> dict[str, dict]:
    _validate_observations(rows)
    return {str(row["prompt_id"]): row for row in rows}


def _mcc_from_class_rate_intervals(
    sensitivity: Mapping[str, float],
    specificity: Mapping[str, float],
    prevalence: float,
) -> dict:
    estimate = _mcc_from_sensitivity_specificity(
        float(sensitivity["estimate"]),
        float(specificity["estimate"]),
        prevalence,
    )
    if estimate is None:
        return _undefined_interval(-1.0, 1.0, "empirical_mcc_denominator_is_zero")
    lower = _mcc_from_sensitivity_specificity(
        float(sensitivity["lower"]), float(specificity["lower"]), prevalence
    )
    upper = _mcc_from_sensitivity_specificity(
        float(sensitivity["upper"]), float(specificity["upper"]), prevalence
    )
    if lower is None or upper is None:
        return {
            "lower": -1.0,
            "upper": 1.0,
            "estimate": estimate,
            "interval_status": "uninformative_denominator_range",
            "undefined_reason": None,
        }
    return {
        "lower": max(-1.0, lower),
        "upper": min(1.0, upper),
        "estimate": estimate,
        "interval_status": "informative",
        "undefined_reason": None,
    }


def _mcc_from_sensitivity_specificity(
    sensitivity: float, specificity: float, prevalence: float
) -> float | None:
    tp = prevalence * sensitivity
    fn = prevalence * (1.0 - sensitivity)
    tn = (1.0 - prevalence) * specificity
    fp = (1.0 - prevalence) * (1.0 - specificity)
    denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return (tp * tn - fp * fn) / denominator if denominator else None


def _rank_auc(positives: Sequence[float], negatives: Sequence[float]) -> float:
    """Compute Mann-Whitney AUC in O(n log n), including half credit for ties."""

    ranked = sorted(
        [(float(value), 1) for value in positives]
        + [(float(value), 0) for value in negatives]
    )
    negative_before = 0
    wins = 0.0
    cursor = 0
    while cursor < len(ranked):
        end = cursor + 1
        while end < len(ranked) and ranked[end][0] == ranked[cursor][0]:
            end += 1
        block = ranked[cursor:end]
        positive_ties = sum(label == 1 for _, label in block)
        negative_ties = len(block) - positive_ties
        wins += positive_ties * negative_before + 0.5 * positive_ties * negative_ties
        negative_before += negative_ties
        cursor = end
    return wins / (len(positives) * len(negatives))


def _cluster_dependent_auc_comparisons(
    comparisons: Sequence[tuple[frozenset[str], float]],
) -> list[float]:
    """Average AUC comparisons connected by a reused response."""

    if not comparisons:
        return []
    parents = list(range(len(comparisons)))

    def find(index: int) -> int:
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    def union(left: int, right: int) -> None:
        left_root = find(left)
        right_root = find(right)
        if left_root != right_root:
            parents[right_root] = left_root

    response_owner: dict[str, int] = {}
    for index, (response_ids, _) in enumerate(comparisons):
        for response_id in response_ids:
            owner = response_owner.setdefault(response_id, index)
            union(index, owner)

    clustered: dict[int, list[float]] = defaultdict(list)
    for index, (_, auc) in enumerate(comparisons):
        clustered[find(index)].append(float(auc))
    return [_mean(clustered[root]) for root in sorted(clustered)]


def _families(observations: Sequence[dict]) -> dict[str, list[dict]]:
    result: dict[str, list[dict]] = defaultdict(list)
    for row in observations:
        result[str(row["family_id"])].append(row)
    return result


def _by_role(observations: Sequence[dict]) -> dict[str, list[dict]]:
    result: dict[str, list[dict]] = defaultdict(list)
    for row in observations:
        result[str(row["role"])].append(row)
    return result


def _thresholds(defaults: Mapping[str, float], configured: Mapping[str, object]) -> dict:
    return {
        name: float(configured.get(name, value)) for name, value in defaults.items()
    }


def _criterion_rows(base: dict, level: str, values: dict, limits: dict) -> list[dict]:
    return [
        {
            **base,
            "level": level,
            "criterion": name,
            "estimate": interval.get("estimate"),
            "lower": interval["lower"],
            "upper": interval["upper"],
            "threshold": float(limits[name]),
            "decision": decide_level({name: interval}, {name: limits[name]}),
            "interval_status": interval.get("interval_status", "informative"),
            "undefined_reason": interval.get("undefined_reason"),
        }
        for name, interval in values.items()
    ]


def _minimum_interval(intervals: Iterable[dict]) -> dict:
    values = list(intervals)
    if not values:
        return _undefined_interval(0.0, 1.0, "no_intervals")
    estimates = [value.get("estimate") for value in values]
    reasons = [value.get("undefined_reason") for value in values if value.get("undefined_reason")]
    return {
        "lower": min(float(value["lower"]) for value in values),
        "upper": min(float(value["upper"]) for value in values),
        "estimate": min(float(value) for value in estimates) if all(value is not None for value in estimates) else None,
        "interval_status": "undefined_empirical_metric" if reasons else "informative",
        "undefined_reason": reasons[0] if reasons else None,
    }


def _point_interval(value: float) -> dict:
    return {
        "lower": float(value),
        "upper": float(value),
        "estimate": float(value),
        "interval_status": "development_point_value",
        "undefined_reason": None,
    }


def _bounded_mean_interval(values: Sequence[float], radius: float) -> dict:
    estimate = _mean(values)
    return {
        "lower": max(0.0, estimate - radius),
        "upper": min(1.0, estimate + radius),
        "estimate": estimate,
        "interval_status": "informative",
        "undefined_reason": None,
    }


def _undefined_interval(lower: float, upper: float, reason: str) -> dict:
    return {
        "lower": lower,
        "upper": upper,
        "estimate": None,
        "interval_status": "undefined_empirical_metric",
        "undefined_reason": reason,
    }


def _hoeffding_radius(count: int, alpha: float) -> float:
    if count <= 0 or not 0.0 < alpha < 1.0:
        raise ValueError("Hoeffding bounds require count > 0 and 0 < alpha < 1.")
    return math.sqrt(math.log(2.0 / alpha) / (2.0 * count))


def _highest_supported_level(l1: str, l2: str, l3: str) -> str | None:
    if l3 == "supported":
        return "L3"
    if l2 == "supported":
        return "L2"
    if l1 == "supported":
        return "L1"
    return None


def _mean(values: Iterable[float]) -> float:
    items = [float(value) for value in values]
    return sum(items) / len(items) if items else 0.0
