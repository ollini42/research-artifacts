"""Tokenization helpers for answer traces."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List

TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:'[A-Za-z0-9]+)?|[^\sA-Za-z0-9]")


@dataclass(frozen=True)
class TokenizationConfig:
    mode: str = "word"
    lowercase: bool = True
    max_tokens: int | None = 256
    min_token_length: int = 1


def tokenize_text(text: str, config: TokenizationConfig | None = None) -> List[str]:
    """Tokenize natural-language answers into a simple symbolic alphabet."""

    cfg = config or TokenizationConfig()
    if cfg.mode not in {"word", "character"}:
        raise ValueError("Unsupported tokenization mode: {}".format(cfg.mode))

    source = text.strip()
    if cfg.lowercase:
        source = source.lower()

    if cfg.mode == "character":
        tokens = [char for char in source if not char.isspace()]
    else:
        tokens = TOKEN_RE.findall(source)

    tokens = [token for token in tokens if len(token) >= cfg.min_token_length]
    if cfg.max_tokens is not None:
        tokens = tokens[: cfg.max_tokens]
    return tokens
