"""SQLite ingestion and prompt metadata handling for ESM-LCD."""

from __future__ import annotations

import csv
import json
import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Set

from .config import DatabaseConfig
from .tokenization import TokenizationConfig, tokenize_text

KEYWORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9]+")
STOPWORDS = {
    "about",
    "also",
    "and",
    "are",
    "city",
    "does",
    "for",
    "from",
    "have",
    "how",
    "into",
    "its",
    "north",
    "northern",
    "the",
    "their",
    "this",
    "with",
}


@dataclass(frozen=True)
class PromptRecord:
    question_id: int
    prompt_id: str
    canonical_question_id: str
    topic_id: str
    topic_key: str
    topic_name: str
    question_index: int | None
    question_text: str
    keywords: frozenset[str]
    variation_type: str
    expected_equivalence_group: str
    concept_id: str | None = None
    concept_statement: str | None = None
    logical_negation: str | None = None
    concept_polarity: str | None = None
    expected_label: int | None = None
    concept_category: str | None = None
    statement_type: str | None = None
    entities: str | None = None


@dataclass(frozen=True)
class ResponseTrace:
    response_id: int
    prompt: PromptRecord
    model_id: str
    device: str
    answer_text: str
    answer_tokens: tuple[str, ...]
    sampling_config: Dict[str, str]
    answer_run_id: str


def connect_sqlite(db_path: str) -> sqlite3.Connection:
    if not Path(db_path).exists():
        raise FileNotFoundError("SQLite database not found: {}".format(db_path))
    connection = sqlite3.connect(db_path)
    connection.row_factory = sqlite3.Row
    return connection


def table_exists(connection: sqlite3.Connection, table_name: str) -> bool:
    cursor = connection.cursor()
    cursor.execute(
        """
        SELECT COUNT(*)
        FROM sqlite_master
        WHERE type = 'table'
          AND name = ?
        """,
        (table_name,),
    )
    return int(cursor.fetchone()[0]) > 0


def table_columns(connection: sqlite3.Connection, table_name: str) -> Set[str]:
    cursor = connection.cursor()
    cursor.execute("PRAGMA table_info({})".format(table_name))
    return {str(row[1]) for row in cursor.fetchall()}


def normalize_keywords(*texts: str) -> frozenset[str]:
    words: Set[str] = set()
    for text in texts:
        for raw_word in KEYWORD_RE.findall(text.lower()):
            if raw_word not in STOPWORDS and len(raw_word) >= 3:
                words.add(raw_word)
    return frozenset(sorted(words))


def _row_value(row: sqlite3.Row, columns: Set[str], name: str, default=None):
    if name in columns:
        value = row[name]
        if value is not None:
            return value
    return default


def _parse_keywords(raw_value, fallback: frozenset[str]) -> frozenset[str]:
    if raw_value is None:
        return fallback
    if isinstance(raw_value, str):
        text = raw_value.strip()
        if not text:
            return fallback
        try:
            parsed = json.loads(text)
            if isinstance(parsed, list):
                return frozenset(str(item).lower() for item in parsed)
        except json.JSONDecodeError:
            pass
        return frozenset(word.strip().lower() for word in text.split(",") if word.strip())
    return fallback


def _optional_string(value) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def prompt_from_question_row(row: sqlite3.Row, columns: Set[str]) -> PromptRecord:
    question_id = int(row["id"])
    prompt_id = str(_row_value(row, columns, "prompt_id", "question:{}".format(question_id)))
    topic_id = str(_row_value(row, columns, "topic_id", "unknown"))
    topic_key = str(_row_value(row, columns, "topic_key", topic_id))
    topic_name = str(_row_value(row, columns, "topic_name", topic_key))
    question_index = _row_value(row, columns, "question_index", None)
    question_index = int(question_index) if question_index is not None else None
    question_text = str(row["question_text"])
    fallback_keywords = normalize_keywords(topic_name, question_text)
    keywords = _parse_keywords(_row_value(row, columns, "keywords", None), fallback_keywords)
    canonical_question_id = str(
        _row_value(row, columns, "canonical_question_id", prompt_id)
    )
    expected_equivalence_group = str(
        _row_value(row, columns, "expected_equivalence_group", canonical_question_id)
    )
    variation_type = str(_row_value(row, columns, "variation_type", "unknown"))
    raw_expected_label = _row_value(row, columns, "expected_label", None)
    expected_label = (
        int(raw_expected_label) if raw_expected_label is not None else None
    )
    concept_statement = _optional_string(
        _row_value(row, columns, "concept_statement", None)
    )

    return PromptRecord(
        question_id=question_id,
        prompt_id=prompt_id,
        canonical_question_id=canonical_question_id,
        topic_id=topic_id,
        topic_key=topic_key,
        topic_name=topic_name,
        question_index=question_index,
        question_text=question_text,
        keywords=keywords,
        variation_type=variation_type,
        expected_equivalence_group=expected_equivalence_group,
        concept_id=topic_key if concept_statement is not None else None,
        concept_statement=concept_statement,
        logical_negation=_optional_string(
            _row_value(row, columns, "logical_negation", None)
        ),
        concept_polarity=_optional_string(
            _row_value(row, columns, "concept_polarity", None)
        ),
        expected_label=expected_label,
        concept_category=_optional_string(
            _row_value(row, columns, "concept_category", None)
        ),
        statement_type=_optional_string(
            _row_value(row, columns, "statement_type", None)
        ),
        entities=_optional_string(_row_value(row, columns, "entities", None)),
    )


def validate_database(connection: sqlite3.Connection, require_responses: bool = True) -> None:
    required = ["questions"]
    if require_responses:
        required.extend(["responses", "meta"])
    missing = [table for table in required if not table_exists(connection, table)]
    if missing:
        raise RuntimeError("Missing required table(s): {}".format(", ".join(missing)))
    question_columns = table_columns(connection, "questions")
    for required_column in ("id", "question_text"):
        if required_column not in question_columns:
            raise RuntimeError("questions table lacks required column {}".format(required_column))


def load_prompt_records(connection: sqlite3.Connection, question_run_id: str | None = None) -> List[PromptRecord]:
    validate_database(connection, require_responses=False)
    columns = table_columns(connection, "questions")
    where = ""
    params: List[str] = []
    if question_run_id is not None:
        if "run_id" not in columns:
            return []
        where = "WHERE run_id = ?"
        params.append(question_run_id)
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM questions {} ORDER BY id".format(where), tuple(params))
    return [prompt_from_question_row(row, columns) for row in cursor.fetchall()]


def load_response_traces(
    db_config: DatabaseConfig,
    tokenization_config: TokenizationConfig,
) -> List[ResponseTrace]:
    connection = connect_sqlite(db_config.path)
    try:
        validate_database(connection, require_responses=True)
        q_columns = table_columns(connection, "questions")
        clauses = []
        params: List[str] = []
        if db_config.question_run_id:
            if "run_id" not in q_columns:
                return []
            clauses.append("q.run_id = ?")
            params.append(db_config.question_run_id)
        if db_config.model_id:
            clauses.append("m.model_id = ?")
            params.append(db_config.model_id)
        if db_config.device:
            clauses.append("m.device = ?")
            params.append(db_config.device)
        where_sql = "WHERE " + " AND ".join(clauses) if clauses else ""
        limit_sql = "LIMIT ?" if db_config.limit is not None else ""
        if db_config.limit is not None:
            params.append(str(db_config.limit))

        cursor = connection.cursor()
        cursor.execute(
            """
            SELECT r.id AS response_id, r.answer_text, r.created_at AS response_created_at,
                   m.model_id, m.device, q.*
            FROM responses AS r
            JOIN questions AS q ON q.id = r.question_fk
            JOIN meta AS m ON m.id = r.meta_fk
            {}
            ORDER BY q.id, r.id
            {}
            """.format(where_sql, limit_sql),
            tuple(params),
        )
        traces: List[ResponseTrace] = []
        for row in cursor.fetchall():
            prompt = prompt_from_question_row(row, q_columns)
            answer_text = str(row["answer_text"] or "")
            answer_tokens = tuple(tokenize_text(answer_text, tokenization_config))
            sampling_config = {
                "source": "sqlite_responses",
                "created_at": str(row["response_created_at"]),
            }
            traces.append(
                ResponseTrace(
                    response_id=int(row["response_id"]),
                    prompt=prompt,
                    model_id=str(row["model_id"]),
                    device=str(row["device"]),
                    answer_text=answer_text,
                    answer_tokens=answer_tokens,
                    sampling_config=sampling_config,
                    answer_run_id="sqlite-responses",
                )
            )
        return traces
    finally:
        connection.close()


def write_prompt_manifest(prompts: Sequence[PromptRecord], output_path: str | Path) -> None:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "question_id",
                "prompt_id",
                "canonical_question_id",
                "topic_id",
                "topic_key",
                "topic_name",
                "question_index",
                "variation_type",
                "expected_equivalence_group",
                "concept_id",
                "concept_statement",
                "logical_negation",
                "concept_polarity",
                "expected_label",
                "concept_category",
                "statement_type",
                "entities",
                "keywords",
                "question_text",
            ],
        )
        writer.writeheader()
        for prompt in prompts:
            writer.writerow(
                {
                    "question_id": prompt.question_id,
                    "prompt_id": prompt.prompt_id,
                    "canonical_question_id": prompt.canonical_question_id,
                    "topic_id": prompt.topic_id,
                    "topic_key": prompt.topic_key,
                    "topic_name": prompt.topic_name,
                    "question_index": prompt.question_index,
                    "variation_type": prompt.variation_type,
                    "expected_equivalence_group": prompt.expected_equivalence_group,
                    "concept_id": prompt.concept_id,
                    "concept_statement": prompt.concept_statement,
                    "logical_negation": prompt.logical_negation,
                    "concept_polarity": prompt.concept_polarity,
                    "expected_label": prompt.expected_label,
                    "concept_category": prompt.concept_category,
                    "statement_type": prompt.statement_type,
                    "entities": prompt.entities,
                    "keywords": ",".join(sorted(prompt.keywords)),
                    "question_text": prompt.question_text,
                }
            )
