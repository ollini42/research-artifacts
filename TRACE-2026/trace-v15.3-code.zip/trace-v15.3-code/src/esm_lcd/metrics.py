"""Similarity and evaluation metric helpers."""

from __future__ import annotations

import math
import random
from collections import defaultdict
from itertools import combinations
from typing import Dict, Iterable, List, Sequence, Tuple


def entropy_from_counts(counts: Dict[str, int]) -> float:
    total = sum(counts.values())
    if total <= 0:
        return 0.0
    entropy = 0.0
    for count in counts.values():
        if count <= 0:
            continue
        p = count / total
        entropy -= p * math.log2(p)
    return entropy


def normalize_counts(counts: Dict[str, int]) -> Dict[str, float]:
    total = sum(counts.values())
    if total <= 0:
        return {}
    return {key: value / total for key, value in counts.items() if value > 0}


def jensen_shannon_divergence(p: Dict[str, float], q: Dict[str, float]) -> float:
    keys = set(p) | set(q)
    if not keys:
        return 0.0
    m = {key: 0.5 * p.get(key, 0.0) + 0.5 * q.get(key, 0.0) for key in keys}
    divergence = 0.5 * _kl_divergence(p, m, keys) + 0.5 * _kl_divergence(
        q, m, keys
    )
    # Base-2 Jensen-Shannon divergence is mathematically bounded by [0, 1].
    # Roundoff can otherwise make a configured upper bound of 1.0 reject a
    # maximally dissimilar but valid pair.
    return max(0.0, min(1.0, divergence))


def _kl_divergence(p: Dict[str, float], q: Dict[str, float], keys: Iterable[str]) -> float:
    value = 0.0
    for key in keys:
        p_value = p.get(key, 0.0)
        q_value = q.get(key, 0.0)
        if p_value > 0.0 and q_value > 0.0:
            value += p_value * math.log2(p_value / q_value)
    return value


def js_similarity(p: Dict[str, float], q: Dict[str, float]) -> float:
    return max(0.0, 1.0 - jensen_shannon_divergence(p, q))


def jaccard_similarity(a: Iterable, b: Iterable) -> float:
    set_a = set(a)
    set_b = set(b)
    if not set_a and not set_b:
        return 1.0
    if not set_a or not set_b:
        return 0.0
    return len(set_a & set_b) / len(set_a | set_b)


def jaccard_distance(a: Iterable, b: Iterable) -> float:
    return 1.0 - jaccard_similarity(a, b)


def rank_values(values: Sequence[float]) -> List[float]:
    indexed = sorted(enumerate(values), key=lambda item: item[1])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(indexed):
        j = i + 1
        while j < len(indexed) and indexed[j][1] == indexed[i][1]:
            j += 1
        avg_rank = (i + 1 + j) / 2.0
        for k in range(i, j):
            ranks[indexed[k][0]] = avg_rank
        i = j
    return ranks


def pearson_correlation(a: Sequence[float], b: Sequence[float]) -> float | None:
    if len(a) != len(b) or len(a) < 2:
        return None
    mean_a = sum(a) / len(a)
    mean_b = sum(b) / len(b)
    da = [value - mean_a for value in a]
    db = [value - mean_b for value in b]
    denom_a = math.sqrt(sum(value * value for value in da))
    denom_b = math.sqrt(sum(value * value for value in db))
    if denom_a == 0.0 or denom_b == 0.0:
        return None
    return sum(x * y for x, y in zip(da, db, strict=True)) / (denom_a * denom_b)


def spearman_correlation(a: Sequence[float], b: Sequence[float]) -> float | None:
    if len(a) != len(b) or len(a) < 2:
        return None
    return pearson_correlation(rank_values(a), rank_values(b))


def grouped_pairs(
    items: Sequence,
    key_fn,
    max_pairs: int,
    seed: int,
) -> List[Tuple]:
    rng = random.Random(seed)
    groups = defaultdict(list)
    for item in items:
        key = key_fn(item)
        if key is not None:
            groups[key].append(item)
    pairs: List[Tuple] = []
    for group_items in groups.values():
        if len(group_items) < 2:
            continue
        pairs.extend(combinations(group_items, 2))
        if len(pairs) > max_pairs * 2:
            rng.shuffle(pairs)
            pairs = pairs[:max_pairs]
    if len(pairs) > max_pairs:
        rng.shuffle(pairs)
        pairs = pairs[:max_pairs]
    return pairs


def sampled_pairs(items: Sequence, max_pairs: int, seed: int) -> List[Tuple]:
    if len(items) < 2:
        return []
    all_pair_count = len(items) * (len(items) - 1) // 2
    if all_pair_count <= max_pairs:
        return list(combinations(items, 2))

    rng = random.Random(seed)
    seen = set()
    pairs = []
    while len(pairs) < max_pairs:
        i = rng.randrange(len(items))
        j = rng.randrange(len(items))
        if i == j:
            continue
        if i > j:
            i, j = j, i
        key = (i, j)
        if key in seen:
            continue
        seen.add(key)
        pairs.append((items[i], items[j]))
    return pairs
