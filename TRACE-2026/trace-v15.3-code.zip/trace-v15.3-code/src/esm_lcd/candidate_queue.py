"""Exact minimum selection over an explicitly supplied candidate graph."""

from __future__ import annotations

import heapq
import math
from collections.abc import Callable, Iterable


class DynamicCandidateQueue:
    """Maintain scored, undirected pairs of integer component roots.

    Selection is exact over active candidates, not over absent pairs. Supply
    all pairs with ``itertools.combinations(roots, 2)`` for exhaustive search.
    Call ``remap`` after every committed merge, before the next ``pop``.
    Distances must remain unchanged for pairs not incident to changed roots.
    Popped pairs stay known but inactive until an endpoint changes or the pair
    is explicitly added again. Self-pairs created by merges are forgotten.
    Adjacency stores two references per known pair, including inactive pairs.
    Heap compaction bounds stale entries, not the size of this candidate graph.
    Callbacks are used only during method calls and are never stored, so the
    queue can be pickled independently of the component model.
    """

    def __init__(self) -> None:
        self._active: dict[tuple[int, int], tuple[float, int]] = {}
        # Keep adjacency for both active and inactive candidates.
        self._neighbors: dict[int, set[int]] = {}
        self._inactive_neighbors: dict[int, set[int]] = {}
        self._heap: list[tuple[float, int, int, int]] = []
        self._version = 0
        self._known_pairs = 0

    @property
    def known_pair_count(self) -> int:
        if not hasattr(self, "_known_pairs"):
            self._known_pairs = sum(map(len, self._neighbors.values())) // 2
        return self._known_pairs

    def __len__(self) -> int:
        return len(self._active)

    def add_pairs(
        self,
        pairs: Iterable[tuple[int, int]],
        distance_callback: Callable[[int, int], float],
    ) -> None:
        """Score new pairs of current roots, ignoring self-pairs and duplicates.

        Existing active pairs keep their scores. Explicitly adding a previously
        popped pair makes it eligible again. Scores may be infinite but not NaN.
        """
        for left, right in pairs:
            if left == right:
                continue
            pair = (min(left, right), max(left, right))
            if pair not in self._active:
                self._insert(pair, self._score(pair, distance_callback))
        # Fresh seeding needs no compaction. With stale entries, additions
        # can still exceed the fixed 64-entry allowance for small queues.
        if len(self._heap) > 2 * len(self._active) and len(self._heap) > 64:
            self._compact()

    def pop(self) -> tuple[float, int, int] | None:
        """Deactivate the current minimum, breaking ties by endpoint IDs.

        Retain adjacency so an endpoint profile change can make a rejected
        pair eligible again. Unchanged inactive pairs are not selected again.
        """
        while self._heap:
            distance, left, right, version = heapq.heappop(self._heap)
            pair = (left, right)
            active = self._active.get(pair)
            if active is None or active[1] != version:
                continue
            del self._active[pair]
            self._ensure_inactive_index()
            self._inactive_neighbors.setdefault(left, set()).add(right)
            self._inactive_neighbors.setdefault(right, set()).add(left)
            self._compact()
            return distance, left, right
        return None

    def remap(
        self,
        merged_groups: Iterable[Iterable[int]],
        find_callback: Callable[[int], int],
        distance_callback: Callable[[int, int], float],
        *,
        score_preserving_roots: set[int] | None = None,
    ) -> None:
        """Rebuild and activate all known edges incident to changed roots.

        Each group supplies its pre-merge roots, including the surviving root.
        ``find_callback`` must resolve the global component structure after the
        entire transaction has committed, not a tentative group representative.
        Overlapping groups and singleton groups for score refresh are allowed.
        Every changed pair is scored once and activated, including previously
        popped pairs, even if its endpoint IDs survive. Unaffected active edges
        retain their scores and unaffected inactive edges remain inactive.
        Accepted pairs become self-edges and disappear. No neighbors are invented.

        ``score_preserving_roots`` may identify surviving roots whose complete
        distance-relevant profiles are exactly unchanged. Active edges between
        unchanged profiles retain their scores. Inactive edges still reactivate
        because statistical evidence or recursive compatibility may have changed.
        """
        changed = {root for group in merged_groups for root in group}
        changed.update(find_callback(root) for root in tuple(changed))
        preserved = score_preserving_roots or frozenset()
        if not preserved <= changed or any(find_callback(root) != root for root in preserved):
            raise ValueError("Score-preserving roots must be surviving changed roots.")
        self._ensure_inactive_index()
        affected = {
            (min(root, neighbor), max(root, neighbor))
            for root in changed
            for neighbor in (
                self._inactive_neighbors if root in preserved else self._neighbors
            ).get(root, ())
        }
        remapped = set()
        for left, right in sorted(affected):
            left, right = find_callback(left), find_callback(right)
            if left != right:
                remapped.add((min(left, right), max(left, right)))

        # Evaluate before mutation so a failed callback leaves the queue intact.
        retained = {
            pair for pair in remapped if pair in self._active
            and all(root not in changed or root in preserved for root in pair)
        }
        scored = [
            (pair, self._score(pair, distance_callback))
            for pair in sorted(remapped - retained)
        ]
        for pair in affected:
            if pair in retained:
                continue
            if pair in remapped:
                # Refresh scores without tearing down unchanged adjacency.
                self._active.pop(pair, None)
            else:
                self._remove(pair)
        for pair, distance in scored:
            self._insert(pair, distance)
        self._compact()

    @staticmethod
    def _score(
        pair: tuple[int, int], distance_callback: Callable[[int, int], float]
    ) -> float:
        distance = float(distance_callback(*pair))
        if math.isnan(distance):
            raise ValueError("Candidate distance must not be NaN.")
        return distance

    def _insert(self, pair: tuple[int, int], distance: float) -> None:
        left, right = pair
        known = self.known_pair_count
        if right not in self._neighbors.get(left, ()):
            self._known_pairs = known + 1
        self._ensure_inactive_index()
        self._discard_inactive(pair)
        # Versions never restart when an inactive pair is reactivated.
        self._version += 1
        self._active[pair] = (distance, self._version)
        left_neighbors = self._neighbors.get(left)
        if left_neighbors is None:
            left_neighbors = self._neighbors[left] = set()
        left_neighbors.add(right)
        right_neighbors = self._neighbors.get(right)
        if right_neighbors is None:
            right_neighbors = self._neighbors[right] = set()
        right_neighbors.add(left)
        heapq.heappush(self._heap, (distance, left, right, self._version))

    def _remove(self, pair: tuple[int, int]) -> None:
        self._known_pairs = self.known_pair_count - 1
        self._active.pop(pair, None)
        self._discard_inactive(pair)
        left, right = pair
        for root, neighbor in ((left, right), (right, left)):
            neighbors = self._neighbors[root]
            neighbors.remove(neighbor)
            if not neighbors:
                del self._neighbors[root]

    def _ensure_inactive_index(self) -> None:
        # Older exact-resume checkpoints predate this derived acceleration index.
        if hasattr(self, "_inactive_neighbors"):
            return
        self._inactive_neighbors = {}
        for left, neighbors in self._neighbors.items():
            for right in neighbors:
                if left < right and (left, right) not in self._active:
                    self._inactive_neighbors.setdefault(left, set()).add(right)
                    self._inactive_neighbors.setdefault(right, set()).add(left)

    def _discard_inactive(self, pair: tuple[int, int]) -> None:
        left, right = pair
        for root, neighbor in ((left, right), (right, left)):
            neighbors = self._inactive_neighbors.get(root)
            if neighbors is not None:
                neighbors.discard(neighbor)
                if not neighbors:
                    del self._inactive_neighbors[root]

    def _compact(self) -> None:
        if not self._active:
            self._heap.clear()
        elif len(self._heap) > max(64, 2 * len(self._active)):
            self._heap = [
                (distance, left, right, version)
                for (left, right), (distance, version) in self._active.items()
            ]
            heapq.heapify(self._heap)
