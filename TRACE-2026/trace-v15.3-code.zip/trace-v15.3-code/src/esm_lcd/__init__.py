"""External State Merging for Latent Concept Discovery (ESM-LCD)."""

__all__ = ["__version__"]

__version__ = "0.1.0"
