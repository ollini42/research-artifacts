"""Pretest fitting and saved-rule execution for automatic concept presence.

This sidecar has no generator, launcher, model adapter, or GPU worker. Call
``fit_presence_rule`` with discovery and development examples only. Its JSON
artifact includes the complete scoring state, including prompt IDF and both
centroids. ``fit_presence_order_controls`` refits controls at the parent's
feature limit. ``freeze_presence_runtime`` binds these artifacts to the existing
inference plan and preparation records. ``evaluate_presence_runtime`` performs
no fitting and exports observations for the unchanged inference implementation.

Compression is a separate development-only operation. Call
``select_presence_compression`` on a complete model-specific matrix of fitted
rules and actual automata. Freeze its bootstrap settings before executing it.
It pools development confusion counts and resamples joined source families,
using the same sample for both sizes. Undefined draws invalidate a comparison,
never become zero or disappear. No fixed-size fallback is provided.

Runtime revision 2 permits recurring text from distinct calls across fitting
splits while retaining origin-based leakage checks and within-split content
grouping for compression. Earlier saved rules and runtimes require their original
implementation, not silent migration to the revised preparation policy.

The caller still owns the complete collection audit, plan construction,
automatic checker validation, chronology, physical artifact retention, and
real-model validation. The module does not assert production readiness. Its
digests bind supplied data, not the accuracy of external attestations.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import random
import tempfile
from collections import Counter
from collections.abc import Mapping, Sequence
from copy import deepcopy
from dataclasses import asdict, dataclass, replace
from pathlib import Path

from . import confirmatory_detector as detector
from .automata import find_determinism_conflicts
from .concept_presence_data import (
    RESPONSE_OVERLAP_POLICY, response_content_overlap, response_provenance_keys,
    validate_presence_annotation,
)
from .concept_presence_evaluation import (
    EVALUATOR_VERSION, LABEL_OBJECTIVE, MAPPING_REVISION, PresenceExample,
    _presence_metrics, _validate_presence_mapping, _validated_answer_tokens, _annotation_metadata,
)
from .presence_inference import (
    INDIVIDUAL, ORDERED, PATH, TEXT, FrozenPresenceInference, _components,
    _digest, _json, _provenance_tokens, evaluate_presence_inference, freeze_presence_inference,
    presence_reference_digest,
)
from .trace_coverage import SHORT_GAP_FAMILY, conservative_fragment_policy


RUNTIME_REVISION = "E-06-presence-runtime-2"
ORDER_REVISION = "exact-segment-fixed-boundaries-1"
REQUIRED_STATE_COUNTS = (20000, 10000, 5000, 2000, 1000)


def _key(item):
    return item.concept_id, item.model_seed, item.prompt_id


def presence_reference_row(item: PresenceExample, model_group: str) -> dict:
    """Serialize an unscored reference, including the prompt used by TF-IDF."""
    row = {
        "label_objective": item.label_objective, "evaluator_version": EVALUATOR_VERSION,
        "concept_id": item.concept_id, "model_seed": item.model_seed,
        "prompt_id": item.prompt_id, "source_family_id": item.source_family_id,
        "source_family_ids": sorted(set(item.source_family_ids) | {item.source_family_id}),
        "dependency_family_id": item.dependency_family_id,
        "text": item.answer_text, "content_sha256": item.content_sha256,
        "presence_label": item.label if item.audit_status == "reviewed" else None,
        "audit_status": item.audit_status, "annotation_source": item.annotation_source,
        "split": item.split,
        "mapping_revision": item.mapping_revision, "diagnostics": dict(item.diagnostics),
        "model_group": model_group, "prompt_text": item.prompt_text,
        **{key: getattr(item, key) for key in ("response_id", "generation_request_id")
           if getattr(item, key) is not None},
    }
    row.update(_annotation_metadata(item))
    return row


def _validate_examples(examples, *, resolved=False):
    seen = set()
    for item in examples:
        if _key(item) in seen:
            raise ValueError("Duplicate presence example.")
        seen.add(_key(item))
        if item.label_objective != LABEL_OBJECTIVE or item.mapping_revision != MAPPING_REVISION:
            raise ValueError("Explicit presence and mapping revisions are required.")
        tokens = _validated_answer_tokens(item.answer_text, item.answer_tokens)
        _validate_presence_mapping(tokens, item.path, item.mapping_kinds)
        if not isinstance(item.prompt_text, str):
            raise ValueError("The complete prompt must be a string.")
        if item.content_sha256 is not None:
            row = presence_reference_row(item, "validation")
            validate_presence_annotation(row, response_identity=row)
            if row.get("verification_mode") != "automatic":
                raise ValueError("Runtime fitting requires automatic reference provenance.")
        elif item.label is not None or resolved:
            raise ValueError("Reference labels require complete content bindings.")
        if resolved and (type(item.label) is not int or item.label not in (0, 1)
                         or item.audit_status != "reviewed"):
            raise ValueError("Unresolved reference labels cannot enter fitting.")


def transform_presence_order(examples, transform):
    """Permute exact segments while preserving the full state multiset and gaps.

    The initial state and both positions of each unknown placeholder are fixed.
    These boundary constraints keep unknown transitions valid. Reversal is an
    involution. Shuffling uses answer identity, never labels or scores. The
    output is a control sequence, not an assertion of graph-valid transitions.
    """
    if transform not in ("shuffle", "reverse"):
        raise ValueError("Unknown presence order transform.")
    output = []
    for item in examples:
        _validate_presence_mapping(item.answer_tokens, item.path, item.mapping_kinds)
        fixed = {0}
        for index, kind in enumerate(item.mapping_kinds):
            if kind == "unknown":
                fixed.update((index, index + 1))
        seed = int(_digest([ORDER_REVISION, *_key(item)])[:16], 16)
        rng = random.Random(seed)
        path = list(item.path)
        start = None
        for index, kind in enumerate((*item.mapping_kinds, "boundary")):
            if kind in ("exact", "reconstruction_exact"):
                if start is None:
                    start = index
            elif start is not None:
                positions = [i for i in range(start, index + 1) if i not in fixed]
                states = [path[i] for i in positions]
                if transform == "shuffle":
                    rng.shuffle(states)
                else:
                    states.reverse()
                for i, state in zip(positions, states, strict=True):
                    path[i] = state
                start = None
        changed = replace(item, path=tuple(path))
        _validate_presence_mapping(changed.answer_tokens, changed.path, changed.mapping_kinds)
        if Counter(path) != Counter(item.path):
            raise ValueError("Order transformation changed state counts.")
        output.append(changed)
    return tuple(output)


def _tuple(value):
    return tuple(_tuple(part) for part in value) if isinstance(value, list) else value


def _scores(state, examples):
    if state["family"] == "prompt_tfidf":
        return [
            detector.cosine(detector.tfidf_vector(detector.text_terms(item.prompt_text), state["idf"]),
                            state["positive_centroid"])
            - detector.cosine(detector.tfidf_vector(detector.text_terms(item.prompt_text), state["idf"]),
                              state["negative_centroid"])
            for item in examples
        ]
    weights = {_tuple(feature): value for feature, value in state["weights"]}
    # Fixed summation order prevents PYTHONHASHSEED from changing score thresholds.
    return [math.fsum(weights[feature] for feature in sorted(
        detector.extract_features(item, state["family"]) & weights.keys(), key=repr
    )) for item in examples]


def _select_presence_threshold(scores, labels):
    values = sorted(set(scores))
    if len(values) > 200:
        values = [values[round(index * (len(values) - 1) / 199)] for index in range(200)]
    candidates = [values[0] - 1e-9, *values, values[-1] + 1e-9]
    ranked = []
    for threshold in candidates:
        metrics = _presence_metrics(labels, [int(score >= threshold) for score in scores], scores)
        if metrics["mcc"] is not None:
            ranked.append(((metrics["mcc"], metrics["balanced_accuracy"], -abs(threshold)), threshold))
    # Constant scores have no defined MCC. Preserve that exclusion explicitly.
    return max(ranked)[1] if ranked else min(candidates, key=abs)


@dataclass(frozen=True)
class FrozenPresenceRule:
    payload: str

    @property
    def sha256(self):
        return hashlib.sha256(self.payload.encode("utf-8")).hexdigest()

    @property
    def record(self):
        return {**json.loads(self.payload)["record"], "rule_sha256": self.sha256}


def score_presence_rule(rule: FrozenPresenceRule, examples: Sequence[PresenceExample]) -> dict:
    """Apply saved state without accessing labels for scoring or selection."""
    payload = json.loads(rule.payload)
    if payload.get("runtime_revision") != RUNTIME_REVISION:
        raise ValueError("Incompatible saved presence rule. Use its original implementation or refit before testing.")
    _validate_examples(examples)
    if any(item.concept_id != payload["concept_id"] for item in examples):
        raise ValueError("Scored example differs from the fitted concept.")
    transform = payload["record"].get("transform")
    if transform:
        if payload["order_revision"] != ORDER_REVISION:
            raise ValueError("Changed order transformation revision.")
        examples = transform_presence_order(examples, transform)
    if payload["record"]["family"] == SHORT_GAP_FAMILY:
        if payload["record"]["fragment_policy"] != conservative_fragment_policy():
            raise ValueError("Changed G-01 fragment policy.")
    scores = _scores(payload["state"], examples)
    if not all(math.isfinite(score) for score in scores):
        raise ValueError("Nonfinite saved-rule score.")
    return {"scores": scores, "predictions": [int(value >= payload["record"]["threshold"])
                                             for value in scores]}


def fit_presence_rule(*, family: str, discovery, development, feature_budget: int,
                      model_group: str, source_revision: str, transform=None,
                      parent_rule: FrozenPresenceRule | None = None) -> FrozenPresenceRule:
    """Fit only on discovery and choose feature count and threshold on development.

    Test and control examples are rejected before feature extraction. Undefined
    development MCC is retained as None. Among finite candidates the smallest
    rule within the unchanged .02 MCC tolerance is saved. No test argument exists.
    """
    if family not in INDIVIDUAL | PATH | TEXT:
        raise ValueError("Unknown presence feature family.")
    if type(feature_budget) is not int or feature_budget < 1:
        raise ValueError("A positive fixed feature limit is required.")
    if family in INDIVIDUAL and feature_budget != 1:
        raise ValueError("Individual-state rules have exactly one feature slot.")
    if not model_group or not source_revision:
        raise ValueError("Model group and source revision must be supplied.")
    discovery, development = tuple(sorted(discovery, key=_key)), tuple(sorted(development, key=_key))
    for split, examples in (("discovery", discovery), ("development", development)):
        if not examples or any(item.split != split for item in examples):
            raise ValueError("Fitting accepts discovery and development splits only.")
        _validate_examples(examples, resolved=True)
        if {item.label for item in examples} != {0, 1}:
            raise ValueError("Both resolved presence classes are required for fitting.")
    combined = discovery + development
    if len({item.concept_id for item in combined}) != 1:
        raise ValueError("Fit one concept at a time.")
    references = [presence_reference_row(item, model_group) for item in combined]
    components = _components(_provenance_tokens(references))
    if set(components[:len(discovery)]) & set(components[len(discovery):]):
        raise ValueError("Dependent sources, prompts or physical answers cross fitting splits.")
    record = {"family": family, "feature_budget": feature_budget,
              "fit_split": "discovery", "selection_split": "development",
              "source_revision": source_revision,
              **{split + "_sha256": presence_reference_digest([
                  presence_reference_row(item, model_group) for item in examples
              ]) for split, examples in (("discovery", discovery), ("development", development))}}
    input_digest = _digest(sorted([asdict(item) for item in combined],
                                  key=lambda row: (row["model_seed"], row["prompt_id"])))
    if transform is not None:
        if (family not in ORDERED or parent_rule is None
                or parent_rule.record["family"] != family
                or parent_rule.record["feature_budget"] != feature_budget
                or json.loads(parent_rule.payload)["preparation_inputs_sha256"] != input_digest
                or any(parent_rule.record[key] != record[key] for key in (
                    "discovery_sha256", "development_sha256", "source_revision"))):
            raise ValueError("Order controls require a matched frozen parent rule.")
        discovery = transform_presence_order(discovery, transform)
        development = transform_presence_order(development, transform)
        record.update(transform=transform, refitted=True,
                      preserves_state_counts_and_gaps=True, transform_applied_to_all_splits=True,
                      parent_rule_sha256=parent_rule.sha256,
                      transform_evidence_sha256=_digest([ORDER_REVISION, transform, input_digest,
                                                        [list(item.path) for item in discovery + development]]))
    elif parent_rule is not None:
        raise ValueError("A parent rule requires an order transformation.")
    if family == SHORT_GAP_FAMILY:
        record["fragment_policy"] = conservative_fragment_policy()
    if family == "prompt_tfidf":
        documents = [detector.text_terms(item.prompt_text) for item in discovery]
        frequency = Counter(term for terms in documents for term in set(terms))
        idf = {term: math.log((len(documents) + 1) / (count + 1)) + 1
               for term, count in sorted(frequency.items())}
        vectors = [detector.tfidf_vector(terms, idf) for terms in documents]
        positive = detector.centroid([vector for vector, item in zip(vectors, discovery, strict=True)
                                      if item.label == 1])
        negative = detector.centroid([vector for vector, item in zip(vectors, discovery, strict=True)
                                      if item.label == 0])
        terms = sorted(set(positive) | set(negative),
                       key=lambda term: (-abs(positive.get(term, 0) - negative.get(term, 0)), term))
        states = [(min(size, len(terms)), {"family": family, "idf": idf,
                   "positive_centroid": {term: positive[term] for term in terms[:size] if term in positive},
                   "negative_centroid": {term: negative[term] for term in terms[:size] if term in negative}})
                  for size in _budgets(family, feature_budget)]
    else:
        weights = detector.feature_log_odds([detector.extract_features(item, family) for item in discovery],
                                           [item.label for item in discovery])
        features = sorted(weights, key=lambda feature: (-abs(weights[feature]), repr(feature)))
        states = [(min(size, len(features)), {"family": family,
                   "weights": [[feature, weights[feature]] for feature in features[:size]]})
                  for size in _budgets(family, feature_budget)]
    choices = []
    for count, state in states:
        scores = _scores(state, development)
        threshold = _select_presence_threshold(scores, [item.label for item in development])
        metrics = _presence_metrics([item.label for item in development],
                                    [int(score >= threshold) for score in scores], scores)
        choices.append((count, state, threshold, metrics["mcc"]))
    finite = [choice for choice in choices if choice[3] is not None]
    if finite:
        best = max(choice[3] for choice in finite)
        chosen = min((choice for choice in finite if choice[3] >= best - 0.02),
                     key=lambda choice: (choice[0], -choice[3]))
    else:
        chosen = min(choices, key=lambda choice: choice[0])
    count, state, threshold, mcc = chosen
    record.update(feature_count=count, threshold=threshold, development_mcc=mcc)
    return FrozenPresenceRule(_json({"runtime_revision": RUNTIME_REVISION,
        "response_overlap_policy": RESPONSE_OVERLAP_POLICY,
        "response_content_overlap": response_content_overlap(references),
        "concept_id": combined[0].concept_id, "model_group": model_group,
        "record": record, "state": state, "order_revision": ORDER_REVISION,
        "preparation_inputs_sha256": input_digest,
        "development_candidates": [{"feature_count": c, "threshold": t, "mcc": m}
                                   for c, _, t, m in choices]}))


def _budgets(family, limit):
    sizes = (1,) if family in INDIVIDUAL else (1, 2, 4, 8, 16, 32, 64)
    return sorted({size for size in sizes if size <= limit} | {limit})


def fit_presence_order_controls(parent_rule, *, discovery, development):
    payload = json.loads(parent_rule.payload)
    record = payload["record"]
    if record["family"] not in ORDERED:
        raise ValueError("Order controls require an ordered feature family.")
    return {transform: fit_presence_rule(
        family=record["family"], discovery=discovery, development=development,
        feature_budget=record["feature_budget"], model_group=payload["model_group"],
        source_revision=record["source_revision"], transform=transform, parent_rule=parent_rule,
    ) for transform in ("shuffle", "reverse")}


def _dependencies(row):
    """Keep recurring development text together in paired compression sampling."""
    return list(response_provenance_keys(row)) + [("text", row["split"], row["content_sha256"])]


def presence_automaton_evidence(automaton, reconstruction_metadata):
    """Check actual graph sizes and bind the supplied reconstruction audit."""
    metadata = deepcopy(reconstruction_metadata)
    if (metadata.get("labels_used_in_merging") is not False
            or metadata.get("development_answers_used_in_merging") is not False
            or metadata.get("test_answers_used_in_merging") is not False
            or metadata.get("reconstruction_configuration", {}).get("implementation_revision") != "M-06-r4"
            or metadata.get("reconstruction_configuration", {}).get("hoeffding_compatibility_alpha") != 0.18
            or metadata.get("actual_state_count") != automaton.state_count):
        raise ValueError("Discovery-only M-06-r4 reconstruction evidence is required.")
    states = set(automaton.state_profiles)
    if (len(states) != automaton.state_count or len(automaton.transitions) != automaton.transition_count
            or find_determinism_conflicts(automaton.transitions)
            or any(row["source"] not in states or row["target"] not in states
                   for row in automaton.transitions)):
        raise ValueError("Automaton state count or transition structure is invalid.")
    return {"actual_state_count": len(states), "automaton_sha256": _digest(automaton.to_dict()),
            "reconstruction_metadata": metadata}


def select_presence_compression(snapshots, *, concept_ids, reconstruction_ids,
                                bootstrap_repetitions, bootstrap_seed,
                                familywise_error_rate, model_group_count):
    """Select a shared exact size for one model, without test observations.

    Each snapshot supplies concept_id, reconstruction_id, automaton,
    reconstruction_metadata, rule, and development examples. Each matrix cell
    must supply all five sizes. The caller must preregister which rule supplies
    each size comparison and all bootstrap settings. This function does not
    choose that scientific policy on the caller's behalf.
    """
    if (type(bootstrap_repetitions) is not int or bootstrap_repetitions < 1
            or type(bootstrap_seed) is not int or type(model_group_count) is not int
            or model_group_count < 1 or familywise_error_rate != 0.05):
        raise ValueError("Explicit frozen bootstrap settings and unchanged .05 error rate are required.")
    cells = {(concept, reconstruction) for concept in concept_ids for reconstruction in reconstruction_ids}
    if not cells or len(set(concept_ids)) != len(concept_ids) or len(set(reconstruction_ids)) != len(reconstruction_ids):
        raise ValueError("Unique declared concepts and reconstructions are required.")
    by_size = {size: {} for size in REQUIRED_STATE_COUNTS}
    bindings = []
    groups = set()
    for snapshot in snapshots:
        cell = snapshot["concept_id"], snapshot["reconstruction_id"]
        evidence = presence_automaton_evidence(snapshot["automaton"], snapshot["reconstruction_metadata"])
        size = evidence["actual_state_count"]
        if size not in by_size or cell not in cells or cell in by_size[size]:
            raise ValueError("Missing exact size, unplanned cell, or duplicate compression snapshot.")
        examples = tuple(snapshot["development"])
        if not examples or any(item.split != "development" or item.concept_id != cell[0] for item in examples):
            raise ValueError("Compression selection accepts development examples only.")
        _validate_examples(examples, resolved=True)
        rule = snapshot["rule"]
        group = json.loads(rule.payload)["model_group"]
        groups.add(group)
        references = [presence_reference_row(item, group) for item in examples]
        if rule.record["development_sha256"] != presence_reference_digest(references):
            raise ValueError("Compression data differ from the fitted rule's development set.")
        scored = score_presence_rule(rule, examples)
        by_size[size][cell] = [{**row, "reconstruction_id": cell[1], "prediction": prediction}
                              for row, prediction in zip(references, scored["predictions"], strict=True)]
        bindings.append({"concept_id": cell[0], "reconstruction_id": cell[1], **evidence,
                         "rule_sha256": rule.sha256})
    if len(groups) != 1 or any(set(matrix) != cells for matrix in by_size.values()):
        raise ValueError("All five exact sizes and the 20000-state reference are required in every cell of one model.")
    def flatten(size):
        return [row for cell in sorted(cells) for row in sorted(by_size[size][cell],
                key=lambda row: (row["model_seed"], row["prompt_id"]))]
    reference = flatten(20000)
    components = _components([_dependencies(row) for row in reference])
    cluster_ids = sorted(set(components))
    comparisons = []
    alpha = familywise_error_rate / (4 * model_group_count)
    for size in REQUIRED_STATE_COUNTS[1:]:
        candidate = flatten(size)
        if [{key: value for key, value in row.items() if key != "prediction"} for row in reference] != [
            {key: value for key, value in row.items() if key != "prediction"} for row in candidate
        ]:
            raise ValueError("Compression sizes use different answers, labels, or source dependencies.")
        counts = []
        for rows in (reference, candidate):
            table = {cluster: [0, 0, 0, 0] for cluster in cluster_ids}
            for row, cluster in zip(rows, components, strict=True):
                label, prediction = row["presence_label"], row["prediction"]
                index = {(1, 1): 0, (0, 0): 1, (0, 1): 2, (1, 0): 3}[label, prediction]
                table[cluster][index] += 1
            counts.append(table)
        def mcc(table, sample):
            tp, tn, fp, fn = (sum(table[cluster][i] for cluster in sample) for i in range(4))
            denominator = math.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
            return (tp * tn - fp * fn) / denominator if denominator else None
        estimates = [mcc(table, cluster_ids) for table in counts]
        rng = random.Random(bootstrap_seed)
        losses = []
        undefined = 0
        for _ in range(bootstrap_repetitions):
            sample = [cluster_ids[rng.randrange(len(cluster_ids))] for _ in cluster_ids]
            left, right = (mcc(table, sample) for table in counts)
            if left is None or right is None:
                undefined += 1
            else:
                losses.append(left - right)
        upper = None
        if not undefined and None not in estimates:
            losses.sort()
            upper = losses[max(0, math.ceil((1 - alpha) * len(losses)) - 1)]
        comparisons.append({"state_count": size, "loss_upper": upper,
            "estimated_loss": None if None in estimates else estimates[0] - estimates[1],
            "undefined_bootstrap_draws": undefined, "comparison_alpha": alpha,
            "admissible": upper is not None and upper <= 0.02})
    reference_mcc = _presence_metrics([row["presence_label"] for row in reference],
                                     [row["prediction"] for row in reference],
                                     [float(row["prediction"]) for row in reference])["mcc"]
    if reference_mcc is None:
        raise ValueError("Undefined development MCC for the exact reference size.")
    admissible = [20000] + [row["state_count"] for row in comparisons if row["admissible"]]
    selected = min(admissible)
    evidence = {"model_group": next(iter(groups)), "snapshots": bindings,
        "response_overlap_policy": RESPONSE_OVERLAP_POLICY,
        "response_content_overlap": response_content_overlap(reference),
        "development_rows_by_size": {str(size): flatten(size) for size in REQUIRED_STATE_COUNTS},
        "comparisons": comparisons, "joined_family_count": len(cluster_ids),
        "bootstrap_repetitions": bootstrap_repetitions, "bootstrap_seed": bootstrap_seed,
        "familywise_error_rate": familywise_error_rate, "model_group_count": model_group_count,
        "mcc_aggregation": "pooled_development_confusion_counts"}
    return {"selection_split": "development", "reference_state_count": 20000,
        "selected_state_count": selected, "attained_state_counts": list(REQUIRED_STATE_COUNTS),
        "paired_family_selection": True, "multiplicity_adjusted": True,
        "loss_upper": 0.0 if selected == 20000 else next(row["loss_upper"] for row in comparisons
                                                       if row["state_count"] == selected),
        "evidence_sha256": _digest(evidence), "evidence": evidence}


@dataclass(frozen=True)
class FrozenPresenceRuntime:
    payload: str

    @property
    def sha256(self):
        return hashlib.sha256(self.payload.encode("utf-8")).hexdigest()


def freeze_presence_runtime(plan, preparation, reference_rows, rules: Mapping) -> FrozenPresenceRuntime:
    """Bind real saved rules to inference records, never replace missing evidence.

    ``rules`` is keyed by (concept_id, model_group, reconstruction_id, rule_id).
    A control rule_id is ``family:shuffle`` or ``family:reverse``. Preparation
    records retain the existing inference schema and compression evidence.
    """
    frozen = freeze_presence_inference(plan, preparation, reference_rows)
    expected = {}
    for prepared in preparation:
        prefix = tuple(prepared[key] for key in ("concept_id", "model_group", "reconstruction_id"))
        compression = prepared.get("compression", {})
        if compression.get("selected_state_count") is not None:
            evidence = compression.get("evidence")
            if not isinstance(evidence, dict) or _digest(evidence) != compression.get("evidence_sha256"):
                raise ValueError("Runtime freeze requires retained compression evidence, not a size-selection attestation.")
            if evidence.get("model_group") != prefix[1]:
                raise ValueError("Compression evidence belongs to a different model group.")
            selected = [row for row in evidence.get("snapshots", []) if
                        (row["concept_id"], row["reconstruction_id"], row["actual_state_count"])
                        == (prefix[0], prefix[2], compression["selected_state_count"])]
            if len(selected) != 1 or selected[0]["automaton_sha256"] != prepared.get("automaton_sha256"):
                raise ValueError("Selected automaton differs from the retained compression evidence.")
        candidates = dict(prepared.get("candidates", {}))
        for family, controls in prepared.get("order_controls", {}).items():
            candidates.update({family + ":" + transform: record for transform, record in controls.items()})
        for name, record in candidates.items():
            expected[(*prefix, name)] = record
    if set(rules) != set(expected):
        raise ValueError("Saved artifacts must exactly match all prepared rules.")
    for key, rule in rules.items():
        payload = json.loads(rule.payload)
        if (payload.get("runtime_revision") != RUNTIME_REVISION or rule.record != expected[key]
                or payload["concept_id"] != key[0] or payload["model_group"] != key[1]):
            raise ValueError("Saved rule content differs from its preparation record.")
    return FrozenPresenceRuntime(_json({"runtime_revision": RUNTIME_REVISION,
        "inference_payload": frozen.payload, "inference_sha256": frozen.sha256,
        "rules": [{"key": list(key), "payload": rules[key].payload} for key in sorted(rules)]}))


def evaluate_presence_runtime(frozen: FrozenPresenceRuntime, mapped_examples: Mapping) -> dict:
    """Score frozen test/control examples and retain every planned outcome.

    Mappings use (concept_id, model_group, reconstruction_id) keys. They must
    contain the same full answers as the frozen reference, not separately
    sampled answers per reconstruction. Unknown labels remain unknown.
    """
    payload = json.loads(frozen.payload)
    if payload.get("runtime_revision") != RUNTIME_REVISION:
        raise ValueError("Incompatible presence runtime. Use its original implementation or a new pretest freeze.")
    inference = FrozenPresenceInference(payload["inference_payload"])
    data = json.loads(inference.payload)
    rules = {tuple(row["key"]): FrozenPresenceRule(row["payload"]) for row in payload["rules"]}
    verified = freeze_presence_runtime(data["plan"], data["preparation"], data["reference_rows"], rules)
    if verified.payload != frozen.payload:
        raise ValueError("Runtime snapshot or saved rules changed.")
    required = {(concept, group, reconstruction) for concept in data["plan"]["concept_ids"]
                for group, spec in data["plan"]["model_groups"].items()
                for reconstruction in spec["reconstruction_ids"]}
    if set(mapped_examples) != required:
        raise ValueError("The complete declared model/concept/reconstruction matrix is required.")
    examples_by_key = {}
    # Validate all mappings before generating the first test prediction.
    for key in sorted(required):
        examples = tuple(mapped_examples[key])
        _validate_examples(examples)
        expected = [row for row in data["reference_rows"] if
                    (row["concept_id"], row["model_group"]) == key[:2]
                    and row["split"] in ("test", "control")]
        actual = [presence_reference_row(item, key[1]) for item in examples]
        if presence_reference_digest(actual) != presence_reference_digest(expected):
            raise ValueError("Mapped test/control answers differ from the frozen reference.")
        examples_by_key[key] = examples
    readiness = evaluate_presence_inference(inference, [])
    blocked = {(row["concept_id"], row["model_group"]) for row in readiness["outcomes"]
               if row["scoring_blocking_reasons"]}
    observations = []
    for key, rule in sorted(rules.items()):
        if key[:2] in blocked:
            continue
        examples = examples_by_key[key[:3]]
        scored = score_presence_rule(rule, examples)
        observations.extend({**presence_reference_row(item, key[1]),
            "reconstruction_id": key[2], "rule_id": key[3], "rule_sha256": rule.sha256,
            "freeze_sha256": inference.sha256, "prediction": prediction, "score": score}
            for item, prediction, score in zip(examples, scored["predictions"], scored["scores"], strict=True))
    result = evaluate_presence_inference(inference, observations)
    return {"runtime_revision": RUNTIME_REVISION, "runtime_sha256": frozen.sha256,
            "inference": result, "observations": observations,
            "production_ready": False, "real_model_validation": "external_prerequisite"}


def export_presence_runtime(path, frozen: FrozenPresenceRuntime, result, *, observation_cells=None):
    """Atomically retain rules, references, predictions, and recomputed inference.

    A saved report is not a completion marker or an experiment release. The
    original frozen runtime and its digest must be retained before test scoring.
    ``result=None`` persists that pretest snapshot without a result claim.
    """
    data = json.loads(frozen.payload)
    inference = FrozenPresenceInference(data["inference_payload"])
    if result is not None:
        if result.get("runtime_sha256") != frozen.sha256:
            raise ValueError("Result belongs to another frozen runtime.")
        if observation_cells is None:
            recomputed = evaluate_presence_inference(inference, result["observations"])
        else:
            from .presence_inference import combine_presence_inference_cells

            if "observations" in result:
                raise ValueError("Export requires either inline observations or cell artifacts, not both.")
            recomputed = combine_presence_inference_cells(inference, (
                evaluate_presence_inference(inference, rows, cells=[cell]) for cell, rows in observation_cells))
        if recomputed != result["inference"]:
            raise ValueError("Exported inference differs from the saved observations.")
    output = {"runtime_sha256": frozen.sha256, "frozen_runtime": data, "result": result,
              "production_ready": False}
    encoded = _json(output)
    path = Path(path)
    if path.exists() and result is not None:
        previous = json.loads(path.read_text(encoding="utf-8"))
        if previous.get("result") is None:
            raise ValueError("Retain the pretest snapshot and export final results to a separate path.")
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix="." + path.name + ".", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(encoded + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return {"path": str(path), "runtime_sha256": frozen.sha256,
            "file_sha256": hashlib.sha256((encoded + "\n").encode("utf-8")).hexdigest()}
