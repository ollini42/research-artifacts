"""Explicitly approved descriptive levels for the original V15.3 metrics."""
from __future__ import annotations

from collections import Counter
import math

REVISION = "E-07-exploratory-levels-r1"
ROLE_ORDER = ("single_state", "state_set", "path", "answer_tokens", "answer_length")
THRESHOLDS = {"recognition": 0.20, "combination": 0.05, "order": 0.03, "text": 0.02}


def mean_three(values):
    if len(values) != 3:
        raise ValueError("Exactly three reconstructions are required")
    if any(v is not None and (type(v) not in (int, float) or not math.isfinite(v)
                             or not -1 <= v <= 1) for v in values):
        raise ValueError("Invalid MCC")
    return math.fsum(values) / 3 if all(v is not None for v in values) else None


def select_roles(validation):
    means = {role: mean_three(validation[role]) for role in ROLE_ORDER}

    def best(options):
        available = [role for role in options if means[role] is not None]
        return min(available, key=lambda r: (-means[r], ROLE_ORDER.index(r))) if available else None

    return {"recognition": best(("single_state", "state_set", "path")),
            "combination": best(("state_set", "path")),
            "text": best(("answer_tokens", "answer_length"))}, means


def conjunction(*values):
    if any(v is False for v in values):
        return False
    return None if any(v is None for v in values) else True


def evaluate_case(source, validation):
    if len(source["reconstruction_ids"]) != 3 or len(set(source["reconstruction_ids"])) != 3:
        raise ValueError("Reconstruction identities must be unique")
    selected, validation_means = select_roles(validation)
    performance = source["performance"]
    for role in ROLE_ORDER + ("shuffled_path",):
        saved = performance[role]["mcc"]
        calculated = mean_three(saved["per_reconstruction"])
        stored = saved["mean"]
        if (calculated is None) != (stored is None) or (calculated is not None and
                not math.isclose(calculated, stored, rel_tol=0, abs_tol=1e-15)):
            raise ValueError("Original mean and per-reconstruction MCC disagree")

    def mcc(role):
        return performance[role]["mcc"]["mean"] if role else None

    def difference(a, b):
        x, y = mcc(a), mcc(b)
        return x - y if x is not None and y is not None else None

    estimates = {
        "recognition": mcc(selected["recognition"]),
        "combination": difference(selected["combination"], "single_state"),
        "order": difference("path", "shuffled_path") if selected["combination"] == "path" else None,
        "text": difference(selected["combination"], selected["text"]),
    }
    criteria = {}
    for name, estimate in estimates.items():
        required = name != "order" or selected["combination"] == "path"
        criteria[name] = {"estimate": estimate, "threshold": THRESHOLDS[name], "required": required,
                          "passed": (True if not required else
                                     None if estimate is None else estimate >= THRESHOLDS[name])}
    l1 = criteria["recognition"]["passed"]
    l2 = conjunction(l1, criteria["combination"]["passed"], criteria["order"]["passed"])
    l3 = conjunction(l2, criteria["text"]["passed"])
    levels = {"L1": l1, "L2": l2, "L3": l3}
    positive = [i for i, value in enumerate((l1, l2, l3), 1) if value is True]
    highest = max(positive) if positive else (0 if l1 is False else None)
    return {
        "revision": REVISION, "concept_id": source["concept_id"], "model_group": source["model_group"],
        "reconstruction_ids": source["reconstruction_ids"],
        "selected_roles": selected, "validation_mcc": validation, "validation_means": validation_means,
        "selection": "highest_mean_validation_MCC_exact_ties_fixed_role_order",
        "criteria": criteria, "levels": levels, "highest_level": highest,
        "unmet_criteria": [k for k, v in criteria.items() if v["required"] and v["passed"] is False],
        "undefined_criteria": [k for k, v in criteria.items() if v["required"] and v["passed"] is None],
        "diagnostics_affect_decision": False, "simultaneous_guarantee": False,
        "source_summary": source,
    }


def summarize(cases):
    identities = [(c["concept_id"], c["model_group"]) for c in cases]
    if len(set(identities)) != len(identities):
        raise ValueError("Duplicate case")
    result = {}
    for group in ["all"] + sorted({c["model_group"] for c in cases}):
        rows = cases if group == "all" else [c for c in cases if c["model_group"] == group]
        counts = Counter(str(c["highest_level"]) for c in rows)
        result[group] = {
            "total": len(rows),
            "exclusive": {name: counts.get(str(level), 0) for name, level in
                          (("none", 0), ("L1", 1), ("L2", 2), ("L3", 3), ("undefined", None))},
            "cumulative": {name: sum(c["levels"][name] is True for c in rows)
                           for name in ("L1", "L2", "L3")},
            "selected_combination": dict(Counter(c["selected_roles"]["combination"] for c in rows)),
        }
    return result
