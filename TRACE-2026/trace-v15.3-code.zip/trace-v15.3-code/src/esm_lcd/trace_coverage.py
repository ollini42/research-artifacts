"""Describe observed mapping gaps without inventing graph transitions."""

from __future__ import annotations

from collections import Counter
import hashlib
import gzip
import json
from pathlib import Path
from typing import Sequence


SHORT_GAP_FAMILY = "short_gap_fragment_pair"


def conservative_fragment_policy() -> dict:
    """V14-informed restriction, not a fitted semantic acceptance threshold."""
    return {
        "revision": "G-01", "maximum_gaps_per_occurrence": 1,
        "maximum_gap_tokens": 1, "exact_transitions_per_fragment": 2,
        "scope": "one_descriptor_occurrence_not_whole_answer",
        "joins_create_graph_edges": False, "recursive_fragment_joining": False,
        "role": "conservative_extrapolation_from_V14_not_presence_calibration",
    }


def short_gap_fragment_features(path: Sequence[int], kinds: Sequence[str]) -> set[tuple]:
    """Two observed two-edge fragments with one explicit missing-token marker.

Never return concatenated paths or edges. Each occurrence contains just one
gap. Multiple occurrences may exist in an answer but are not recursively
joined. Exact features remain available when a fragment pair is rejected.
"""
    if (len(path) != len(kinds) + 1 or any(type(state) is not int for state in path)
            or any(kind not in {"exact", "reconstruction_exact", "unknown", "global_fallback"}
                   for kind in kinds)):
        raise ValueError("Fragment extraction requires complete mapping provenance.")
    if any(kind == "unknown" and path[i] != path[i + 1] for i, kind in enumerate(kinds)):
        raise ValueError("Unknown tokens cannot assert a graph transition.")
    exact = [kind in {"exact", "reconstruction_exact"} for kind in kinds]
    features = set()
    for index in range(2, len(kinds) - 2):
        if not exact[index] and all(exact[index - 2:index]) and all(exact[index + 1:index + 3]):
            features.add((
                "fragment_pair", "G-01", ("exact", *path[index - 2:index + 1]),
                ("gap_tokens", 1), ("exact", *path[index + 1:index + 4]),
            ))
    return features


def summarize_mapping_gaps(kinds: Sequence[str], minimum_segment_tokens: int = 2) -> dict:
    """Count every original token position, including unknown tokens.

    The minimum is the length required by a feature, not a learned acceptance
    threshold. Missing coverage does not decide whether a concept is absent.
    """
    if type(minimum_segment_tokens) is not int or minimum_segment_tokens < 1:
        raise ValueError("Minimum segment length must be a positive integer.")
    if any(kind not in {"exact", "reconstruction_exact", "global_fallback", "unknown"}
           for kind in kinds):
        raise ValueError("Unknown token mapping provenance.")
    exact_lengths, gap_lengths = [], []
    previous = None
    length = 0
    for kind in kinds:
        exact = kind in {"exact", "reconstruction_exact"}
        if previous is not None and previous != exact:
            (exact_lengths if previous else gap_lengths).append(length)
            length = 0
        previous = exact
        length += 1
    if previous is not None:
        (exact_lengths if previous else gap_lengths).append(length)
    total = len(kinds)
    return {
        "token_positions": total,
        "non_exact_token_positions": sum(gap_lengths),
        "gap_count": len(gap_lengths),
        "gap_length_histogram": dict(sorted(Counter(gap_lengths).items())),
        "exact_segment_count": len(exact_lengths),
        "mean_exact_segment_length": sum(exact_lengths) / len(exact_lengths) if exact_lengths else 0.0,
        "usable_exact_segment_count": sum(n >= minimum_segment_tokens for n in exact_lengths),
        "exact_transition_rate": sum(exact_lengths) / total if total else None,
        "ordered_features_cross_mapping_gaps": False,
        "concept_presence_decision": None,
    }


def load_v14_mapping_reference(path: Path) -> dict:
    """Use one recorded audit per corpus rather than repeated policy/concept rows."""
    content = path.read_bytes()
    evidence = json.loads(content)
    fields = (
        "total_tokens", "exact_transition_rate", "global_label_fallback_rate",
        "unknown_token_rate", "exact_contiguous_segment_count",
        "mean_exact_contiguous_segment_length",
    )
    audits = {}
    for row in evidence["detector_results"]:
        if row["policy_id"] != "S001000":
            continue
        audit = {field: row["inductive_mapping"][field] for field in fields}
        if row["model_seed"] in audits and audits[row["model_seed"]] != audit:
            raise ValueError("V14 mapping audits disagree within a corpus.")
        audits[row["model_seed"]] = audit
    if not audits:
        raise ValueError("V14 reference contains no selected-policy mapping audits.")
    return {
        "source_campaign": "V14.4",
        "source_sha256": hashlib.sha256(content).hexdigest(),
        "role": "retrospective_engineering_reference_not_acceptance_threshold",
        "policy_id_is_not_attained_state_count": True,
        "corpus_audits": audits,
        "contiguous_gap_counts_available": False,
        "gap_length_threshold": None,
        "minimum_coverage_threshold": None,
    }


def audit_mapping_provenance(paths: Sequence[Path], policy_id: str) -> dict:
    """Stream saved token provenance and count contiguous gaps per answer.

    A partial set of downloaded shards is reported as such. This read-only audit
    does not choose a coverage threshold or recompute historical predictions.
    """
    seen = set()
    models = {}
    concepts = set()
    sources = []
    for path in paths:
        h = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                h.update(chunk)
        sources.append({"path": str(path), "sha256": h.hexdigest()})
        key = None
        kinds = []

        def finish():
            if key is None:
                return
            if key in seen:
                raise ValueError("Duplicate answer provenance across input shards.")
            seen.add(key)
            summary = summarize_mapping_gaps(kinds)
            out = models.setdefault(key[0], {
                "answer_count": 0, "token_positions": 0,
                "non_exact_token_positions": 0, "gap_count": 0,
                "answers_with_gaps": 0, "exact_segment_count": 0,
                "usable_exact_segment_count": 0, "gap_length_histogram": Counter(),
            })
            out["answer_count"] += 1
            out["answers_with_gaps"] += summary["gap_count"] > 0
            for field in ("token_positions", "non_exact_token_positions", "gap_count",
                          "exact_segment_count", "usable_exact_segment_count"):
                out[field] += summary[field]
            out["gap_length_histogram"].update(summary["gap_length_histogram"])

        opener = gzip.open if path.suffix == ".gz" else open
        with opener(path, "rt", encoding="utf-8") as handle:
            for line in handle:
                row = json.loads(line)
                if row["policy_id"] != policy_id:
                    continue
                next_key = (row["model_seed"], row["prompt_id"])
                if next_key != key:
                    finish()
                    key, kinds = next_key, []
                if type(row["token_position"]) is not int or row["token_position"] != len(kinds):
                    raise ValueError("Token provenance is incomplete or not in original order.")
                concepts.add(row["concept_id"])
                kinds.append(row["mapping_kind"])
        finish()
    for out in models.values():
        out["gap_length_histogram"] = dict(sorted(out["gap_length_histogram"].items()))
        out["exact_transition_rate"] = (
            1.0 - out["non_exact_token_positions"] / out["token_positions"]
            if out["token_positions"] else None
        )
    return {
        "policy_id": policy_id, "sources": sources,
        "concept_ids": sorted(concepts), "model_audits": models,
        "scope": "only_the_explicitly_supplied_provenance_shards",
        "acceptance_threshold_selected": False, "historical_predictions_changed": False,
    }
