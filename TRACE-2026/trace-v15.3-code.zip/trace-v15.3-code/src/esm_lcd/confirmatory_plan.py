"""Planning, validation, and locking for confirmatory ESM-LCD studies."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import unicodedata
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Sequence

from .config import read_config_mapping
from .audited_assurance import (
    EVALUATOR_IMPLEMENTATION_REVISION,
    RETROSPECTIVE_EVIDENCE_ROLE,
    assess_prelock_feasibility,
    retrospective_input_audit,
)


REQUIRED_CONCEPT_COLUMNS = {
    "concept_id",
    "topic_name",
    "selection_stratum",
    "confirmatory_selected",
    "expert_definition",
    "positive_criteria",
    "exclusion_criteria",
    "forbidden_lexical_cues",
    "expert_approved",
}
REQUIRED_PROMPT_COLUMNS = {
    "prompt_id",
    "concept_id",
    "split",
    "condition",
    "pair_id",
    "expected_label",
    "prompt_text",
    "expert_approved",
}
ALLOWED_SPLITS = {"discovery", "development", "test"}
PAIRED_CONDITIONS = {
    "irrelevant_original",
    "irrelevant_perturbation",
    "relevant_original",
    "relevant_toggle",
}
LEXICAL_DISJOINT_CONDITIONS = {
    "lexical_disjoint_positive",
    "lexical_disjoint_negative",
}
SCAP_REQUIRED_CONDITIONS = {
    "lexical_disjoint_positive",
    "lexical_disjoint_negative",
    "hard_negative",
    "irrelevant_original",
    "irrelevant_perturbation",
    "relevant_original",
    "relevant_toggle",
    "unseen_composition_positive",
    "unseen_composition_negative",
    "token_control_positive",
    "token_control_negative",
    "position_control_positive",
    "position_control_negative",
    "template_control_positive",
    "template_control_negative",
    "style_control_positive",
    "style_control_negative",
}
AUTOMATIC_SCAP_REQUIRED_CONDITIONS = {
    "natural_positive",
    "natural_negative",
    "lexical_disjoint_positive",
    "lexical_disjoint_negative",
    "hard_negative_keyword_topic",
    "hard_negative_llm_topic_relation",
    "hard_negative_combined",
    "irrelevant_original",
    "irrelevant_perturbation",
    "relevant_original",
    "relevant_toggle",
    "unseen_composition_positive",
    "unseen_composition_negative",
    "entity_renamed_positive",
    "entity_renamed_negative",
    "lexical_decoy_positive",
    "lexical_decoy_negative",
    "adversarial_paraphrase_positive",
    "adversarial_paraphrase_negative",
}
EXPECTED_LABEL_BY_CONDITION = {
    "natural_positive": 1,
    "natural_negative": 0,
    "lexical_matched_negative": 0,
    "lexical_disjoint_positive": 1,
    "lexical_disjoint_negative": 0,
    "hard_negative": 0,
    "hard_negative_keyword_topic": 0,
    "hard_negative_llm_topic_relation": 0,
    "hard_negative_combined": 0,
    "irrelevant_original": 1,
    "irrelevant_perturbation": 1,
    "relevant_original": 1,
    "relevant_toggle": 0,
    "unseen_composition_positive": 1,
    "unseen_composition_negative": 0,
    "token_control_positive": 1,
    "token_control_negative": 0,
    "position_control_positive": 1,
    "position_control_negative": 0,
    "template_control_positive": 1,
    "template_control_negative": 0,
    "style_control_positive": 1,
    "style_control_negative": 0,
    "entity_renamed_positive": 1,
    "entity_renamed_negative": 0,
    "lexical_decoy_positive": 1,
    "lexical_decoy_negative": 0,
    "adversarial_paraphrase_positive": 1,
    "adversarial_paraphrase_negative": 0,
}
TRUTHY = {"1", "true", "yes", "y"}
WORD_RE = re.compile(r"[a-z0-9]+")
ALLOWED_CONCEPT_TYPES = {
    "entity_anchor",
    "relation_schema",
    "binary_proposition",
}
CONDITIONAL_ASSURANCE_REQUIRED_GATES = {
    "held_out_mcc_lower_95",
    "response_coverage_lower_95",
    "evidence_response_coverage_lower_95",
    "mean_evidence_path_fraction_lower_95",
    "mean_evidence_token_count_lower_95",
    "contrastive_auc_lower_95",
    "lexical_disjoint_balanced_accuracy_lower_95",
    "hard_negative_three_mode_minimum_tnr_lower_95",
    "irrelevant_invariance_lower_95",
    "relevant_counterfactual_sensitivity_lower_95",
    "unseen_composition_balanced_accuracy_lower_95",
    "entity_renamed_balanced_accuracy_lower_95",
    "lexical_decoy_balanced_accuracy_lower_95",
    "adversarial_paraphrase_balanced_accuracy_lower_95",
    "surface_control_balanced_accuracy_lower_95",
    "matched_surface_mcc_margin",
}
BINARY_LEARNING_REQUIRED_CRITERIA = {
    "mean_development_mcc",
    "minimum_development_mcc",
    "minimum_test_mcc_lower_95",
    "minimum_positive_sensitivity_lower_95",
    "minimum_contrastive_auc_lower_95",
    "seed_prediction_jaccard",
}
SIMULTANEOUS_L1_THRESHOLDS = {
    "mean_development_mcc": 0.35,
    "minimum_development_mcc": 0.20,
    "minimum_test_mcc": 0.20,
    "minimum_positive_sensitivity": 0.65,
    "minimum_family_balanced_auc": 0.55,
    "minimum_prediction_jaccard": 0.60,
}
SIMULTANEOUS_L2_THRESHOLDS = {
    "minimum_path_gain": 0.05,
    "minimum_order_gain": 0.03,
}
SIMULTANEOUS_L3_THRESHOLDS = {"minimum_visible_text_margin": 0.02}


class ConfirmatoryInputError(ValueError):
    """Raised when a confirmatory protocol would violate its lock conditions."""


def load_confirmatory_config(path: str | Path) -> Dict[str, Any]:
    config_path = Path(path)
    raw = read_config_mapping(config_path)
    base_path = raw.pop("extends", None)
    if base_path:
        resolved_base = Path(str(base_path))
        if not resolved_base.is_absolute():
            resolved_base = (config_path.parent / resolved_base).resolve()
        base = read_config_mapping(resolved_base)
        if base.get("extends"):
            raise ConfirmatoryInputError(
                "Confirmatory config inheritance supports one level only."
            )
        raw = _deep_merge(base, raw)
    for section in ("campaign", "protocol", "resources"):
        if section not in raw or not isinstance(raw[section], dict):
            raise ConfirmatoryInputError(
                "Confirmatory config requires a '{}' mapping.".format(section)
            )
    return raw


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    merged: Dict[str, Any] = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def build_confirmatory_plan(path: str | Path) -> Dict[str, Any]:
    """Build a write-free Slurm and design plan with hard safety guards."""

    raw = load_confirmatory_config(path)
    if raw["protocol"].get("label_objective") == "concept_presence":
        raise ConfirmatoryInputError(
            "Concept-presence preparation cannot use the legacy proposition job plan. "
            "The new label audit, inference and execution chain are not released."
        )
    campaign = raw["campaign"]
    resources = raw["resources"]
    phases = resources.get("phases")
    if not isinstance(phases, list) or not phases:
        raise ConfirmatoryInputError("resources.phases must be a non-empty list.")

    max_jobs = _positive_int(campaign, "max_slurm_jobs")
    max_running = _positive_int(campaign, "max_running_jobs")
    deadline_hours = _positive_float(campaign, "deadline_hours")
    partition_limits = resources.get("partition_limits_hours", {})
    if not isinstance(partition_limits, dict):
        raise ConfirmatoryInputError(
            "resources.partition_limits_hours must be a mapping."
        )
    _validate_design_guards(raw)

    phase_by_name: Dict[str, Dict[str, Any]] = {}
    for raw_phase in phases:
        if not isinstance(raw_phase, dict):
            raise ConfirmatoryInputError("Each resources.phases entry must be a mapping.")
        name = str(raw_phase.get("name", "")).strip()
        if not name or name in phase_by_name:
            raise ConfirmatoryInputError("Phase names must be non-empty and unique.")
        task_count = _positive_int(raw_phase, "task_count")
        max_concurrent = _positive_int(raw_phase, "max_concurrent")
        time_limit_hours = _positive_float(raw_phase, "time_limit_hours")
        estimated_hours = _positive_float(raw_phase, "estimated_hours")
        _validate_phase_expansion(name, raw_phase, task_count)
        if max_concurrent > task_count:
            raise ConfirmatoryInputError(
                "Phase '{}' max_concurrent exceeds task_count.".format(name)
            )
        if max_concurrent > max_running:
            raise ConfirmatoryInputError(
                "Phase '{}' exceeds campaign.max_running_jobs.".format(name)
            )
        partition = str(raw_phase.get("partition", "")).strip()
        if partition not in partition_limits:
            raise ConfirmatoryInputError(
                "Phase '{}' uses an unregistered partition '{}'.".format(
                    name, partition
                )
            )
        if time_limit_hours > float(partition_limits[partition]):
            raise ConfirmatoryInputError(
                "Phase '{}' exceeds the configured '{}' partition limit.".format(
                    name, partition
                )
            )
        depends_on = [str(value) for value in raw_phase.get("depends_on", [])]
        concurrency_group = str(raw_phase.get("concurrency_group", name))
        phase_by_name[name] = {
            **raw_phase,
            "name": name,
            "task_count": task_count,
            "max_concurrent": max_concurrent,
            "time_limit_hours": time_limit_hours,
            "estimated_hours": estimated_hours,
            "depends_on": depends_on,
            "concurrency_group": concurrency_group,
            "waves": int(math.ceil(task_count / max_concurrent)),
        }

    for phase in phase_by_name.values():
        unknown = sorted(set(phase["depends_on"]) - set(phase_by_name))
        if unknown:
            raise ConfirmatoryInputError(
                "Phase '{}' has unknown dependencies: {}.".format(
                    phase["name"], ", ".join(unknown)
                )
            )
    order = _topological_order(phase_by_name)

    total_jobs = sum(phase["task_count"] for phase in phase_by_name.values())
    if total_jobs > max_jobs:
        raise ConfirmatoryInputError(
            "Campaign requires {} Slurm tasks, exceeding the cap of {}.".format(
                total_jobs, max_jobs
            )
        )

    group_concurrency: Counter[str] = Counter()
    for phase in phase_by_name.values():
        group_concurrency[phase["concurrency_group"]] += phase["max_concurrent"]
    peak_concurrency = max(group_concurrency.values(), default=0)
    if peak_concurrency > max_running:
        raise ConfirmatoryInputError(
            "A concurrency group requires {} simultaneous jobs, exceeding {}.".format(
                peak_concurrency, max_running
            )
        )

    estimated_finish: Dict[str, float] = {}
    hard_finish: Dict[str, float] = {}
    for name in order:
        phase = phase_by_name[name]
        estimated_start = max(
            (estimated_finish[dep] for dep in phase["depends_on"]), default=0.0
        )
        hard_start = max(
            (hard_finish[dep] for dep in phase["depends_on"]), default=0.0
        )
        estimated_finish[name] = estimated_start + (
            phase["estimated_hours"] * phase["waves"]
        )
        hard_finish[name] = hard_start + (
            phase["time_limit_hours"] * phase["waves"]
        )

    estimated_critical_path = max(estimated_finish.values(), default=0.0)
    hard_critical_path = max(hard_finish.values(), default=0.0)
    if hard_critical_path > deadline_hours:
        raise ConfirmatoryInputError(
            "The phase time-limit envelope is {:.1f} h, exceeding {:.1f} h.".format(
                hard_critical_path, deadline_hours
            )
        )

    ordered_phases = [phase_by_name[name] for name in order]
    planned_gpu_tasks = sum(
        phase["task_count"]
        for phase in phase_by_name.values()
        if int(phase.get("gpus_per_task", 0)) > 0
    )
    planned_gpu_time_limit_hours = sum(
        phase["task_count"]
        * int(phase.get("gpus_per_task", 0))
        * phase["time_limit_hours"]
        for phase in phase_by_name.values()
    )
    packed_subtasks = sum(
        int(phase.get("packed_subtask_count", 0))
        for phase in phase_by_name.values()
    )
    return {
        "campaign_id": str(campaign.get("id", "confirmatory-study")),
        "max_slurm_jobs": max_jobs,
        "planned_slurm_jobs": total_jobs,
        "remaining_job_headroom": max_jobs - total_jobs,
        "max_running_jobs": max_running,
        "planned_peak_concurrency": peak_concurrency,
        "planned_gpu_tasks": planned_gpu_tasks,
        "planned_gpu_time_limit_hours": planned_gpu_time_limit_hours,
        "planned_packed_subtasks": packed_subtasks,
        "deadline_hours": deadline_hours,
        "estimated_compute_critical_path_hours": estimated_critical_path,
        "time_limit_critical_path_hours": hard_critical_path,
        "scheduler_queue_time_included": False,
        "phase_order": order,
        "phases": ordered_phases,
        "concurrency_groups": dict(sorted(group_concurrency.items())),
        "hypotheses": raw.get("hypotheses", {}),
        "locked_reconstructions": raw.get("locked_reconstructions", []),
        "protocol": raw["protocol"],
    }


def _validate_design_guards(raw: Dict[str, Any]) -> None:
    guards = raw.get("design_guards", {})
    if not isinstance(guards, dict):
        raise ConfirmatoryInputError("design_guards must be a mapping.")
    if guards.get("require_complete_scap"):
        allowed = set(raw["protocol"].get("allowed_conditions", []))
        missing = sorted(SCAP_REQUIRED_CONDITIONS - allowed)
        if missing:
            raise ConfirmatoryInputError(
                "Complete SCAP requires conditions: {}.".format(", ".join(missing))
            )
        if len(raw["protocol"].get("scap_gate_lower_bounds", {})) < 5:
            raise ConfirmatoryInputError("Complete SCAP requires five locked gates.")
        if len(raw["protocol"].get("scap_mandatory_prerequisites", {})) < 4:
            raise ConfirmatoryInputError(
                "Complete SCAP requires surface, stability, baseline, and transfer prerequisites."
            )
    if guards.get("require_automatic_scap"):
        if raw["protocol"].get("approval_mode") != "automatic_labels":
            raise ConfirmatoryInputError(
                "Automatic SCAP requires protocol.approval_mode=automatic_labels."
            )
        allowed = set(raw["protocol"].get("allowed_conditions", []))
        missing = sorted(AUTOMATIC_SCAP_REQUIRED_CONDITIONS - allowed)
        if missing:
            raise ConfirmatoryInputError(
                "Automatic SCAP requires conditions: {}.".format(", ".join(missing))
            )
        if len(raw["protocol"].get("automatic_gate_lower_bounds", {})) < 7:
            raise ConfirmatoryInputError(
                "Automatic SCAP requires at least seven locked challenge gates."
            )
    if guards.get("require_transfer_model"):
        campaign = raw["campaign"]
        if not campaign.get("primary_response_model") or not campaign.get(
            "transfer_response_model"
        ):
            raise ConfirmatoryInputError(
                "A primary and transfer response model are required."
            )
        if campaign["primary_response_model"] == campaign["transfer_response_model"]:
            raise ConfirmatoryInputError("Transfer model must differ from primary model.")
    if guards.get("require_conditional_concept_assurance"):
        _validate_conditional_concept_assurance(raw["protocol"])
    if guards.get("require_binary_concept_learning"):
        _validate_binary_concept_learning(raw["protocol"])
    if guards.get("require_simultaneous_nested_learning"):
        _validate_simultaneous_nested_learning(raw["protocol"])
        if (
            raw["protocol"].get("simultaneous_nested_learning", {}).get("version")
            == "E-05"
        ):
            _validate_method_versions(raw["protocol"])
            _validate_reconstruction_guarantees(
                raw.get("locked_reconstructions", []),
                merger_version=raw["protocol"]["method_versions"]["merger"],
                implementation_revision=raw["protocol"]["method_versions"].get(
                    "merger_implementation_revision"
                ),
            )
    required_sections = {
        "require_neural_interventions": "neural_realization",
        "require_memory_baselines": "external_memory",
        "require_xai_evaluation": "xai_evaluation",
        "require_training_controls": "training_evaluation",
    }
    for guard, section in required_sections.items():
        if guards.get(guard) and not isinstance(raw.get(section), dict):
            raise ConfirmatoryInputError(
                "Design guard '{}' requires the '{}' mapping.".format(guard, section)
            )


def _validate_conditional_concept_assurance(protocol: Dict[str, Any]) -> None:
    settings = protocol.get("conditional_concept_assurance")
    if not isinstance(settings, dict) or not settings.get("enabled"):
        raise ConfirmatoryInputError(
            "Conditional concept assurance must be enabled by the protocol."
        )
    selection = settings.get("selection")
    if not isinstance(selection, dict):
        raise ConfirmatoryInputError(
            "Conditional concept assurance requires a selection mapping."
        )
    required_selection = {
        "minimum_development_mcc",
        "minimum_development_surface_margin",
        "minimum_state_set_mcc_gain",
        "minimum_path_mcc_gain",
        "minimum_order_mcc_gain",
        "sparse_state_max_features",
    }
    missing_selection = sorted(required_selection - set(selection))
    if missing_selection:
        raise ConfirmatoryInputError(
            "Conditional concept assurance lacks selection values: {}.".format(
                ", ".join(missing_selection)
            )
        )
    gates = settings.get("gates")
    if not isinstance(gates, dict):
        raise ConfirmatoryInputError(
            "Conditional concept assurance requires locked test gates."
        )
    missing_gates = sorted(CONDITIONAL_ASSURANCE_REQUIRED_GATES - set(gates))
    if missing_gates:
        raise ConfirmatoryInputError(
            "Conditional concept assurance lacks gates: {}.".format(
                ", ".join(missing_gates)
            )
        )
    for name, value in gates.items():
        numeric = float(value)
        if name == "mean_evidence_token_count_lower_95":
            if numeric < 0.0:
                raise ConfirmatoryInputError(
                    "Evidence token count threshold must be non-negative."
                )
        elif not -1.0 <= numeric <= 1.0:
            raise ConfirmatoryInputError(
                "Conditional assurance gate '{}' must be in [-1, 1].".format(name)
            )
    if int(settings.get("minimum_seed_count", 0)) < 2:
        raise ConfirmatoryInputError(
            "Conditional concept assurance requires at least two generation seeds."
        )


def _validate_binary_concept_learning(protocol: Dict[str, Any]) -> None:
    settings = protocol.get("binary_concept_learning")
    if not isinstance(settings, dict) or not settings.get("enabled"):
        raise ConfirmatoryInputError(
            "The binary concept-learning test must be enabled by the protocol."
        )
    if int(settings.get("minimum_reconstruction_count", 0)) < 3:
        raise ConfirmatoryInputError(
            "The binary concept-learning test requires at least three reconstructions."
        )
    if int(settings.get("bootstrap_repetitions", 0)) < 10000:
        raise ConfirmatoryInputError(
            "The binary concept-learning test requires at least 10,000 bootstrap repetitions."
        )
    model_groups = settings.get("model_groups")
    if not isinstance(model_groups, dict) or not model_groups:
        raise ConfirmatoryInputError(
            "The binary concept-learning test requires named model groups."
        )
    minimum = int(settings["minimum_reconstruction_count"])
    labels = []
    for name, group_labels in model_groups.items():
        if not isinstance(group_labels, list) or len(group_labels) < minimum:
            raise ConfirmatoryInputError(
                "Model group '{}' has fewer than {} reconstructions.".format(
                    name, minimum
                )
            )
        labels.extend(str(label) for label in group_labels)
    if len(labels) != len(set(labels)):
        raise ConfirmatoryInputError(
            "Binary concept-learning model groups must be disjoint."
        )

    threshold_sets = {}
    for threshold_name in (
        "lenient_thresholds",
        "thresholds",
        "strict_thresholds",
    ):
        values = settings.get(threshold_name)
        if not isinstance(values, dict):
            raise ConfirmatoryInputError(
                "binary_concept_learning.{} must be a mapping.".format(
                    threshold_name
                )
            )
        missing = sorted(BINARY_LEARNING_REQUIRED_CRITERIA - set(values))
        if missing:
            raise ConfirmatoryInputError(
                "Binary learning thresholds lack criteria: {}.".format(
                    ", ".join(missing)
                )
            )
        threshold_sets[threshold_name] = {
            name: float(values[name]) for name in BINARY_LEARNING_REQUIRED_CRITERIA
        }
    for criterion in BINARY_LEARNING_REQUIRED_CRITERIA:
        lenient = threshold_sets["lenient_thresholds"][criterion]
        nominal = threshold_sets["thresholds"][criterion]
        strict = threshold_sets["strict_thresholds"][criterion]
        if not -1.0 <= lenient <= nominal <= strict <= 1.0:
            raise ConfirmatoryInputError(
                "Binary learning thresholds for '{}' must be ordered in [-1, 1]."
                .format(criterion)
            )


def _validate_simultaneous_nested_learning(protocol: Dict[str, Any]) -> None:
    settings = protocol.get("simultaneous_nested_learning")
    if not isinstance(settings, dict) or not settings.get("enabled"):
        raise ConfirmatoryInputError(
            "The simultaneous nested concept-learning test must be enabled."
        )
    version = settings.get("version")
    if version == "E-05":
        _validate_audited_nested_learning(protocol, settings)
        return
    if version != "E-04":
        raise ConfirmatoryInputError(
            "The simultaneous nested concept-learning version must be E-04 or E-05."
        )
    if "total_error_budget" not in settings:
        raise ConfirmatoryInputError(
            "E-04 requires an explicit total_error_budget."
        )
    eta = float(settings["total_error_budget"])
    if not 0.0 < eta < 1.0:
        raise ConfirmatoryInputError("E-04 total_error_budget must be in (0, 1).")
    budgets = settings.get("concept_error_budgets")
    if not isinstance(budgets, dict) or not budgets:
        raise ConfirmatoryInputError(
            "E-04 requires explicit positive concept_error_budgets."
        )
    values = [float(value) for value in budgets.values()]
    if any(value <= 0.0 for value in values):
        raise ConfirmatoryInputError("Every E-04 concept error budget must be positive.")
    if sum(values) > eta + 1e-12:
        raise ConfirmatoryInputError(
            "The sum of E-04 concept error budgets exceeds total_error_budget."
        )
    expected_concepts = int(protocol.get("selected_concept_count", 0))
    if expected_concepts and len(budgets) != expected_concepts:
        raise ConfirmatoryInputError(
            "E-04 requires one error budget for each selected concept."
        )
    if settings.get("interval_method") != "family_level_hoeffding_union_bound":
        raise ConfirmatoryInputError(
            "E-04 interval_method must be family_level_hoeffding_union_bound."
        )
    if int(settings.get("minimum_reconstruction_count", 0)) < 3:
        raise ConfirmatoryInputError("E-04 requires at least three reconstructions.")
    if float(settings.get("representation_mcc_tolerance", -1.0)) != 0.02:
        raise ConfirmatoryInputError(
            "E-04 representation_mcc_tolerance must equal 0.02."
        )
    negative_conditions = settings.get("contrast_negative_conditions")
    if not isinstance(negative_conditions, list) or not negative_conditions:
        raise ConfirmatoryInputError(
            "E-04 requires an explicit non-empty contrast_negative_conditions list."
        )
    visible_families = settings.get("visible_text_families")
    allowed_visible = {
        "answer_token_ngram",
        "answer_position",
        "answer_template",
        "answer_length",
        "prompt_tfidf",
    }
    if (
        not isinstance(visible_families, list)
        or not visible_families
        or not set(visible_families) <= allowed_visible
    ):
        raise ConfirmatoryInputError(
            "E-04 visible_text_families must be a non-empty supported family list."
        )
    model_groups = settings.get("model_groups")
    if not isinstance(model_groups, dict) or not model_groups:
        raise ConfirmatoryInputError("E-04 requires named model groups.")
    minimum = int(settings["minimum_reconstruction_count"])
    labels = []
    for name, group_labels in model_groups.items():
        if not isinstance(group_labels, list) or len(group_labels) < minimum:
            raise ConfirmatoryInputError(
                "E-04 model group '{}' has fewer than {} reconstructions.".format(
                    name, minimum
                )
            )
        labels.extend(str(label) for label in group_labels)
    if len(labels) != len(set(labels)):
        raise ConfirmatoryInputError("E-04 model groups must be disjoint.")

    configured = settings.get("thresholds", {})
    for level, expected in (
        ("l1", SIMULTANEOUS_L1_THRESHOLDS),
        ("l2", SIMULTANEOUS_L2_THRESHOLDS),
        ("l3", SIMULTANEOUS_L3_THRESHOLDS),
    ):
        values_by_name = configured.get(level)
        if not isinstance(values_by_name, dict) or set(values_by_name) != set(expected):
            raise ConfirmatoryInputError(
                "E-04 thresholds.{} must contain exactly the locked criteria.".format(
                    level
                )
            )
        for name, value in expected.items():
            if not math.isclose(float(values_by_name[name]), value, abs_tol=1e-12):
                raise ConfirmatoryInputError(
                    "E-04 threshold '{}' must equal {:.3f}.".format(name, value)
                )
    strict = settings.get("strict_l1_thresholds")
    if not isinstance(strict, dict) or set(strict) != set(SIMULTANEOUS_L1_THRESHOLDS):
        raise ConfirmatoryInputError(
            "E-04 strict_l1_thresholds must contain every L1 criterion."
        )
    for name, nominal in SIMULTANEOUS_L1_THRESHOLDS.items():
        value = float(strict[name])
        if not nominal <= value <= 1.0:
            raise ConfirmatoryInputError(
                "E-04 strict threshold '{}' must be in [{:.3f}, 1].".format(
                    name, nominal
                )
            )

    selection = protocol.get("compression_policy_selection", {})
    if not selection.get("enabled"):
        raise ConfirmatoryInputError(
            "E-04 requires development-only compression-policy selection."
        )
    if [int(value) for value in selection.get("expected_state_counts", [])] != [
        20000,
        10000,
        5000,
        2000,
        1000,
    ]:
        raise ConfirmatoryInputError(
            "E-04 requires state-count candidates 20000, 10000, 5000, 2000, 1000."
        )
    if float(selection.get("maximum_tolerable_mcc_drop", -1.0)) != 0.02:
        raise ConfirmatoryInputError(
            "E-04 maximum_tolerable_mcc_drop must equal 0.02."
        )


def _validate_audited_nested_learning(
    protocol: Dict[str, Any], settings: Dict[str, Any]
) -> None:
    """Validate the complete, preregistered E-05 method contract."""

    if "total_error_budget" not in settings:
        raise ConfirmatoryInputError("E-05 requires an explicit total_error_budget.")
    eta = float(settings["total_error_budget"])
    if not 0.0 < eta < 1.0:
        raise ConfirmatoryInputError("E-05 total_error_budget must be in (0, 1).")
    budgets = settings.get("concept_error_budgets")
    if not isinstance(budgets, dict) or not budgets:
        raise ConfirmatoryInputError(
            "E-05 requires explicit positive concept_error_budgets."
        )
    if any(float(value) <= 0.0 for value in budgets.values()):
        raise ConfirmatoryInputError("Every E-05 concept error budget must be positive.")
    if sum(float(value) for value in budgets.values()) > eta + 1e-12:
        raise ConfirmatoryInputError(
            "The sum of E-05 concept error budgets exceeds total_error_budget."
        )
    expected_concepts = int(protocol.get("selected_concept_count", 0))
    if expected_concepts and len(budgets) != expected_concepts:
        raise ConfirmatoryInputError(
            "E-05 requires one error budget for each selected concept."
        )
    if settings.get("interval_method") != (
        "family_level_hoeffding_union_bound_with_class_constraints"
    ):
        raise ConfirmatoryInputError(
            "E-05 requires the class-constrained family-level interval method."
        )
    retrospective = settings.get("evidence_role") == RETROSPECTIVE_EVIDENCE_ROLE
    if settings.get("evidence_role") not in {
        "independent_confirmatory_evaluation", RETROSPECTIVE_EVIDENCE_ROLE
    }:
        raise ConfirmatoryInputError(
            "E-05 requires an explicit independent_confirmatory_evaluation or "
            "retrospective_reanalysis evidence_role."
        )
    if retrospective:
        if protocol.get("method_versions", {}).get("evidence_role") != RETROSPECTIVE_EVIDENCE_ROLE:
            raise ConfirmatoryInputError("Retrospective E-05 method provenance must be explicit.")
        if protocol.get("binary_concept_learning", {}).get("enabled", False):
            raise ConfirmatoryInputError("Retrospective E-05 must not enable the E-03 evaluator.")
    minimum = int(settings.get("minimum_reconstruction_count", 0))
    if minimum < 3:
        raise ConfirmatoryInputError("E-05 requires at least three reconstructions.")
    model_groups = settings.get("model_groups")
    if not isinstance(model_groups, dict) or not model_groups:
        raise ConfirmatoryInputError("E-05 requires named model groups.")
    labels = []
    for name, group_labels in model_groups.items():
        if not isinstance(group_labels, list) or not group_labels or (
            len(group_labels) < minimum and not retrospective
        ):
            raise ConfirmatoryInputError(
                "E-05 model group '{}' has fewer than {} reconstructions.".format(
                    name, minimum
                )
            )
        labels.extend(str(label) for label in group_labels)
    if len(labels) != len(set(labels)):
        raise ConfirmatoryInputError("E-05 model groups must be disjoint.")
    configured_labels = [str(value) for value in protocol.get("model_seed_labels", [])]
    if sorted(labels) != sorted(configured_labels):
        raise ConfirmatoryInputError(
            "E-05 model groups must exactly cover protocol.model_seed_labels."
        )

    contrasts = settings.get("contrast_families")
    if not isinstance(contrasts, dict) or not contrasts:
        raise ConfirmatoryInputError(
            "E-05 requires preregistered contrast_families."
        )
    claimed_negative_conditions = {
        str(value) for value in settings.get("contrast_negative_conditions", [])
    }
    covered_negative_conditions = set()
    for name, spec in contrasts.items():
        if not isinstance(spec, dict):
            raise ConfirmatoryInputError(
                "E-05 contrast family '{}' must be a mapping.".format(name)
            )
        positive = spec.get("positive_conditions")
        negative = spec.get("negative_conditions")
        if not isinstance(positive, list) or not positive:
            raise ConfirmatoryInputError(
                "E-05 contrast family '{}' lacks positive conditions.".format(name)
            )
        if not isinstance(negative, list) or not negative:
            raise ConfirmatoryInputError(
                "E-05 contrast family '{}' lacks negative conditions.".format(name)
            )
        if int(spec.get("minimum_complete_families", 0)) <= 0:
            raise ConfirmatoryInputError(
                "E-05 contrast family '{}' needs a positive family minimum.".format(name)
            )
        covered_negative_conditions.update(str(value) for value in negative)
    if claimed_negative_conditions != covered_negative_conditions:
        raise ConfirmatoryInputError(
            "E-05 contrast families must exactly cover every claimed negative condition."
        )

    configured = settings.get("thresholds", {})
    for level, expected in (
        ("l1", SIMULTANEOUS_L1_THRESHOLDS),
        ("l2", SIMULTANEOUS_L2_THRESHOLDS),
        ("l3", SIMULTANEOUS_L3_THRESHOLDS),
    ):
        values_by_name = configured.get(level)
        if not isinstance(values_by_name, dict) or set(values_by_name) != set(expected):
            raise ConfirmatoryInputError(
                "E-05 thresholds.{} must contain exactly the locked criteria.".format(
                    level
                )
            )
        for name, value in expected.items():
            if not math.isclose(float(values_by_name[name]), value, abs_tol=1e-12):
                raise ConfirmatoryInputError(
                    "E-05 threshold '{}' must equal {:.3f}.".format(name, value)
                )
    strict = settings.get("strict_l1_thresholds")
    if not isinstance(strict, dict) or set(strict) != set(SIMULTANEOUS_L1_THRESHOLDS):
        raise ConfirmatoryInputError(
            "E-05 strict_l1_thresholds must contain every L1 criterion."
        )
    for name, nominal in SIMULTANEOUS_L1_THRESHOLDS.items():
        if not nominal <= float(strict[name]) <= 1.0:
            raise ConfirmatoryInputError(
                "E-05 strict threshold '{}' is outside its valid range.".format(name)
            )

    construct = settings.get("construct_validity")
    if not isinstance(construct, dict) or not construct.get("required", False):
        raise ConfirmatoryInputError(
            "E-05 requires controlled empirical construct-validity checks."
        )
    required_controls = {
        "known_correct",
        "systematically_wrong",
        "prompt_echo",
        "template_only",
    }
    if set(construct.get("control_types", [])) != required_controls:
        raise ConfirmatoryInputError(
            "E-05 construct validity must include all four locked control types."
        )
    required_construct_thresholds = {
        "minimum_correct_sensitivity",
        "minimum_wrong_specificity",
        "minimum_echo_specificity",
        "minimum_template_specificity",
    }
    construct_thresholds = construct.get("thresholds")
    if not isinstance(construct_thresholds, dict) or set(construct_thresholds) != (
        required_construct_thresholds
    ):
        raise ConfirmatoryInputError(
            "E-05 construct-validity thresholds are incomplete."
        )
    if any(not 0.0 <= float(value) <= 1.0 for value in construct_thresholds.values()):
        raise ConfirmatoryInputError(
            "E-05 construct-validity thresholds must lie in [0, 1]."
        )

    rq1 = protocol.get("rq1_evaluation")
    if not isinstance(rq1, dict):
        raise ConfirmatoryInputError("E-05 requires protocol.rq1_evaluation.")
    if int(rq1.get("maximum_state_features", 0)) != 4:
        raise ConfirmatoryInputError("E-05 RQ1 must use at most four states.")
    if not rq1.get("require_budget_matched_text_baseline", False):
        raise ConfirmatoryInputError(
            "E-05 RQ1 requires a budget-matched visible-text baseline."
        )

    selection = protocol.get("compression_policy_selection", {})
    if selection.get("method") != "fixed_reference_paired_family_bootstrap":
        raise ConfirmatoryInputError(
            "E-05 requires fixed-reference paired-family bootstrap selection."
        )
    if selection.get("selection_split") != "development":
        raise ConfirmatoryInputError(
            "E-05 compression selection must use development data."
        )
    if str(selection.get("reference_policy_id")) != "S020000":
        raise ConfirmatoryInputError(
            "E-05 compression selection requires S020000 as the fixed reference."
        )
    if float(selection.get("maximum_tolerable_mcc_drop", -1.0)) != 0.02:
        raise ConfirmatoryInputError(
            "E-05 maximum_tolerable_mcc_drop must equal 0.02."
        )
    if float(selection.get("familywise_error_rate", 0.0)) <= 0.0:
        raise ConfirmatoryInputError(
            "E-05 compression selection requires a positive familywise_error_rate."
        )


def _validate_method_versions(protocol: Dict[str, Any]) -> None:
    versions = protocol.get("method_versions")
    required = {"data", "merger", "evaluator", "evidence_role"}
    if not isinstance(versions, dict) or not required <= set(versions):
        raise ConfirmatoryInputError(
            "E-05 requires data, merger, evaluator, and evidence-role versions."
        )
    if str(versions["evaluator"]) != "E-05":
        raise ConfirmatoryInputError("method_versions.evaluator must be E-05.")
    if versions["merger"] == "M-06" and versions.get("merger_implementation_revision") not in (
        "M-06-r3", "M-06-r4",
    ):
        raise ConfirmatoryInputError("M-06 requires an explicit supported merger implementation revision.")
    if str(versions.get("evaluator_implementation_revision")) not in (
        "E-05-r1", "E-05-r2"
    ):
        raise ConfirmatoryInputError(
            "method_versions.evaluator_implementation_revision must be E-05-r1 or E-05-r2."
        )


def _validate_reconstruction_guarantees(
    policies: Sequence[Dict[str, Any]], merger_version: str | None = None,
    implementation_revision: str | None = None,
) -> None:
    if not policies:
        raise ConfirmatoryInputError("E-05 requires locked reconstructions.")
    for policy in policies:
        policy_id = str(policy.get("id", "unknown"))
        mode = str(policy.get("reconstruction_mode", ""))
        guarantee = str(policy.get("guarantee_scope", ""))
        if merger_version == "M-06" and mode != "hoeffding_compatibility":
            raise ConfirmatoryInputError("M-06 requires Hoeffding-only reconstruction policies.")
        if mode == "hoeffding_compatibility":
            if (policy.get("implementation_revision") is None
                    or (implementation_revision is not None
                        and policy.get("implementation_revision") != implementation_revision)):
                raise ConfirmatoryInputError(
                    "Every M-06 policy must explicitly match its protocol implementation revision."
                )
            if (policy.get("method_version") != "M-06"
                    or merger_version not in (None, "M-06")
                    or guarantee != "local_non_rejection_only"
                    or policy.get("statistical_compatibility_guarantee") is not False):
                raise ConfirmatoryInputError(
                    "M-06 requires explicit method provenance and local non-rejection only."
                )
            from .automata import PTAStateMerger
            from .config import ReconstructionConfig, _dataclass_from_dict

            metadata = {"id", "description", "reconstruction_mode", "guarantee_scope",
                        "statistical_compatibility_guarantee"}
            try:
                PTAStateMerger(_dataclass_from_dict(
                    ReconstructionConfig,
                    {key: value for key, value in policy.items() if key not in metadata},
                ))
            except (TypeError, ValueError) as error:
                raise ConfirmatoryInputError("Invalid M-06 policy: {}".format(error)) from error
        # Historical modes are read-only lock validation, not executable mergers.
        elif mode == "strict_statistical_compatibility":
            if not bool(policy.get("sample_size_compatibility_enabled", False)):
                raise ConfirmatoryInputError(
                    "Strict reconstruction '{}' disables compatibility checks.".format(
                        policy_id
                    )
                )
            if guarantee != "structural_quotient_and_locked_local_compatibility":
                raise ConfirmatoryInputError(
                    "Strict reconstruction '{}' has an invalid guarantee.".format(
                        policy_id
                    )
                )
        elif mode == "target_driven_structural_quotient":
            if guarantee != "observed_path_quotient_only":
                raise ConfirmatoryInputError(
                    "Target-driven reconstruction '{}' must disclaim similarity guarantees."
                    .format(policy_id)
                )
            if policy.get("statistical_compatibility_guarantee") is not False:
                raise ConfirmatoryInputError(
                    "Target-driven reconstruction '{}' must set its compatibility "
                    "guarantee to false.".format(policy_id)
                )
        else:
            raise ConfirmatoryInputError(
                "Reconstruction '{}' lacks an explicit supported mode.".format(policy_id)
            )


def _validate_phase_expansion(
    name: str,
    phase: Dict[str, Any],
    task_count: int,
) -> None:
    task_matrix = phase.get("task_matrix")
    if task_matrix is not None:
        if not isinstance(task_matrix, list) or not task_matrix:
            raise ConfirmatoryInputError(
                "Phase '{}' task_matrix must be a non-empty list.".format(name)
            )
        matrix_total = 0
        for row in task_matrix:
            if not isinstance(row, dict):
                raise ConfirmatoryInputError(
                    "Phase '{}' task_matrix rows must be mappings.".format(name)
                )
            row_tasks = _positive_int(row, "task_count")
            matrix_total += row_tasks
            factors = ("seed_count", "corpus_groups", "shards_per_group")
            if all(key in row for key in factors):
                expanded = math.prod(_positive_int(row, key) for key in factors)
                if expanded != row_tasks:
                    raise ConfirmatoryInputError(
                        "Phase '{}' task_matrix row expands to {} tasks, not {}.".format(
                            name, expanded, row_tasks
                        )
                    )
        if matrix_total != task_count:
            raise ConfirmatoryInputError(
                "Phase '{}' task_matrix totals {} tasks, not {}.".format(
                    name, matrix_total, task_count
                )
            )
    packed_count = int(phase.get("packed_subtask_count", 0))
    packed_per_task = int(phase.get("packed_subtasks_per_task", 0))
    if packed_count or packed_per_task:
        if packed_count < 1 or packed_per_task < 1:
            raise ConfirmatoryInputError(
                "Phase '{}' requires positive packed subtask counts.".format(name)
            )
        if packed_count != task_count * packed_per_task:
            raise ConfirmatoryInputError(
                "Phase '{}' packs {} subtasks but {} tasks x {} slots is {}.".format(
                    name,
                    packed_count,
                    task_count,
                    packed_per_task,
                    task_count * packed_per_task,
                )
            )


def _protocol_lock_stage(protocol: dict, stage: str | None) -> str:
    stage = stage or str(protocol.get("lock_stage", "full"))
    if stage not in {"full", "reconstruction_only", "retrospective_evaluation"}:
        raise ConfirmatoryInputError("Unknown protocol lock stage: {}.".format(stage))
    if stage != "full":
        settings = protocol.get("simultaneous_nested_learning", {})
        if not (settings.get("enabled") and settings.get("version") == "E-05"
                and settings.get("evidence_role") == RETROSPECTIVE_EVIDENCE_ROLE):
            raise ConfirmatoryInputError("Stage-specific locks require explicit retrospective E-05.")
    return stage


def validate_confirmatory_inputs(
    path: str | Path, *, stage: str | None = None
) -> Dict[str, Any]:
    """Validate expert-approved concept and prompt manifests before locking."""

    raw = load_confirmatory_config(path)
    protocol = raw["protocol"]
    lock_stage = _protocol_lock_stage(protocol, stage)
    approval_mode = str(protocol.get("approval_mode", "human_expert")).strip()
    if approval_mode not in {"human_expert", "computational_proxy", "automatic_labels"}:
        raise ConfirmatoryInputError(
            "protocol.approval_mode must be human_expert, computational_proxy, "
            "or automatic_labels."
        )
    config_path = Path(path).resolve()
    root = config_path.parent.parent
    catalog_path = _resolve_path(root, protocol.get("concept_catalog"))
    prompt_path = _resolve_path(root, protocol.get("prompt_manifest"))
    catalog_rows, catalog_fields = _read_csv(catalog_path)
    prompt_rows, prompt_fields = _read_csv(prompt_path)

    errors: list[str] = []
    missing_catalog = sorted(REQUIRED_CONCEPT_COLUMNS - catalog_fields)
    missing_prompts = sorted(REQUIRED_PROMPT_COLUMNS - prompt_fields)
    audited_learning = protocol.get("simultaneous_nested_learning", {})
    e05_enabled = bool(
        audited_learning.get("enabled")
        and audited_learning.get("version") == "E-05"
    )
    retrospective = e05_enabled and audited_learning.get("evidence_role") == RETROSPECTIVE_EVIDENCE_ROLE
    if e05_enabled:
        _validate_audited_nested_learning(protocol, audited_learning)
        _validate_method_versions(protocol)
    e05_errors: list[str] = []
    if e05_enabled and "condition_index" not in prompt_fields:
        e05_errors.append("E-05 prompt manifests require condition_index.")
    if e05_enabled:
        missing_semantics = sorted(
            {"canonical_statement", "logical_negation"} - catalog_fields
        )
        if missing_semantics:
            e05_errors.append(
                "E-05 concept catalogs lack semantic control columns: {}.".format(
                    ", ".join(missing_semantics)
                )
            )
    if not retrospective:
        errors.extend(e05_errors)
    if approval_mode == "computational_proxy":
        if "proxy_approved" not in catalog_fields:
            errors.append("Computational-proxy catalog lacks proxy_approved.")
        if "proxy_approved" not in prompt_fields:
            errors.append("Computational-proxy manifest lacks proxy_approved.")
    if approval_mode == "automatic_labels":
        if "automatic_approved" not in catalog_fields:
            errors.append("Automatic-label catalog lacks automatic_approved.")
        if "automatic_approved" not in prompt_fields:
            errors.append("Automatic-label manifest lacks automatic_approved.")
    require_concept_types = bool(protocol.get("require_concept_types", False))
    if require_concept_types:
        required_type_fields = {"concept_type", "invariance_profile"}
        missing_catalog_types = sorted(required_type_fields - catalog_fields)
        missing_prompt_types = sorted(required_type_fields - prompt_fields)
        if missing_catalog_types:
            errors.append(
                "Type-aware catalog lacks columns: {}.".format(
                    ", ".join(missing_catalog_types)
                )
            )
        if missing_prompt_types:
            errors.append(
                "Type-aware prompt manifest lacks columns: {}.".format(
                    ", ".join(missing_prompt_types)
                )
            )
    if missing_catalog:
        errors.append(
            "Concept catalog lacks columns: {}.".format(", ".join(missing_catalog))
        )
    if missing_prompts:
        errors.append(
            "Prompt manifest lacks columns: {}.".format(", ".join(missing_prompts))
        )
    if errors:
        return _validation_result(catalog_path, prompt_path, errors, {}, {})

    selected_rows = [
        row for row in catalog_rows if _is_true(row.get("confirmatory_selected", ""))
    ]
    selected_ids = {row["concept_id"].strip() for row in selected_rows}
    expected_concepts = int(protocol.get("selected_concept_count", 0))
    if len(selected_ids) != expected_concepts:
        errors.append(
            "Expected {} selected concepts, found {}.".format(
                expected_concepts, len(selected_ids)
            )
        )
    if len(selected_ids) != len(selected_rows):
        errors.append("Selected concept IDs must be unique.")

    cue_tokens: Dict[str, set[str]] = {}
    concept_types: Dict[str, str] = {}
    invariance_profiles: Dict[str, str] = {}
    for row in selected_rows:
        concept_id = row["concept_id"].strip()
        for field in (
            "topic_name",
            "selection_stratum",
            "expert_definition",
            "positive_criteria",
            "exclusion_criteria",
            "forbidden_lexical_cues",
        ):
            if not row.get(field, "").strip():
                errors.append(
                    "Selected concept '{}' lacks {}.".format(concept_id, field)
                )
        approval_field = {
            "human_expert": "expert_approved",
            "computational_proxy": "proxy_approved",
            "automatic_labels": "automatic_approved",
        }[approval_mode]
        if not _is_true(row.get(approval_field, "")):
            errors.append(
                "Selected concept '{}' is not approved for mode '{}'.".format(
                    concept_id, approval_mode
                )
            )
        cue_tokens[concept_id] = _cue_tokens(row.get("forbidden_lexical_cues", ""))
        if require_concept_types:
            concept_type = row.get("concept_type", "").strip()
            invariance_profile = row.get("invariance_profile", "").strip()
            if concept_type not in ALLOWED_CONCEPT_TYPES:
                errors.append(
                    "Selected concept '{}' has invalid concept_type '{}'.".format(
                        concept_id, concept_type
                    )
                )
            if not invariance_profile:
                errors.append(
                    "Selected concept '{}' lacks invariance_profile.".format(
                        concept_id
                    )
                )
            concept_types[concept_id] = concept_type
            invariance_profiles[concept_id] = invariance_profile

    seen_prompt_ids: set[str] = set()
    normalized_prompt_splits: Dict[str, set[str]] = defaultdict(set)
    cell_counts: Counter[tuple[str, str, str, int]] = Counter()
    pair_splits: Dict[str, set[str]] = defaultdict(set)
    allowed_conditions = set(protocol.get("allowed_conditions", []))
    pair_conditions: Dict[tuple[str, str], Counter[str]] = defaultdict(Counter)
    condition_indices: set[tuple[str, str, str, int]] = set()
    for row_number, row in enumerate(prompt_rows, 2):
        prompt_id = row.get("prompt_id", "").strip()
        concept_id = row.get("concept_id", "").strip()
        split = row.get("split", "").strip().lower()
        condition = row.get("condition", "").strip().lower()
        label_text = row.get("expected_label", "").strip()
        prompt_text = row.get("prompt_text", "").strip()
        pair_id = row.get("pair_id", "").strip()
        if e05_enabled:
            try:
                condition_index = int(row.get("condition_index", ""))
            except (TypeError, ValueError):
                condition_index = 0
            if condition_index <= 0:
                (e05_errors if retrospective else errors).append(
                    "Prompt '{}' has an invalid E-05 condition_index.".format(prompt_id)
                )
            index_key = (concept_id, split, condition, condition_index)
            if condition_index > 0 and index_key in condition_indices:
                (e05_errors if retrospective else errors).append(
                    "Prompt '{}' duplicates an E-05 condition index.".format(prompt_id)
                )
            condition_indices.add(index_key)
        if not prompt_id or prompt_id in seen_prompt_ids:
            errors.append("Prompt ID at row {} is empty or duplicated.".format(row_number))
        seen_prompt_ids.add(prompt_id)
        if concept_id not in selected_ids:
            errors.append(
                "Prompt '{}' references an unselected concept '{}'.".format(
                    prompt_id, concept_id
                )
            )
        elif require_concept_types:
            prompt_concept_type = row.get("concept_type", "").strip()
            prompt_invariance = row.get("invariance_profile", "").strip()
            if prompt_concept_type != concept_types.get(concept_id):
                errors.append(
                    "Prompt '{}' concept_type '{}' does not match concept '{}'.".format(
                        prompt_id, prompt_concept_type, concept_types.get(concept_id)
                    )
                )
            if prompt_invariance != invariance_profiles.get(concept_id):
                errors.append(
                    "Prompt '{}' invariance_profile does not match concept '{}'.".format(
                        prompt_id, concept_id
                    )
                )
        if split not in ALLOWED_SPLITS:
            errors.append("Prompt '{}' has invalid split '{}'.".format(prompt_id, split))
        if allowed_conditions and condition not in allowed_conditions:
            errors.append(
                "Prompt '{}' has invalid condition '{}'.".format(prompt_id, condition)
            )
        if label_text not in {"0", "1"}:
            errors.append("Prompt '{}' expected_label must be 0 or 1.".format(prompt_id))
            label = -1
        else:
            label = int(label_text)
            expected_label = EXPECTED_LABEL_BY_CONDITION.get(condition)
            if expected_label is not None and label != expected_label:
                errors.append(
                    "Prompt '{}' condition '{}' requires expected_label {}.".format(
                        prompt_id, condition, expected_label
                    )
                )
        if not prompt_text:
            errors.append("Prompt '{}' has empty text.".format(prompt_id))
        approval_field = {
            "human_expert": "expert_approved",
            "computational_proxy": "proxy_approved",
            "automatic_labels": "automatic_approved",
        }[approval_mode]
        if not _is_true(row.get(approval_field, "")):
            errors.append(
                "Prompt '{}' is not approved for mode '{}'.".format(
                    prompt_id, approval_mode
                )
            )
        if condition in PAIRED_CONDITIONS:
            if not pair_id:
                errors.append("Paired prompt '{}' lacks pair_id.".format(prompt_id))
            pair_conditions[(concept_id, pair_id)][condition] += 1
        if pair_id:
            pair_splits[pair_id].add(split)
        normalized = " ".join(_normalized_words(prompt_text))
        normalized_prompt_splits[normalized].add(split)
        if condition in LEXICAL_DISJOINT_CONDITIONS:
            overlap = sorted(
                set(_normalized_words(prompt_text))
                & cue_tokens.get(concept_id, set())
            )
            if overlap:
                errors.append(
                    "Lexical-disjoint prompt '{}' contains forbidden cues: {}.".format(
                        prompt_id, ", ".join(overlap)
                    )
                )
        if split in ALLOWED_SPLITS and label in {0, 1}:
            cell_counts[(concept_id, split, condition, label)] += 1

    for normalized, splits in normalized_prompt_splits.items():
        if normalized and len(splits) > 1:
            errors.append(
                "An identical normalized prompt occurs across splits: '{}'.".format(
                    normalized[:120]
                )
            )
    for pair_id, splits in pair_splits.items():
        if len(splits) > 1:
            errors.append(
                "Pair '{}' crosses split boundaries: {}.".format(
                    pair_id, ", ".join(sorted(splits))
                )
            )
    valid_pair_shapes = {
        frozenset({"irrelevant_original", "irrelevant_perturbation"}),
        frozenset({"relevant_original", "relevant_toggle"}),
    }
    for (concept_id, pair_id), conditions in pair_conditions.items():
        if frozenset(conditions) not in valid_pair_shapes or any(
            count != 1 for count in conditions.values()
        ):
            errors.append(
                "Concept '{}' pair '{}' must contain exactly one valid original/"
                "counterpart condition pair. Observed {}.".format(
                    concept_id,
                    pair_id,
                    dict(sorted(conditions.items())),
                )
            )

    minimums = protocol.get("minimum_items_per_concept", {})
    if not isinstance(minimums, dict):
        errors.append("protocol.minimum_items_per_concept must be a mapping.")
    else:
        for split, condition_minimums in minimums.items():
            if not isinstance(condition_minimums, dict):
                errors.append(
                    "Minimum item rules for '{}' must be a mapping.".format(split)
                )
                continue
            for condition, raw_minimum in condition_minimums.items():
                minimum = int(raw_minimum)
                for concept_id in sorted(selected_ids):
                    observed = sum(
                        count
                        for (cell_concept, cell_split, cell_condition, _), count in cell_counts.items()
                        if cell_concept == concept_id
                        and cell_split == split
                        and cell_condition == condition
                    )
                    if observed < minimum:
                        errors.append(
                            "Concept '{}' has {} '{}'/'{}' prompts. Minimum is {}.".format(
                                concept_id, observed, split, condition, minimum
                            )
                        )

    catalog_summary = {
        "rows": len(catalog_rows),
        "selected_concepts": len(selected_ids),
        "selected_concept_ids": sorted(selected_ids),
        "approval_mode": approval_mode,
        "human_expert_gate_available": approval_mode == "human_expert",
        "type_aware_invariance": require_concept_types,
        "concept_type_counts": dict(sorted(Counter(concept_types.values()).items())),
    }
    feasibility = None
    retrospective_audit = None
    if retrospective:
        retrospective_audit = retrospective_input_audit(catalog_rows, prompt_rows, audited_learning)
        if set(selected_ids) != set(audited_learning["concept_error_budgets"]):
            errors.append("E-05 concept budgets do not match the selected catalog IDs.")
        if e05_errors:
            for report in retrospective_audit["concept_reports"]:
                report["status"] = "not_identifiable"
                report["reasons"].append("invalid_or_missing_e05_metadata")
        retrospective_audit["metadata_errors"] = e05_errors
    if e05_enabled and not errors:
        feasible_ids = sorted(selected_ids)
        if retrospective:
            feasible_ids = [report["concept_id"] for report in retrospective_audit["concept_reports"]
                            if report["status"] == "available"]
        feasibility = (
            assess_prelock_feasibility(
                prompt_rows, feasible_ids, audited_learning,
                evaluator_implementation_revision=protocol.get("method_versions", {}).get(
                    "evaluator_implementation_revision", EVALUATOR_IMPLEMENTATION_REVISION
                ),
            )
            if feasible_ids else {"status": "not_identifiable", "concept_reports": []}
        )
        if retrospective:
            failed_ids = {row["concept_id"] for row in feasibility["concept_reports"]
                          if not row["perfect_case_can_support_l1"]}
            for report in retrospective_audit["concept_reports"]:
                if report["concept_id"] in failed_ids:
                    report["status"] = "not_identifiable"
                    report["reasons"].append("infeasible_e05_family_design")
            retrospective_audit["status"] = (
                "not_identifiable" if any(row["reasons"] for row in retrospective_audit["concept_reports"])
                or retrospective_audit["insufficient_model_groups"] else "available"
            )
        elif feasibility["status"] != "passed":
            failed = [
                row["concept_id"]
                for row in feasibility["concept_reports"]
                if not row["perfect_case_can_support_l1"]
            ]
            errors.append(
                "E-05 pre-lock feasibility failed for: {}.".format(
                    ", ".join(failed)
                )
            )
    prompt_summary = {
        "rows": len(prompt_rows),
        "split_counts": dict(sorted(Counter(row.get("split", "") for row in prompt_rows).items())),
        "condition_counts": dict(
            sorted(Counter(row.get("condition", "") for row in prompt_rows).items())
        ),
        "e05_prelock_feasibility": feasibility,
        "retrospective_input_audit": retrospective_audit,
        "lock_stage": lock_stage,
    }
    return _validation_result(
        catalog_path, prompt_path, errors, catalog_summary, prompt_summary
    )


def audit_locked_reconstructions(
    config_path: str | Path,
    aggregate_csv_path: str | Path,
) -> Dict[str, Any]:
    """Verify that locked reconstruction points exist in the old sweep output."""

    raw = load_confirmatory_config(config_path)
    aggregate_path = Path(aggregate_csv_path)
    rows, fields = _read_csv(aggregate_path)
    required_fields = {
        "semantic_reference_mode",
        "threshold",
        "suffix_length",
        "candidate_bucket_strategy",
        "candidate_pair_sampling_strategy",
        "max_total_pairs",
        "max_pairs_per_bucket",
        "pta_state_reduction_ratio_mean",
        "path_similarity_state_set_jaccard_semantic_spearman_mean",
        "path_similarity_ordered_lcs_semantic_spearman_mean",
    }
    missing = sorted(required_fields - fields)
    if missing:
        raise ConfirmatoryInputError(
            "Old aggregate CSV lacks columns: {}.".format(", ".join(missing))
        )

    reports = []
    errors = []
    for spec in raw.get("locked_reconstructions", []):
        matching = [row for row in rows if _matches_reconstruction(row, spec)]
        modes = sorted({row["semantic_reference_mode"] for row in matching})
        reductions = sorted(
            {round(float(row["pta_state_reduction_ratio_mean"]), 12) for row in matching}
        )
        expected_reduction = float(spec.get("old_pta_state_reduction_ratio"))
        if len(matching) != 3 or modes != [
            "combined",
            "keyword_topic",
            "llm_topic_relation",
        ]:
            errors.append(
                "{}: expected one row per semantic mode, found {} rows and modes {}.".format(
                    spec.get("id"), len(matching), modes
                )
            )
        if len(reductions) != 1 or abs(reductions[0] - expected_reduction) > 1e-9:
            errors.append(
                "{}: configured reduction {:.10f} does not match observed {}.".format(
                    spec.get("id"), expected_reduction, reductions
                )
            )
        reports.append(
            {
                "id": spec.get("id"),
                "matching_rows": len(matching),
                "semantic_modes": modes,
                "observed_reductions": reductions,
                "metrics_by_mode": {
                    row["semantic_reference_mode"]: {
                        "state_set_spearman": float(
                            row[
                                "path_similarity_state_set_jaccard_semantic_spearman_mean"
                            ]
                        ),
                        "ordered_lcs_spearman": float(
                            row[
                                "path_similarity_ordered_lcs_semantic_spearman_mean"
                            ]
                        ),
                    }
                    for row in matching
                },
            }
        )
    return {
        "valid": not errors,
        "aggregate_csv": str(aggregate_path.resolve()),
        "locked_reconstruction_count": len(reports),
        "errors": errors,
        "reconstructions": reports,
    }


def lock_confirmatory_inputs(
    config_path: str | Path,
    output_path: str | Path,
    *,
    stage: str | None = None,
) -> Dict[str, Any]:
    """Validate and hash inputs so the confirmatory test cannot be silently changed."""

    resolved_config = load_confirmatory_config(config_path)
    protocol = resolved_config["protocol"]
    lock_stage = _protocol_lock_stage(protocol, stage)
    validation = validate_confirmatory_inputs(config_path, stage=lock_stage)
    if not validation["valid"]:
        raise ConfirmatoryInputError(
            "Confirmatory inputs are not lockable:\n- "
            + "\n- ".join(validation["errors"])
        )
    paths = {
        "config": Path(config_path).resolve(),
        "concept_catalog": Path(validation["concept_catalog_path"]),
        "prompt_manifest": Path(validation["prompt_manifest_path"]),
    }
    project_root = Path(config_path).resolve().parent.parent
    if lock_stage == "retrospective_evaluation":
        predecessor = _resolve_path(project_root, protocol.get("lock_file"))
        verification = verify_confirmatory_lock(
            predecessor, required_stage="reconstruction", config_path=config_path
        )
        if not verification["valid"] or verification["lock_stage"] != "reconstruction_only":
            raise ConfirmatoryInputError("A valid reconstruction-only predecessor lock is required.")
        if predecessor.resolve() == Path(output_path).resolve():
            raise ConfirmatoryInputError("The evaluator lock must not replace the reconstruction lock.")
        paths["reconstruction_lock"] = predecessor
        previous = json.loads(predecessor.read_text(encoding="utf-8"))
        for name, record in previous["files"].items():
            paths.setdefault(name, Path(record["path"]))
        release_root = Path(output_path).resolve().parent
        for name, relative in {
            "source_manifest": "source_manifest.sha256",
            "response_manifest": "response_manifest.sha256",
            "test_report": "preflight/tests.json",
            "test_junit": "preflight/pytest.xml",
            "pilot_report": "preflight/pilot.json",
        }.items():
            paths[name] = release_root / relative
    for name in ("question_database", "topic_relation_path", "design_manifest"):
        if protocol.get(name):
            paths[name] = _resolve_path(project_root, protocol[name])
    for name, value in protocol.get("question_databases", {}).items():
        paths["question_database_{}".format(name)] = _resolve_path(
            project_root, value
        )
    config_mapping = read_config_mapping(config_path)
    if config_mapping.get("extends"):
        base_path = Path(str(config_mapping["extends"]))
        if not base_path.is_absolute():
            base_path = (Path(config_path).resolve().parent / base_path).resolve()
        paths["base_config"] = base_path
    lock = {
        "schema_version": 1,
        "lock_stage": lock_stage,
        "scope": lock_stage,
        "evaluation_authorized": lock_stage != "reconstruction_only",
        "evidence_role": protocol.get("method_versions", {}).get("evidence_role"),
        "locked_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "files": {
            name: {
                "path": str(path),
                "sha256": _sha256(path),
                "size_bytes": path.stat().st_size,
            }
            for name, path in paths.items()
        },
        "validation": validation,
        "plan": build_confirmatory_plan(config_path),
    }
    output = Path(output_path)
    if lock_stage != "full" and output.exists():
        raise ConfirmatoryInputError("Stage-specific locks are immutable. Choose a new lock path.")
    output.parent.mkdir(parents=True, exist_ok=True)
    if lock_stage == "retrospective_evaluation":
        lock["ready"] = True
        lock["campaign_root"] = str(output.parent.resolve())
        temporary = output.with_name(output.name + ".pending")
        with temporary.open("x", encoding="utf-8") as handle:
            handle.write(json.dumps(lock, indent=2, sort_keys=True) + "\n")
        try:
            verify_evaluation_release(config_path, temporary, output.parent)
            temporary.replace(output)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise
        return lock
    output.write_text(json.dumps(lock, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return lock


def verify_confirmatory_lock(
    lock_path: str | Path, *, required_stage: str | None = None,
    config_path: str | Path | None = None,
) -> Dict[str, Any]:
    """Verify every locked file hash before a confirmatory task starts."""

    lock = json.loads(Path(lock_path).read_text(encoding="utf-8"))
    mismatches = []
    stage = str(lock.get("scope", lock.get("lock_stage", "full")))
    if "scope" in lock and "lock_stage" in lock and lock["scope"] != lock["lock_stage"]:
        mismatches.append("conflicting protocol lock scopes")
    if stage not in {"full", "reconstruction_only", "retrospective_evaluation"}:
        mismatches.append("unknown protocol lock stage")
    if required_stage not in {None, "reconstruction", "evaluation"}:
        raise ValueError("Unknown required protocol stage.")
    if required_stage == "evaluation" and stage == "reconstruction_only":
        mismatches.append("reconstruction-only lock does not authorize evaluation")
    if not lock.get("files"):
        mismatches.append("protocol lock contains no hashed inputs")
    if config_path is not None:
        locked_config = lock.get("files", {}).get("config", {})
        if locked_config.get("sha256") != _sha256(Path(config_path)):
            mismatches.append("active configuration differs from locked configuration")
    for name, record in lock.get("files", {}).items():
        path = Path(record["path"])
        if not path.exists():
            mismatches.append("{}: missing {}".format(name, path))
            continue
        observed = _sha256(path)
        if observed != record.get("sha256"):
            mismatches.append(
                "{}: expected {}, observed {}".format(
                    name, record.get("sha256"), observed
                )
            )
    return {
        "valid": not mismatches,
        "lock_path": str(Path(lock_path).resolve()),
        "checked_files": len(lock.get("files", {})),
        "mismatches": mismatches,
        "lock_stage": stage,
        "evaluation_authorized": stage in {"full", "retrospective_evaluation"} and not mismatches,
        "validation": lock.get("validation", {}),
    }


def _verify_digest_manifest(path: Path, root: Path) -> set[Path]:
    """Read the sha256sum format used by the portable deployment scripts."""
    checked = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        match = re.fullmatch(r"([0-9a-f]{64}) [ *](.+)", line)
        if not match:
            raise ConfirmatoryInputError("Invalid SHA-256 manifest entry in {}.".format(path))
        target = Path(match.group(2))
        target = (target if target.is_absolute() else root / target).resolve()
        if target in checked:
            raise ConfirmatoryInputError("Duplicate manifest entry: {}.".format(target))
        if not target.is_file() or _sha256(target) != match.group(1):
            raise ConfirmatoryInputError("Manifest hash mismatch: {}.".format(target))
        checked.add(target)
    if not checked:
        raise ConfirmatoryInputError("A release manifest is empty.")
    return checked


def verify_evaluation_release(
    config_path: str | Path, lock_path: str | Path, campaign_root: str | Path
) -> dict:
    """Require a source-tested, input-bound retrospective evaluator release.

    A reconstruction-only lock resolves to campaign_root/evaluation_lock.json.
    Legacy independent locks retain their original verification behavior.
    This gate establishes execution readiness, never scientific eligibility.
    """
    try:
        return _verify_evaluation_release(config_path, lock_path, campaign_root)
    except (OSError, KeyError, TypeError, ValueError, ET.ParseError) as error:
        raise ConfirmatoryInputError("Evaluation release rejected: {}".format(error)) from error


def _verify_evaluation_release(config_path, lock_path, campaign_root) -> dict:
    config = Path(config_path).resolve()
    root = Path(campaign_root).resolve()
    protocol = load_confirmatory_config(config)["protocol"]
    settings = protocol.get("simultaneous_nested_learning", {})
    supplied = verify_confirmatory_lock(lock_path, config_path=config)
    if not supplied["valid"]:
        raise ConfirmatoryInputError("Invalid supplied lock: {}.".format(supplied["mismatches"]))
    retrospective = settings.get("evidence_role") == RETROSPECTIVE_EVIDENCE_ROLE
    if not retrospective and supplied["lock_stage"] == "full":
        return supplied
    if not retrospective or settings.get("version") != "E-05" or not settings.get("enabled"):
        raise ConfirmatoryInputError("A stage-specific release requires retrospective E-05.")
    _validate_audited_nested_learning(protocol, settings)
    _validate_method_versions(protocol)
    release_path = (
        root / "evaluation_lock.json" if supplied["lock_stage"] == "reconstruction_only"
        else Path(lock_path).resolve()
    )
    released = verify_confirmatory_lock(
        release_path, required_stage="evaluation", config_path=config
    )
    if not released["valid"] or released["lock_stage"] != "retrospective_evaluation":
        raise ConfirmatoryInputError("A separate retrospective evaluator lock is required.")
    release = json.loads(release_path.read_text(encoding="utf-8"))
    if release.get("ready") is not True or release.get("evidence_role") != RETROSPECTIVE_EVIDENCE_ROLE:
        raise ConfirmatoryInputError("Evaluator readiness and retrospective provenance are required.")
    if Path(str(release.get("campaign_root", ""))).resolve() != root:
        raise ConfirmatoryInputError("Evaluator release belongs to a different campaign root.")
    expected_paths = {
        "config": config,
        "concept_catalog": _resolve_path(config.parent.parent, protocol["concept_catalog"]),
        "prompt_manifest": _resolve_path(config.parent.parent, protocol["prompt_manifest"]),
        "reconstruction_lock": root / "protocol_lock.json",
        "source_manifest": root / "source_manifest.sha256",
        "response_manifest": root / "response_manifest.sha256",
        "test_report": root / "preflight/tests.json",
        "test_junit": root / "preflight/pytest.xml",
        "pilot_report": root / "preflight/pilot.json",
    }
    files = release["files"]
    for name, path in expected_paths.items():
        if name not in files or Path(files[name]["path"]).resolve() != path.resolve():
            raise ConfirmatoryInputError("Missing or misbound release input: {}.".format(name))
    predecessor_path = expected_paths["reconstruction_lock"]
    predecessor = verify_confirmatory_lock(
        predecessor_path, required_stage="reconstruction", config_path=config
    )
    if not predecessor["valid"] or predecessor["lock_stage"] != "reconstruction_only":
        raise ConfirmatoryInputError("The reconstruction predecessor is not valid.")
    old = json.loads(predecessor_path.read_text(encoding="utf-8"))
    for name, record in old["files"].items():
        current = files.get(name, {})
        if current.get("sha256") != record.get("sha256") or (
            Path(current.get("path", "")).resolve() != Path(record["path"]).resolve()
        ):
            raise ConfirmatoryInputError("Reconstruction input binding changed: {}.".format(name))
    source_paths = _verify_digest_manifest(expected_paths["source_manifest"], config.parent.parent)
    required_source = {config, *(config.parent.parent / "esm_lcd").glob("*.py")}
    required_source.update((config.parent.parent / "tests").glob("test_*.py"))
    if not {path.resolve() for path in required_source} <= source_paths:
        raise ConfirmatoryInputError("Source manifest omits current scientific source or tests.")
    response_paths = _verify_digest_manifest(expected_paths["response_manifest"], root)
    expected_responses = {
        (root / "response_databases" / (label + "_" + split + ".db")).resolve()
        for label in protocol["model_seed_labels"]
        for split in ("discovery_development", "test")
    }
    if response_paths != expected_responses:
        raise ConfirmatoryInputError("Response manifest does not exactly cover the configured runs.")
    source_digest = _sha256(expected_paths["source_manifest"])
    tests = json.loads(expected_paths["test_report"].read_text(encoding="utf-8"))
    if tests.get("passed") is not True or tests.get("source_manifest_sha256") != source_digest:
        raise ConfirmatoryInputError("Tests do not attest the current source manifest.")
    junit = ET.parse(expected_paths["test_junit"]).getroot()
    cases = list(junit.iter("testcase"))
    if not cases or any(list(junit.iter(tag)) for tag in ("failure", "error")) or (
        all(case.find("skipped") is not None for case in cases)
    ):
        raise ConfirmatoryInputError("JUnit evidence must include passing, nonempty tests without failures.")
    pilot = json.loads(expected_paths["pilot_report"].read_text(encoding="utf-8"))
    if (pilot.get("source_manifest_sha256") != source_digest
            or pilot.get("committed_merges") != 0
            or pilot.get("preparation_reuse", {}).get("unmerged_only") is not True
            or pilot.get("role") != "bounded_runtime_and_input_pilot_not_scientific_results"):
        raise ConfirmatoryInputError("The real pilot does not validate this source and unmerged preparation.")
    current_validation = validate_confirmatory_inputs(config, stage="retrospective_evaluation")
    if not current_validation["valid"] or current_validation != release.get("validation"):
        raise ConfirmatoryInputError("Evaluator validation is missing, stale, or inconsistent with inputs.")
    return {**released, "evaluation_lock_path": str(release_path),
            "scientific_eligibility": "determined_per_cell_by_E-05"}


def _topological_order(phases: Dict[str, Dict[str, Any]]) -> list[str]:
    remaining = set(phases)
    resolved: set[str] = set()
    order: list[str] = []
    while remaining:
        ready = sorted(
            name
            for name in remaining
            if set(phases[name].get("depends_on", [])) <= resolved
        )
        if not ready:
            raise ConfirmatoryInputError("Phase dependencies contain a cycle.")
        order.extend(ready)
        resolved.update(ready)
        remaining.difference_update(ready)
    return order


def _positive_int(mapping: Dict[str, Any], key: str) -> int:
    value = int(mapping.get(key, 0))
    if value < 1:
        raise ConfirmatoryInputError("{} must be a positive integer.".format(key))
    return value


def _positive_float(mapping: Dict[str, Any], key: str) -> float:
    value = float(mapping.get(key, 0.0))
    if value <= 0.0:
        raise ConfirmatoryInputError("{} must be positive.".format(key))
    return value


def _resolve_path(root: Path, raw_path: Any) -> Path:
    if raw_path is None or not str(raw_path).strip():
        raise ConfirmatoryInputError("Confirmatory input path is missing.")
    path = Path(str(raw_path))
    return path if path.is_absolute() else (root / path).resolve()


def _read_csv(path: Path) -> tuple[list[dict[str, str]], set[str]]:
    if not path.exists():
        raise ConfirmatoryInputError("CSV file not found: {}".format(path))
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or [])
        return [dict(row) for row in reader], fields


def _is_true(value: Any) -> bool:
    return str(value).strip().lower() in TRUTHY


def _cue_tokens(raw_value: str) -> set[str]:
    tokens: set[str] = set()
    for cue in raw_value.split("|"):
        tokens.update(_normalized_words(cue))
    return tokens


def _normalized_words(value: str) -> list[str]:
    normalized = unicodedata.normalize("NFKD", value)
    ascii_value = normalized.encode("ascii", "ignore").decode("ascii")
    return WORD_RE.findall(ascii_value.lower())


def _validation_result(
    catalog_path: Path,
    prompt_path: Path,
    errors: Sequence[str],
    catalog_summary: Dict[str, Any],
    prompt_summary: Dict[str, Any],
) -> Dict[str, Any]:
    return {
        "valid": not errors,
        "concept_catalog_path": str(catalog_path),
        "prompt_manifest_path": str(prompt_path),
        "error_count": len(errors),
        "errors": list(errors),
        "concept_catalog": catalog_summary,
        "prompt_manifest": prompt_summary,
    }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _matches_reconstruction(row: Dict[str, str], spec: Dict[str, Any]) -> bool:
    string_keys = (
        "candidate_bucket_strategy",
        "candidate_pair_sampling_strategy",
    )
    integer_keys = (
        "suffix_length",
        "max_total_pairs",
        "max_pairs_per_bucket",
    )
    float_keys = (
        "threshold",
        "lambda_next",
        "lambda_suffix",
        "lambda_transition",
    )
    return (
        all(str(row.get(key)) == str(spec.get(key)) for key in string_keys)
        and all(int(row.get(key, -1)) == int(spec.get(key, -2)) for key in integer_keys)
        and all(
            abs(float(row.get(key, "nan")) - float(spec.get(key, "nan"))) < 1e-9
            for key in float_keys
        )
    )
