"""V15.3 evaluation against original question-construction assignments.

This module fits only small classifiers to existing answer features. It never
generates answers, learns automata, or changes the original annotation records.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import asdict, replace
import hashlib
import json
import math

from . import confirmatory_detector as detector
from .concept_presence_data import content_sha256, response_provenance_keys
from .concept_presence_evaluation import _validate_presence_mapping
from .presence_evaluation_runtime import _select_presence_threshold, transform_presence_order
from .presence_inference import _components

REVISION = "E-07-construction-r1"
OBJECTIVE = "original_question_construction_assignment"
ROLES = {
    "single_state": ("best_interior_state", (1,), None),
    "state_set": ("unordered_state_set", (1, 2, 4), None),
    "path": ("contiguous_state_motif", (1, 2, 4), None),
    "shuffled_path": ("contiguous_state_motif", (1, 2, 4), "shuffle"),
    "answer_tokens": ("answer_token_ngram", (1, 2, 4), None),
    "answer_length": ("answer_length", (1, 2, 4), None),
}
COMPARISONS = {
    "state_set_minus_single": ("state_set", "single_state"),
    "path_minus_single": ("path", "single_state"),
    "path_minus_shuffled": ("path", "shuffled_path"),
    "path_minus_tokens": ("path", "answer_tokens"),
    "path_minus_length": ("path", "answer_length"),
}
SPLITS = ("discovery", "development", "test")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def identity(item):
    return (item.model_seed, item.prompt_id)


def original_labels(examples, questions, concept_id):
    """Join by prompt AND concept. Never derive negatives from another concept."""
    bound, audit, excluded = [], [], []
    seen = set()
    for item in sorted(examples, key=identity):
        if item.split not in SPLITS:
            continue
        key = identity(item)
        if key in seen:
            raise ValueError("Duplicate physical answer in one concept evaluation")
        seen.add(key)
        question = questions.get(item.prompt_id)
        if question is None or question.get("concept_id") != concept_id:
            excluded.append({"identity": key, "split": item.split, "reason": "missing_original_concept_assignment"})
            continue
        label = question.get("question_intent_label")
        if type(label) is not int or label not in (0, 1):
            excluded.append({"identity": key, "split": item.split, "reason": "missing_original_binary_label"})
            continue
        if question.get("construction_label", label) != label:
            raise ValueError("Conflicting original construction fields")
        for field in ("concept_id", "split", "source_family_id", "dependency_family_id"):
            if question.get(field) != getattr(item, field):
                raise ValueError("Original question/answer binding changed: " + field)
        # The original CPU cache intentionally omits question condition. The
        # manifest remains authoritative, while a present conflicting value fails.
        if not isinstance(question.get("condition"), str) or not question["condition"]:
            raise ValueError("Original question condition is missing")
        if item.condition and item.condition != question["condition"]:
            raise ValueError("Original question/answer binding changed: condition")
        if (question["text"] != item.prompt_text
                or tuple(question["source_family_ids"]) != item.source_family_ids
                or content_sha256(item.answer_text) != item.content_sha256):
            raise ValueError("Question lineage or answer content mismatch")
        metadata = dict(item.annotation_metadata)
        for field in ("construction_label", "question_intent_label"):
            if field in metadata and metadata[field] != label:
                raise ValueError("Stored original assignment conflicts with question manifest")
        _validate_presence_mapping(item.answer_tokens, item.path, item.mapping_kinds)
        audit.append({"identity": key, "split": item.split, "construction_label": label,
                      "automatic_label": item.label, "automatic_audit_status": item.audit_status,
                      "automatic_disagreement": item.label is not None and item.label != label,
                      "answer_content_sha256": item.content_sha256,
                      "original_question_condition": question["condition"], "cached_condition": item.condition})
        bound.append(replace(item, label=label, label_objective=OBJECTIVE, condition=question["condition"]))
    return tuple(bound), audit, excluded


def provenance(examples):
    rows, tokens = [], []
    physical_owners = {}
    for item in examples:
        row = asdict(item)
        for field in ("response_id", "generation_request_id"):
            if row.get(field) is None:
                row.pop(field, None)
        dependencies = response_provenance_keys(row)
        for key in dependencies:
            if key[0] in ("response", "generation_request"):
                if physical_owners.setdefault(key, identity(item)) != identity(item):
                    raise ValueError("Physical response identifier reused across different answers")
        rows.append(row)
        tokens.append(dependencies)
    components = _components(tokens)
    splits = {}
    for item, cluster in zip(examples, components, strict=True):
        splits.setdefault(cluster, set()).add(item.split)
    if any(len(group) > 1 for group in splits.values()):
        raise ValueError("Shared source provenance crosses a fixed split")
    return components


def metrics(labels, predictions):
    if len(labels) != len(predictions):
        raise ValueError("Prediction alignment changed")
    if any(type(x) is not int or x not in (0, 1) for x in (*labels, *predictions)):
        raise ValueError("Metrics require binary labels and predictions")
    counts = Counter((a, b) for a, b in zip(labels, predictions, strict=True))
    tp, tn, fp, fn = (counts[(1, 1)], counts[(0, 0)], counts[(0, 1)], counts[(1, 0)])
    denom = (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    positive, negative = tp + fn, tn + fp
    return {"n": len(labels), "positive": positive, "negative": negative,
            "tp": tp, "tn": tn, "fp": fp, "fn": fn,
            "mcc": (tp * tn - fp * fn) / math.sqrt(denom) if denom else None,
            "balanced_accuracy": (tp / positive + tn / negative) / 2 if positive and negative else None,
            "positive_recall": tp / positive if positive else None,
            "negative_recall": tn / negative if negative else None,
            "accuracy": (tp + tn) / len(labels) if labels else None}


def feature_scores(feature_sets, weights):
    return [math.fsum(weights[f] for f in sorted(features & weights.keys(), key=repr))
            for features in feature_sets]


def fit(discovery, development, role):
    if role not in ROLES or not discovery or not development:
        raise ValueError("Fitting requires a declared role and nonempty training splits")
    if any(x.split != "discovery" for x in discovery) or any(x.split != "development" for x in development):
        raise ValueError("Test/control answers cannot enter classifier fitting")
    discovery, development = tuple(sorted(discovery, key=identity)), tuple(sorted(development, key=identity))
    if any(type(x.label) is not int or x.label not in (0, 1) for x in (*discovery, *development)):
        raise ValueError("Fitting requires original binary assignments")
    family, budgets, transform = ROLES[role]
    if transform:
        discovery = transform_presence_order(discovery, transform)
        development = transform_presence_order(development, transform)
    # Retain document counts only. Motif sets for a whole concept need not coexist.
    positive, negative = Counter(), Counter()
    for item in discovery:
        (positive if item.label else negative).update(detector.extract_features(item, family))
    pdocs = sum(x.label for x in discovery)
    ndocs = len(discovery) - pdocs
    weights = {}
    for feature in positive.keys() | negative.keys():
        if positive[feature] + negative[feature] >= 3:
            weights[feature] = math.log(((positive[feature] + 1) / (pdocs - positive[feature] + 1))
                                       / ((negative[feature] + 1) / (ndocs - negative[feature] + 1)))
    ordered = sorted(weights, key=lambda f: (-abs(weights[f]), repr(f)))
    candidates = []
    selected = {feature: weights[feature] for feature in ordered[:max(budgets)]}
    del positive, negative, weights, ordered
    dev_features = [detector.extract_features(item, family) & selected.keys() for item in development]
    y = [x.label for x in development]
    for budget in budgets:
        current = dict(list(selected.items())[:budget])
        scores = feature_scores(dev_features, current)
        threshold = _select_presence_threshold(scores, y)
        performance = metrics(y, [int(s >= threshold) for s in scores])
        candidates.append({"budget": budget, "feature_count": len(current), "threshold": threshold,
                           "weights": [[f, w] for f, w in current.items()], "development": performance})
    finite = [x for x in candidates if x["development"]["mcc"] is not None]
    if finite:
        best = max(x["development"]["mcc"] for x in finite)
        choice = min((x for x in finite if x["development"]["mcc"] >= best - 0.02),
                     key=lambda x: (x["feature_count"], -x["development"]["mcc"], x["budget"]))
    else:
        choice = min(candidates, key=lambda x: (x["feature_count"], x["budget"]))
    rule = {"revision": REVISION, "objective": OBJECTIVE, "role": role, "family": family,
            "transform": transform, **choice, "candidate_development": candidates,
            "selection": "fewest_features_within_0.02_development_MCC",
            "fit_class_counts": dict(Counter(x.label for x in discovery)),
            "fit_identities_sha256": digest([identity(x) for x in discovery]),
            "development_identities_sha256": digest([identity(x) for x in development])}
    return {**rule, "sha256": digest(rule)}


def score(rule, examples):
    if rule["sha256"] != digest({k: v for k, v in rule.items() if k != "sha256"}):
        raise ValueError("Classifier checksum mismatch")
    if rule["transform"]:
        examples = transform_presence_order(examples, rule["transform"])
    weights = {tuple(feature): weight for feature, weight in rule["weights"]}
    scores = feature_scores([detector.extract_features(x, rule["family"]) & weights.keys()
                             for x in examples], weights)
    return scores, [int(x >= rule["threshold"]) for x in scores]


def evaluate(examples):
    clusters = provenance(examples)
    parts = {split: [x for x in examples if x.split == split] for split in SPLITS}
    counts = {split: {"n": len(rows), "positive": sum(x.label for x in rows),
                      "negative": sum(1 - x.label for x in rows)} for split, rows in parts.items()}
    if not all(parts.values()):
        return {"status": "not_estimable", "reason": "empty_required_split", "counts": counts,
                "rules": {}, "test_rows": [], "metrics": {}}
    discovery, development, test = (parts[s] for s in SPLITS)
    test_clusters = [c for x, c in zip(examples, clusters, strict=True) if x.split == "test"]
    rules, performance, outputs = {}, {}, {}
    for role in ROLES:
        rule = fit(discovery, development, role)
        scores, predictions = score(rule, test)
        rules[role], outputs[role] = rule, (scores, predictions)
        performance[role] = metrics([x.label for x in test], predictions)
    constant = int(sum(x.label for x in discovery) > len(discovery) / 2)
    outputs["constant"] = ([float(constant)] * len(test), [constant] * len(test))
    performance["constant"] = metrics([x.label for x in test], outputs["constant"][1])
    rows = [{"model_seed": item.model_seed, "prompt_id": item.prompt_id, "label": item.label,
             "cluster": cluster, "content_sha256": item.content_sha256,
             "scores": {r: values[0][i] for r, values in outputs.items()},
             "predictions": {r: values[1][i] for r, values in outputs.items()}}
            for i, (item, cluster) in enumerate(zip(test, test_clusters, strict=True))]
    return {"status": "evaluated", "counts": counts, "rules": rules, "metrics": performance,
            "constant_discovery_prediction": constant, "test_rows": rows,
            "test_cluster_count": len(set(test_clusters))}


def bootstrap(reconstructions, *, seed, repetitions=1000):
    """Paired cluster bootstrap, averaged over all three fixed reconstructions."""
    import numpy as np
    if len(reconstructions) != 3 or any(r["status"] != "evaluated" for r in reconstructions):
        return {"status": "not_estimable", "reason": "three_evaluated_reconstructions_required"}
    base = reconstructions[0]["test_rows"]
    keys = [(r["model_seed"], r["prompt_id"], r["label"], r["cluster"]) for r in base]
    for result in reconstructions[1:]:
        if [(r["model_seed"], r["prompt_id"], r["label"], r["cluster"]) for r in result["test_rows"]] != keys:
            raise ValueError("Reconstruction predictions are not paired")
    groups = sorted({r["cluster"] for r in base})
    index = {key: i for i, key in enumerate(groups)}
    roles = [*ROLES, "constant"]
    counts = np.zeros((len(groups), 3, len(roles), 4), dtype=np.int64)
    for j, result in enumerate(reconstructions):
        for row in result["test_rows"]:
            for k, role in enumerate(roles):
                counts[index[row["cluster"]], j, k, 2 * row["label"] + row["predictions"][role]] += 1
    rng = np.random.default_rng(seed)
    draws = rng.multinomial(len(groups), np.full(len(groups), 1 / len(groups)), size=repetitions)
    samples = np.tensordot(draws, counts, axes=(1, 0)).astype(float)
    tn, fp, fn, tp = (samples[..., i] for i in range(4))
    with np.errstate(divide="ignore", invalid="ignore"):
        mcc = (tp * tn - fp * fn) / np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        ba = (tp / (tp + fn) + tn / (tn + fp)) / 2
    values = {"mcc": mcc.mean(axis=1), "balanced_accuracy": ba.mean(axis=1)}
    def interval(array):
        valid = array[np.isfinite(array)]
        return {"lower": float(np.quantile(valid, 0.025)) if len(valid) else None,
                "upper": float(np.quantile(valid, 0.975)) if len(valid) else None,
                "valid_repetitions": len(valid), "total_repetitions": repetitions,
                "conditional_on_defined_metric": len(valid) != repetitions}
    output = {metric: {role: interval(data[:, i]) for i, role in enumerate(roles)}
              for metric, data in values.items()}
    differences = {metric: {name: interval(data[:, roles.index(a)] - data[:, roles.index(b)])
                           for name, (a, b) in COMPARISONS.items()} for metric, data in values.items()}
    return {"status": "computed", "seed": seed, "repetitions": repetitions,
            "cluster_count": len(groups), "confidence": 0.95, "intervals": output,
            "difference_intervals": differences, "simultaneous_200_case_coverage": False,
            "interpretation": "exploratory_pointwise_paired_cluster_bootstrap"}
