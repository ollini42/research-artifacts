"""Label-free presence reconstruction and bounded-memory answer mapping."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from .automata import PTAStateMerger, LearnedAutomaton
from .config import ReconstructionConfig
from .concept_presence_data import _json_sha256, content_sha256
from .confirmatory_detector import _map_token_sequence, _transition_maps
from .data import PromptRecord, ResponseTrace
from .tokenization import TokenizationConfig, tokenize_text


def presence_reconstruction_traces(manifest: dict, responses: list[dict], *, model_run: str) -> list[ResponseTrace]:
    """Use every discovery answer, never test/development text or concept labels."""
    questions = manifest.get("questions", [])
    if manifest.get("questions_sha256") != _json_sha256(questions):
        raise ValueError("Reconstruction requires the complete frozen question manifest.")
    by_id = {row["prompt_id"]: row for row in questions if row["split"] == "discovery"}
    if not by_id or len({row["prompt_id"] for row in questions}) != len(questions):
        raise ValueError("Discovery questions are missing or duplicated.")
    selected = {}
    for row in responses:
        if row.get("model_seed") != model_run:
            raise ValueError("Reconstruction must use one declared answer origin.")
        pid = row["prompt_id"]
        if pid not in by_id:
            raise ValueError("Only discovery responses may enter the reconstruction stage.")
        if pid in selected or row.get("split") != "discovery":
            raise ValueError("Duplicate response or wrong reconstruction split.")
        question = by_id[pid]
        for field in ("source_family_id", "source_family_ids", "dependency_family_id"):
            if row.get(field) != question.get(field):
                raise ValueError("Reconstruction source-family binding changed.")
        if not isinstance(row.get("text"), str):
            raise ValueError("Missing complete answer text.")
        selected[pid] = row
    if set(selected) != set(by_id):
        raise ValueError("Every planned discovery answer is required, including empty answers.")
    traces = []
    tokenization = TokenizationConfig(mode="word", lowercase=True, max_tokens=None)
    for index, (pid, row) in enumerate(sorted(selected.items())):
        prompt = PromptRecord(
            question_id=index, prompt_id=pid, canonical_question_id=pid,
            topic_id="unlabelled", topic_key="unlabelled", topic_name="unlabelled",
            question_index=index, question_text="", keywords=frozenset(),
            variation_type="", expected_equivalence_group="",
        )
        traces.append(ResponseTrace(
            response_id=index, prompt=prompt, model_id=model_run, device="external",
            answer_text=row["text"], answer_tokens=tuple(tokenize_text(row["text"], tokenization)),
            sampling_config={}, answer_run_id=model_run,
        ))
    return traces


def reconstruct_presence(manifest: dict, responses: list[dict], *, model_run: str,
                         config: ReconstructionConfig, checkpoint_path: str | Path,
                         checkpoint_interval_seconds: float = 1800,
                         preparation_cache_path: str | Path | None = None,
                         stop_requested=None, checkpoint_import_provenance=None) -> tuple[LearnedAutomaton, dict]:
    """Use the unchanged progressive merger and its exact-resume checkpoint API."""
    if config.implementation_revision != "M-06-r4":
        raise ValueError("New presence experiments require the approved progressive merger.")
    traces = presence_reconstruction_traces(manifest, responses, model_run=model_run)
    automaton = PTAStateMerger(config).fit(
        traces, checkpoint_path=checkpoint_path, checkpoint_interval_seconds=checkpoint_interval_seconds,
        preparation_cache_path=preparation_cache_path, stop_requested=stop_requested,
        checkpoint_import_provenance=checkpoint_import_provenance,
    )
    return automaton, {
        "label_objective": "concept_presence", "model_run": model_run,
        "questions_sha256": manifest["questions_sha256"],
        "discovery_answers_sha256": _json_sha256([
            [trace.prompt.prompt_id, content_sha256(trace.answer_text)] for trace in traces
        ]),
        "reconstruction_configuration": asdict(config), "labels_used_in_merging": False,
        "development_answers_used_in_merging": False, "test_answers_used_in_merging": False,
        "actual_state_count": automaton.state_count, "pta_state_count": automaton.pta_node_count,
        "requested_state_floor": config.minimum_state_count,
        "floor_attained": automaton.state_count == config.minimum_state_count,
        "global_minimality_established": False,
    }


def map_presence_responses(responses, transitions: list[dict], *, root_state: int):
    """Yield one mapped answer at a time without storing per-token dictionaries.

The caller shards answer origins separately and persists each yielded record.
Graph provenance is retained as one exact/fallback/unknown code per token.
"""
    exact, fallback = _transition_maps(transitions)
    tokenization = TokenizationConfig(mode="word", lowercase=True, max_tokens=None)
    seen = set()
    for response in responses:
        key = response["model_seed"], response["prompt_id"]
        if key in seen:
            raise ValueError("Duplicate mapped answer identity.")
        seen.add(key)
        tokens = tuple(tokenize_text(response["text"], tokenization))
        path, kinds = _map_token_sequence(tokens, root_state, exact, fallback,
                                         mapping_revision="concept-presence-v1")
        yield {**response, "answer_tokens": tokens, "path": path, "mapping_kinds": kinds,
               "content_sha256": content_sha256(response["text"]),
               "mapping_revision": "concept-presence-v1"}
