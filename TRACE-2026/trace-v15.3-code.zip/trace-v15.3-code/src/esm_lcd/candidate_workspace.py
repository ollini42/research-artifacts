"""Private, leased scratch slots for one candidate-history scope.

Only known files in an exclusively locked slot are reclaimed. A killed process
releases its lease, so a later invocation reuses that slot instead of creating
an unbounded sequence of abandoned databases.
"""

from contextlib import contextmanager
from contextvars import ContextVar
import fcntl
import hashlib
import os
from pathlib import Path
import stat
import tempfile
import sys

_SESSION = ContextVar("candidate_storage_session", default=None)
MAX_SLOTS = 8
_SUFFIXES = ("", "-journal", "-wal", "-shm")


def _private_directory(path):
    try:
        path.mkdir(mode=0o700)
    except FileExistsError:
        pass
    info = path.lstat()
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid()
            or stat.S_IMODE(info.st_mode) != 0o700):
        raise RuntimeError("Candidate workspace is not an owned private directory.")
    return path


class CandidateWorkspace:
    def __init__(self, scope):
        self.fd = None
        self.path = None
        scratch = Path(os.environ.get("SLURM_TMPDIR") or tempfile.gettempdir()).resolve()
        base = _private_directory(scratch / ("esm-candidates-" + str(os.getuid())))
        root = _private_directory(base / hashlib.sha256(str(scope).encode()).hexdigest())
        for number in range(MAX_SLOTS):
            lock = root / ("slot-{}.lock".format(number))
            fd = os.open(lock, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
            try:
                info = os.fstat(fd)
                if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                        or info.st_nlink != 1 or stat.S_IMODE(info.st_mode) != 0o600):
                    raise RuntimeError("Candidate workspace lease has unsafe ownership.")
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    continue
                self.fd = fd
                self.path = root / ("slot-{}.sqlite".format(number))
                try:
                    self._clean()
                except BaseException:
                    self.fd = None
                    raise
                return
            finally:
                if self.fd != fd:
                    os.close(fd)
        raise RuntimeError("All bounded candidate workspace slots are owned.")

    def _clean(self):
        for suffix in _SUFFIXES:
            path = self.path.with_name(self.path.name + suffix)
            try:
                info = path.lstat()
            except FileNotFoundError:
                continue
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                    or info.st_nlink != 1):
                raise RuntimeError("Refusing to reclaim an unowned candidate workspace file.")
            path.unlink()

    def close(self):
        if self.fd is None:
            return
        try:
            self._clean()
        finally:
            os.close(self.fd)
            self.fd = None

    def __del__(self):
        # Explicit sessions handle normal exits. The lease also protects
        # standalone readers until their owning store is released.
        if self.fd is not None:
            try:
                self.close()
            except (OSError, RuntimeError):
                pass


def current_scope(fallback=None):
    session = _SESSION.get()
    return session[0] if session is not None else (fallback or "standalone")


def register_store(store):
    session = _SESSION.get()
    if session is not None:
        session[1].append(store)


@contextmanager
def candidate_storage_session(scope):
    name = str(Path(scope).resolve()) if scope is not None else "fit-without-checkpoint"
    stores = []
    token = _SESSION.set((name, stores))
    try:
        yield
    finally:
        active_error = sys.exc_info()[0] is not None
        cleanup_error = None
        try:
            for store in reversed(stores):
                try:
                    store.close()
                except Exception as exc:
                    if cleanup_error is None:
                        cleanup_error = exc
        finally:
            _SESSION.reset(token)
        if cleanup_error is not None and not active_error:
            raise cleanup_error
