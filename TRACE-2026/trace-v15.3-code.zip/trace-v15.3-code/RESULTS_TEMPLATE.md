# Results Template

Record concept ID, model group, all three reconstruction IDs,
validation MCC, test MCC, selected roles, diagnostic fields, criteria,
highest level and cumulative membership. Preserve undefined values.
Never replace the included original results with illustrative test outputs.
