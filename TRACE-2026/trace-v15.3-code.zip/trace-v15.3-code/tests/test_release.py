"""Small synthetic checks. These are not additional scientific experiments."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

import pytest

from esm_lcd import construction_evaluation as evaluation
from esm_lcd import exploratory_levels


def test_metrics_keep_undefined_mcc():
    assert evaluation.metrics([1, 1], [1, 1])["mcc"] is None


def test_metrics_perfect_binary_predictions():
    result = evaluation.metrics([1, 0, 1, 0], [1, 0, 1, 0])
    assert result["mcc"] == 1.0
    assert result["balanced_accuracy"] == 1.0


def test_metric_alignment_is_checked():
    with pytest.raises(ValueError):
        evaluation.metrics([1, 0], [1])


def test_original_labels_are_an_explicit_objective():
    assert evaluation.OBJECTIVE == "original_question_construction_assignment"
    assert set(evaluation.ROLES) == {
        "single_state", "state_set", "path", "shuffled_path", "answer_tokens", "answer_length"}


def test_thresholds_are_the_approved_descriptive_values():
    assert sorted(exploratory_levels.THRESHOLDS.values()) == [0.02, 0.03, 0.05, 0.20]


def test_selection_does_not_modify_validation():
    scores = {role: [0.3, 0.4, 0.5] for role in exploratory_levels.ROLE_ORDER}
    before = copy.deepcopy(scores)
    exploratory_levels.select_roles(scores)
    assert scores == before


def release_cli():
    path = Path(__file__).resolve().parents[1] / "scripts/main.py"
    spec = importlib.util.spec_from_file_location("release_cli", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def release_fixture(tmp_path):
    def digest(value):
        return hashlib.sha256(value).hexdigest()
    (tmp_path / "payload.txt").write_bytes(b"example")
    (tmp_path / "payload.txt.license").write_bytes(b"notice")
    (tmp_path / "license.txt").write_bytes(b"license")
    manifest = {"files": [{"path": "payload.txt", "bytes": 7,
        "sha256": digest(b"example"), "notice": "payload.txt.license",
        "notice_sha256": digest(b"notice")}], "license_texts": {"license.txt": digest(b"license")}}
    (tmp_path / "MANIFEST.json").write_text(json.dumps(manifest))
    return tmp_path


def test_manifest_verifies_complete_fixture(release_fixture):
    assert release_cli().verify(release_fixture)["verified_payload_files"] == 1


@pytest.mark.parametrize("name", ["payload.txt", "payload.txt.license", "license.txt"])
def test_manifest_rejects_modified_content_and_notices(release_fixture, name):
    (release_fixture / name).write_bytes(b"changed")
    with pytest.raises(ValueError):
        release_cli().verify(release_fixture)


def test_manifest_rejects_duplicate_paths(release_fixture):
    path = release_fixture / "MANIFEST.json"
    manifest = json.loads(path.read_text())
    manifest["files"] *= 2
    path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="Duplicate"):
        release_cli().verify(release_fixture)


def test_manifest_rejects_path_escape(release_fixture):
    path = release_fixture / "MANIFEST.json"
    manifest = json.loads(path.read_text())
    manifest["files"][0]["path"] = "../outside.txt"
    path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="Unsafe"):
        release_cli().verify(release_fixture)
