"""Synthetic regression tests for the approved diagnostic-only contract."""
import copy
import math
import unittest

from esm_lcd import exploratory_levels as el


def example():
    scores = {"single_state": 0.25, "state_set": 0.40, "path": 0.45,
              "shuffled_path": 0.30, "answer_tokens": 0.32, "answer_length": 0.10}
    source = {
        "concept_id": "F001", "model_group": "model", "reconstruction_ids": ["r0", "r1", "r2"],
        "performance": {role: {"mcc": {"per_reconstruction": [value] * 3,
                                      "mean": sum([value] * 3) / 3}} for role, value in scores.items()},
        "uncertainty": {"status": "inconclusive"}, "controls": {"passed": False},
        "agreement": 0.0, "floor_attained": [False] * 3,
    }
    validation = {r: [scores[r]] * 3 for r in el.ROLE_ORDER}
    return source, validation


class ExploratoryLevelsTests(unittest.TestCase):
    def test_nested_all_three(self):
        source, validation = example()
        result = el.evaluate_case(source, validation)
        self.assertEqual(result["highest_level"], 3)
        self.assertEqual(result["levels"], {"L1": True, "L2": True, "L3": True})

    def test_diagnostics_never_gate(self):
        source, validation = example()
        before = el.evaluate_case(source, validation)
        source.update(controls={"passed": False, "accuracy": 0}, agreement=None,
                      uncertainty={"status": "not_identifiable", "lower": -1},
                      automatic_disagreement_count=99999, floor_attained=[False] * 3)
        after = el.evaluate_case(source, validation)
        self.assertEqual(before["levels"], after["levels"])
        self.assertEqual(before["selected_roles"], after["selected_roles"])

    def test_no_validation_floor(self):
        source, validation = example()
        validation = {r: [-0.5] * 3 for r in validation}
        result = el.evaluate_case(source, validation)
        self.assertEqual(result["selected_roles"]["recognition"], "single_state")
        self.assertTrue(result["levels"]["L1"])

    def test_selection_never_uses_test(self):
        source, validation = example()
        before = el.evaluate_case(source, validation)["selected_roles"]
        for role in source["performance"]:
            source["performance"][role]["mcc"] = {"per_reconstruction": [-0.9] * 3,
                                                   "mean": sum([-0.9] * 3) / 3}
        self.assertEqual(before, el.evaluate_case(source, validation)["selected_roles"])

    def test_selection_uses_mean_not_one_best_run(self):
        source, validation = example()
        validation["state_set"] = [1.0, 0.0, 0.0]
        self.assertEqual(el.select_roles(validation)[0]["combination"], "path")

    def test_unordered_combination_has_no_order_gate(self):
        source, validation = example()
        validation["state_set"] = [0.9] * 3
        source["performance"]["shuffled_path"]["mcc"] = {"per_reconstruction": [0.9] * 3,
                                                        "mean": sum([0.9] * 3) / 3}
        result = el.evaluate_case(source, validation)
        self.assertFalse(result["criteria"]["order"]["required"])
        self.assertEqual(result["highest_level"], 3)

    def test_ordered_combination_requires_order_gain(self):
        source, validation = example()
        source["performance"]["shuffled_path"]["mcc"] = copy.deepcopy(source["performance"]["path"]["mcc"])
        result = el.evaluate_case(source, validation)
        self.assertTrue(result["levels"]["L1"])
        self.assertFalse(result["levels"]["L2"])
        self.assertFalse(result["levels"]["L3"])

    def test_all_three_runs_contribute_but_individual_failures_do_not_gate(self):
        source, validation = example()
        source["performance"]["path"]["mcc"] = {"per_reconstruction": [0.1, 0.7, 0.7],
                                                "mean": (0.1 + 0.7 + 0.7) / 3}
        self.assertTrue(el.evaluate_case(source, validation)["levels"]["L1"])

    def test_undefined_never_becomes_zero(self):
        source, validation = example()
        source["performance"]["path"]["mcc"] = {"per_reconstruction": [None, 0.7, 0.7], "mean": None}
        result = el.evaluate_case(source, validation)
        self.assertIsNone(result["highest_level"])
        self.assertIsNone(result["levels"]["L1"])

    def test_rejects_mean_mismatch(self):
        source, validation = example()
        source["performance"]["path"]["mcc"]["mean"] = 0.999
        with self.assertRaises(ValueError):
            el.evaluate_case(source, validation)

    def test_fixed_tie_order(self):
        _, validation = example()
        validation = {role: [0.4] * 3 for role in validation}
        self.assertEqual(el.select_roles(validation)[0], {
            "recognition": "single_state", "combination": "state_set", "text": "answer_tokens"})

    def test_boundary_l1_inclusive(self):
        source, validation = example()
        source["performance"]["path"]["mcc"] = {"per_reconstruction": [0.2, 0.2, 0.2],
                                                "mean": (0.2 + 0.2 + 0.2) / 3}
        self.assertTrue(el.evaluate_case(source, validation)["levels"]["L1"])

    def test_exclusive_and_cumulative_differ(self):
        source, validation = example()
        result = el.evaluate_case(source, validation)
        counts = el.summarize([result])["all"]
        self.assertEqual(counts["exclusive"]["L3"], 1)
        self.assertEqual(counts["exclusive"]["L1"], 0)
        self.assertEqual(counts["cumulative"], {"L1": 1, "L2": 1, "L3": 1})

    def test_unchanged_inputs(self):
        source, validation = example()
        before = copy.deepcopy((source, validation))
        el.evaluate_case(source, validation)
        self.assertEqual(before, (source, validation))

    def test_invalid_mcc(self):
        for values in ([0.2] * 2, [math.nan, 0, 0], [math.inf, 0, 0], [True, 0, 0], [2, 0, 0]):
            with self.subTest(values=values), self.assertRaises(ValueError):
                el.mean_three(values)

    def test_rejects_duplicate_cases(self):
        source, validation = example()
        row = el.evaluate_case(source, validation)
        with self.assertRaises(ValueError):
            el.summarize([row, row])

    def test_false_dominates_undefined(self):
        self.assertFalse(el.conjunction(False, None))
        self.assertIsNone(el.conjunction(True, None))


if __name__ == "__main__":
    unittest.main()
