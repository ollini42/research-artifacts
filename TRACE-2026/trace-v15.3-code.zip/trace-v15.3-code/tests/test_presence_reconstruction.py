from copy import deepcopy

import pytest

from esm_lcd.config import ReconstructionConfig
from esm_lcd.concept_presence_data import _json_sha256
from esm_lcd.presence_reconstruction import (
    presence_reconstruction_traces, reconstruct_presence, map_presence_responses,
)
from esm_lcd.confirmatory_detector import map_traces_inductively


def fixture():
    questions = [{"prompt_id": str(i), "source_family_id": "family" + str(i),
                  "source_family_ids": ["family" + str(i)], "split": "discovery"} for i in range(6)]
    manifest = {"questions": questions, "questions_sha256": _json_sha256(questions)}
    responses = [{**row, "model_seed": "fixture", "text": "alpha cheese end" if i % 2 else "beta rice end",
                  "presence_label": i % 2, "concept_id": "fixture"} for i, row in enumerate(questions)]
    return manifest, responses


def test_reconstruction_cannot_see_presence_or_question_labels(tmp_path):
    manifest, responses = fixture()
    other = deepcopy(responses)
    for row in other:
        row.update(presence_label=1 - row["presence_label"], concept_id="another", construction_label=42)
    first = presence_reconstruction_traces(manifest, responses, model_run="fixture")
    assert first == presence_reconstruction_traces(manifest, other, model_run="fixture")
    assert all(trace.prompt.expected_label is None and trace.prompt.concept_id is None for trace in first)
    automaton, audit = reconstruct_presence(manifest, responses, model_run="fixture",
                                           config=ReconstructionConfig(minimum_state_count=2),
                                           checkpoint_path=tmp_path / "checkpoint.pkl")
    assert audit["actual_state_count"] == automaton.state_count
    assert not audit["labels_used_in_merging"]
    assert not audit["global_minimality_established"]


def test_reconstruction_excludes_test_and_requires_complete_discovery():
    manifest, responses = fixture()
    with pytest.raises(ValueError, match="Every planned"):
        presence_reconstruction_traces(manifest, responses[:-1], model_run="fixture")
    responses[0]["split"] = "test"
    with pytest.raises(ValueError, match="wrong reconstruction split"):
        presence_reconstruction_traces(manifest, responses, model_run="fixture")


def test_streaming_mapping_matches_full_mapping_without_per_token_dicts(tmp_path):
    manifest, responses = fixture()
    automaton, _ = reconstruct_presence(manifest, responses, model_run="fixture",
                                        config=ReconstructionConfig(minimum_state_count=2),
                                        checkpoint_path=tmp_path / "checkpoint.pkl")
    changed = deepcopy(responses)
    changed[0]["text"] = "unseen alpha cheese"
    root = automaton.node_to_state[0]
    full_paths, audit = map_traces_inductively(
        presence_reconstruction_traces(manifest, changed, model_run="fixture"),
        automaton.transitions, root, mapping_revision="concept-presence-v1")
    streamed = list(map_presence_responses(changed, automaton.transitions, root_state=root))
    assert {row["prompt_id"]: row["path"] for row in streamed} == full_paths
    assert {row["prompt_id"]: row["mapping_kinds"] for row in streamed} == audit["_path_mapping_kinds"]
    assert "unknown" in streamed[0]["mapping_kinds"]
